# ENCODING-0 Conclusion

**Status:** COMPLETE WITHIN FROZEN CORPUS  
**Terminal experiment verdict:** `ENCODING_TRADEOFF_FRONTIER`  
**Narrow byte-cost result:** `C1-ID / VARINT_SHARED` leads every measured byte view.

## Frozen corpus scale

```text
wire packets:    27
storage packets: 24
ACT symbols:     6
RELATION symbols:9
SYMBOL entries:  31
global dictionary bootstrap: 356 bytes
```

This is deliberately a small encoding experiment. Results are not extrapolated to large streams.

## Byte result

`C1-ID / VARINT_SHARED`:

```text
warm transport  = 188 bytes
cold transport  = 544 bytes
warm storage    = 168 bytes
cold storage    = 524 bytes
```

It is the minimum in all four frozen byte views.

Against the semantically equivalent `C1-HANDLE / VARINT_SHARED`:

```text
warm transport: 188 vs 198
warm storage:   168 vs 174
```

The handle protocol therefore costs about 5.1% more warm transport and 3.4% more warm storage on this corpus.

Against `C1-ID / FIXED_SHARED`, shared varints reduce warm transport by about 30.4%.

Batching does not win here:

```text
VARINT_SHARED warm transport:       188
BATCH_COLUMNAR_SHARED warm transport:210
```

The frozen tasks are too small for the batch structure to amortize itself.

Task-local dictionaries are also expensive on this tiny corpus:

```text
LOCAL_DICT_VARINT transport: 683
```

because dictionary material is repeatedly carried with each task.

## Scientific interpretation

The result supports a narrower engineering statement:

> Within the frozen ENCODING-0 corpus, carrying stable identity in-band and encoding the six-field symbolic primitive with shared dictionary indexes plus varints is cheaper than moving stable identity into an external handle protocol.

This does **not** establish that in-band identity is universally better.

Possible reversals remain testable under different traffic regimes:

- very large packet streams;
- long-lived shared sessions;
- highly dynamic symbol creation;
- very large symbol dictionaries;
- packet loss / resynchronization;
- random-access requirements;
- cross-process dictionary versioning;
- large batches with repeated columns.

## Protocol constraints recorded

- `FIXED_SHARED`, `VARINT_SHARED`, and `BATCH_COLUMNAR_SHARED` assume a shared benchmark/schema dictionary. Its 356-byte bootstrap is charged in cold metrics.
- `LOCAL_DICT_VARINT` requires enough buffering to construct a task-local dictionary before emitting its self-contained record.
- `BATCH_COLUMNAR_SHARED` requires task-level buffering before batch emission.
- `C1-HANDLE` requires identity synchronization. That cost is charged either as a side table or embedded batched identity table depending on codec.
- Shared dictionaries in ENCODING-0 are derived from the frozen corpus/schema universe. Online dictionary growth is not tested here.

## Current smallest tested sufficient stack

Semantics:

```text
STABLE_REFERENCE
ACT
SUBJECT
RELATION
OBJECT
VALUE
```

Current encoding leader within scope:

```text
shared semantic dictionaries
+
unsigned varints for symbolic indexes
+
ZigZag varint for VALUE
+
stable ID carried in-band
```

This is an experimental winner within a tiny frozen corpus, not a universal machine-language claim.

## Next independently judgeable unit

The next useful test is not another field.

It is a scale/crossover experiment:

```text
ENCODING-1 — TRAFFIC REGIME CROSSOVER
```

Hold semantics fixed and vary only:

```text
packet count
symbol cardinality
new-symbol rate
batch size
session lifetime
dictionary reset frequency
```

The question becomes:

> At what traffic regimes do fixed width, varints, batching, or external handles overtake the current ENCODING-0 leader?
