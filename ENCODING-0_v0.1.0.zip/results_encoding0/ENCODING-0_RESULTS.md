# ENCODING-0 Results

**Fixture manifest:** `844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e`  
**Semantic corpus:** `14e02eb1ba75dbe96f02d6a0a2ad57776179fe444f85433752f8c9189d7fcbd1`  
**Global dictionary bootstrap:** 356 bytes  
**Terminal verdict:** `ENCODING_TRADEOFF_FRONTIER`

## Packed results

| Semantic placement | Profile | Warm transport | Cold transport | Warm storage | Cold storage | Wire identity side bytes | Roundtrip |
|---|---|---:|---:|---:|---:|---:|---|
| C1-ID | FIXED_SHARED | 270 | 626 | 240 | 596 | 0 | PASS |
| C1-ID | VARINT_SHARED | 188 | 544 | 168 | 524 | 0 | PASS |
| C1-ID | LOCAL_DICT_VARINT | 683 | 683 | 559 | 559 | 0 | PASS |
| C1-ID | BATCH_COLUMNAR_SHARED | 210 | 566 | 181 | 537 | 0 | PASS |
| C1-HANDLE | FIXED_SHARED | 290 | 646 | 252 | 608 | 20 | PASS |
| C1-HANDLE | VARINT_SHARED | 198 | 554 | 174 | 530 | 10 | PASS |
| C1-HANDLE | LOCAL_DICT_VARINT | 701 | 701 | 573 | 573 | 0 | PASS |
| C1-HANDLE | BATCH_COLUMNAR_SHARED | 234 | 590 | 200 | 556 | 0 | PASS |

## Metric minima

- **warm_transport_bytes:** 188 bytes — C1-ID/VARINT_SHARED
- **cold_transport_bytes:** 544 bytes — C1-ID/VARINT_SHARED
- **warm_storage_bytes:** 168 bytes — C1-ID/VARINT_SHARED
- **cold_storage_bytes:** 524 bytes — C1-ID/VARINT_SHARED

## Constraints

- No composite score is used.
- Shared profiles pay global dictionary bootstrap in the cold view.
- LOCAL_DICT_VARINT carries task dictionaries inline; warm and cold are identical.
- C1-HANDLE identity synchronization is charged explicitly.
- This experiment compares encoding only; no new cognitive primitive was added.
