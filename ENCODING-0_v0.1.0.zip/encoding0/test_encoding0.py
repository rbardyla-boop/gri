#!/usr/bin/env python3
import json,hashlib,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
c=json.loads((HERE/"ENCODING-0_CORPUS.json").read_text())
got=hashlib.sha256(json.dumps(c["tasks"],sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()
assert got==c["semantic_corpus_sha256"]
subprocess.run([sys.executable,str(HERE/"run_encoding0.py")],check=True,stdout=subprocess.DEVNULL)
r=json.loads((ROOT/"results_encoding0"/"ENCODING-0_RESULTS.json").read_text())
assert r["terminal_verdict"]=="ENCODING_TRADEOFF_FRONTIER"
for s in ("C1-ID","C1-HANDLE"):
    for p in ("FIXED_SHARED","VARINT_SHARED","LOCAL_DICT_VARINT","BATCH_COLUMNAR_SHARED"):
        x=r["results"][s][p]
        assert x["execution_verdict"]=="RUN_VALID",(s,p,x)
        assert x["byte_determinism"]=="PASS",(s,p)
        assert x["exact_roundtrip"]=="PASS",(s,p)
print("ENCODING_0_TEST_PASS")
