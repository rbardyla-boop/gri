# ENCODING-0 DECLARATIONS

**Experiment:** ENCODING-0 v0.1.0  
**Status:** FROZEN BEFORE SCORING  
**PRIMITIVE-0 fixture manifest SHA-256:** `844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e`  
**Semantic corpus SHA-256:** `14e02eb1ba75dbe96f02d6a0a2ad57776179fe444f85433752f8c9189d7fcbd1`

## Research question

Given the two semantically sufficient C1 solutions, what actual packed representation minimizes transport/storage cost without changing semantics?

```text
C1-ID
(ID, ACT, SUBJECT, RELATION, OBJECT, VALUE)
```

versus:

```text
C1-HANDLE
external stable HANDLE + (ACT, SUBJECT, RELATION, OBJECT, VALUE)
with HANDLE → source-ID synchronization when source identity exists
```

No new cognitive field is authorized.

## Hard rules

1. ENCODING-0 consumes the frozen semantic corpus; it does not rerun PRIMITIVE-0 semantics.
2. Every codec must round-trip to the exact frozen semantic packet stream.
3. Same corpus + same codec configuration must emit byte-identical output.
4. Dictionary/bootstrap cost is never free.
5. C1-HANDLE identity synchronization is never free.
6. No compression library is used.
7. No composite score is authorized.
8. Bit widths are encoding decisions, not ontology decisions.
9. A codec that cannot represent frozen cardinalities is invalid rather than widened after scoring.
10. One shared SYMBOL domain covers packet ID, SUBJECT and OBJECT to preserve cross-role referentiality.

## P1 — FIXED_SHARED

Global dictionaries plus fixed-width fields.

```text
ACT       u8
RELATION  u8
SYMBOL    u16
VALUE     i16
HANDLE    u16
```

C1-ID packet:

```text
ID:u16 | ACT:u8 | SUBJECT:u16 | RELATION:u8 | OBJECT:u16 | VALUE:i16
```

C1-HANDLE packet:

```text
HANDLE:u16 | ACT:u8 | SUBJECT:u16 | RELATION:u8 | OBJECT:u16 | VALUE:i16
```

Identity synchronization entry when source ID exists:

```text
HANDLE:u16 | SOURCE_ID:u16
```

## P2 — VARINT_SHARED

Same global dictionaries. Nonnegative integers use unsigned varints. VALUE uses ZigZag signed varint.

## P3 — LOCAL_DICT_VARINT

Each task is self-contained: ACT, RELATION and SYMBOL dictionaries are serialized inside the task record, followed by varint packet data. No global dictionary is assumed.

## P4 — BATCH_COLUMNAR_SHARED

Global dictionaries plus task-level columnar batches:

```text
packet_count
ID-presence bitset OR delta-coded HANDLE column
RLE ACT column
SUBJECT varints
RLE RELATION column
OBJECT varints
VALUE ZigZag varints
```

C1-HANDLE appends a batched identity table using delta-coded handles.

## Cost views

Shared profiles report:

```text
WARM = packet/protocol bytes only
COLD = global dictionary bootstrap + packet/protocol bytes
```

LOCAL_DICT_VARINT carries dictionaries in each task record, so warm and cold are identical.

Transport and storage remain separate metric groups.

## Required validity gates

```text
EXACT_WIRE_ROUNDTRIP
EXACT_STORAGE_ROUNDTRIP
BYTE_DETERMINISM
CARDINALITY_BOUNDS
NO_HIDDEN_DICTIONARY
NO_FREE_HANDLE_TABLE
```
