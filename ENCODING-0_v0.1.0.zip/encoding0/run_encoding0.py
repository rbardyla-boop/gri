#!/usr/bin/env python3
from __future__ import annotations
import json, hashlib, struct, time
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
CORPUS=HERE/"ENCODING-0_CORPUS.json"
DECL=HERE/"ENCODING-0_DECLARATIONS.md"
RESULTS=ROOT/"results_encoding0"
EXPECTED_FIXTURE="844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e"
EXPECTED_CORPUS="14e02eb1ba75dbe96f02d6a0a2ad57776179fe444f85433752f8c9189d7fcbd1"

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def hobj(v):
    return hashlib.sha256(canon(v).encode()).hexdigest()

def uv(n):
    if n<0: raise ValueError("negative uvarint")
    o=bytearray()
    while True:
        b=n&0x7f; n>>=7
        if n: o.append(b|0x80)
        else: o.append(b); return bytes(o)
def ruv(d,p):
    s=0; v=0
    while True:
        if p>=len(d): raise ValueError("truncated varint")
        b=d[p]; p+=1; v|=(b&0x7f)<<s
        if not b&0x80: return v,p
        s+=7
        if s>63: raise ValueError("varint too long")
def zz(n): return (n<<1) if n>=0 else ((-n<<1)-1)
def uzz(n): return n>>1 if n%2==0 else -((n>>1)+1)

def ptable(xs):
    o=bytearray(uv(len(xs)))
    for s in xs:
        b=s.encode(); o+=uv(len(b))+b
    return bytes(o)
def rtable(d,p):
    n,p=ruv(d,p); xs=[]
    for _ in range(n):
        m,p=ruv(d,p)
        if p+m>len(d): raise ValueError("truncated string")
        xs.append(d[p:p+m].decode()); p+=m
    return xs,p

class T:
    def __init__(self,a,r,s):
        self.acts=list(a); self.rels=list(r); self.syms=list(s)
        self.a={x:i+1 for i,x in enumerate(self.acts)}
        self.r={x:i+1 for i,x in enumerate(self.rels)}
        self.s={x:i+1 for i,x in enumerate(self.syms)}
    def ia(self,c): return self.acts[c-1]
    def ir(self,c): return self.rels[c-1]
    def is_(self,c): return self.syms[c-1]
    def blob(self):
        return b"A"+ptable(self.acts)+b"R"+ptable(self.rels)+b"S"+ptable(self.syms)

def parse_tables(d):
    p=0
    if d[p:p+1]!=b"A": raise ValueError("A tag")
    p+=1; a,p=rtable(d,p)
    if d[p:p+1]!=b"R": raise ValueError("R tag")
    p+=1; r,p=rtable(d,p)
    if d[p:p+1]!=b"S": raise ValueError("S tag")
    p+=1; s,p=rtable(d,p)
    if p!=len(d): raise ValueError("dict trailing")
    return T(a,r,s)

def domains(tasks):
    a=set(); r=set(); s=set()
    for t in tasks:
        for sec in ("wire_packets","storage_packets"):
            for p in t[sec]:
                a.add(str(p["act"])); r.add(str(p["relation"]))
                for f in ("id","subject","object"):
                    if p.get(f) is not None: s.add(str(p[f]))
    return T(sorted(a),sorted(r),sorted(s))

def local(packets):
    a=sorted({str(p["act"]) for p in packets})
    r=sorted({str(p["relation"]) for p in packets})
    s=sorted({str(p[f]) for p in packets for f in ("id","subject","object") if p.get(f) is not None})
    return T(a,r,s)

def bounds(t,tasks):
    if len(t.acts)>255: raise ValueError("ACT>u8")
    if len(t.rels)>255: raise ValueError("REL>u8")
    if len(t.syms)>65534: raise ValueError("SYM>u16")
    for task in tasks:
        if max(len(task["wire_packets"]),len(task["storage_packets"]))>65535: raise ValueError("HANDLE>u16")
        for sec in ("wire_packets","storage_packets"):
            for p in task[sec]:
                if not -32768<=int(p.get("value",0))<=32767: raise ValueError("VALUE>i16")

def handleize(ps):
    rows=[]; maps=[]
    for i,p in enumerate(ps,1):
        q={k:v for k,v in p.items() if k!="id"}
        rows.append((i,q))
        if p.get("id") is not None: maps.append((i,str(p["id"])))
    return rows,maps
def restore(rows,maps):
    m=dict(maps); out=[]
    for h,p in rows:
        q=dict(p)
        if h in m: q["id"]=m[h]
        out.append(q)
    return out

def rle(xs):
    if not xs: return uv(0)
    rr=[]; last=xs[0]; n=1
    for x in xs[1:]:
        if x==last: n+=1
        else: rr.append((last,n)); last=x; n=1
    rr.append((last,n))
    o=bytearray(uv(len(rr)))
    for x,n in rr: o+=uv(x)+uv(n)
    return bytes(o)
def unrle(d,p,nexp):
    n,p=ruv(d,p); out=[]
    for _ in range(n):
        x,p=ruv(d,p); k,p=ruv(d,p); out += [x]*k
    if len(out)!=nexp: raise ValueError("rle mismatch")
    return out,p
def bits(bs):
    o=bytearray((len(bs)+7)//8)
    for i,b in enumerate(bs):
        if b:o[i//8]|=1<<(i%8)
    return bytes(o)
def unbits(d,p,n):
    m=(n+7)//8
    if p+m>len(d): raise ValueError("bitset truncated")
    b=d[p:p+m]; p+=m
    return [bool(b[i//8]&(1<<(i%8))) for i in range(n)],p

# P1
def f_id_enc(ps,t):
    o=bytearray()
    for p in ps:
        iid=0 if p.get("id") is None else t.s[str(p["id"])]
        o+=struct.pack(">HBHBHh",iid,t.a[str(p["act"])],t.s[str(p["subject"])],t.r[str(p["relation"])],t.s[str(p["object"])],int(p["value"]))
    return bytes(o),b""
def f_id_dec(d,side,t):
    if len(d)%10: raise ValueError("fixed size")
    out=[]
    for p in range(0,len(d),10):
        iid,a,s,r,o,v=struct.unpack(">HBHBHh",d[p:p+10])
        q={"act":t.ia(a),"subject":t.is_(s),"relation":t.ir(r),"object":t.is_(o),"value":v}
        if iid:q["id"]=t.is_(iid)
        out.append(q)
    return out
def f_h_enc(ps,t):
    rows,m=handleize(ps); o=bytearray(); side=bytearray()
    for h,p in rows:
        o+=struct.pack(">HBHBHh",h,t.a[str(p["act"])],t.s[str(p["subject"])],t.r[str(p["relation"])],t.s[str(p["object"])],int(p["value"]))
    for h,sid in m: side+=struct.pack(">HH",h,t.s[sid])
    return bytes(o),bytes(side)
def f_h_dec(d,side,t):
    if len(d)%10 or len(side)%4: raise ValueError("fixed handle size")
    rows=[]; m=[]
    for p in range(0,len(d),10):
        h,a,s,r,o,v=struct.unpack(">HBHBHh",d[p:p+10])
        rows.append((h,{"act":t.ia(a),"subject":t.is_(s),"relation":t.ir(r),"object":t.is_(o),"value":v}))
    for p in range(0,len(side),4):
        h,s=struct.unpack(">HH",side[p:p+4]); m.append((h,t.is_(s)))
    return restore(rows,m)

# P2
def v_id_enc(ps,t):
    o=bytearray()
    for p in ps:
        o+=uv(0 if p.get("id") is None else t.s[str(p["id"])])
        o+=uv(t.a[str(p["act"])])+uv(t.s[str(p["subject"])])+uv(t.r[str(p["relation"])])+uv(t.s[str(p["object"])])+uv(zz(int(p["value"])))
    return bytes(o),b""
def v_id_dec(d,side,t):
    out=[]; p=0
    while p<len(d):
        iid,p=ruv(d,p); a,p=ruv(d,p); s,p=ruv(d,p); r,p=ruv(d,p); o,p=ruv(d,p); z,p=ruv(d,p)
        q={"act":t.ia(a),"subject":t.is_(s),"relation":t.ir(r),"object":t.is_(o),"value":uzz(z)}
        if iid:q["id"]=t.is_(iid)
        out.append(q)
    return out
def v_h_enc(ps,t):
    rows,m=handleize(ps); o=bytearray(); side=bytearray()
    for h,p in rows:
        o+=uv(h)+uv(t.a[str(p["act"])])+uv(t.s[str(p["subject"])])+uv(t.r[str(p["relation"])])+uv(t.s[str(p["object"])])+uv(zz(int(p["value"])))
    for h,sid in m: side+=uv(h)+uv(t.s[sid])
    return bytes(o),bytes(side)
def v_h_dec(d,side,t):
    rows=[]; p=0
    while p<len(d):
        h,p=ruv(d,p); a,p=ruv(d,p); s,p=ruv(d,p); r,p=ruv(d,p); o,p=ruv(d,p); z,p=ruv(d,p)
        rows.append((h,{"act":t.ia(a),"subject":t.is_(s),"relation":t.ir(r),"object":t.is_(o),"value":uzz(z)}))
    m=[]; p=0
    while p<len(side):
        h,p=ruv(side,p); sid,p=ruv(side,p); m.append((h,t.is_(sid)))
    return restore(rows,m)

# P3 local dict
def l_id_enc(ps,_):
    t=local(ps); db=t.blob(); body,_=v_id_enc(ps,t)
    return uv(len(db))+db+body,b""
def l_id_dec(d,side,_):
    n,p=ruv(d,0); t=parse_tables(d[p:p+n]); p+=n
    return v_id_dec(d[p:],b"",t)
def l_h_enc(ps,_):
    t=local(ps); db=t.blob(); body,side=v_h_enc(ps,t)
    return uv(len(db))+db+uv(len(side))+side+body,b""
def l_h_dec(d,side,_):
    n,p=ruv(d,0); t=parse_tables(d[p:p+n]); p+=n
    sn,p=ruv(d,p); st=d[p:p+sn]; p+=sn
    return v_h_dec(d[p:],st,t)

# P4 batch
def b_id_enc(ps,t):
    n=len(ps); o=bytearray(uv(n)); pres=[p.get("id") is not None for p in ps]; bb=bits(pres)
    o+=uv(len(bb))+bb
    for p in ps:
        if p.get("id") is not None:o+=uv(t.s[str(p["id"])])
    o+=rle([t.a[str(p["act"])] for p in ps])
    for p in ps:o+=uv(t.s[str(p["subject"])])
    o+=rle([t.r[str(p["relation"])] for p in ps])
    for p in ps:o+=uv(t.s[str(p["object"])])
    for p in ps:o+=uv(zz(int(p["value"])))
    return bytes(o),b""
def b_id_dec(d,side,t):
    n,p=ruv(d,0); bl,p=ruv(d,p); pres,np=unbits(d,p,n)
    if bl!=(n+7)//8: raise ValueError("bitset length")
    p=np; ids=[]
    for b in pres:
        if b:c,p=ruv(d,p); ids.append(t.is_(c))
        else:ids.append(None)
    acts,p=unrle(d,p,n); subs=[]
    for _ in range(n):c,p=ruv(d,p); subs.append(t.is_(c))
    rels,p=unrle(d,p,n); objs=[]
    for _ in range(n):c,p=ruv(d,p); objs.append(t.is_(c))
    vals=[]
    for _ in range(n):z,p=ruv(d,p); vals.append(uzz(z))
    if p!=len(d):raise ValueError("batch trailing")
    out=[]
    for i in range(n):
        q={"act":t.ia(acts[i]),"subject":subs[i],"relation":t.ir(rels[i]),"object":objs[i],"value":vals[i]}
        if ids[i] is not None:q["id"]=ids[i]
        out.append(q)
    return out
def b_h_enc(ps,t):
    rows,m=handleize(ps); n=len(rows); o=bytearray(uv(n)); prev=0
    for h,_ in rows:o+=uv(h-prev); prev=h
    o+=rle([t.a[str(p["act"])] for _,p in rows])
    for _,p in rows:o+=uv(t.s[str(p["subject"])])
    o+=rle([t.r[str(p["relation"])] for _,p in rows])
    for _,p in rows:o+=uv(t.s[str(p["object"])])
    for _,p in rows:o+=uv(zz(int(p["value"])))
    o+=uv(len(m)); prev=0
    for h,sid in m:o+=uv(h-prev)+uv(t.s[sid]); prev=h
    return bytes(o),b""
def b_h_dec(d,side,t):
    n,p=ruv(d,0); hs=[]; h=0
    for _ in range(n):x,p=ruv(d,p); h+=x; hs.append(h)
    acts,p=unrle(d,p,n); subs=[]
    for _ in range(n):c,p=ruv(d,p); subs.append(t.is_(c))
    rels,p=unrle(d,p,n); objs=[]
    for _ in range(n):c,p=ruv(d,p); objs.append(t.is_(c))
    vals=[]
    for _ in range(n):z,p=ruv(d,p); vals.append(uzz(z))
    mc,p=ruv(d,p); m=[]; h=0
    for _ in range(mc):x,p=ruv(d,p); h+=x; sid,p=ruv(d,p); m.append((h,t.is_(sid)))
    if p!=len(d):raise ValueError("batch handle trailing")
    rows=[(hs[i],{"act":t.ia(acts[i]),"subject":subs[i],"relation":t.ir(rels[i]),"object":objs[i],"value":vals[i]}) for i in range(n)]
    return restore(rows,m)

PROFILES={
"FIXED_SHARED":((f_id_enc,f_id_dec),(f_h_enc,f_h_dec)),
"VARINT_SHARED":((v_id_enc,v_id_dec),(v_h_enc,v_h_dec)),
"LOCAL_DICT_VARINT":((l_id_enc,l_id_dec),(l_h_enc,l_h_dec)),
"BATCH_COLUMNAR_SHARED":((b_id_enc,b_id_dec),(b_h_enc,b_h_dec)),
}

def main():
    c=json.loads(CORPUS.read_text())
    if c["primitive0_fixture_manifest_sha256"]!=EXPECTED_FIXTURE:raise RuntimeError("fixture binding")
    got=hobj(c["tasks"])
    if got!=EXPECTED_CORPUS or got!=c["semantic_corpus_sha256"]:raise RuntimeError("corpus changed")
    t=domains(c["tasks"]); bounds(t,c["tasks"]); setup=len(t.blob())
    out={"experiment":"ENCODING-0","version":"0.1.0","fixture_manifest_sha256":EXPECTED_FIXTURE,
         "semantic_corpus_sha256":EXPECTED_CORPUS,"declarations_sha256":hashlib.sha256(DECL.read_bytes()).hexdigest(),
         "global_dictionary_bytes":setup,
         "domain_cardinality":{"ACT":len(t.acts),"RELATION":len(t.rels),"SYMBOL":len(t.syms)},
         "results":{}}
    for si,sol in enumerate(("C1-ID","C1-HANDLE")):
        out["results"][sol]={}
        for prof,pairs in PROFILES.items():
            enc,dec=pairs[si]
            tw=ts=sw=ss=0; nw=ns=0; errs=[]; valid=True
            start=time.perf_counter_ns()
            for task in c["tasks"]:
                for sec in ("wire_packets","storage_packets"):
                    ps=task[sec]
                    a,b=enc(ps,t); a2,b2=enc(ps,t)
                    if a!=a2 or b!=b2:
                        valid=False; errs.append(f"{task['task_id']} {sec} nondeterministic bytes")
                    try:d=dec(a,b,t)
                    except Exception as e:
                        valid=False; errs.append(f"{task['task_id']} {sec} decode {type(e).__name__}:{e}"); d=None
                    if d!=ps:
                        valid=False; errs.append(f"{task['task_id']} {sec} roundtrip mismatch")
                    if sec=="wire_packets":tw+=len(a); ts+=len(b); nw+=len(ps)
                    else:sw+=len(a); ss+=len(b); ns+=len(ps)
            elapsed=time.perf_counter_ns()-start
            boot=0 if prof=="LOCAL_DICT_VARINT" else setup
            out["results"][sol][prof]={
                "execution_verdict":"RUN_VALID" if valid else "EXPERIMENT_INVALID",
                "errors":errs,
                "dictionary_setup_bytes":boot,
                "wire_payload_bytes":tw,
                "identity_side_channel_bytes":ts,
                "warm_transport_bytes":tw+ts,
                "cold_transport_bytes":tw+ts+boot,
                "storage_payload_bytes":sw,
                "storage_identity_side_bytes":ss,
                "warm_storage_bytes":sw+ss,
                "cold_storage_bytes":sw+ss+boot,
                "wire_packet_count":nw,
                "storage_packet_count":ns,
                "byte_determinism":"PASS" if valid else "FAIL",
                "exact_roundtrip":"PASS" if valid else "FAIL",
                "reference_encode_decode_ns":elapsed
            }
    invalid=[(s,p) for s in out["results"] for p,r in out["results"][s].items() if r["execution_verdict"]!="RUN_VALID"]
    out["terminal_verdict"]="EXPERIMENT_INVALID" if invalid else "ENCODING_TRADEOFF_FRONTIER"
    if not invalid:
        mins={}
        for metric in ("warm_transport_bytes","cold_transport_bytes","warm_storage_bytes","cold_storage_bytes"):
            vals={(s,p):r[metric] for s,ps in out["results"].items() for p,r in ps.items()}
            m=min(vals.values())
            mins[metric]={"bytes":m,"winners":[f"{s}/{p}" for (s,p),v in vals.items() if v==m]}
        out["metric_minima"]=mins
    RESULTS.mkdir(exist_ok=True)
    (RESULTS/"ENCODING-0_RESULTS.json").write_text(json.dumps(out,indent=2))
    lines=["# ENCODING-0 Results","",
           f"**Fixture manifest:** `{EXPECTED_FIXTURE}`  ",
           f"**Semantic corpus:** `{EXPECTED_CORPUS}`  ",
           f"**Global dictionary bootstrap:** {setup} bytes  ",
           f"**Terminal verdict:** `{out['terminal_verdict']}`","",
           "## Packed results","",
           "| Semantic placement | Profile | Warm transport | Cold transport | Warm storage | Cold storage | Wire identity side bytes | Roundtrip |",
           "|---|---|---:|---:|---:|---:|---:|---|"]
    for s in ("C1-ID","C1-HANDLE"):
        for p in PROFILES:
            r=out["results"][s][p]
            lines.append(f"| {s} | {p} | {r['warm_transport_bytes']} | {r['cold_transport_bytes']} | {r['warm_storage_bytes']} | {r['cold_storage_bytes']} | {r['identity_side_channel_bytes']} | {r['exact_roundtrip']} |")
    lines+=["","## Metric minima",""]
    for k,v in out.get("metric_minima",{}).items():
        lines.append(f"- **{k}:** {v['bytes']} bytes — {', '.join(v['winners'])}")
    lines+=["","## Constraints","",
            "- No composite score is used.",
            "- Shared profiles pay global dictionary bootstrap in the cold view.",
            "- LOCAL_DICT_VARINT carries task dictionaries inline; warm and cold are identical.",
            "- C1-HANDLE identity synchronization is charged explicitly.",
            "- This experiment compares encoding only; no new cognitive primitive was added."]
    (RESULTS/"ENCODING-0_RESULTS.md").write_text("\n".join(lines)+"\n")
    print(json.dumps({"terminal_verdict":out["terminal_verdict"],"global_dictionary_bytes":setup,"metric_minima":out.get("metric_minima")},indent=2))
if __name__=="__main__":main()
