# PRIMITIVE-2E Results

**Terminal verdict:** `VERIFICATION_SIGNAL_INSUFFICIENT`  
**Known baseline equivalence:** `PASS`  
**Deterministic replay:** `PASS`  
**Scored cases:** 105 = 9 known failures + 96 fresh confirmation model/graph cases  
**Fresh confirmation cases with baseline corruption:** 4/96

| Verifier | Known exact | Confirmation exact | Bad facts left | Valid facts challenged | Aggregate challenge precision | Aggregate primary-bad recall | Min final recall |
|---|---:|---:|---:|---:|---:|---:|---:|
| CONFIDENCE_0_99 | 0/9 | 85/96 | 292 | 41 | 0.609524 | 0.000000 | 0.800000 |
| RENAMING_K8 | 0/9 | 92/96 | 347 | 0 | 1.000000 | 0.000000 | 1.000000 |
| RENAMING_K32 | 0/9 | 92/96 | 344 | 0 | 1.000000 | 0.000000 | 1.000000 |
| RENAMING_K8_PLUS_CONFIDENCE | 0/9 | 85/96 | 292 | 41 | 0.609524 | 0.000000 | 0.800000 |
