# PRIMITIVE-2E Conclusion

**Terminal verdict:** `VERIFICATION_SIGNAL_INSUFFICIENT`

## Question

Can the machine generate reliable challenge signals against its own derived packets without a complete symbolic truth engine, while keeping PRIMITIVE-2D rollback unchanged?

Within the frozen candidates, the answer is **no**.

## Baseline validity

```text
known PRIMITIVE-2B failures reproduced: 9/9
scored cases:                           105
deterministic case-payload replay:      PASS
```

The confirmation surface contained **4 new corrupted model/graph cases** in addition to the nine known failures.

## Confidence is not a truth signal

`CONFIDENCE_0_99` challenged 105 facts.

```text
valid facts falsely challenged: 41
aggregate challenge precision:  0.609524
primary-bad recall:             0.000000
bad facts remaining:           292
minimum final valid recall:     0.800000
```

It sometimes catches bad roots, but it also challenges valid closure facts, especially cyclic/self-closure facts.

## Reference-renaming is specific but insensitive

`RENAMING_K8`:

```text
valid facts falsely challenged: 0
aggregate challenge precision:  1.000000
primary-bad recall:             0.000000
bad facts remaining:           347
```

`RENAMING_K32`:

```text
valid facts falsely challenged: 0
aggregate challenge precision:  1.000000
primary-bad recall:             0.000000
bad facts remaining:           344
```

The invariance test almost never accuses a valid fact. That is useful.

But many false derivations are themselves stable under arbitrary reference renaming. They are wrong in a way that is internally consistent.

Therefore:

> Invariance under irrelevant representation changes is evidence of representation stability, not evidence of truth.

## Frozen rollback still works as designed

The failure is not in the PRIMITIVE-2D justification DAG.

The autonomous verifier simply fails to challenge enough primary bad roots. When a bad root is not challenged, rollback has no reason to revoke it.

This preserves the separation established in PRIMITIVE-2D:

```text
VERIFICATION SIGNAL
        ↓
JUSTIFICATION-DAG ROLLBACK
```

PRIMITIVE-2E changed only the first layer.

## Architectural consequence

The program has now ruled out several cheap substitutes for verification:

```text
model confidence
model voting
swap symmetry
reference-renaming invariance
```

None is sufficient as a generic truth/challenge signal.

The remaining verification problem is therefore closer to:

> Can a derived packet be checked against evidence or consequences that are at least partly independent of the exact computation that produced it?

That suggests the next experiment should test **independent predictive/constraint verification**, not another confidence heuristic.
