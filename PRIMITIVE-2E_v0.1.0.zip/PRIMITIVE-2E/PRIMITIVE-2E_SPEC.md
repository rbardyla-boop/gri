# PRIMITIVE-2E — AUTONOMOUS VERIFICATION

**Version:** 0.1.0
**Status:** FROZEN BEFORE SCORING
**Experiment SHA-256:** `eff257fdb3224e24dbab2479ef6780fb00cac3ffbbc8aa02e3f25ab2f2826730`
**Verifier SHA-256:** `a847e3f6a7e535eb9a407a9187689adc6f7a23513084b43a20029cb7843b875f`
**Confirmation fixture SHA-256:** `3e1bc66f9d7accf67a02fc10eb59f1a8434b12275bd2987e35eab8dcd3b3936d`

## Question

> Can a machine generate reliable challenge signals against its own derived packets without using a complete symbolic truth engine, while preserving the frozen justification-DAG rollback guarantees from PRIMITIVE-2D?

## Frozen rollback

PRIMITIVE-2D's `JUSTIFICATION_DAG` is not redesigned.

The verifier may only output:

```text
CHALLENGE semantic fact
or
NO CHALLENGE
```

The rollback layer then performs the same least-fixed-point support reconstruction used in PRIMITIVE-2D.

## Verification hypothesis

Entity/reference IDs are arbitrary machine identifiers.

Therefore a valid packet transformation should be invariant to a bijective renaming of those identifiers that preserves equality structure.

PRIMITIVE-2E tests whether instability under harmless renaming is a useful autonomous challenge signal.

This verifier knows no symbolic composition truth table.

## Candidate verifiers

```text
CONFIDENCE_0_99
RENAMING_K8
RENAMING_K32
RENAMING_K8_PLUS_CONFIDENCE
```

The 0.99 threshold and renaming counts are frozen before scoring.

## Fact-level aggregation

A derived semantic fact is challenged only when **all recorded support pairs** for that fact are challenged by the candidate verifier.

This aggregation occurs before the unchanged PRIMITIVE-2D rollback.

## Scored surfaces

```text
9 known corrupted PRIMITIVE-2B model/graph pairs
32 fresh confirmation graphs × 3 frozen model seeds
```

All three seeds are required.

## Oracle boundary

The experimenter oracle is used only after verifier output to score challenge precision, bad-root recall, false challenges, and final rollback correctness.

The verifier never sees that oracle.

## Strict success

A verifier succeeds only if it produces, across both surfaces:

```text
0 active bad facts after rollback
100% valid recall
100% exact final graphs
0 valid facts challenged
deterministic replay
```
