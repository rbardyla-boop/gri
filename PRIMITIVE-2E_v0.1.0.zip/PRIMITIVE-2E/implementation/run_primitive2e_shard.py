from __future__ import annotations
import argparse, hashlib, itertools, json, math, os, sys, time
from pathlib import Path
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)
BASE=Path('/mnt/data')
P2A=BASE/'PRIMITIVE-2A'; P2B=BASE/'PRIMITIVE-2B'; P2D=BASE/'PRIMITIVE-2D'
ROOT=BASE/'PRIMITIVE-2E'; FIX=ROOT/'PRIMITIVE-2E_FIXTURES'; RES=ROOT/'results'
RES.mkdir(exist_ok=True)
ACTS=['ASSERT','DERIVE']; RELS=['BEFORE','PART_OF','ASSIGNED_TO','LOCATED_IN']
A2I={x:i for i,x in enumerate(ACTS)}; R2I={x:i for i,x in enumerate(RELS)}; I2R={i:x for x,i in R2I.items()}
RO_NONE=4
RULES={'BEFORE|BEFORE':'BEFORE','PART_OF|PART_OF':'PART_OF','PART_OF|ASSIGNED_TO':'ASSIGNED_TO'}
bitpos=torch.arange(24,dtype=torch.long)

def sha_file(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)

freeze=json.loads((ROOT/'PRIMITIVE-2E_FREEZE.json').read_text())
verifier_spec=json.loads((ROOT/'PRIMITIVE-2E_VERIFIERS.json').read_text())
pool=json.loads((ROOT/'PRIMITIVE-2E_REFERENCE_POOL.json').read_text())['references']
confirm=json.loads((FIX/'CONFIRMATION_GRAPHS.json').read_text())
known_suite=json.loads((P2D/'PRIMITIVE-2D_FIXTURES'/'CHALLENGE_SUITE.json').read_text())
p2b_graphs=json.loads((P2B/'PRIMITIVE-2B_FIXTURES'/'RECURSIVE_STABILITY_GRAPHS.json').read_text())
p2b_map={f['fixture_id']:f for f in p2b_graphs['fixtures']}

class BindingComposer(nn.Module):
    def __init__(self):
        super().__init__()
        self.refenc=nn.Sequential(nn.Linear(24,32),nn.ReLU(),nn.Linear(32,32),nn.ReLU())
        self.body=nn.Sequential(nn.Linear(332,128),nn.ReLU(),nn.Linear(128,128),nn.ReLU())
        self.bind=nn.Linear(128,3); self.rel=nn.Linear(128,5); self.ssel=nn.Linear(128,4); self.osel=nn.Linear(128,4)
    def forward(self,acts,rels,refs):
        rb=((refs.unsqueeze(-1)>>bitpos)&1).float(); e=self.refenc(rb)
        diffs=torch.cat([(e[:,i]-e[:,j]).abs() for i,j in itertools.combinations(range(4),2)],dim=1)
        meta=torch.cat([F.one_hot(acts[:,0],2).float(),F.one_hot(acts[:,1],2).float(),F.one_hot(rels[:,0],4).float(),F.one_hot(rels[:,1],4).float()],dim=1)
        h=self.body(torch.cat([e.flatten(1),diffs,meta],dim=1))
        return self.bind(h),self.rel(h),self.ssel(h),self.osel(h)

def load_model(seed):
    m=BindingComposer(); m.load_state_dict(torch.load(P2A/'models'/f'M2_seed_{seed}.pt',map_location='cpu',weights_only=True)); m.eval(); return m

def verify_freeze():
    for rec in freeze['files']:
        if sha_file(ROOT/rec['name'])!=rec['sha256']: raise RuntimeError('freeze file changed '+rec['name'])
    for seed,h in freeze['parent_model_hashes'].items():
        if sha_file(P2A/'models'/f'M2_seed_{seed}.pt')!=h: raise RuntimeError('model changed '+seed)
    if sha_file(P2B/'PRIMITIVE-2B_FIXTURES'/'RECURSIVE_STABILITY_GRAPHS.json')!=freeze['parent_p2b_fixture_sha256']: raise RuntimeError('p2b fixtures changed')
    if sha_file(P2D/'PRIMITIVE-2D_MECHANISMS.json')!=freeze['parent_p2d_mechanism_sha256']: raise RuntimeError('p2d mechanism changed')

def oracle_pair(l,r):
    ls,lr,lo=l; rs,rr,ro=r
    key=f'{I2R[lr]}|{I2R[rr]}'
    if lo==rs and key in RULES: return (ls,R2I[RULES[key]],ro)
    key=f'{I2R[rr]}|{I2R[lr]}'
    if ro==ls and key in RULES: return (rs,R2I[RULES[key]],lo)
    return None

def oracle_closure(fx):
    facts={(int(p['subject']),R2I[p['relation']],int(p['object'])) for p in fx['inputs']}
    while True:
        arr=list(facts); new=set()
        for l in arr:
            for r in arr:
                x=oracle_pair(l,r)
                if x is not None and x not in facts: new.add(x)
        if not new: return facts
        facts |= new

def model_decisions(model,acts,rels,refs):
    with torch.no_grad():
        outs=model(acts,rels,refs); probs=[x.softmax(-1) for x in outs]; preds=[p.argmax(-1) for p in probs]
    return preds,probs

def audited_run(model,fx):
    gold=oracle_closure(fx)
    packets=[[int(p['id']),A2I[p['act']],int(p['subject']),R2I[p['relation']],int(p['object']),1000] for p in fx['inputs']]
    facts=[(p[2],p[3],p[4]) for p in packets]; is_input={f:True for f in facts}; fact_to_idx={f:i for i,f in enumerate(facts)}
    supports={f:[] for f in facts}; next_ref=max(p[0] for p in packets)+1; frontier=list(range(len(packets))); rounds=0; pair_evals=0
    while frontier and rounds<int(fx['max_rounds']):
        rounds+=1; n=len(packets); fset=set(frontier); pairs=[(i,j) for i in range(n) for j in range(n) if i!=j and (i in fset or j in fset)]
        if not pairs: break
        newfacts=set(); chunk=4096
        for st in range(0,len(pairs),chunk):
            ij=pairs[st:st+chunk]; left=torch.tensor([packets[i] for i,j in ij],dtype=torch.long); right=torch.tensor([packets[j] for i,j in ij],dtype=torch.long)
            acts=torch.stack([left[:,1],right[:,1]],dim=1); rels=torch.stack([left[:,3],right[:,3]],dim=1); refs=torch.stack([left[:,2],left[:,4],right[:,2],right[:,4]],dim=1)
            preds,probs=model_decisions(model,acts,rels,refs); pb,pr,ps,po=preds; mask=(pb!=0)&(pr!=RO_NONE); sel=torch.nonzero(mask,as_tuple=False).flatten(); pair_evals+=len(ij)
            for t in sel.tolist():
                i,j=ij[t]; slots=refs[t]; fact=(int(slots[int(ps[t])]),int(pr[t]),int(slots[int(po[t])]))
                sup={'left_fact':facts[i],'right_fact':facts[j],'left_packet':[int(x) for x in packets[i]],'right_packet':[int(x) for x in packets[j]],'decision':[int(pb[t]),int(pr[t]),int(ps[t]),int(po[t])],
                     'min_confidence':float(min(float(probs[0][t,int(pb[t])]),float(probs[1][t,int(pr[t])]),float(probs[2][t,int(ps[t])]),float(probs[3][t,int(po[t])]))) }
                supports.setdefault(fact,[]).append(sup)
                if fact not in fact_to_idx: newfacts.add(fact)
        if not newfacts: break
        frontier=[]
        for fact in sorted(newfacts):
            if fact in fact_to_idx: continue
            s,r,o=fact; p=[next_ref,A2I['DERIVE'],s,r,o,1000]; next_ref+=1; idx=len(packets); packets.append(p); facts.append(fact); fact_to_idx[fact]=idx; is_input[fact]=False; frontier.append(idx)
    final=set(facts); bad=final-gold
    return {'gold':gold,'final':final,'bad':bad,'supports':supports,'is_input':is_input,'rounds':rounds,'pair_evals':pair_evals}

def primary_bad(run):
    out=set()
    for fact in run['bad']:
        for sup in run['supports'].get(fact,[]):
            if sup['left_fact'] in run['gold'] and sup['right_fact'] in run['gold']: out.add(fact); break
    return out

def renamed_refs_batch(seed,fact,support,K):
    orig=[support['left_packet'][2],support['left_packet'][4],support['right_packet'][2],support['right_packet'][4]]
    uniq=[]
    for x in orig:
        if x not in uniq: uniq.append(x)
    prefix=f"{seed}|{fact}|{support['left_fact']}|{support['right_fact']}|".encode()
    rows=[]
    for k in range(K):
        h=hashlib.sha256(prefix+str(k).encode()).digest(); start=int.from_bytes(h[:8],'big')%len(pool); step=(int.from_bytes(h[8:16],'big')%(len(pool)-1))+1
        if step%2==0: step+=1
        vals=[]; idx=start
        while len(vals)<len(uniq):
            v=pool[idx%len(pool)]
            if v not in vals: vals.append(v)
            idx+=step
        mp=dict(zip(uniq,vals)); rows.append([mp[x] for x in orig])
    return rows

def compute_support_flags(model,seed,run):
    # Returns flags per verifier for each semantic fact, aggregated as ALL support-pairs flagged.
    fact_flags={v:{} for v in verifier_spec['support_level_verifiers']}
    # Confidence can be resolved without model calls.
    for fact in run['final']:
        if run['is_input'].get(fact,False): continue
        sups=run['supports'].get(fact,[])
        if not sups: continue
        conf=[s['min_confidence']<0.99 for s in sups]
        fact_flags['CONFIDENCE_0_99'][fact]=all(conf)

        # Compute K8 per support, then only extend K32 on K8-stable supports.
        k8_flags=[]; k32_flags=[]
        for sup in sups:
            orig=torch.tensor(sup['decision'],dtype=torch.long).unsqueeze(0)
            acts8=torch.tensor([[sup['left_packet'][1],sup['right_packet'][1]]]*8,dtype=torch.long)
            rels8=torch.tensor([[sup['left_packet'][3],sup['right_packet'][3]]]*8,dtype=torch.long)
            refs8=torch.tensor(renamed_refs_batch(seed,fact,sup,8),dtype=torch.long)
            preds,_=model_decisions(model,acts8,rels8,refs8); rows=torch.stack(preds,dim=1); f8=bool((rows!=orig).any().item()); k8_flags.append(f8)
            if f8:
                k32_flags.append(True)
            else:
                acts24=torch.tensor([[sup['left_packet'][1],sup['right_packet'][1]]]*24,dtype=torch.long)
                rels24=torch.tensor([[sup['left_packet'][3],sup['right_packet'][3]]]*24,dtype=torch.long)
                refs24=torch.tensor(renamed_refs_batch(seed,fact,sup,32)[8:],dtype=torch.long)
                preds24,_=model_decisions(model,acts24,rels24,refs24); rows24=torch.stack(preds24,dim=1); k32_flags.append(bool((rows24!=orig).any().item()))
        fact_flags['RENAMING_K8'][fact]=all(k8_flags)
        fact_flags['RENAMING_K32'][fact]=all(k32_flags)
        fact_flags['RENAMING_K8_PLUS_CONFIDENCE'][fact]=all(a or b for a,b in zip(k8_flags,conf))
    return fact_flags

def justification_dag(run,challenged):
    active={f for f,v in run['is_input'].items() if v and f not in challenged}; changed=True
    while changed:
        changed=False
        for fact in run['final']:
            if fact in active or fact in challenged or run['is_input'].get(fact,False): continue
            for sup in run['supports'].get(fact,[]):
                if sup['left_fact'] in active and sup['right_fact'] in active: active.add(fact); changed=True; break
    return active

def score_variant(run,challenged,primary):
    active=justification_dag(run,challenged); bad_after=active-run['gold']; fn=run['gold']-active; cb=len(challenged&run['bad']); cv=len(challenged&run['gold'])
    return {'challenged_fact_count':len(challenged),'challenged_bad_fact_count':cb,'challenged_valid_fact_count':cv,'challenge_precision':1.0 if not challenged else cb/len(challenged),
            'primary_bad_challenge_recall':1.0 if not primary else len(challenged&primary)/len(primary),'active_bad_fact_count_after_rollback':len(bad_after),'false_negative_fact_count_after_rollback':len(fn),
            'oracle_valid_recall_after_rollback':1.0 if not run['gold'] else len(active&run['gold'])/len(run['gold']),'exact_graph_match_after_rollback':active==run['gold']}

def get_cases(surface):
    cases=[]
    if surface in ('known','all'):
        for c in known_suite['cases']: cases.append(('KNOWN',int(c['seed']),p2b_map[c['fixture_id']],c))
    if surface in ('confirmation','all'):
        for seed in (13,29,61):
            for fx in confirm['fixtures']: cases.append(('CONFIRMATION',seed,fx,None))
    return cases

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--surface',choices=['known','confirmation','all'],default='known'); ap.add_argument('--start',type=int,default=0); ap.add_argument('--count',type=int,default=999999); args=ap.parse_args()
    verify_freeze(); cases=get_cases(args.surface); sel=cases[args.start:args.start+args.count]; models={s:load_model(s) for s in (13,29,61)}; out=[]; t0=time.time()
    for offset,(surface,seed,fx,expected) in enumerate(sel,args.start):
        run=audited_run(models[seed],fx); prim=primary_bad(run); eq=True
        if surface=='KNOWN': eq=(len(run['bad'])==expected['baseline_bad_packet_count'] and len(run['final']-run['gold'])==expected['baseline_false_positive_facts'])
        ff=compute_support_flags(models[seed],seed,run); variants={}
        for v in verifier_spec['support_level_verifiers']:
            challenged={fact for fact,flag in ff[v].items() if flag}; variants[v]=score_variant(run,challenged,prim)
        rec={'surface':surface,'seed':seed,'fixture_id':fx['fixture_id'],'family':fx['family'],'scale':fx['scale'],'baseline_equivalence_pass':eq,'baseline_bad_fact_count':len(run['bad']),'baseline_primary_bad_count':len(prim),'baseline_fact_count':len(run['final']),'gold_fact_count':len(run['gold']),'pair_evaluations':run['pair_evals'],'variants':variants}
        out.append(rec); print(offset,surface,seed,fx['fixture_id'],'bad',len(run['bad']),{v:(variants[v]['challenged_fact_count'],variants[v]['active_bad_fact_count_after_rollback'],variants[v]['oracle_valid_recall_after_rollback']) for v in variants},flush=True)
    payload={'surface':args.surface,'start':args.start,'count':len(out),'elapsed_seconds':time.time()-t0,'cases':out}; payload['sha256']=hashlib.sha256(canon(payload).encode()).hexdigest()
    p=RES/f"SHARD_{args.surface}_{args.start}_{len(out)}.json"; p.write_text(json.dumps(payload,indent=2)); print('WROTE',p)
if __name__=='__main__': main()
