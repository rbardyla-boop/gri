#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2E_RESULTS.json").read_text())
assert r["terminal_verdict"]=="VERIFICATION_SIGNAL_INSUFFICIENT"
assert r["known_baseline_equivalence"]=="PASS"
assert r["deterministic_replay"]=="PASS"
assert r["case_count"]==105
assert r["known_failure_case_count"]==9
assert r["confirmation_case_count"]==96
for name,s in r["verifier_summary"].items():
    assert s["known"]["exact_after_rollback_count"] < 9
    assert s["success_gate_pass"] is False
print("PRIMITIVE_2E_TEST_PASS")
