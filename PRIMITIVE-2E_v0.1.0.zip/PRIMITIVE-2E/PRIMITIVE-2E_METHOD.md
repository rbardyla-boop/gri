# PRIMITIVE-2E METHOD

1. Freeze the exact three PRIMITIVE-2A learned binding models by SHA-256.
2. Freeze PRIMITIVE-2D's JUSTIFICATION_DAG rollback unchanged.
3. Freeze four autonomous verifier signals before scoring:
   - CONFIDENCE_0_99
   - RENAMING_K8
   - RENAMING_K32
   - RENAMING_K8_PLUS_CONFIDENCE
4. Freeze a new 24-bit reference pool disjoint from prior PRIMITIVE-2A/2B pools.
5. Freeze 32 new confirmation graphs.
6. Reproduce the nine known PRIMITIVE-2B failure states while recording every learned parent-pair justification.
7. For each learned support pair, compute verifier signals without oracle truth access.
8. Challenge a semantic fact only if every recorded support pair for that fact is challenged.
9. Apply the exact frozen PRIMITIVE-2D JUSTIFICATION_DAG rollback.
10. Use the experimenter oracle only after challenge generation to score challenge precision, bad-root recall, and final graph correctness.
11. Score 96 additional confirmation model/graph cases.
12. Re-run every shard and require exact equality of case payload hashes.

The verifier does not receive the symbolic truth/composition table. Reference-renaming verification tests whether the model's decision is invariant under bijective changes to arbitrary numeric entity IDs.
