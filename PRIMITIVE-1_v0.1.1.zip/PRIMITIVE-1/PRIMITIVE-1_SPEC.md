# PRIMITIVE-1 SPECIFICATION
## Packet-Native Repeated Inference

**Version:** 0.1.1  
**Status:** FROZEN BEFORE IMPLEMENTATION  
**Rules SHA-256:** `d6487fe7b883c33182f6f631c0455d7f88bf9e97ca86a34fdd6ffcec4761bd91`  
**Fixture-set SHA-256:** `daa0c2c6a00832634afca8eac4ea0c157047b0a3a0d74d153444c8c9a83c0178`

## Research question

> Can useful repeated inference be performed by transforming the frozen machine-native primitive directly, without an explicit natural-language intermediate substrate?

## Frozen primitive

```text
STABLE_REFERENCE
ACT
SUBJECT
RELATION
OBJECT
VALUE
```

No field may be added, removed, or reinterpreted inside PRIMITIVE-1.

## Scope

PRIMITIVE-1 is an existence/sufficiency experiment over a frozen rule-governed task family.

A pass may establish only:

> At least one frozen machine mechanism can perform the tested repeated inference tasks using packet-native state transformations without explicit natural-language intermediate reasoning.

It does not establish:

- universal reasoning sufficiency;
- learned/neural sufficiency;
- consciousness;
- human-like cognition;
- production usefulness;
- that the frozen rule algebra is optimal.

## Hard no-prose rule

During authoritative inference:

```text
numeric packets
    ↓
numeric rule mechanism
    ↓
numeric packets
```

No explicit natural-language sentence, explanation, chain-of-thought, prompt, or reparsed prose may be emitted, stored, or passed between inference rounds.

Human-readable decoding is permitted only after the scored packet trajectory is complete.

## Frozen mechanism knowledge

The only authorized semantic machinery is `PRIMITIVE-1_RULES.json`.

No task-specific rule may be introduced.

The mechanism may maintain generic implementation state required for:

- stable-reference allocation;
- deterministic deduplication;
- current-state indexing for functional relations;
- fixed-point iteration.

Any other side machinery must be declared and counted.

## Task suite

```text
T1 CHAIN4
T2 CHAIN16
T3 DISTRACTOR
T4 HIERARCHY
T5 CONTRADICTION
T6 UPDATE_REQUEST
T7 NOVEL
T8 CYCLE
```

## Primary metrics

No composite score.

```text
UTILITY
- required outputs present
- forbidden outputs absent
- task pass/fail

ITERATION
- inference rounds
- fixed point reached
- derived packets emitted
- final packet count

COMPUTATION
- pair/rule checks
- deterministic operations
- model calls

INTERMEDIATE REPRESENTATION
- explicit natural-language intermediates
- numeric-only authoritative trajectory
- estimated varint bytes of emitted packet state

REPLAY
- trajectory hash
- deterministic rerun equality
```

## Execution validity

`EXPERIMENT_INVALID` if:

- a fixture changes after implementation begins;
- the rule algebra changes after implementation begins;
- a task-specific rule is added;
- prose is used as an authoritative intermediate;
- evaluator expectations are fed into inference;
- deterministic replay diverges where determinism is claimed.

## Terminal verdicts

```text
PACKET_NATIVE_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE
PARTIAL
NOT_DEMONSTRATED
EXPERIMENT_INVALID
```

`PACKET_NATIVE_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE` requires all eight frozen tasks to pass, numeric-only authoritative trajectories, and deterministic replay.

## v0.1.1 pre-implementation consistency patch

Before any candidate implementation was run, the functional-current-state wording was found to conflict with T5.

Corrected rule:

```text
ASSERT → adds current candidate
UPDATE → supersedes prior current candidates for SUBJECT+functional RELATION
later ASSERT → may add a new candidate
```

No task inputs, required outputs, forbidden outputs, or task identities changed.

This patch occurred before implementation and before any scored result existed.
