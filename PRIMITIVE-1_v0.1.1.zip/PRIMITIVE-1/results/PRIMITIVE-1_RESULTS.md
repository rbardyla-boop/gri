# PRIMITIVE-1 Results

**Terminal verdict:** `PACKET_NATIVE_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Mechanism:** `M0_NUMERIC_FIXED_POINT`  
**Tasks passed:** 8/8  
**Numeric-only authoritative trajectory:** `PASS`  
**Deterministic replay:** `PASS`  
**Model calls:** 0

| Task | Verdict | Rounds | Derived | Final packets | Pair checks | Replay |
|---|---|---:|---:|---:|---:|---|
| T1 CHAIN4 | PASS | 3 | 3 | 6 | 70 | PASS |
| T2 CHAIN16 | PASS | 5 | 105 | 120 | 26846 | PASS |
| T3 DISTRACTOR | PASS | 4 | 10 | 143 | 527 | PASS |
| T4 HIERARCHY | PASS | 3 | 6 | 10 | 107 | PASS |
| T5 CONTRADICTION | PASS | 2 | 1 | 3 | 0 | PASS |
| T6 UPDATE_REQUEST | PASS | 2 | 1 | 4 | 0 | PASS |
| T7 NOVEL | PASS | 3 | 3 | 6 | 39 | PASS |
| T8 CYCLE | PASS | 3 | 9 | 12 | 189 | PASS |
