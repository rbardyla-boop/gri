# PRIMITIVE-1 Conclusion

**Accepted terminal verdict:** `PACKET_NATIVE_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## What was demonstrated

A frozen deterministic machine mechanism completed all eight preregistered tasks by repeatedly transforming the six-field primitive:

```text
STABLE_REFERENCE
ACT
SUBJECT
RELATION
OBJECT
VALUE
```

The authoritative inference loop used numeric packets and numeric rule opcodes only.

```text
tasks passed:                    8/8
explicit natural-language intermediates: 0
model calls:                     0
deterministic replay:            PASS
maximum fixed-point rounds:      5
total derived packets:           138
total pair checks:               27778
```

The task suite included:

```text
short transitive closure
16-node multi-round closure
128-packet distractor field
multi-rule hierarchy composition
stable-reference contradiction
UPDATE → REQUEST → RESPONSE
novel entity combinations
cyclic fixed-point termination
```

## Accepted claim

The strongest supported statement is:

> At least one frozen machine mechanism can perform the tested repeated inference tasks directly over the machine-native primitive without an explicit natural-language intermediate substrate.

That answers the PRIMITIVE-1 existence question positively within the frozen task family.

## What this does not establish

This experiment does not show that:

- every useful reasoning task fits the primitive;
- a learned neural model can use the primitive effectively;
- the frozen rule algebra is minimal;
- symbolic inference is superior to neural inference;
- natural language is unnecessary at the human interface;
- the primitive is a universal cognitive instruction set.

The reference mechanism is deliberately symbolic and rule-governed.

## Validity incident

The first scored run produced 8/8 passes but was rejected as:

```text
EXPERIMENT_INVALID
```

because the compiler pre-seeded its symbol table from evaluator required/forbidden output patterns.

The benchmark did not change.

The implementation was repaired so symbol compilation consumes fixture inputs only, then the entire frozen experiment was rerun from scratch.

The accepted clean rerun again produced 8/8 passes with exact replay.

The invalid first-run receipt remains preserved as:

```text
results/PRIMITIVE-1_FIRST_RUN_INVALID.json
```

## Most demanding frozen task

By reference pair-check count:

```text
T2 CHAIN16
pair checks = 26846
rounds      = 5
derived     = 105
```

## Scientific interpretation

PRIMITIVE-0 established that the semantic interchange representation was sufficient for the frozen communication tasks after stable reference was added.

ENCODING-0 through ENCODING-2 established a compact transport strategy.

PRIMITIVE-1 now establishes an existence proof that the same semantic substrate can support repeated, fixed-point, multi-step inference without a prose round-trip.

The next scientifically different question is not another symbolic rule.

It is:

```text
PRIMITIVE-2 — LEARNED PACKET-NATIVE INFERENCE
```

> Can a learned model acquire useful packet→packet transformations and generalize them to held-out structures without being given explicit natural-language intermediate reasoning or task-specific symbolic rules?

That experiment should keep the primitive and PRIMITIVE-1 fixtures fixed where useful, but separate training examples from held-out structures and compare learned packet-native inference against the symbolic reference mechanism.
