# PRIMITIVE-1 VERDICT CONTRACT

## Run validity

```text
RUN_VALID
EXPERIMENT_INVALID
```

## Task verdict

```text
PASS
FAIL
```

A task passes only when:

- all required final semantic outputs are present;
- all forbidden final semantic outputs are absent;
- every explicit fixture requirement is satisfied;
- fixed point is reached when required.

## Failure classes

```text
MISSING_DERIVATION
INCORRECT_DERIVATION
VALUE_PROPAGATION_ERROR
STABLE_REFERENCE_FAILURE
UPDATE_SEMANTICS_FAILURE
REQUEST_RESPONSE_FAILURE
NONTERMINATION
DUPLICATE_EXPLOSION
PROSE_INTERMEDIATE_LEAK
REPLAY_FAILURE
UNDECLARED_SIDE_MACHINERY
OTHER
```

## Experiment terminal verdict

```text
PACKET_NATIVE_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE
PARTIAL
NOT_DEMONSTRATED
EXPERIMENT_INVALID
```

No stronger universal claim is authorized.
