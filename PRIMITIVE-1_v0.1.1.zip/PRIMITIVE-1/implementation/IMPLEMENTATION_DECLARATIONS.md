# PRIMITIVE-1 IMPLEMENTATION DECLARATIONS

**Version:** 0.1.1  
**Status:** FROZEN BEFORE FIRST SCORED RUN  
**Rules SHA-256:** `d6487fe7b883c33182f6f631c0455d7f88bf9e97ca86a34fdd6ffcec4761bd91`  
**Fixture-set SHA-256:** `daa0c2c6a00832634afca8eac4ea0c157047b0a3a0d74d153444c8c9a83c0178`

## Reference mechanism

```text
M0_NUMERIC_FIXED_POINT
```

Purpose:

> Provide an existence test for repeated inference over the frozen primitive without explicit natural-language intermediate reasoning.

## Boundary compilation

Before authoritative inference begins:

```text
human-readable fixture symbols
        ↓ one-way compile
integer symbol IDs / integer ACT IDs / integer RELATION IDs
```

The scored inference mechanism receives only numeric packets and numeric rule opcodes.

It does not receive:

- required outputs;
- forbidden outputs;
- task names;
- evaluator notes;
- natural-language descriptions.

## Authoritative packet

```text
[stable_ref, act, subject, relation, object, value]
```

Every element is an integer.

## Allowed generic mechanism state

```text
packet list
semantic-dedup set
functional current-state index
stable-reference allocator
numeric rule table
fixed-point round counter
operation counters
```

No task-specific state or task-specific rules are allowed.

## Inference procedure

Per round:

1. reconstruct current numeric facts from the packet stream;
2. apply frozen numeric composition rules;
3. apply frozen functional-contradiction rule;
4. apply frozen request/current-state response rule;
5. deduplicate candidate semantic packets;
6. sort candidates canonically;
7. allocate deterministic stable references;
8. append candidates;
9. stop when a round emits zero packets.

## Numeric-only audit

The authoritative trajectory is stored as nested arrays of integers only.

A recursive type audit must find:

```text
string_count = 0
```

inside the authoritative trajectory.

Human-readable decoding occurs only after inference has terminated.

## Limits

This mechanism is symbolic and rule-governed.

A successful result demonstrates packet-native inference sufficiency for the frozen tasks. It does not demonstrate learned/neural packet inference.

## First-run invalidation

The first scored execution was invalidated before acceptance because the compiler seeded its symbol table using evaluator required/forbidden output patterns.

Patch:

```text
symbol table inputs BEFORE:
fixture inputs + evaluator patterns

symbol table inputs AFTER:
fixture inputs only
```

The frozen rules and fixtures were not changed.

The invalid run is preserved in:

`results/PRIMITIVE-1_FIRST_RUN_INVALID.json`
