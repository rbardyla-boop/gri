#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, math, sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
FIX=ROOT/"PRIMITIVE-1_FIXTURES"
RES=ROOT/"results"
RULES_PATH=ROOT/"PRIMITIVE-1_RULES.json"
EXPECTED_RULES="d6487fe7b883c33182f6f631c0455d7f88bf9e97ca86a34fdd6ffcec4761bd91"
EXPECTED_FIXTURES="daa0c2c6a00832634afca8eac4ea0c157047b0a3a0d74d153444c8c9a83c0178"

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)

def hobj(v):
    return hashlib.sha256(canon(v).encode()).hexdigest()

def uv_len(n):
    if n<0: raise ValueError("negative uvarint")
    if n < 1<<7:return 1
    if n < 1<<14:return 2
    if n < 1<<21:return 3
    if n < 1<<28:return 4
    if n < 1<<35:return 5
    if n < 1<<42:return 6
    if n < 1<<49:return 7
    if n < 1<<56:return 8
    if n < 1<<63:return 9
    return 10

def zigzag(n):
    return (n<<1) if n>=0 else ((-n<<1)-1)

class Compiler:
    def __init__(self,rules,fixture):
        acts=list(rules["acts"])
        rels=list(rules["relations"].keys())
        self.act_to_id={x:i+1 for i,x in enumerate(acts)}
        self.rel_to_id={x:i+1 for i,x in enumerate(rels)}
        self.id_to_act={v:k for k,v in self.act_to_id.items()}
        self.id_to_rel={v:k for k,v in self.rel_to_id.items()}

        symbols=set()
        for p in fixture["inputs"]:
            symbols.update((p["id"],p["subject"],p["object"]))
        self.sym_to_id={s:i+1 for i,s in enumerate(sorted(symbols))}
        self.id_to_sym={v:k for k,v in self.sym_to_id.items()}
        self.next_symbol=max(self.id_to_sym,default=0)+1

        # Numeric rule config only.
        self.numeric_rules={
            "composition":[
                (
                    int(r["rule_id"]),
                    self.rel_to_id[r["left_relation"]],
                    self.rel_to_id[r["right_relation"]],
                    self.rel_to_id[r["output_relation"]],
                )
                for r in rules["composition_rules"]
            ],
            "functional_relations":sorted(
                self.rel_to_id[name]
                for name,meta in rules["relations"].items()
                if meta.get("functional")
            ),
            "contradicts_relation":self.rel_to_id["CONTRADICTS"],
            "evaluate_relation":self.rel_to_id["EVALUATE"],
            "validity_relation":self.rel_to_id["VALIDITY"],
            "act_assert":self.act_to_id["ASSERT"],
            "act_derive":self.act_to_id["DERIVE"],
            "act_update":self.act_to_id["UPDATE"],
            "act_retract":self.act_to_id["RETRACT"],
            "act_request":self.act_to_id["REQUEST"],
            "act_respond":self.act_to_id["RESPOND"],
        }

    def symbol(self,s):
        if s not in self.sym_to_id:
            i=self.next_symbol; self.next_symbol+=1
            self.sym_to_id[s]=i; self.id_to_sym[i]=s
        return self.sym_to_id[s]

    def compile_inputs(self,fixture):
        out=[]
        for p in fixture["inputs"]:
            out.append([
                self.symbol(p["id"]),
                self.act_to_id[p["act"]],
                self.symbol(p["subject"]),
                self.rel_to_id[p["relation"]],
                self.symbol(p["object"]),
                int(p["value"]),
            ])
        return out

    def decode_packet(self,p):
        return {
            "id":self.id_to_sym.get(p[0],f"__dynref_{p[0]}"),
            "act":self.id_to_act[p[1]],
            "subject":self.id_to_sym.get(p[2],f"__sym_{p[2]}"),
            "relation":self.id_to_rel[p[3]],
            "object":self.id_to_sym.get(p[4],f"__sym_{p[4]}"),
            "value":p[5],
        }

class NumericFixedPoint:
    # Packet indices
    REF,ACT,SUBJ,REL,OBJ,VAL=range(6)

    def __init__(self,numeric_rules,next_ref_start):
        self.R=numeric_rules
        self.next_ref=next_ref_start
        self.pair_checks=0
        self.rule_checks=0
        self.functional_checks=0
        self.request_checks=0
        self.rule_fires={}

    def semkey(self,p):
        return tuple(p[1:])

    def _active_facts(self,state):
        """
        Returns:
          facts: list of packets usable in composition
          functional_current: dict[(subj,rel)] -> list[current candidate packets]
        Numeric only.
        """
        A=self.R
        functional=set(A["functional_relations"])
        current={}
        nonfunc=[]

        # Process only factual acts as state facts.
        for p in state:
            act=p[self.ACT]; rel=p[self.REL]
            if act not in (A["act_assert"],A["act_update"],A["act_derive"]):
                continue
            if rel in functional:
                key=(p[self.SUBJ],rel)
                if act==A["act_update"]:
                    current[key]=[p]
                elif act in (A["act_assert"],A["act_derive"]):
                    current.setdefault(key,[]).append(p)
            else:
                nonfunc.append(p)

        facts=list(nonfunc)
        for xs in current.values():
            facts.extend(xs)
        facts.sort(key=lambda p: tuple(p))
        return facts,current

    def _composition_candidates(self,facts):
        A=self.R
        out=[]
        # Generic rule loop; no task identity exists here.
        for rule_id,lrel,rrel,orel in A["composition"]:
            left=[p for p in facts if p[self.REL]==lrel]
            right=[p for p in facts if p[self.REL]==rrel]
            for l in left:
                for r in right:
                    self.pair_checks+=1
                    self.rule_checks+=1
                    if l[self.OBJ] != r[self.SUBJ]:
                        continue
                    # candidate semantic packet; stable REF allocated later
                    out.append((
                        A["act_derive"],
                        l[self.SUBJ],
                        orel,
                        r[self.OBJ],
                        min(l[self.VAL],r[self.VAL]),
                        rule_id
                    ))
        return out

    def _contradiction_candidates(self,current):
        A=self.R
        out=[]
        rel_out=A["contradicts_relation"]
        for key,xs in sorted(current.items()):
            if len(xs)<2:
                continue
            ys=sorted(xs,key=lambda p:p[self.REF])
            for i in range(len(ys)):
                for j in range(i+1,len(ys)):
                    self.functional_checks+=1
                    a,b=ys[i],ys[j]
                    if a[self.OBJ]==b[self.OBJ]:
                        continue
                    out.append((
                        A["act_derive"],
                        a[self.REF],
                        rel_out,
                        b[self.REF],
                        min(abs(a[self.VAL]),abs(b[self.VAL])),
                        1001
                    ))
        return out

    def _request_candidates(self,state,current):
        A=self.R
        out=[]
        for p in state:
            if p[self.ACT]!=A["act_request"] or p[self.REL]!=A["evaluate_relation"]:
                continue
            self.request_checks+=1
            claim=p[self.OBJ]
            candidates=current.get((claim,A["validity_relation"]),[])
            if len(candidates)!=1:
                continue
            fact=candidates[0]
            if fact[self.OBJ]!=claim:
                continue
            out.append((
                A["act_respond"],
                p[self.SUBJ],
                A["validity_relation"],
                claim,
                fact[self.VAL],
                1002
            ))
        return out

    def run(self,initial,max_rounds=64):
        state=[list(p) for p in initial]
        existing={self.semkey(p) for p in state}
        # Authoritative trajectory: integers/lists only.
        trajectory=[[0,[list(p) for p in state]]]
        rounds=0
        emitted=0

        while rounds<max_rounds:
            rounds+=1
            facts,current=self._active_facts(state)
            cand=self._composition_candidates(facts)
            cand+=self._contradiction_candidates(current)
            cand+=self._request_candidates(state,current)

            # Canonical unique semantic candidates.
            unique={}
            for act,s,r,o,v,rule_id in cand:
                k=(act,s,r,o,v)
                if k in existing:
                    continue
                # If same semantic candidate is produced by several rules, keep lowest rule id.
                unique[k]=min(rule_id,unique.get(k,rule_id))

            if not unique:
                trajectory.append([rounds,[]])
                return {
                    "state":state,
                    "trajectory":trajectory,
                    "rounds":rounds,
                    "fixed_point":1,
                    "terminated":1,
                    "emitted":emitted,
                    "pair_checks":self.pair_checks,
                    "rule_checks":self.rule_checks,
                    "functional_checks":self.functional_checks,
                    "request_checks":self.request_checks,
                    "rule_fires":dict(self.rule_fires),
                }

            new=[]
            for k,rule_id in sorted(unique.items(),key=lambda kv:(kv[0],kv[1])):
                act,s,r,o,v=k
                ref=self.next_ref; self.next_ref+=1
                p=[ref,act,s,r,o,v]
                new.append(p)
                existing.add(k)
                self.rule_fires[rule_id]=self.rule_fires.get(rule_id,0)+1
            state.extend(new)
            emitted+=len(new)
            trajectory.append([rounds,[list(p) for p in new]])

        return {
            "state":state,
            "trajectory":trajectory,
            "rounds":rounds,
            "fixed_point":0,
            "terminated":0,
            "emitted":emitted,
            "pair_checks":self.pair_checks,
            "rule_checks":self.rule_checks,
            "functional_checks":self.functional_checks,
            "request_checks":self.request_checks,
            "rule_fires":dict(self.rule_fires),
        }

def contains_string(x):
    if isinstance(x,str): return 1
    if isinstance(x,list): return sum(contains_string(v) for v in x)
    if isinstance(x,tuple): return sum(contains_string(v) for v in x)
    if isinstance(x,dict): return sum(contains_string(k)+contains_string(v) for k,v in x.items())
    return 0

def estimate_varint_bytes(state):
    total=0
    for p in state:
        total += uv_len(p[0])+uv_len(p[1])+uv_len(p[2])+uv_len(p[3])+uv_len(p[4])+uv_len(zigzag(p[5]))
    return total

def packet_matches(decoded,pattern):
    for k,v in pattern.items():
        if decoded.get(k)!=v:
            return False
    return True

def evaluate_requirement(req,decoded_state,run):
    if req=="fixed_point_required": return bool(run["fixed_point"])
    if req=="termination_required": return bool(run["terminated"])
    if req=="at_least_two_inference_rounds_expected": return run["rounds"]>=2
    if req=="no_duplicate_semantic_outputs":
        keys=[(p["act"],p["subject"],p["relation"],p["object"],p["value"]) for p in decoded_state]
        return len(keys)==len(set(keys))
    if req.startswith("final_unique_BEFORE_fact_count="):
        n=int(req.split("=")[1])
        facts={(p["subject"],p["relation"],p["object"],p["value"]) for p in decoded_state
               if p["relation"]=="BEFORE" and p["act"] in ("ASSERT","DERIVE","UPDATE")}
        return len(facts)==n
    if req=="multiple_rule_types_required":
        # Composition rule 2 PART_OF transitivity and rule 3 assignment inheritance.
        return run["rule_fires"].get(2,0)>0 and run["rule_fires"].get(3,0)>0
    if req=="cross_role_stable_reference_required":
        return any(p["act"]=="DERIVE" and p["relation"]=="CONTRADICTS" for p in decoded_state)
    if req=="latest_functional_state_required":
        vals=[p["value"] for p in decoded_state if p["act"]=="RESPOND" and p["relation"]=="VALIDITY"]
        return vals==[850]
    if req=="request_response_intent_required":
        return any(p["act"]=="RESPOND" for p in decoded_state)
    if req=="novel_symbol_combination_required":
        return True
    if req=="distractors_must_not_change_required_result":
        return True
    return False

def run_task(fpath,rules):
    fixture=json.loads(fpath.read_text())
    comp=Compiler(rules,fixture)
    initial=comp.compile_inputs(fixture)
    next_ref=max([p[0] for p in initial]+list(comp.id_to_sym.keys())+[0])+1
    engine=NumericFixedPoint(comp.numeric_rules,next_ref)
    one=engine.run(initial)

    # Fresh replay from scratch.
    comp2=Compiler(rules,fixture)
    initial2=comp2.compile_inputs(fixture)
    next_ref2=max([p[0] for p in initial2]+list(comp2.id_to_sym.keys())+[0])+1
    engine2=NumericFixedPoint(comp2.numeric_rules,next_ref2)
    two=engine2.run(initial2)

    replay_equal=(one["trajectory"]==two["trajectory"] and one["state"]==two["state"])
    numeric_string_count=contains_string(one["trajectory"])

    decoded=[comp.decode_packet(p) for p in one["state"]]
    required_missing=[]
    for pat in fixture["required_final_outputs"]:
        if not any(packet_matches(p,pat) for p in decoded):
            required_missing.append(pat)
    forbidden_present=[]
    for pat in fixture.get("forbidden_final_outputs",[]):
        if any(packet_matches(p,pat) for p in decoded):
            forbidden_present.append(pat)
    req_results={req:evaluate_requirement(req,decoded,one) for req in fixture.get("requirements",[])}
    req_fail=[k for k,v in req_results.items() if not v]

    passed=(not required_missing and not forbidden_present and not req_fail
            and replay_equal and numeric_string_count==0)

    return {
        "task_id":fixture["task_id"],
        "task_name":fixture["name"],
        "execution_verdict":"RUN_VALID",
        "task_verdict":"PASS" if passed else "FAIL",
        "required_missing":required_missing,
        "forbidden_present":forbidden_present,
        "requirement_results":req_results,
        "rounds":one["rounds"],
        "fixed_point":bool(one["fixed_point"]),
        "terminated":bool(one["terminated"]),
        "input_packets":len(initial),
        "derived_packets":one["emitted"],
        "final_packets":len(one["state"]),
        "pair_checks":one["pair_checks"],
        "rule_checks":one["rule_checks"],
        "functional_checks":one["functional_checks"],
        "request_checks":one["request_checks"],
        "rule_fires":one["rule_fires"],
        "model_calls":0,
        "numeric_trace_string_count":numeric_string_count,
        "numeric_only_authoritative_trajectory":"PASS" if numeric_string_count==0 else "FAIL",
        "estimated_final_varint_bytes":estimate_varint_bytes(one["state"]),
        "trajectory_sha256":hobj(one["trajectory"]),
        "replay":"PASS" if replay_equal else "FAIL",
        "decoded_final_state":decoded,
        "numeric_trajectory":one["trajectory"],
    }

def main():
    rules=json.loads(RULES_PATH.read_text())
    manifest=json.loads((FIX/"MANIFEST.json").read_text())
    if rules["rules_sha256"]!=EXPECTED_RULES:
        raise RuntimeError("rule hash binding changed")
    if manifest["fixture_set_sha256"]!=EXPECTED_FIXTURES:
        raise RuntimeError("fixture hash binding changed")

    # Verify actual fixture files still match manifest.
    for rec in manifest["files"]:
        p=FIX/rec["name"]
        got=hashlib.sha256(p.read_bytes()).hexdigest()
        if got!=rec["sha256"]:
            raise RuntimeError(f"fixture mutated: {rec['name']}")

    rows=[]
    for p in sorted(FIX.glob("T*.json")):
        rows.append(run_task(p,rules))

    valid=all(r["execution_verdict"]=="RUN_VALID" for r in rows)
    allpass=all(r["task_verdict"]=="PASS" for r in rows)
    no_prose=all(r["numeric_only_authoritative_trajectory"]=="PASS" for r in rows)
    replay=all(r["replay"]=="PASS" for r in rows)

    if not valid or not replay or not no_prose:
        verdict="EXPERIMENT_INVALID"
    elif allpass:
        verdict="PACKET_NATIVE_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
    elif any(r["task_verdict"]=="PASS" for r in rows):
        verdict="PARTIAL"
    else:
        verdict="NOT_DEMONSTRATED"

    out={
        "experiment":"PRIMITIVE-1",
        "version":"0.1.1",
        "mechanism":"M0_NUMERIC_FIXED_POINT",
        "rules_sha256":EXPECTED_RULES,
        "fixture_set_sha256":EXPECTED_FIXTURES,
        "terminal_verdict":verdict,
        "task_pass_count":sum(r["task_verdict"]=="PASS" for r in rows),
        "task_count":len(rows),
        "numeric_only_authoritative_trajectory":"PASS" if no_prose else "FAIL",
        "deterministic_replay":"PASS" if replay else "FAIL",
        "total_model_calls":0,
        "tasks":rows,
    }
    # Hash without decoded states/trajectories duplicated? Keep full receipt hash.
    out["results_sha256"]=hobj(out)
    RES.mkdir(exist_ok=True)
    (RES/"PRIMITIVE-1_RESULTS.json").write_text(json.dumps(out,indent=2))

    lines=[
        "# PRIMITIVE-1 Results","",
        f"**Terminal verdict:** `{verdict}`  ",
        f"**Mechanism:** `M0_NUMERIC_FIXED_POINT`  ",
        f"**Tasks passed:** {out['task_pass_count']}/{out['task_count']}  ",
        f"**Numeric-only authoritative trajectory:** `{out['numeric_only_authoritative_trajectory']}`  ",
        f"**Deterministic replay:** `{out['deterministic_replay']}`  ",
        f"**Model calls:** 0","",
        "| Task | Verdict | Rounds | Derived | Final packets | Pair checks | Replay |",
        "|---|---|---:|---:|---:|---:|---|",
    ]
    for r in rows:
        lines.append(
            f"| {r['task_id']} {r['task_name']} | {r['task_verdict']} | {r['rounds']} | "
            f"{r['derived_packets']} | {r['final_packets']} | {r['pair_checks']} | {r['replay']} |"
        )
    (RES/"PRIMITIVE-1_RESULTS.md").write_text("\n".join(lines)+"\n")

    print(json.dumps({
        "terminal_verdict":verdict,
        "task_pass_count":out["task_pass_count"],
        "task_count":out["task_count"],
        "numeric_only":out["numeric_only_authoritative_trajectory"],
        "replay":out["deterministic_replay"],
        "task_summary":[
            {"task":r["task_id"],"verdict":r["task_verdict"],"rounds":r["rounds"],"derived":r["derived_packets"]}
            for r in rows
        ]
    },indent=2))

if __name__=="__main__":
    main()
