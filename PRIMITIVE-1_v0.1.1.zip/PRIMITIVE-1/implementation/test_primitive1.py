#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
subprocess.run([sys.executable,str(HERE/"run_primitive1.py")],check=True,stdout=subprocess.DEVNULL)
r=json.loads((ROOT/"results"/"PRIMITIVE-1_RESULTS.json").read_text())
assert r["terminal_verdict"]=="PACKET_NATIVE_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["task_count"]==8
assert r["task_pass_count"]==8
assert all(x["task_verdict"]=="PASS" for x in r["tasks"])
assert r["numeric_only_authoritative_trajectory"]=="PASS"
assert r["deterministic_replay"]=="PASS"
assert r["total_model_calls"]==0
assert (ROOT/"results"/"PRIMITIVE-1_FIRST_RUN_INVALID.json").exists()
print("PRIMITIVE_1_TEST_PASS")
