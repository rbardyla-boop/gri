# PRIMITIVE-2S — CONTROL-FLOW TOPOLOGY SYNTHESIS

**Version:** 0.1.0-design  
**Status:** `DESIGN_FROZEN_IMPLEMENTATION_UNSCORED`

## Question

> Given raw execution instructions and costs but no supplied handler/loop topology, can the machine construct the control-flow graph itself—branches, loops, halting paths and register interactions—directly from residual collisions and counterexamples?

## Parent boundary

PRIMITIVE-2R demonstrated open instruction construction inside a supplied guarded-handler streaming normal form.

PRIMITIVE-2S removes that normal form.

There is no external:

```text
for token in stream:
    handler[token]()
```

The synthesized artifact owns its program counter and termination.

Parent hashes:

```text
2R experiment:     2e4ac08b565b63e1c1c53fdd4ef89a8a92f85012639305c7b9b8c8005156e79a
2R micro-language: 64a9a172e775eaca36df9c27bf52d1fb74de34015cfc113d6cb676251778ab51
2R search:         2050de9decc0f87d23b0abd3e6731eb0431bfbdc9f82f14cf198bc48a2ed5d15
2R results:        1079530b52534df5515d7ff91b13a92c9bfaead60a312da686959afd3db0f14f
```

## Two anti-contamination corrections

### 1. No `CALL` / `RET`

`CALL` and `RET` normally imply a call stack. Supplying them would quietly introduce a stack execution abstraction before the later instruction-substrate experiment.

2S v0.1 therefore uses explicit jumps only.

### 2. No `ADVANCE N`

The prior stream wrapper advanced exactly one token.

2S reifies that as:

```text
ADVANCE 1
```

only.

A dynamic skip must be synthesized structurally:

```text
branch A: ADVANCE → return
branch B: ADVANCE → ADVANCE → return
```

rather than being handed an `ADVANCE 2` or `ADVANCE_BY_REGISTER` primitive.

## Candidate artifact

A candidate is a directed control-flow graph:

```text
G = (V, E)
```

whose reachable basic blocks contain at most two raw instructions and terminate in `JMP`, `JZ`, or `HALT`.

Maximum reachable blocks in v0.1: `8`.

## Search

```text
residual 2R collision traces
        ↓
graph-grammar mutations
        ↓
cost-weighted beam
        ↓
candidate CFG
        ↓
full discovery replay
        ↓
counterexample
        ↓
CEGIS repeat
```

No complete candidate-program library is supplied.

## Complexity

The frozen objective is:

```text
instruction/operand/edge description cost
+ gamma * cyclomatic complexity
+ alpha * runtime
+ beta * peak persistent state
```

Exactness is lexicographically prior to cost.

## Halting

A raw step cap is not accepted as proof.

Every reachable cycle must receive a static ranking certificate:

```text
INPUT_REMAINING
or
REGISTER_DESCENT
```

Candidates with uncertified cycles are rejected before behavioral scoring.

## Required world classes

```text
DATA_DEPENDENT_STREAM_SKIP
MULTI_WAY_EARLY_EXIT
NESTED_ZERO_ADVANCE_SUBLOOP
```

These names are audit metadata only and are not synthesis inputs.

## Global-minimum firewall

A topology-synthesis pass and a global-minimum claim are separate.

If the complete lower-cost bounded CFG closure cannot be exhausted, the strongest permissible successful verdict is:

```text
CONTROL_FLOW_TOPOLOGY_SYNTHESIS_DEMONSTRATED_WITHOUT_GLOBAL_MINIMALITY
```

The benchmark may not silently equate a beam-search result with the global minimum.

## Current state

```text
DESIGN: FROZEN
FIXTURE GENERATION: NOT FROZEN
IMPLEMENTATION: PROTOTYPED
SCIENTIFIC SCORING: NOT RUN
TERMINAL SCIENTIFIC VERDICT: NONE
```

Exploratory graph-search prototypes were used only to expose the combinatorial search problem. They are not scientific runs and no result from them is being promoted.
