# PRIMITIVE-2H METHOD

1. Keep the PRIMITIVE-2A learned reasoners, six-field semantic primitive, PRIMITIVE-2D justification ledger, and rollback algorithm frozen.
2. Replace named verification slots with anonymous probe IDs and fixed costs.
3. Withhold all probe semantics from the planner.
4. Provide historical calibration records containing anonymous probe outcomes plus independently verified TRUE/FALSE labels.
5. Use a complete-factorial discovery set and a second complete-factorial validation set so nuisance probes cannot become perfect predictors by sampling accident.
6. For each relation, enumerate all probe subsets.
7. A subset is admissible only if its observed tuple maps deterministically to label in discovery and produces zero error/unseen tuples in validation.
8. Choose minimum total probe cost; tie-break by fewer probes and then lexicographic probe IDs.
9. Freeze the discovered contracts before final test scoring.
10. Apply the frozen contracts to the same 99 acyclic learned-reasoner cases used in PRIMITIVE-2G.
11. The environment uses the hidden probe map only to answer selected observations; it does not expose probe meaning to the planner.
12. Feed SUPPORT/CHALLENGE outcomes into the unchanged PRIMITIVE-2D JUSTIFICATION_DAG.
13. Use the experimenter oracle only after challenge generation to score exact graph state, false challenges, and remaining bad facts.
14. Rerun the full scorer and require identical canonical result hash.

The experiment tests empirical verification-contract discovery from prior labeled evidence. It does not yet test invention of new sensors, interventions, or causal experiments with no calibration history.
