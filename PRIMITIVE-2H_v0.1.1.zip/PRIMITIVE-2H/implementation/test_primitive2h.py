#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/'results'/'PRIMITIVE-2H_RESULTS.json').read_text())
rp=json.loads((ROOT/'results'/'PRIMITIVE-2H_REPLAY_CHECK.json').read_text())
assert r['terminal_verdict']=='VERIFICATION_CONTRACT_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE'
assert r['known_baseline_equivalence']=='PASS'
assert r['case_count']==99
assert rp['canonical_replay']=='PASS'
for rel,c in r['contract_audit'].items():
    assert c['validation_errors']==0
    assert c['validation_unseen']==0
    assert c['cost_optimal'] is True
p=r['planner_summary']['MIN_COST_CONTRACT_DISCOVERY']['all']
assert p['exact_after_rollback_count']==99
assert p['active_bad_after_total']==0
assert p['valid_false_challenges_total']==0
assert p['min_post_rollback_recall']==1.0
assert p['abstained_fact_count']==0
cheap=r['planner_summary']['CHEAPEST_SINGLE_PROBE']['all']
assert cheap['abstained_fact_count']==11464
assert cheap['active_bad_after_total']==375
print('PRIMITIVE_2H_TEST_PASS')
