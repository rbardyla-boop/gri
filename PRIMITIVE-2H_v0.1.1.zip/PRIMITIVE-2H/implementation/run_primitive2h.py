from pathlib import Path
import json, hashlib, itertools, time
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)

BASE=Path('/mnt/data')
P2A=BASE/'PRIMITIVE-2A'
P2B=BASE/'PRIMITIVE-2B'
P2D=BASE/'PRIMITIVE-2D'
P2E=BASE/'PRIMITIVE-2E'
ROOT=BASE/'PRIMITIVE-2H'
FIX=ROOT/'PRIMITIVE-2H_FIXTURES'
RES=ROOT/'results'
RES.mkdir(exist_ok=True)

ACTS=['ASSERT','DERIVE']
RELS=['BEFORE','PART_OF','ASSIGNED_TO','LOCATED_IN']
A2I={x:i for i,x in enumerate(ACTS)}
R2I={x:i for i,x in enumerate(RELS)}
I2R={i:x for x,i in R2I.items()}
RO_NONE=4
RULES={'BEFORE|BEFORE':'BEFORE','PART_OF|PART_OF':'PART_OF','PART_OF|ASSIGNED_TO':'ASSIGNED_TO'}
bitpos=torch.arange(24,dtype=torch.long)

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)

def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

# Freeze bindings.
freeze=json.loads((ROOT/'PRIMITIVE-2H_FREEZE.json').read_text())
for rec in freeze['files']:
    if sha_file(ROOT/rec['name']) != rec['sha256']:
        raise RuntimeError(f"frozen file changed: {rec['name']}")
for seed,h in freeze['parent_model_hashes'].items():
    if sha_file(P2A/'models'/f'M2_seed_{seed}.pt') != h:
        raise RuntimeError(f'parent model changed: {seed}')
if sha_file(P2D/'PRIMITIVE-2D_MECHANISMS.json') != freeze['parent_p2d_rollback_sha256']:
    raise RuntimeError('rollback changed')

contract_freeze=json.loads((ROOT/'PRIMITIVE-2H_CONTRACT_FREEZE.json').read_text())
contracts_doc=json.loads((RES/'PRIMITIVE-2H_DISCOVERED_CONTRACTS.json').read_text())
if sha_file(RES/'PRIMITIVE-2H_DISCOVERED_CONTRACTS.json') != contract_freeze['contracts_file_sha256']:
    raise RuntimeError('discovered contract changed')
if contracts_doc['contracts_sha256'] != contract_freeze['contracts_sha256']:
    raise RuntimeError('contract logical hash changed')

cal=json.loads((FIX/'CALIBRATION_DATA.json').read_text())['relations']
catalog=json.loads((ROOT/'PRIMITIVE-2H_ANONYMOUS_PROBES.json').read_text())['relations']
secret=json.loads((FIX/'EXPERIMENTER_SECRET_PROBE_MAP.json').read_text())
secret_map=secret['probe_semantics']
hidden_contracts=secret['contracts']
suite=json.loads((FIX/'CASE_SUITE.json').read_text())
wdoc=json.loads((FIX/'TEST_WITNESS_LEDGERS.json').read_text())
wmap={r['fixture_id']:r for r in wdoc['records']}
known_suite=json.loads((P2D/'PRIMITIVE-2D_FIXTURES'/'CHALLENGE_SUITE.json').read_text())
p2b_graphs=json.loads((P2B/'PRIMITIVE-2B_FIXTURES'/'RECURSIVE_STABILITY_GRAPHS.json').read_text())
p2b_map={f['fixture_id']:f for f in p2b_graphs['fixtures']}
p2e_graphs=json.loads((P2E/'PRIMITIVE-2E_FIXTURES'/'CONFIRMATION_GRAPHS.json').read_text())
p2e_map={f['fixture_id']:f for f in p2e_graphs['fixtures']}

class BindingComposer(nn.Module):
    def __init__(self):
        super().__init__()
        self.refenc=nn.Sequential(nn.Linear(24,32),nn.ReLU(),nn.Linear(32,32),nn.ReLU())
        self.body=nn.Sequential(nn.Linear(332,128),nn.ReLU(),nn.Linear(128,128),nn.ReLU())
        self.bind=nn.Linear(128,3)
        self.rel=nn.Linear(128,5)
        self.ssel=nn.Linear(128,4)
        self.osel=nn.Linear(128,4)
    def forward(self,acts,rels,refs):
        rb=((refs.unsqueeze(-1)>>bitpos)&1).float()
        e=self.refenc(rb)
        diffs=torch.cat([(e[:,i]-e[:,j]).abs() for i,j in itertools.combinations(range(4),2)],dim=1)
        meta=torch.cat([
            F.one_hot(acts[:,0],2).float(),F.one_hot(acts[:,1],2).float(),
            F.one_hot(rels[:,0],4).float(),F.one_hot(rels[:,1],4).float()
        ],dim=1)
        h=self.body(torch.cat([e.flatten(1),diffs,meta],dim=1))
        return self.bind(h),self.rel(h),self.ssel(h),self.osel(h)

def load_model(seed):
    m=BindingComposer()
    m.load_state_dict(torch.load(P2A/'models'/f'M2_seed_{seed}.pt',map_location='cpu',weights_only=True))
    m.eval()
    return m

def oracle_pair(l,r):
    ls,lr,lo=l; rs,rr,ro=r
    key=f'{I2R[lr]}|{I2R[rr]}'
    if lo==rs and key in RULES:
        return (ls,R2I[RULES[key]],ro)
    key=f'{I2R[rr]}|{I2R[lr]}'
    if ro==ls and key in RULES:
        return (rs,R2I[RULES[key]],lo)
    return None

def oracle_closure(fx):
    facts={(int(p['subject']),R2I[p['relation']],int(p['object'])) for p in fx['inputs']}
    while True:
        arr=list(facts); new=set()
        for l in arr:
            for r in arr:
                x=oracle_pair(l,r)
                if x is not None and x not in facts:
                    new.add(x)
        if not new:
            return facts
        facts |= new

def predict_candidates(model,packets,pairs,chunk=4096):
    pkt=torch.tensor(packets,dtype=torch.long)
    for st in range(0,len(pairs),chunk):
        ij=pairs[st:st+chunk]
        ii=torch.tensor([x[0] for x in ij],dtype=torch.long)
        jj=torch.tensor([x[1] for x in ij],dtype=torch.long)
        left=pkt[ii]; right=pkt[jj]
        acts=torch.stack([left[:,1],right[:,1]],dim=1)
        rels=torch.stack([left[:,3],right[:,3]],dim=1)
        refs=torch.stack([left[:,2],left[:,4],right[:,2],right[:,4]],dim=1)
        with torch.no_grad():
            pb,pr,ps,po=[x.argmax(-1) for x in model(acts,rels,refs)]
        mask=(pb!=0)&(pr!=RO_NONE)
        sel=torch.nonzero(mask,as_tuple=False).flatten()
        for t in sel.tolist():
            i,j=ij[t]; slots=refs[t]
            yield (int(slots[int(ps[t])]),int(pr[t]),int(slots[int(po[t])])),i,j

def audited_run(model,fx):
    gold=oracle_closure(fx)
    packets=[[int(p['id']),A2I[p['act']],int(p['subject']),R2I[p['relation']],int(p['object']),1000] for p in fx['inputs']]
    facts=[(p[2],p[3],p[4]) for p in packets]
    fact_to_idx={f:i for i,f in enumerate(facts)}
    is_input={f:True for f in facts}
    supports={f:set() for f in facts}
    next_ref=max(p[0] for p in packets)+1
    frontier=list(range(len(packets)))
    rounds=0; pair_evals=0
    while frontier and rounds<int(fx['max_rounds']):
        rounds+=1
        n=len(packets); fset=set(frontier)
        pairs=[(i,j) for i in range(n) for j in range(n) if i!=j and (i in fset or j in fset)]
        pair_evals+=len(pairs)
        newfacts=set()
        for fact,li,ri in predict_candidates(model,packets,pairs):
            supports.setdefault(fact,set()).add((facts[li],facts[ri]))
            if fact not in fact_to_idx:
                newfacts.add(fact)
        if not newfacts:
            break
        frontier=[]
        for fact in sorted(newfacts):
            if fact in fact_to_idx:
                continue
            s,r,o=fact
            p=[next_ref,A2I['DERIVE'],s,r,o,1000]; next_ref+=1
            idx=len(packets)
            packets.append(p); facts.append(fact); fact_to_idx[fact]=idx
            is_input[fact]=False; frontier.append(idx)
    final=set(facts)
    return {'gold':gold,'final':final,'bad':final-gold,'supports':supports,'is_input':is_input,'rounds':rounds,'pair_evaluations':pair_evals}

def justification_dag(run,challenged):
    active={f for f,v in run['is_input'].items() if v and f not in challenged}
    changed=True
    while changed:
        changed=False
        for fact in run['final']:
            if fact in active or fact in challenged or run['is_input'].get(fact,False):
                continue
            for l,r in run['supports'].get(fact,set()):
                if l in active and r in active:
                    active.add(fact); changed=True; break
    return active

def truth_from_signals(rel,vals):
    if rel=='BEFORE': return int(vals['same_component'] and vals['rank_lt'])
    if rel=='PART_OF': return int(vals['same_component'] and vals['low_gt'] and vals['high_lt'])
    if rel=='ASSIGNED_TO': return int(vals['assignment_match'])
    if rel=='LOCATED_IN': return int(vals['location_match'])
    raise KeyError(rel)

def signals_for_fact(fact,w):
    s,r,o=fact; rel=I2R[r]; ss=str(s); oo=str(o)
    if rel=='BEFORE':
        s_exists=ss in w['order_component'] and ss in w['order_rank']
        o_exists=oo in w['order_component'] and oo in w['order_rank']
        same=int(s_exists and o_exists and w['order_component'][ss]==w['order_component'][oo])
        lt=int(s_exists and o_exists and w['order_rank'][ss] < w['order_rank'][oo])
        neq=int(s_exists and o_exists and w['order_rank'][ss] != w['order_rank'][oo])
        vals={'same_component':same,'rank_lt':lt,'rank_neq':neq,'subject_exists':int(s_exists),'object_exists':int(o_exists)}
    elif rel=='PART_OF':
        s_exists=ss in w['containment_component'] and ss in w['interval_low'] and ss in w['interval_high']
        o_exists=oo in w['containment_component'] and oo in w['interval_low'] and oo in w['interval_high']
        same=int(s_exists and o_exists and w['containment_component'][ss]==w['containment_component'][oo])
        low_gt=int(s_exists and o_exists and w['interval_low'][ss] > w['interval_low'][oo])
        high_lt=int(s_exists and o_exists and w['interval_high'][ss] < w['interval_high'][oo])
        overlap=int(s_exists and o_exists and max(w['interval_low'][ss],w['interval_low'][oo]) <= min(w['interval_high'][ss],w['interval_high'][oo]))
        vals={'same_component':same,'low_gt':low_gt,'high_lt':high_lt,'interval_overlap':overlap,'subject_exists':int(s_exists),'object_exists':int(o_exists)}
    elif rel=='ASSIGNED_TO':
        has=ss in w['assignment_zone']
        match=int(has and int(w['assignment_zone'][ss])==o)
        seen=int(o in set(int(x) for x in w['assignment_zone'].values()))
        vals={'assignment_match':match,'subject_has_assignment':int(has),'object_seen_as_zone':seen,'parity_proxy':(s^o)&1}
    elif rel=='LOCATED_IN':
        has=ss in w['location']
        match=int(has and int(w['location'][ss])==o)
        seen=int(o in set(int(x) for x in w['location'].values()))
        vals={'location_match':match,'subject_has_location':int(has),'object_seen_as_location':seen,'parity_proxy':(s^o)&1}
    else:
        raise KeyError(rel)
    vals['hash_proxy']=int(hashlib.sha256(f'{s}|{rel}|{o}|probe'.encode()).digest()[0]&1)
    return vals

def probe_value(rel,pid,fact,w):
    semantic=secret_map[rel][pid]
    vals=signals_for_fact(fact,w)
    if semantic=='direct_truth':
        return truth_from_signals(rel,vals)
    return int(vals[semantic])

def learn_lookup(rows,subset):
    table={}
    for row in rows:
        key=tuple(row['probes'][p] for p in subset)
        y=int(row['verified_label'])
        if key in table and table[key]!=y:
            return None
        table[key]=y
    return table

def baseline_contract(rel,planner):
    d=cal[rel]; probes=sorted(d['probe_costs'])
    if planner=='FULL_PROBE_LOOKUP':
        subset=tuple(probes)
    elif planner=='CHEAPEST_SINGLE_PROBE':
        subset=(min(probes,key=lambda p:(d['probe_costs'][p],p)),)
    else:
        raise KeyError(planner)
    table=learn_lookup(d['discovery'],subset)
    valid=True
    if table is None:
        valid=False; table={}
    else:
        for row in d['validation']:
            key=tuple(row['probes'][p] for p in subset)
            if key not in table or table[key]!=int(row['verified_label']):
                valid=False; break
    return {'probe_ids':list(subset),'cost_per_fact':sum(d['probe_costs'][p] for p in subset),'lookup':{','.join(map(str,k)):v for k,v in table.items()},'valid':valid}

primary_contracts=contracts_doc['contracts']
baseline_contracts={p:{rel:baseline_contract(rel,p) for rel in RELS} for p in ['FULL_PROBE_LOOKUP','CHEAPEST_SINGLE_PROBE']}

def decision_from_contract(contract,rel,fact,w):
    subset=contract['probe_ids']
    key=tuple(probe_value(rel,p,fact,w) for p in subset)
    skey=','.join(map(str,key))
    if not contract.get('valid',True) or skey not in contract['lookup']:
        return 'ABSTAIN',contract['cost_per_fact']
    y=int(contract['lookup'][skey])
    return ('SUPPORT' if y==1 else 'CHALLENGE'),contract['cost_per_fact']

def planner_challenges(run,w,planner):
    challenged=set(); cost=0; verified=0; abstained=0
    for fact in sorted(run['final']):
        if run['is_input'].get(fact,False):
            continue
        rel=I2R[fact[1]]
        if planner=='MIN_COST_CONTRACT_DISCOVERY':
            contract=primary_contracts[rel]
        else:
            contract=baseline_contracts[planner][rel]
        decision,c=decision_from_contract(contract,rel,fact,w)
        cost+=c
        if decision=='ABSTAIN':
            abstained+=1
        else:
            verified+=1
            if decision=='CHALLENGE':
                challenged.add(fact)
    return challenged,{'total_observation_cost':cost,'verified_fact_count':verified,'abstained_fact_count':abstained}

def score_case(seed,fx,model,w,expected=None,surface='CONFIRMATION'):
    run=audited_run(model,fx)
    baseline_equiv=True
    if expected is not None:
        recall=len(run['final']&run['gold'])/len(run['gold'])
        baseline_equiv=(len(run['bad'])==expected['baseline_bad_packet_count'] and len(run['final']-run['gold'])==expected['baseline_false_positive_facts'] and abs(recall-expected['baseline_recall'])<1e-12)
    variants={}
    for planner in ['FULL_PROBE_LOOKUP','CHEAPEST_SINGLE_PROBE','MIN_COST_CONTRACT_DISCOVERY']:
        ch,meta=planner_challenges(run,w,planner)
        active=justification_dag(run,ch)
        bad_after=active-run['gold']; fn=run['gold']-active
        variants[planner]={
            'challenged_fact_count':len(ch),
            'challenged_bad_fact_count':len(ch&run['bad']),
            'challenged_valid_fact_count':len(ch&run['gold']),
            'active_bad_fact_count_after_rollback':len(bad_after),
            'false_negative_fact_count_after_rollback':len(fn),
            'oracle_valid_recall_after_rollback':len(active&run['gold'])/len(run['gold']),
            'exact_graph_match_after_rollback':active==run['gold'],
            **meta,
        }
    return {'surface':surface,'seed':seed,'fixture_id':fx['fixture_id'],'family':fx['family'],'scale':fx['scale'],'baseline_equivalence_pass':baseline_equiv,'baseline_bad_fact_count':len(run['bad']),'baseline_fact_count':len(run['final']),'gold_fact_count':len(run['gold']),'variants':variants}

def experimenter_minimum_cost(rel):
    cfg=hidden_contracts[rel]
    relevant=sum(cfg['relevant_signal_costs'].values())
    return min(relevant,cfg['direct_probe_cost'])

# Contract audit against hidden semantics, after discovery is frozen.
contract_audit={}
for rel,c in primary_contracts.items():
    contract_audit[rel]={
        'discovered_probe_ids':c['probe_ids'],
        'discovered_cost':c['cost_per_fact'],
        'experimenter_minimum_cost':experimenter_minimum_cost(rel),
        'cost_optimal':c['cost_per_fact']==experimenter_minimum_cost(rel),
        'validation_errors':c['validation_errors'],
        'validation_unseen':c['validation_unseen'],
    }

models={s:load_model(s) for s in (13,29,61)}
case_results=[]; t0=time.time()
for c in known_suite['cases']:
    fx=p2b_map[c['fixture_id']]
    case_results.append(score_case(c['seed'],fx,models[c['seed']],wmap[fx['fixture_id']],expected=c,surface='KNOWN'))
for seed in (13,29,61):
    for fid in suite['confirmation_fixture_ids']:
        fx=p2e_map[fid]
        case_results.append(score_case(seed,fx,models[seed],wmap[fid],surface='CONFIRMATION'))

known=[c for c in case_results if c['surface']=='KNOWN']
conf=[c for c in case_results if c['surface']=='CONFIRMATION']
known_equiv=all(c['baseline_equivalence_pass'] for c in known)

def agg(sub,p):
    rs=[c['variants'][p] for c in sub]
    return {
        'case_count':len(rs),
        'exact_after_rollback_count':sum(r['exact_graph_match_after_rollback'] for r in rs),
        'active_bad_after_total':sum(r['active_bad_fact_count_after_rollback'] for r in rs),
        'valid_false_challenges_total':sum(r['challenged_valid_fact_count'] for r in rs),
        'min_post_rollback_recall':min(r['oracle_valid_recall_after_rollback'] for r in rs),
        'total_observation_cost':sum(r['total_observation_cost'] for r in rs),
        'verified_fact_count':sum(r['verified_fact_count'] for r in rs),
        'abstained_fact_count':sum(r['abstained_fact_count'] for r in rs),
    }

summary={}
for p in ['FULL_PROBE_LOOKUP','CHEAPEST_SINGLE_PROBE','MIN_COST_CONTRACT_DISCOVERY']:
    summary[p]={'known':agg(known,p),'confirmation':agg(conf,p),'all':agg(case_results,p)}

primary=summary['MIN_COST_CONTRACT_DISCOVERY']['all']
all_contracts_optimal=all(x['cost_optimal'] and x['validation_errors']==0 and x['validation_unseen']==0 for x in contract_audit.values())
primary_pass=(
    known_equiv and
    summary['MIN_COST_CONTRACT_DISCOVERY']['known']['exact_after_rollback_count']==9 and
    summary['MIN_COST_CONTRACT_DISCOVERY']['confirmation']['exact_after_rollback_count']==90 and
    primary['active_bad_after_total']==0 and
    primary['valid_false_challenges_total']==0 and
    primary['min_post_rollback_recall']==1.0 and
    primary['abstained_fact_count']==0 and
    all_contracts_optimal
)
if not known_equiv:
    terminal='EXPERIMENT_INVALID'
elif primary_pass:
    terminal='VERIFICATION_CONTRACT_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE'
elif summary['MIN_COST_CONTRACT_DISCOVERY']['known']['exact_after_rollback_count']==9:
    terminal='PARTIAL'
else:
    terminal='CONTRACT_DISCOVERY_INSUFFICIENT'

results={
    'experiment':'PRIMITIVE-2H','version':'0.1.1','terminal_verdict':terminal,
    'freeze_sha256':freeze['freeze_sha256'],
    'contract_freeze_sha256':contract_freeze['contract_freeze_sha256'],
    'known_baseline_equivalence':'PASS' if known_equiv else 'FAIL',
    'case_count':len(case_results),
    'elapsed_seconds':time.time()-t0,
    'contract_audit':contract_audit,
    'planner_summary':summary,
    'cases':case_results,
}
hash_view=dict(results); hash_view.pop('elapsed_seconds',None)
results['results_sha256']=hashlib.sha256(canon(hash_view).encode()).hexdigest()
(RES/'PRIMITIVE-2H_RESULTS.json').write_text(json.dumps(results,indent=2))
print('PRIMITIVE-2H',terminal,'cases',len(case_results),'seconds',round(results['elapsed_seconds'],2))
print('CONTRACT_AUDIT',json.dumps(contract_audit,sort_keys=True))
for p,s in summary.items():
    print(p,json.dumps(s['all'],sort_keys=True))
