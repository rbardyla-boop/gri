# PRIMITIVE-2H — VERIFICATION-CONTRACT DISCOVERY

**Version:** 0.1.1  
**Status:** FROZEN BEFORE CONTRACT DISCOVERY  
**Experiment SHA-256:** `64fee3ea45a023b29c58b53d001777fa20726319a1a6721b854ea446fd54ea61`  
**Calibration SHA-256:** `9bf2de8d45e9241fce3245841c411184e1c256b32c9b8519a8b3fbe46cf09fd6`  
**Anonymous-probe catalog SHA-256:** `903b7203fd410e704e43b5a8a7eb3a81f3db2ef6d7733fe37ce297d61082d6f2`

## Question

> Given a novel derived packet and a collection of observable variables whose relevance is not supplied, can the machine identify which observations discriminate true from false, acquire the minimum-cost discovered contract, and use the unchanged PRIMITIVE-2D rollback?

## What changes from PRIMITIVE-2G

PRIMITIVE-2G was told which witness slots mattered and which channels covered them.

PRIMITIVE-2H removes that information.

The planner sees only:

```text
anonymous probe IDs
probe costs
historical probe outcomes
historically verified TRUE/FALSE labels
```

Probe semantics are experimenter-only.

## Discovery mechanism

For each relation independently:

1. enumerate candidate subsets of anonymous probes;
2. test whether the subset's observed value tuple deterministically maps to verified label on discovery calibration;
3. reject any subset with nonzero held-out calibration error;
4. choose minimum total acquisition cost;
5. tie-break by fewer probes, then lexicographic probe IDs;
6. freeze the discovered tuple→label contract before test scoring.

No symbolic verification formula is supplied.

## Test surface

The discovered contracts are applied to the same 99 acyclic learned-reasoner model/graph cases used in PRIMITIVE-2G.

## Frozen lower layers

```text
learned reasoner: unchanged
semantic primitive: unchanged
justification ledger: unchanged
PRIMITIVE-2D rollback: unchanged
```

## Strict pass

A discovered contract must achieve:

```text
0 calibration validation errors
99/99 exact post-rollback test cases
0 active bad facts
0 valid facts challenged
100% valid recall
0 abstentions
minimum sufficient anonymous-probe cost
exact deterministic replay
```

A cheap but insufficient probe is failure, not efficiency.

## v0.1.1 pre-discovery calibration repair

Before contract discovery or test scoring, the first calibration construction was rejected because deterministic nuisance schedules accidentally made a cheap nuisance probe perfectly predictive for two one-bit relations.

Repair:

```text
calibration → complete factorial over every anonymous binary probe source
discovery   → one complete factorial copy
validation  → second complete factorial copy
```

This guarantees that an irrelevant probe cannot appear sufficient merely because of sampling correlation.

No parent model, final test case, probe cost, hidden verification contract, planner algorithm, rollback mechanism, or success gate changed.
