# PRIMITIVE-2H Conclusion

**Terminal verdict:** `VERIFICATION_CONTRACT_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Contract discovery

The planner was never told what any anonymous probe meant.

It discovered:

```text
BEFORE      -> P02 + P06      cost 4
PART_OF     -> P01 + P02 + P06 cost 7
ASSIGNED_TO -> P05            cost 3
LOCATED_IN  -> P01            cost 3
```

All discovered contracts had zero held-out calibration error and matched the experimenter-side minimum sufficient cost.

After scoring, the experimenter-only map showed that the selected probes corresponded exactly to the independent evidence needed by the hidden world contracts:

```text
BEFORE      -> same-component + rank-less-than
PART_OF     -> same-component + lower-bound-greater + upper-bound-less
ASSIGNED_TO -> assignment-match
LOCATED_IN  -> location-match
```

That semantic decoding was not available during discovery.

## Final test

The discovered contracts were frozen before being applied to the learned reasoner.

```text
99/99 exact post-rollback cases
0 bad facts remaining
0 valid facts challenged
100% valid recall
0 abstentions
11,464 derived facts verified
```

Observation cost:

```text
FULL_PROBE_LOOKUP             270526
MIN_COST_CONTRACT_DISCOVERY    66058
reduction                      75.58%
```

The cheap-single-probe control spent only 11824 cost units, but its selected probes were not sufficient verification contracts. It abstained on all 11464 derived facts and left all 375 bad facts active.

## Supported claim

> Within the frozen synthetic relation families, a machine can discover a minimum-cost verification contract from anonymous historical observations and verified outcomes, then generalize that discovered contract to novel learned-derived packets and preserve exact epistemic rollback without being given the semantic relevance of the probes.

## What this does not establish

PRIMITIVE-2H still receives historical TRUE/FALSE calibration labels and a fixed inventory of available probes.

It does not establish that the machine can:

- invent a new observable variable;
- design a novel physical intervention;
- identify causality from passive correlation alone;
- discover a verification contract when no labeled calibration exists;
- decide which new sensor or experiment should be constructed;
- solve open-world verification universally.

## New largest gap

The remaining problem is now narrower:

> Can the machine construct a discriminating experiment when no sufficient verification contract has been supplied by history?

That is a transition from contract discovery to **intervention discovery / active causal experiment design**.
