# PRIMITIVE-2H Results

**Terminal verdict:** `VERIFICATION_CONTRACT_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Known baseline equivalence:** `PASS`  
**Canonical deterministic replay:** `PASS`  
**Test cases:** 99  

## Discovered anonymous contracts

| Relation | Probe IDs | Cost/fact | Hidden minimum | Validation errors |
|---|---|---:|---:|---:|
| BEFORE | P02, P06 | 4 | 4 | 0 |
| PART_OF | P01, P02, P06 | 7 | 7 | 0 |
| ASSIGNED_TO | P05 | 3 | 3 | 0 |
| LOCATED_IN | P01 | 3 | 3 | 0 |

## Planner comparison

| Planner | Exact cases | Bad left | Valid challenged | Abstentions | Observation cost |
|---|---:|---:|---:|---:|---:|
| FULL_PROBE_LOOKUP | 99/99 | 0 | 0 | 0 | 270526 |
| CHEAPEST_SINGLE_PROBE | 86/99 | 375 | 0 | 11464 | 11824 |
| MIN_COST_CONTRACT_DISCOVERY | 99/99 | 0 | 0 | 0 | 66058 |
