# PRIMITIVE-2A SPECIFICATION
## Learned Reference Binding and Operand Selection

**Version:** 0.1.1  
**Status:** FROZEN BEFORE TRAINING  
**Experiment SHA-256:** `1361282149b7968753fcbf9ee12db713cb86dc3f3f6d4b2fe094563e639bda9c`  
**Oracle SHA-256:** `77dc440167e693048e1b301405caf7f9337e4b46b4b7d5a2fc9d48057bbe91c2`  
**Reference-pool SHA-256:** `509307b8dbddbf7f303a7de26fc5f522861908e2a90a9e12324885da7ff75a55`  
**Held-out graph SHA-256:** `a3b6e4768004511f647ac2d2c41ef34bbd55176de45c343924c0a7affa75ca35`  
**Held-out pair SHA-256:** `1ea0dcf55b56e3be877d5bd342455052fb7eaca97ccf9c875d9f15d13d4ee58c`

## Research question

> Can a learned mechanism determine which packets interact, which references bind, which SUBJECT/OBJECT references survive, and which RELATION is emitted, then generalize to unseen numeric references and longer structures?

## Removed hard-coded inference machinery

PRIMITIVE-2 supplied:

```text
left.OBJECT == right.SUBJECT
output SUBJECT = left.SUBJECT
output OBJECT  = right.OBJECT
```

PRIMITIVE-2A forbids those runtime rules.

The runtime enumerates every ordered packet pair without semantic filtering.

For each pair the neural model must emit:

```text
BINDING:
NONE | FORWARD | REVERSE

RELATION:
BEFORE | PART_OF | ASSIGNED_TO | LOCATED_IN | NONE

SUBJECT SELECTOR:
L_SUBJECT | L_OBJECT | R_SUBJECT | R_OBJECT

OBJECT SELECTOR:
L_SUBJECT | L_OBJECT | R_SUBJECT | R_OBJECT
```

The runtime follows those learned outputs. It does not verify the learned binding with an equality predicate.

## Reference representation

References are arbitrary 24-bit numeric IDs.

Training and held-out ID pools are disjoint.

The model receives raw reference bits. It receives no entity semantics.

## Generic neural comparison

The model architecture may compute generic learned embeddings and pairwise continuous difference features between reference embeddings.

That is architecture, not a hard equality rule.

No boolean `reference_a == reference_b` feature is supplied.

## Strict gate

Every preregistered seed must achieve 100% on:

```text
held-out pair binding classification
held-out pair output relation
held-out positive operand selectors
held-out graph precision
held-out graph recall
held-out exact graph match
held-out termination
```

and authoritative trajectories must contain no strings/natural-language intermediates.

## v0.1.1 pre-training consistency patch

Before the first training run, the architecture declaration was corrected:

```text
pair-body input width: 256 → 332
```

Reason: four 32-dimensional reference embeddings (128), six pairwise 32-dimensional absolute-difference vectors (192), and ACT/RELATION one-hot features (12) total 332 inputs.

No fixtures, labels, reference pools, oracle rules, training seeds, training steps, or pass gates changed.
