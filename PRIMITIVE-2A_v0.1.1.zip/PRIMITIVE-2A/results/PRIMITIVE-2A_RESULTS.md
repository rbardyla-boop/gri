# PRIMITIVE-2A Results

**Terminal verdict:** `PARTIAL`  
**Seed gate:** 2/3 pass; all 3 required  

## Pair-level held-out exam

All three seeds achieved:

```text
binding accuracy  = 1.000
relation accuracy = 1.000
selector accuracy = 1.000
```

## Iterated graph inference

| Seed | Exact graphs | Min precision | Min recall | Verdict |
|---:|---:|---:|---:|---|
| 13 | 17/18 | 0.983607 | 1.000000 | FAIL |
| 29 | 18/18 | 1.000000 | 1.000000 | PASS |
| 61 | 18/18 | 1.000000 | 1.000000 | PASS |

## Failure localization

- Seed **13**, `H3_PARTOF_16` (LONG_CHAIN): 2 false positive, 0 false negatives; precision 0.983607, recall 1.000000.
