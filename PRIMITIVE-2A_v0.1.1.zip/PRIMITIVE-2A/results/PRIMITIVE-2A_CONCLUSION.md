# PRIMITIVE-2A Conclusion

**Terminal verdict:** `PARTIAL`

The experiment removed these PRIMITIVE-2 runtime rules:

```text
left.OBJECT == right.SUBJECT
output SUBJECT = left.SUBJECT
output OBJECT  = right.OBJECT
relation-specific composition rule
```

The learned model instead received raw numeric packet fields and emitted:

```text
BINDING
RELATION
SUBJECT SELECTOR
OBJECT SELECTOR
```

The runtime enumerated every ordered pair and obeyed the model's outputs without verifying reference equality.

## What succeeded

All three preregistered seeds scored exactly:

```text
held-out binding classification = 100%
held-out output relation        = 100%
held-out positive selectors     = 100%
```

Training and held-out reference pools were disjoint.

Two seeds (`29`, `61`) also achieved:

```text
18/18 held-out graph exact matches
precision = 1.0
recall    = 1.0
termination = 1.0
```

This shows that learned reference binding and learned operand selection are possible for the frozen task family.

## Why the terminal verdict is not PASS

The pass gate required **all three** preregistered seeds.

Seed `13` achieved perfect held-out pair-level classification but only:

```text
17/18 exact held-out graphs
minimum precision = 0.983606557377
minimum recall    = 1.0
```

Failure localization:

```json
[
  {
    "seed": 13,
    "fixture_id": "H3_PARTOF_16",
    "group": "LONG_CHAIN",
    "precision": 0.9836065573770492,
    "recall": 1.0,
    "false_positive_count": 2,
    "false_negative_count": 0,
    "predicted_fact_count": 122,
    "gold_fact_count": 120,
    "rounds": 5,
    "pair_evaluations": 27664
  }
]
```

The failure emerged only under repeated inference.

Therefore the stronger robustness claim is not demonstrated.

## Scientific interpretation

This is a useful failure.

It separates two claims that looked similar:

```text
Can the network identify unseen packet bindings locally?
YES — 3/3 seeds.

Does perfect local held-out accuracy guarantee stable iterated reasoning?
NO — not under the frozen all-seeds test.
```

A rare local decision error outside the finite pair exam can enter the packet state, then become input to later rounds. Iteration amplifies the mistake.

The result therefore exposes a new substrate requirement:

> Packet-native learned inference needs error stability under recursive self-consumption, not merely high local transformation accuracy.

PRIMITIVE-2A should not be silently retrained or enlarged against the held-out failure.

The next independent unit should diagnose robustness using a new preregistered distribution or stability mechanism, while preserving this failure as evidence.
