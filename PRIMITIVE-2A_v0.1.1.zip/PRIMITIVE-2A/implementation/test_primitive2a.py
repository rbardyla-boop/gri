#!/usr/bin/env python3
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2A_RESULTS.json").read_text())
assert r["terminal_verdict"]=="PARTIAL"
assert r["seed_pass_count"]==2
assert r["seed_count"]==3
assert r["all_seeds_required"] is True
assert r["all_seeds_pass"] is False
assert r["heldout_pair_exam_all_seeds"]=={
    "binding_accuracy":1.0,
    "relation_accuracy":1.0,
    "selector_accuracy":1.0
}
assert len(r["failure_details"])==1
assert r["failure_details"][0]["seed"]==13
print("PRIMITIVE_2A_TEST_PASS")
