# PRIMITIVE-2O Conclusion

**Terminal verdict:** `PRIMITIVE_SHAPE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE`

The exhaustive old 2N-style primitive shape had exact support in:

```text
0/40 worlds
```

The primary resource-growth system recovered the exact minimum-cost shape in:

```text
40/40 worlds
```

and the exact hidden enumerated program in `40/40` worlds.

Held-out and intervention prediction were both `1.000000`.

The important difference from PRIMITIVE-2M is that the selector was not offered structural repair names. It received only resource tuples and costs. The same search rule handled all five pressures.

The maximum allocation costs 18 units/world. Minimum growth spent 184 total units versus 720 for always allocating maximum resources, saving 536 units.

## Supported claim

Within the frozen numeric resource grammar and bounded deterministic program enumerator:

> When the old generic primitive shape has empty exact support, a machine can identify which generic representational resources must grow, stop at the unique minimum-cost sufficient shape, and preserve exact unseen and interventional prediction.

## Boundary

The resource axes themselves were still supplied: source references, temporal range, state bits, node count, and internal connectivity. PRIMITIVE-2O therefore demonstrates adaptive primitive-shape growth, not invention of an entirely new resource axis.

That is now the next gap.
