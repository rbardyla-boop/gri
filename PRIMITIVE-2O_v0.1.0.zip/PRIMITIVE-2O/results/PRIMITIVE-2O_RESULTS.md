# PRIMITIVE-2O Results

**Terminal verdict:** `PRIMITIVE_SHAPE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Deterministic world replay:** `PASS`  
**Worlds:** 40

| Target pressure | Worlds | Exact minimum shape | Resource cost |
|---|---:|---:|---:|
| SOURCE_REFERENCES | 8 | 8/8 | 3.0 |
| TEMPORAL_OFFSETS | 8 | 8/8 | 4.0 |
| STATE_SYMBOLS | 8 | 8/8 | 4.0 |
| COMPOSITION_NODES | 8 | 8/8 | 5.0 |
| INTERNAL_TOPOLOGY | 8 | 8/8 | 7.0 |

## Primary system

- Old exhaustive shape exact support: `0/40`
- Minimum shape exact: `40/40`
- Hidden program exact: `40/40`
- Held-out accuracy: `1.000000`
- Interventional accuracy: `1.000000`
- Selected resource cost: `184`
- Max-allocation cost: `720`
- Cost saved: `536`
