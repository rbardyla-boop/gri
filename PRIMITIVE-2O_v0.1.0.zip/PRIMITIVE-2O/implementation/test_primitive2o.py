#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/'results'/'PRIMITIVE-2O_RESULTS.json').read_text())
rp=json.loads((ROOT/'results'/'PRIMITIVE-2O_REPLAY_CHECK.json').read_text())
p=r['system_summary']['MIN_COST_RESOURCE_GROWTH']
assert r['terminal_verdict']=='PRIMITIVE_SHAPE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE'
assert p['old_shape_exact_support_worlds']==0
assert p['shape_exact_worlds']==40
assert p['program_exact_worlds']==40
assert p['minimum_cost_exact_worlds']==40
assert p['mean_heldout_accuracy']==1.0
assert p['mean_interventional_accuracy']==1.0
assert rp['world_payload_replay']=='PASS'
print('PRIMITIVE_2O_TEST_PASS')
