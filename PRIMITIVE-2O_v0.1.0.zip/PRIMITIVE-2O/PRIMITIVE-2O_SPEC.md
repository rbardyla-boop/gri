# PRIMITIVE-2O — PRIMITIVE-SHAPE ESCAPE

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `ed29fa01cd20357e41d6ffb685cb3bd0f0c79368eb71d9c44ebbe71a1ee42630`

## Question

> When the current generic primitive-construction language itself has empty support, can the system determine which resource dimensions of that language must grow and construct the minimum-cost expanded primitive shape?

## Resource grammar

The selector does not receive named repairs. A candidate shape is only:

```text
(source_reference_budget,
 max_temporal_offset,
 state_bits,
 composition_nodes,
 internal_edge_budget)
```

Frozen ranges:

```text
source refs      3 or 4
temporal offset  2 or 4
state bits       1 or 2      # 2 or 4 symbols
nodes            1 or 2
internal edge    0 or 1
```

Resource growth has explicit costs. The selector searches by total cost.

## Frozen worlds

40 worlds, balanced across five experimenter-only pressures:

```text
SOURCE_REFERENCES
TEMPORAL_OFFSETS
STATE_SYMBOLS
COMPOSITION_NODES
INTERNAL_TOPOLOGY
```

Those labels are audit metadata only. The selector sees numeric tuples and costs.

## Old-language firewall

The old 2N-style shape is checked exhaustively, not sampled:

```text
3 source references
lags <= 2
1 binary state
1 node
no internal edge
```

Every frozen world has zero exact support there.

## Expanded search

Expanded shapes use one deterministic universal program enumerator with 192 programs per shape. Every frozen world has one unique minimum-cost shape/program in that bounded enumerator.

## Validation

After the minimum resource shape is frozen:

```text
3 held-out trajectories
+
every heldout episode × every time × every root bit × both values
```

must be predicted exactly.

## Scope

PRIMITIVE-2O tests adaptive growth inside a bounded numeric resource grammar. It does not invent entirely new resource axes.
