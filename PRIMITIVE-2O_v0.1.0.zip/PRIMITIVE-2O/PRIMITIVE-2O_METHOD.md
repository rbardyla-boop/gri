# PRIMITIVE-2O METHOD

1. Freeze a numeric resource grammar rather than a menu of named repairs.
2. Base shape: 3 source references, temporal offset <=2, one state bit, one node, no internal edge.
3. Allow only numeric growth axes: source budget, temporal offset, state bits, node count, internal-edge budget.
4. Charge every growth axis using a frozen additive resource cost.
5. Exhaustively index the old 2N-style base language over four observable roots and lags 0..2.
6. Generate a deterministic bounded universal program catalog for every expanded resource tuple.
7. Freeze forty worlds: eight each whose unique minimum-cost explanation requires more source references, temporal depth, state symbols, composition nodes, or internal topology. Those labels are experimenter-only.
8. Retain a world only if the exhaustive old language has zero exact support and exactly one minimum-cost expanded shape/program exists.
9. Primary selector searches shapes by cost and stops at the first exact-support cost level.
10. Freeze the selected shape/program before validation.
11. Score three held-out trajectories and the complete root-bit intervention surface over those trajectories.
12. Recompute the complete world-level result payload independently and require exact equality.

Expanded-shape program search remains bounded by a deterministic universal enumerator. The experiment does not claim unrestricted new resource-axis invention.
