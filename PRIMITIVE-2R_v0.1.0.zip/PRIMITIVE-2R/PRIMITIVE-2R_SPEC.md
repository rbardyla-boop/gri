# PRIMITIVE-2R — OPEN BYTECODE SYNTHESIS

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `7f95b5e79544acdcd9389fa540ca6a9d7534bb79a1c357e61cadb41ad2f8fc0c`

## Question

> Given only raw micro-instructions, costs and residual collision examples—but no candidate program library—can the system construct the missing executable operator?

## Difference from PRIMITIVE-2Q

```text
2Q:
choose from 60 supplied bytecode programs

2R:
program catalog = NONE
construct instruction sequence from μL
```

## Bounded μL normal form

A program may allocate one or two integer registers.

For each of four token values it may synthesize zero or one raw effect:

```text
NOOP
ADD_IMM r,+1
ADD_IMM r,-1
SET_IMM r,0
```

A non-NOOP token handler compiles to:

```text
CMP_TOK token
BR_FALSE 1
<raw effect>
```

Two final outputs must be synthesized using:

```text
OUT_EQ_ZERO
OUT_GT_ZERO
```

This is open construction inside a bounded guarded-handler control-flow normal form.

It is not unrestricted arbitrary bytecode ordering.

## CEGIS

The engine begins from residual collision examples produced by the best saturated one-bit Ω0 model.

It then:

```text
cost-weighted beam synthesis
→ candidate program
→ full discovery verification
→ first counterexample added
→ repeat
```

Beam width may grow through:

```text
32 → 128 → 512 → 2048
```

## Independent oracle

After CEGIS produces a full exact program, an evaluator independently exhausts the entire bounded μL normal-form grammar.

The scientific gate requires the synthesized program to match the oracle's minimum cost and minimum behavioral operator class.

## Frozen worlds

18 worlds, selected from the full bounded grammar without preassembled templates:

```text
6 one-register additive regimes
6 one-register regimes using reset
6 two-register regimes
```

Those labels are audit-only resource descriptions.

## OOD

Discovery sequences have length <=12.

OOD sequences have length 20..40.

No CEGIS or beam search may rerun after OOD begins.

## Scope

PRIMITIVE-2R v0.1 tests unsupplied program construction, but only inside the frozen guarded-handler bytecode normal form.

A later unit must test arbitrary control-flow structure and, after that, instruction-substrate escape.
