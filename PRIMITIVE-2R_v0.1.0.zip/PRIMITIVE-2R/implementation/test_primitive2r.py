#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2R_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2R_REPLAY_CHECK.json").read_text())
p=r["system_summary"]["OPEN_CEGIS_BEAM_SYNTHESIS"]
assert r["terminal_verdict"]=="OPEN_BYTECODE_SYNTHESIS_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["world_count"]==18
assert r["system_summary"]["FORCE_OMEGA0"]["exact_support_worlds"]==0
assert p["cegis_success_worlds"]==18
assert p["full_discovery_exact_worlds"]==18
assert p["minimum_cost_exact_worlds"]==18
assert p["minimum_behavior_class_exact_worlds"]==18
assert p["ood_accuracy"]==1.0
assert p["cheaper_than_raw_history_worlds"]==18
assert p["max_cegis_rounds"]<=5
assert rp["exact_byte_replay"]=="PASS"
print("PRIMITIVE_2R_TEST_PASS")
