from pathlib import Path
import json, hashlib, itertools, math, os, subprocess, sys, zipfile, csv

ROOT=Path("/mnt/data/PRIMITIVE-2R")
FIX=ROOT/"PRIMITIVE-2R_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

def canon(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_file(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2R_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"],rec["name"]

micro=json.loads((ROOT/"PRIMITIVE-2R_MICROLANGUAGE.json").read_text())
search_spec=json.loads((ROOT/"PRIMITIVE-2R_SEARCH.json").read_text())
fixture=json.loads((FIX/"OPEN_SYNTHESIS_WORLDS.json").read_text())
DISC=fixture["discovery_inputs"]
OOD=fixture["ood_inputs"]
worlds=fixture["worlds"]

TOKENS=4
INSTR_COST={k:v["description_cost"] for k,v in micro["instruction_set"].items()}
RW=float(micro["cost"]["runtime"])
SW=float(micro["cost"]["state_bits"])

def effects(regs):
    e=[("NOOP",None,None)]
    for r in range(regs):
        e += [("ADD_IMM",r,1),("ADD_IMM",r,-1),("SET_IMM",r,0)]
    return e

def readouts(regs):
    out=[]
    for r in range(regs):
        out += [("OUT_EQ_ZERO",r),("OUT_GT_ZERO",r)]
    return out

def compile_program(regs,handlers,ro_pair):
    eff=effects(regs); loop=[]
    for tok,code in enumerate(handlers):
        op,r,arg=eff[code]
        if op=="NOOP":
            continue
        loop += [["CMP_TOK",tok],["BR_FALSE",1],[op,r,arg]]
    ros=readouts(regs)
    final=[]
    for oi,roi in enumerate(ro_pair):
        op,r=ros[roi]
        final.append([op,oi,r])
    return {"registers":regs,"loop":loop,"final":final}

def run_program(program,tokens):
    regs=[0]*program["registers"]; peak=[1]*program["registers"]; runtime=0; flag=False
    for tok in tokens:
        pc=0
        while pc<len(program["loop"]):
            ins=program["loop"][pc]; op=ins[0]; runtime+=INSTR_COST[op]
            if op=="CMP_TOK":
                flag=(tok==ins[1]); pc+=1
            elif op=="BR_FALSE":
                pc=pc+1+ins[1] if not flag else pc+1
            elif op=="ADD_IMM":
                regs[ins[1]]+=ins[2]
                peak[ins[1]]=max(peak[ins[1]],max(1,math.ceil(math.log2(abs(regs[ins[1]])+2))+1))
                pc+=1
            elif op=="SET_IMM":
                regs[ins[1]]=ins[2]; pc+=1
            else:
                raise ValueError(op)
    out=[0,0]
    for ins in program["final"]:
        op,oi,r=ins; runtime+=INSTR_COST[op]
        if op=="OUT_EQ_ZERO": out[oi]=int(regs[r]==0)
        elif op=="OUT_GT_ZERO": out[oi]=int(regs[r]>0)
        else: raise ValueError(op)
    return out,{"runtime":runtime,"state_bits":sum(peak)}

def desc_cost(program):
    return program["registers"]+sum(INSTR_COST[x[0]] for x in program["loop"])+sum(INSTR_COST[x[0]] for x in program["final"])

def total_cost(program,seqs):
    rt=0; st=0
    for s in seqs:
        _,m=run_program(program,s); rt+=m["runtime"]; st=max(st,m["state_bits"])
    return desc_cost(program)+RW*(rt/max(1,len(seqs)))+SW*st

def behavior_class(program):
    sig=[]
    for L in range(5):
        for s in itertools.product(range(TOKENS),repeat=L):
            sig.append(run_program(program,list(s))[0])
    return hashlib.sha256(canon(sig).encode()).hexdigest()

def bit_error(program,indices,outputs):
    err=0
    for i in indices:
        pred=run_program(program,DISC[i])[0]; gold=outputs[i]
        err+=int(pred[0]!=gold[0])+int(pred[1]!=gold[1])
    return err

def best_readout_for_partial(regs,handlers_prefix,active,outputs):
    handlers=list(handlers_prefix)+[0]*(TOKENS-len(handlers_prefix))
    best=None
    R=readouts(regs)
    for ro in itertools.product(range(len(R)),repeat=2):
        prog=compile_program(regs,handlers,ro)
        err=bit_error(prog,active,outputs)
        key=(err,desc_cost(prog),tuple(ro))
        if best is None or key<best[0]:
            best=(key,tuple(ro))
    return best

def beam_synthesize(active,outputs,width):
    candidates=[]
    for regs in (1,2):
        beam=[tuple()]
        E=effects(regs)
        expanded=0
        for _depth in range(TOKENS):
            next_items=[]
            for pref in beam:
                for code in range(len(E)):
                    npref=pref+(code,)
                    (err,dc,_ro),_=best_readout_for_partial(regs,npref,active,outputs)
                    next_items.append(((err,dc,npref),npref))
                    expanded+=1
            next_items.sort(key=lambda x:x[0])
            beam=[x[1] for x in next_items[:width]]
        R=readouts(regs)
        for handlers in beam:
            for ro in itertools.product(range(len(R)),repeat=2):
                prog=compile_program(regs,handlers,ro)
                if bit_error(prog,active,outputs)==0:
                    cost=total_cost(prog,[DISC[i] for i in active])
                    candidates.append((cost,desc_cost(prog),behavior_class(prog),canon(prog),regs,handlers,ro,prog,expanded))
    if not candidates:
        return None
    candidates.sort(key=lambda x:(x[0],x[1],x[2],x[3]))
    return candidates[0]

def cegis_synthesize(world):
    outputs=world["discovery_outputs"]
    active=[]
    for a,b in world["collision_pairs"][:4]:
        if a not in active: active.append(a)
        if b not in active: active.append(b)
    if len(active)<4:
        active=list(range(min(8,len(DISC))))
    rounds=[]; total_expanded=0
    for round_idx in range(40):
        found=None; used_width=None
        for width in search_spec["beam"]["width_schedule"]:
            found=beam_synthesize(active,outputs,width)
            if found is not None:
                used_width=width
                break
        if found is None:
            return None,rounds,total_expanded
        chosen=found[-2]
        total_expanded+=found[-1]
        fail=None
        for i in range(len(DISC)):
            if run_program(chosen,DISC[i])[0]!=outputs[i]:
                fail=i; break
        rounds.append({
            "round":round_idx+1,
            "active_example_count":len(active),
            "beam_width":used_width,
            "candidate_description_cost":desc_cost(chosen),
            "candidate_behavior_class":behavior_class(chosen),
            "full_discovery_counterexample":fail,
        })
        if fail is None:
            return chosen,rounds,total_expanded
        if fail not in active:
            active.append(fail)
        else:
            return None,rounds,total_expanded
    return None,rounds,total_expanded

def oracle_min(outputs):
    exact=[]
    for regs in (1,2):
        E=effects(regs); R=readouts(regs)
        for handlers in itertools.product(range(len(E)),repeat=TOKENS):
            for ro in itertools.product(range(len(R)),repeat=2):
                prog=compile_program(regs,handlers,ro)
                ok=True
                for i in range(len(DISC)):
                    if run_program(prog,DISC[i])[0]!=outputs[i]:
                        ok=False; break
                if ok:
                    c=total_cost(prog,DISC)
                    exact.append((c,desc_cost(prog),behavior_class(prog),canon(prog),prog))
    exact.sort(key=lambda x:(x[0],x[1],x[2],x[3]))
    minc=exact[0][0]
    mins=[x for x in exact if abs(x[0]-minc)<1e-12]
    classes=sorted(set(x[2] for x in mins))
    return minc,classes,mins[0][4],len(exact)

rows=[]; cegis_receipts=[]
for w in worlds:
    synthesized,rounds,expanded=cegis_synthesize(w)
    if synthesized is None:
        rows.append({"world_id":w["world_id"],"audit_resource_regime":w["audit_resource_regime"],"cegis_success":False})
        continue

    disc_exact=all(run_program(synthesized,DISC[i])[0]==w["discovery_outputs"][i] for i in range(len(DISC)))
    synth_class=behavior_class(synthesized)
    synth_disc_cost=total_cost(synthesized,DISC)
    omin,oclasses,_oprog,exact_count=oracle_min(w["discovery_outputs"])
    min_cost_exact=abs(synth_disc_cost-omin)<1e-12
    min_class_exact=(synth_class in oclasses and oclasses==[w["bounded_grammar_min_behavior_class"]])

    ood_correct=0; ood_total=0
    for i,seq in enumerate(OOD):
        pred=run_program(synthesized,seq)[0]; gold=w["ood_outputs"][i]
        ood_correct+=int(pred[0]==gold[0])+int(pred[1]==gold[1]); ood_total+=2
    ood_acc=ood_correct/ood_total
    synth_ood_cost=total_cost(synthesized,OOD)
    raw_cost=w["raw_history_cost"]

    rows.append({
        "world_id":w["world_id"],
        "audit_resource_regime":w["audit_resource_regime"],
        "cegis_success":True,
        "cegis_rounds":len(rounds),
        "beam_expansions":expanded,
        "synthesized_program":synthesized,
        "synthesized_behavior_class":synth_class,
        "discovery_exact":disc_exact,
        "synthesized_discovery_cost":synth_disc_cost,
        "oracle_min_cost":omin,
        "oracle_exact_program_count":exact_count,
        "oracle_min_behavior_classes":oclasses,
        "minimum_cost_exact":min_cost_exact,
        "minimum_behavior_class_exact":min_class_exact,
        "ood_accuracy":ood_acc,
        "synthesized_ood_cost":synth_ood_cost,
        "raw_history_cost":raw_cost,
        "cheaper_than_raw_history":synth_ood_cost<raw_cost,
    })
    cegis_receipts.append({"world_id":w["world_id"],"rounds":rounds})

summary={
    "FORCE_OMEGA0":{"exact_support_worlds":sum(1 for w in worlds if w["omega0_exact_support"]), "world_count":18},
    "OPEN_CEGIS_BEAM_SYNTHESIS":{
        "world_count":18,
        "cegis_success_worlds":sum(r.get("cegis_success",False) for r in rows),
        "full_discovery_exact_worlds":sum(r.get("discovery_exact",False) for r in rows),
        "minimum_cost_exact_worlds":sum(r.get("minimum_cost_exact",False) for r in rows),
        "minimum_behavior_class_exact_worlds":sum(r.get("minimum_behavior_class_exact",False) for r in rows),
        "ood_accuracy":sum(r.get("ood_accuracy",0.0) for r in rows)/18,
        "cheaper_than_raw_history_worlds":sum(r.get("cheaper_than_raw_history",False) for r in rows),
        "mean_cegis_rounds":sum(r.get("cegis_rounds",0) for r in rows)/18,
        "max_cegis_rounds":max(r.get("cegis_rounds",0) for r in rows),
        "total_beam_expansions":sum(r.get("beam_expansions",0) for r in rows),
    },
    "RAW_HISTORY_MEMORIZATION":{
        "mean_ood_exact_key_coverage":sum(w["raw_history_ood_coverage"] for w in worlds)/18,
        "mean_cost":sum(w["raw_history_cost"] for w in worlds)/18,
    }
}
p=summary["OPEN_CEGIS_BEAM_SYNTHESIS"]
if (
    summary["FORCE_OMEGA0"]["exact_support_worlds"]==0 and
    p["cegis_success_worlds"]==18 and p["full_discovery_exact_worlds"]==18 and
    p["minimum_cost_exact_worlds"]==18 and p["minimum_behavior_class_exact_worlds"]==18 and
    p["ood_accuracy"]==1.0 and p["cheaper_than_raw_history_worlds"]==18
):
    terminal="OPEN_BYTECODE_SYNTHESIS_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif p["full_discovery_exact_worlds"]>0:
    terminal="PARTIAL"
else:
    terminal="OPEN_BYTECODE_SYNTHESIS_INSUFFICIENT"

results={
    "experiment":"PRIMITIVE-2R","version":"0.1.0","freeze_sha256":freeze["freeze_sha256"],
    "terminal_verdict":terminal,"world_count":18,
    "system_summary":summary,"world_results":rows
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2R_RESULTS.json").write_text(json.dumps(results,indent=2))
(RES/"PRIMITIVE-2R_CEGIS_RECEIPTS.json").write_text(json.dumps(cegis_receipts,indent=2))

print("PRIMITIVE-2R scored")
print("terminal:",terminal)
print(json.dumps(summary,indent=2))