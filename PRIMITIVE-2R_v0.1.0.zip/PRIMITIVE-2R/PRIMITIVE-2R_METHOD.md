# PRIMITIVE-2R METHOD

1. Bind PRIMITIVE-2R to the frozen PRIMITIVE-2Q experiment, micro-language and results by SHA-256.
2. Remove the PRIMITIVE-2Q candidate bytecode library from the synthesis interface.
3. Freeze only raw instruction semantics, operand domains, execution costs, register budget and a guarded-handler control-flow normal form.
4. Exhaust the inherited complete one-bit Ω0 representation on the frozen discovery corpus; every retained world has zero exact Ω0 support.
5. Generate fixture worlds from the complete bounded normal-form grammar, but do not expose those programs to the synthesis engine.
6. Select 18 worlds whose unique minimum behavioral classes cover three audit-only resource regimes:
   - one-register additive state,
   - one-register additive state with reset,
   - two-register state.
   These are post-hoc resource-use descriptions, not selector-visible templates.
7. For each world, compute the least-error Ω0 model and extract residual same-state / contradictory-outcome collision pairs.
8. Start Counterexample-Guided Inductive Synthesis (CEGIS) from examples appearing in the first four residual collision pairs.
9. Run cost-weighted beam search over raw token-handler instruction choices. Unassigned handlers are treated as NOOP only for the partial beam heuristic.
10. Beam widths are attempted in the frozen order 32, 128, 512, 2048.
11. Candidate programs that are exact on the active CEGIS set are checked against the complete discovery corpus.
12. On failure, append the first deterministic counterexample and repeat.
13. Once full discovery exactness is reached, freeze the synthesized bytecode.
14. Independently exhaust the complete bounded 39,440-program normal-form grammar and verify:
    - the synthesized discovery cost equals the global minimum;
    - its behavioral operator class equals the unique global minimum class.
15. Execute the frozen synthesized program on OOD sequences of length 20–40 without any resynthesis.
16. Compare representation/runtime/state cost against exact raw-history retention.
17. Re-run the exact scorer and require byte-identical result JSON.

Execution note:
- The first post-freeze scoring attempt terminated with a tuple-indexing implementation error before producing a scientific result. The scorer read `(program, expansion_count)` in reverse order.
- The frozen experiment, fixtures, search specification and gates were unchanged.
- The scorer indexing bug was corrected and the frozen experiment was then scored.
- No benchmark or candidate was modified in response to a scientific result.

Scope:
PRIMITIVE-2R v0.1 performs unsupplied program construction inside a bounded guarded-handler bytecode normal form. It does not establish arbitrary control-flow graph synthesis.
