# PRIMITIVE-2R Conclusion

**Terminal verdict:** `OPEN_BYTECODE_SYNTHESIS_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## What changed from PRIMITIVE-2Q

PRIMITIVE-2Q selected among a supplied bytecode library.

PRIMITIVE-2R supplied no candidate programs.

The synthesis interface contained only:

```text
raw instruction semantics
operand choices
1–2 register allocation
instruction/runtime/state costs
residual collision examples
```

The program itself had to be constructed.

## Baseline saturation

The complete inherited one-bit Ω0 had:

```text
exact-support worlds: 0/18
```

Thus no world could be solved by remaining inside the old one-bit operator substrate.

## CEGIS + beam synthesis

Open synthesis succeeded in:

```text
18/18
```

worlds.

Every synthesized program fit the complete discovery corpus:

```text
18/18
```

The CEGIS loop required:

```text
mean rounds: 3.277778
maximum:     5
```

and performed:

```text
17820
```

beam expansions in total.

## Independent minimum-cost proof

After synthesis, an evaluator independently exhausted all:

```text
39,440
```

programs in the bounded normal-form grammar.

The CEGIS result matched the exact global minimum cost in:

```text
18/18
```

worlds and the unique minimum behavioral operator class in:

```text
18/18
```

worlds.

This matters because the beam search itself is heuristic; scientific minimality does not depend on trusting the heuristic.

## OOD transfer

The synthesized bytecode was frozen before OOD execution.

Discovery sequence length:

```text
<= 12
```

OOD sequence length:

```text
20..40
```

Result:

```text
OOD accuracy = 1.000000
```

No search or parameter update occurred during OOD evaluation.

## Cost

```text
mean synthesized OOD cost: 26.329589
mean raw-history cost:      93.905882
mean saving:                67.576293
```

The synthesized program was cheaper in:

```text
18/18
```

worlds.

Raw-history exact-key coverage on OOD was:

```text
0.000000
```

## Supported claim

Within the frozen guarded-handler μL normal form:

> Given no candidate bytecode library, a machine can construct an executable instruction sequence from raw micro-instructions using residual collisions, CEGIS and cost-weighted beam search; an independent exhaustive oracle confirms the constructed program is globally minimum-cost within that grammar; and the frozen program preserves exact behavior on longer OOD trajectories at lower cost than raw-history retention.

## Scope boundary

The search did not synthesize arbitrary control flow.

The following structure remained supplied:

```text
one streaming loop
one optional guarded effect per token
one or two registers
two final readouts
```

Therefore the next gap is not yet instruction-set semantics.

First comes:

> Can the machine synthesize the control-flow topology itself rather than filling a supplied guarded-handler normal form?

Only after open control-flow synthesis succeeds should the program test remove a necessary instruction semantic and ask for true instruction-substrate escape.
