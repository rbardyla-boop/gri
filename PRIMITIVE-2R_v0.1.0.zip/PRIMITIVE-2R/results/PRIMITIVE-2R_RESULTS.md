# PRIMITIVE-2R Results

**Terminal verdict:** `OPEN_BYTECODE_SYNTHESIS_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Exact deterministic replay:** `PASS`  
**Worlds:** 18  

| System | Discovery result | Minimum-cost oracle | OOD |
|---|---:|---:|---:|
| FORCE_OMEGA0 | 0/18 exact-support worlds | n/a | n/a |
| RAW_HISTORY_MEMORIZATION | discovery keys only | n/a | 0.000000 exact-key coverage |
| **OPEN_CEGIS_BEAM_SYNTHESIS** | **18/18 exact** | **18/18** | **1.000000** |

## Open synthesis

- Candidate program catalog supplied: `NO`
- Bounded grammar size used only by independent oracle: `39,440`
- CEGIS success: `18/18`
- Minimum behavioral class exact: `18/18`
- Mean CEGIS rounds: `3.277778`
- Maximum CEGIS rounds: `5`
- Total beam expansions: `17820`
- Mean synthesized OOD cost: `26.329589`
- Mean raw-history cost: `93.905882`
- Mean saving: `67.576293`
- Cheaper than raw history: `18/18`

Audit resource regimes: `{'TWO_REGISTER': 6, 'RESETTING_ONE_REGISTER': 6, 'SIGNED_ONE_REGISTER': 6}`
