# SRI-1A-α.4 — Live-Pilot & Human Recruitment Authorization

## Terminal status

```text
SRI_ALPHA4_RECRUITMENT_NOT_AUTHORIZED
```

This is intentional fail-closed behavior.

The recovered α.3 evidence establishes survey implementation fidelity but explicitly leaves recruitment locked. The currently available frozen sources do not provide enough information to invent the human operational parameters after α.3.

## Frozen now

- parent α.3 evidence snapshot;
- operational authorization contract;
- immutable scientific-invariant list;
- required consent components;
- raw-export → frozen-parser data-lock protocol;
- explicit authorization predicate;
- fail-closed validator.

## Remaining blockers

See `AUTHORIZATION_CHECK.txt`.

These are operational parameters, not permission to reopen the α experiment.

## Contract SHA-256

`e3e08436e7fd526268a4fc0a53e1e53b1ce737ad8b2226c5f38adbcbffe82667`
