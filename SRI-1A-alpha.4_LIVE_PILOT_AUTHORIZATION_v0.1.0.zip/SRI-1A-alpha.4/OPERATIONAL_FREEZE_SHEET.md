# SRI-1A-α.4 — Operational Freeze Sheet

**Current status:** `RECRUITMENT_NOT_AUTHORIZED`

The α.3 implementation passed its dry-run fidelity gates, including 8/8 randomized branches, 8/8 participant-facing UI branches, 160 completed synthetic W2 records, 8 controlled attriters, exact frozen export schema, and unchanged frozen parser acceptance. Human recruitment remained explicitly outside α.3.

## Fields that must be filled without changing the scientific instrument

```text
RECRUITMENT_SOURCE =
PLATFORM_CONFIGURATION =
INCLUSION_CRITERIA =
EXCLUSION_CRITERIA =
TARGET_N_OR_FIXED_STOP_RULE =
ATTRITION_RULE =
INCOMPLETE_RESPONSE_RULE =
COMPENSATION =
CONSENT_FINAL_SHA256 =
DATA_RETENTION_RULE =
WITHDRAWAL_RULE =
RESEARCH_CONTACT =
ETHICS_REB_DISPOSITION =
FROZEN_ALPHA2_PARSER_SHA256 =
FROZEN_EXPORT_SCHEMA_SHA256 =
```

## Authorization test

Recruitment is permitted only if:

```text
all required fields resolved
AND all parent scientific invariants unchanged
AND consent hash frozen
AND recruitment configuration hash frozen
AND attrition/exclusion rules frozen
AND target N / stopping rule frozen
AND ethics/REB disposition documented
AND parser hash exact
AND export schema hash exact
AND ingestion dry-run against a zero-human-data fixture PASS
```

Otherwise:

```text
SRI_ALPHA4_RECRUITMENT_NOT_AUTHORIZED
```

No live participant may be recruited merely because the survey software works.
