#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
contract = json.loads((ROOT / "SRI-1A-alpha.4_AUTHORIZATION_CONTRACT.json").read_text())

unresolved = []
for key, value in contract["operational_fields_required_before_unlock"].items():
    if isinstance(value, str) and value.startswith("UNRESOLVED"):
        unresolved.append(key)

if unresolved:
    print("SRI_ALPHA4_RECRUITMENT_NOT_AUTHORIZED")
    print("BLOCKERS:")
    for item in unresolved:
        print("-", item)
    raise SystemExit(2)

print("SRI_ALPHA4_OPERATIONAL_FIELDS_COMPLETE")
print("NOTE: parent-hash/invariant verification must also PASS before recruitment.")
