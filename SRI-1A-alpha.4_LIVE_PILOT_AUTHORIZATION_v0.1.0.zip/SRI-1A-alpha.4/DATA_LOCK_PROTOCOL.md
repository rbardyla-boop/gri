# SRI-1A-α.4 — Raw Export → Frozen Parser Data-Lock Protocol

## Objective

Prevent manual transformation, selective deletion, or schema drift between live survey export and the already-frozen α.2 parser.

## Required path

```text
survey platform raw export
        ↓
write-once acquisition copy
        ↓
SHA-256 acquisition receipt
        ↓
schema/header exact-match gate
        ↓
frozen α.2 parser hash gate
        ↓
parser execution with no manual row edits
        ↓
parser output + integrity flags
        ↓
analysis-lock receipt
```

## Fail-closed rules

- Never open a participant row in a spreadsheet and save the file before acquisition hashing.
- Never manually delete incomplete, inattentive, duplicate, or suspicious rows.
- All exclusions must be executed by the pre-frozen exclusion/attrition rule and recorded with machine-readable reason codes.
- A schema mismatch blocks ingestion.
- A parser-hash mismatch blocks ingestion.
- A row that cannot be parsed is retained in the raw acquisition copy and receives an integrity/error status; it is not silently repaired.
- Raw export and parsed output receive separate hashes.
- The analysis input is immutable once the analysis-lock receipt is created.

## Required unresolved bindings

```text
FROZEN_ALPHA2_PARSER_SHA256 = UNRESOLVED
FROZEN_EXPORT_SCHEMA_SHA256 = UNRESOLVED
RAW_EXPORT_FORMAT            = UNRESOLVED
```
