# SRI-1A-α.4 — Consent Text Skeleton

**Status:** NOT PARTICIPANT-READY / operational fields unresolved.

This file freezes the required consent components, not final wording. It must not be deployed until every bracketed field is resolved and the resulting text is hash-frozen.

## Required participant-visible components

1. **Study purpose**
   - State that this is a research pilot evaluating responses to a judgment/generalization task.
   - Do not reveal the experimental manipulation in a way that changes the frozen participant task.

2. **What participation involves**
   - Describe the survey procedure and approximate duration: `[UNRESOLVED_DURATION]`.
   - State that participation is voluntary.

3. **Eligibility**
   - `[UNRESOLVED_ELIGIBILITY_TEXT]`

4. **Risks / discomfort**
   - State the reasonably foreseeable discomforts created by the frozen stimuli and questions.
   - `[UNRESOLVED_RISK_WORDING]`

5. **Benefits**
   - Do not promise personal benefit.
   - Explain any broader research purpose conservatively.

6. **Compensation**
   - `[UNRESOLVED_AMOUNT_CURRENCY_PAYMENT_RULE]`
   - Compensation/partial-payment handling after withdrawal must be specified before launch.

7. **Privacy and data handling**
   - State exactly what identifiers, if any, are collected.
   - State retention period, storage location, access controls, deletion schedule, and whether de-identified data may be reused.
   - `[UNRESOLVED_PRIVACY_RETENTION_TEXT]`

8. **Withdrawal**
   - Explain whether and until when submitted data can be withdrawn.
   - `[UNRESOLVED_WITHDRAWAL_RULE]`

9. **Research / ethics contacts**
   - Research contact: `[UNRESOLVED_RESEARCH_CONTACT]`
   - Ethics/complaints contact if applicable: `[UNRESOLVED_ETHICS_CONTACT]`

10. **Consent action**
   - The participant must affirmatively indicate consent before entering the frozen survey flow.

## Prohibited consent changes

Consent may not:
- alter the experimental hypothesis;
- prime participants with the category-generalization hypothesis;
- change stimuli or task order;
- change scoring;
- change eligibility after recruitment starts;
- promise confidentiality or anonymity beyond what the actual data path supports.
