# PRIMITIVE-2D — EPISTEMIC STATE & REVERSIBLE DEPENDENCY

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `c73199e772bb0e40db56a525d469a13fff1552d46bb1a7989437c4f15dec5bcc`  
**Mechanisms SHA-256:** `985e6e28af47f13640b967ac52a16c0f72dc528b21b4c181f7b8f3a6f8d2c5db`  
**Challenge-suite SHA-256:** `dcd1de88939e5dc5417f725c77115e50c313f16146f59b39b81ae51fd233e39d`

## Question

> Can explicit epistemic status plus dependency history recover a learned packet reasoner from detected false derivations without deleting independently supported valid conclusions?

## What this experiment does NOT test

PRIMITIVE-2D does not solve truth detection.

The experimenter injects a challenge only after determining that a derived semantic fact is false. The learned model never sees the oracle.

Therefore a positive result may establish:

> once a bad thought is detected, the digital state representation can revoke it and correctly repair dependent state.

It may not establish:

> the digital mind can autonomously detect that the thought was bad.

That becomes a later verification experiment.

## Primitive preservation

The six-field semantic packet is unchanged:

```text
STABLE_REFERENCE
ACT
SUBJECT
RELATION
OBJECT
VALUE
```

Epistemic metadata lives in a sidecar ledger:

```text
status
support parent pairs
challenge state
```

This avoids adding a cognitive field before proving the control plane needs one in-band.

## Challenge suite

All nine known corrupted model/graph pairs from PRIMITIVE-2B are included.

No corrupted case was removed.

## Primary bad fact

A bad derived semantic fact is `PRIMARY_BAD` when at least one recorded learned support pair consists entirely of oracle-valid parent facts.

These are the first-order model mistakes.

All `PRIMARY_BAD` facts are challenged after the baseline reaches fixed point.

## Competing state mechanisms

```text
STATUS_ONLY
CASCADE_ANY
JUSTIFICATION_DAG
JUSTIFICATION_DAG_RECOMPUTE
```

### STATUS_ONLY

Revoke challenged facts only.

This asks whether status without dependency is enough.

### CASCADE_ANY

Revoke a challenged fact and every downstream fact that has any dependency path from it.

This tests dependency without alternate-support reasoning.

### JUSTIFICATION_DAG

Rebuild committed state from immutable input roots.

A derived fact is committed only if at least one recorded support pair has two committed parents.

Use the least fixed point from input roots, so a cycle cannot justify itself.

### JUSTIFICATION_DAG_RECOMPUTE

After DAG rollback, run the unchanged learned model again over surviving committed facts.

Permanently block the challenged semantic facts.

This tests whether valid conclusions removed during rollback can be recovered without silently reintroducing the challenged error.

## Success gate

A mechanism succeeds only if all nine known failures end with:

```text
0 active bad facts
100% oracle-valid recall
exact graph match
0 challenged facts active
deterministic replay
```

Safety without recall is failure.
