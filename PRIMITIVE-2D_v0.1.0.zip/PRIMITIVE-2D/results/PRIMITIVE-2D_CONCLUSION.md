# PRIMITIVE-2D Conclusion

**Terminal verdict:** `REVERSIBLE_DEPENDENCY_SUFFICIENT_FOR_DETECTED_ERRORS_WITHIN_TESTED_SCOPE`

## Baseline validity

The support-audited frontier scorer reproduced all nine frozen PRIMITIVE-2B failures:

```text
BASELINE_EQUIVALENCE = PASS
```

PRIMITIVE-2D therefore repaired the same failure states rather than a rewritten benchmark.

## STATUS_ONLY

```text
challenged primary bad facts: 55
bad facts still active:       183
minimum valid recall:         1.000000
joint-gate cases:             0/9
```

A status bit without dependency history cannot retract consequences already committed downstream.

## CASCADE_ANY

```text
bad facts still active:       0
valid facts wrongly removed:  1097
minimum valid recall:         0.075000
joint-gate cases:             0/9
```

Blind descendant deletion removes the poison but also destroys valid conclusions that have independent support.

## JUSTIFICATION_DAG

```text
bad facts still active:       0
valid facts wrongly removed:  0
minimum valid recall:         1.000000
exact graph rate:             1.000000
joint-gate cases:             9/9
```

The multi-support justification ledger removed every challenged root and every unsupported consequence while retaining every oracle-valid fact.

## JUSTIFICATION_DAG_RECOMPUTE

It also passed 9/9.

```text
recomputed facts required: 0
new bad facts after recompute: 0
```

No recomputation was required in these nine failures because the recorded alternate support graph was already sufficient.

## Supported claim

> Once primary false derivations are correctly identified, an external multi-support justification DAG is sufficient to revoke them and all unsupported consequences while preserving independently justified valid conclusions, within the nine known PRIMITIVE-2B failure cases.

This is an epistemic-state result, not a truth-detection result.

## Architectural implication

The useful machine state is not merely:

```text
FACT
```

and not merely:

```text
FACT + VALID/INVALID
```

The minimum structure exposed by this experiment is closer to:

```text
semantic packet
+
source class
+
epistemic status
+
zero or more parent-pair justifications
+
challenge/revocation state
```

A derived conclusion remains committed because at least one active justification survives, not merely because a model emitted it.

## Remaining gap

The experimenter supplied the challenge.

The next largest gap is therefore:

> Can the system generate trustworthy verification/challenge signals without reintroducing a complete symbolic truth engine?
