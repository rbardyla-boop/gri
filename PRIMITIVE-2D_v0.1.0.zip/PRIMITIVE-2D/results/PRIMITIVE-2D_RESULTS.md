# PRIMITIVE-2D Results

**Terminal verdict:** `REVERSIBLE_DEPENDENCY_SUFFICIENT_FOR_DETECTED_ERRORS_WITHIN_TESTED_SCOPE`  
**Baseline equivalence:** `PASS`  
**Known failure cases:** 9

| Mechanism | Joint-gate cases | Active bad facts | Collateral valid retractions | Min recall | Exact graph rate |
|---|---:|---:|---:|---:|---:|
| STATUS_ONLY | 0/9 | 183 | 0 | 1.000000 | 0.000000 |
| CASCADE_ANY | 0/9 | 0 | 1097 | 0.075000 | 0.000000 |
| JUSTIFICATION_DAG | 9/9 | 0 | 0 | 1.000000 | 1.000000 |
| JUSTIFICATION_DAG_RECOMPUTE | 9/9 | 0 | 0 | 1.000000 | 1.000000 |
