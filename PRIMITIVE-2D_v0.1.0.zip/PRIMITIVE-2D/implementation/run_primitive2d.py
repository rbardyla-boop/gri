from pathlib import Path
import json, hashlib, itertools, os, time, csv, zipfile
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)

BASE=Path("/mnt/data")
P2A=BASE/"PRIMITIVE-2A"
P2B=BASE/"PRIMITIVE-2B"
ROOT=BASE/"PRIMITIVE-2D"
FIX=ROOT/"PRIMITIVE-2D_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

ACTS=["ASSERT","DERIVE"]
RELS=["BEFORE","PART_OF","ASSIGNED_TO","LOCATED_IN"]
A2I={x:i for i,x in enumerate(ACTS)}
R2I={x:i for i,x in enumerate(RELS)}
I2R={i:x for x,i in R2I.items()}
RO_NONE=4
RULES={
    "BEFORE|BEFORE":"BEFORE",
    "PART_OF|PART_OF":"PART_OF",
    "PART_OF|ASSIGNED_TO":"ASSIGNED_TO",
}
bitpos=torch.arange(24,dtype=torch.long)

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)

def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

class BindingComposer(nn.Module):
    def __init__(self):
        super().__init__()
        self.refenc=nn.Sequential(nn.Linear(24,32),nn.ReLU(),nn.Linear(32,32),nn.ReLU())
        self.body=nn.Sequential(nn.Linear(332,128),nn.ReLU(),nn.Linear(128,128),nn.ReLU())
        self.bind=nn.Linear(128,3)
        self.rel=nn.Linear(128,5)
        self.ssel=nn.Linear(128,4)
        self.osel=nn.Linear(128,4)
    def forward(self,acts,rels,refs):
        rb=((refs.unsqueeze(-1)>>bitpos)&1).float()
        e=self.refenc(rb)
        diffs=torch.cat([(e[:,i]-e[:,j]).abs() for i,j in itertools.combinations(range(4),2)],dim=1)
        meta=torch.cat([
            F.one_hot(acts[:,0],2).float(),F.one_hot(acts[:,1],2).float(),
            F.one_hot(rels[:,0],4).float(),F.one_hot(rels[:,1],4).float()
        ],dim=1)
        h=self.body(torch.cat([e.flatten(1),diffs,meta],dim=1))
        return self.bind(h),self.rel(h),self.ssel(h),self.osel(h)

def load_model(seed):
    p=P2A/"models"/f"M2_seed_{seed}.pt"
    m=BindingComposer()
    m.load_state_dict(torch.load(p,map_location="cpu",weights_only=True))
    m.eval()
    return m

def oracle_pair(l,r):
    ls,lr,lo=l; rs,rr,ro=r
    key=f"{I2R[lr]}|{I2R[rr]}"
    if lo==rs and key in RULES:
        return (ls,R2I[RULES[key]],ro)
    key=f"{I2R[rr]}|{I2R[lr]}"
    if ro==ls and key in RULES:
        return (rs,R2I[RULES[key]],lo)
    return None

def oracle_closure(fx):
    facts={(int(p["subject"]),R2I[p["relation"]],int(p["object"])) for p in fx["inputs"]}
    while True:
        arr=list(facts); new=set()
        for l in arr:
            for r in arr:
                x=oracle_pair(l,r)
                if x is not None and x not in facts:
                    new.add(x)
        if not new:
            return facts
        facts |= new

def predict_candidates(model, packets, pairs, chunk=4096):
    """Yield (fact,left_idx,right_idx) for accepted pair decisions."""
    pkt=torch.tensor(packets,dtype=torch.long)
    for st in range(0,len(pairs),chunk):
        block=pairs[st:st+chunk]
        ii=torch.tensor([x[0] for x in block],dtype=torch.long)
        jj=torch.tensor([x[1] for x in block],dtype=torch.long)
        left=pkt[ii]; right=pkt[jj]
        acts=torch.stack([left[:,1],right[:,1]],dim=1)
        rels=torch.stack([left[:,3],right[:,3]],dim=1)
        refs=torch.stack([left[:,2],left[:,4],right[:,2],right[:,4]],dim=1)
        with torch.no_grad():
            outs=model(acts,rels,refs)
            pb,pr,ps,po=[x.argmax(-1) for x in outs]
        mask=(pb!=0)&(pr!=RO_NONE)
        sel=torch.nonzero(mask,as_tuple=False).flatten()
        if sel.numel()==0:
            continue
        slots=refs[sel]
        s=slots.gather(1,ps[sel].unsqueeze(1)).squeeze(1)
        o=slots.gather(1,po[sel].unsqueeze(1)).squeeze(1)
        rr=pr[sel]
        for k,tidx in enumerate(sel.tolist()):
            yield (int(s[k]),int(rr[k]),int(o[k])), int(ii[tidx]), int(jj[tidx])

def audited_flat_run(model,fx):
    gold=oracle_closure(fx)
    packets=[[int(p["id"]),A2I[p["act"]],int(p["subject"]),R2I[p["relation"]],int(p["object"]),1000] for p in fx["inputs"]]
    facts=[(p[2],p[3],p[4]) for p in packets]
    fact_to_idx={f:i for i,f in enumerate(facts)}
    is_input={f:True for f in facts}
    round_created={f:0 for f in facts}
    supports={f:set() for f in facts}
    next_ref=max(p[0] for p in packets)+1
    frontier=list(range(len(packets)))
    rounds=0; pair_evals=0
    trajectory=[[0,[list(p) for p in packets]]]

    while frontier and rounds < int(fx["max_rounds"]):
        rounds += 1
        n=len(packets)
        fset=set(frontier)
        pairs=[(i,j) for i in range(n) for j in range(n) if i!=j and (i in fset or j in fset)]
        pair_evals += len(pairs)
        new_supports={}
        for fact,li,ri in predict_candidates(model,packets,pairs):
            lf=facts[li]; rf=facts[ri]
            supports.setdefault(fact,set()).add((lf,rf))
            if fact not in fact_to_idx:
                new_supports.setdefault(fact,set()).add((lf,rf))
        if not new_supports:
            trajectory.append([rounds,[]])
            break
        new_indices=[]; new_packets=[]
        for fact in sorted(new_supports):
            if fact in fact_to_idx:
                continue
            s,r,o=fact
            p=[next_ref,A2I["DERIVE"],s,r,o,1000]; next_ref+=1
            idx=len(packets)
            packets.append(p); facts.append(fact); fact_to_idx[fact]=idx
            is_input[fact]=False; round_created[fact]=rounds
            supports.setdefault(fact,set()).update(new_supports[fact])
            new_indices.append(idx); new_packets.append(p)
        frontier=new_indices
        trajectory.append([rounds,new_packets])
    final=set(facts)
    bad=final-gold
    return {
        "gold":gold,"packets":packets,"facts":facts,"fact_to_idx":fact_to_idx,
        "is_input":is_input,"round_created":round_created,"supports":supports,
        "final":final,"bad":bad,"rounds":rounds,"pair_evals":pair_evals,"trajectory":trajectory
    }

def primary_bad_set(run):
    gold=run["gold"]; out=set()
    for fact in run["bad"]:
        for lf,rf in run["supports"].get(fact,set()):
            if lf in gold and rf in gold:
                out.add(fact); break
    return out

def metrics(active, gold, challenged):
    bad=active-gold
    fn=gold-active
    return {
        "active_fact_count":len(active),
        "active_bad_fact_count":len(bad),
        "active_false_negative_fact_count":len(fn),
        "oracle_valid_recall":1.0 if not gold else len(active&gold)/len(gold),
        "precision":1.0 if not active else len(active&gold)/len(active),
        "exact_graph_match":active==gold,
        "challenged_facts_active":len(active & challenged),
        "collateral_valid_retractions":len(fn),
    }

def status_only(run,challenged):
    active=set(run["final"])-set(challenged)
    return active,{"recomputed_fact_count":0,"new_bad_fact_count_after_recompute":0}

def cascade_any(run,challenged):
    children={}
    for child,sups in run["supports"].items():
        for l,r in sups:
            children.setdefault(l,set()).add(child)
            children.setdefault(r,set()).add(child)
    revoked=set(challenged)
    q=list(challenged)
    while q:
        x=q.pop()
        for c in children.get(x,set()):
            if c not in revoked:
                revoked.add(c); q.append(c)
    active=set(run["final"])-revoked
    return active,{"recomputed_fact_count":0,"new_bad_fact_count_after_recompute":0,"revoked_total":len(revoked)}

def justification_dag(run,challenged):
    active={f for f,v in run["is_input"].items() if v and f not in challenged}
    changed=True
    while changed:
        changed=False
        for fact in run["final"]:
            if fact in active or fact in challenged or run["is_input"].get(fact,False):
                continue
            for l,r in run["supports"].get(fact,set()):
                if l in active and r in active:
                    active.add(fact); changed=True; break
    return active,{"recomputed_fact_count":0,"new_bad_fact_count_after_recompute":0}

def recompute_from_active(model,run,active,challenged,max_rounds=32):
    # Create deterministic packet state from semantic facts. Inputs keep ASSERT, others DERIVE.
    ordered=sorted(active)
    packets=[]
    facts=[]
    next_ref=1
    for fact in ordered:
        s,r,o=fact
        act=A2I["ASSERT"] if run["is_input"].get(fact,False) else A2I["DERIVE"]
        packets.append([next_ref,act,s,r,o,1000]); facts.append(fact); next_ref+=1
    existing=set(facts)
    frontier=list(range(len(packets)))
    added=0
    new_bad=0
    rounds=0
    gold=run["gold"]
    while frontier and rounds<max_rounds:
        rounds+=1
        n=len(packets); fset=set(frontier)
        pairs=[(i,j) for i in range(n) for j in range(n) if i!=j and (i in fset or j in fset)]
        cand=set()
        for fact,li,ri in predict_candidates(model,packets,pairs):
            if fact in challenged or fact in existing:
                continue
            cand.add(fact)
        if not cand:
            break
        frontier=[]
        for fact in sorted(cand):
            if fact in challenged or fact in existing:
                continue
            s,r,o=fact
            packets.append([next_ref,A2I["DERIVE"],s,r,o,1000]); next_ref+=1
            facts.append(fact); existing.add(fact); frontier.append(len(packets)-1)
            added+=1
            new_bad+=int(fact not in gold)
    return existing,{"recomputed_fact_count":added,"new_bad_fact_count_after_recompute":new_bad,"recompute_rounds":rounds}

def run_case(seed,fixture,expected):
    model=load_model(seed)
    base=audited_flat_run(model,fixture)
    base_metrics=metrics(base["final"],base["gold"],set())
    primary=primary_bad_set(base)

    # Baseline equivalence against frozen PRIMITIVE-2B receipt.
    equivalence=(
        len(base["bad"])==expected["baseline_bad_packet_count"]
        and len(base["final"]-base["gold"])==expected["baseline_false_positive_facts"]
        and abs(base_metrics["oracle_valid_recall"]-expected["baseline_recall"])<1e-12
    )

    variants={}
    for mech in ["STATUS_ONLY","CASCADE_ANY","JUSTIFICATION_DAG","JUSTIFICATION_DAG_RECOMPUTE"]:
        if mech=="STATUS_ONLY":
            active,extra=status_only(base,primary)
        elif mech=="CASCADE_ANY":
            active,extra=cascade_any(base,primary)
        else:
            active0,extra=justification_dag(base,primary)
            if mech=="JUSTIFICATION_DAG_RECOMPUTE":
                active,extra2=recompute_from_active(model,base,active0,primary)
                extra.update(extra2)
            else:
                active=active0
        m=metrics(active,base["gold"],primary)
        m.update(extra)
        m["support_edge_count"]=sum(len(v) for v in base["supports"].values())
        m["challenged_primary_bad_count"]=len(primary)
        m["success_gate_pass"]=(
            m["active_bad_fact_count"]==0 and
            m["oracle_valid_recall"]==1.0 and
            m["exact_graph_match"] and
            m["challenged_facts_active"]==0
        )
        variants[mech]=m

    return {
        "seed":seed,"fixture_id":fixture["fixture_id"],"family":fixture["family"],"scale":fixture["scale"],
        "baseline_equivalence_pass":equivalence,
        "baseline":{
            "final_fact_count":len(base["final"]),
            "gold_fact_count":len(base["gold"]),
            "bad_fact_count":len(base["bad"]),
            "recall":base_metrics["oracle_valid_recall"],
            "support_edge_count":sum(len(v) for v in base["supports"].values()),
            "primary_bad_count":len(primary),
            "primary_bad_facts":[list(x) for x in sorted(primary)],
            "rounds":base["rounds"],
            "pair_evaluations":base["pair_evals"],
        },
        "variants":variants,
    }

# Load frozen suite and fixtures.
suite=json.loads((FIX/"CHALLENGE_SUITE.json").read_text())
gd=json.loads((P2B/"PRIMITIVE-2B_FIXTURES"/"RECURSIVE_STABILITY_GRAPHS.json").read_text())
fxmap={f["fixture_id"]:f for f in gd["fixtures"]}

case_results=[]
t0=time.time()
for c in suite["cases"]:
    cr=run_case(c["seed"],fxmap[c["fixture_id"]],c)
    case_results.append(cr)
    print(c["seed"],c["fixture_id"],"baseline_eq",cr["baseline_equivalence_pass"],
          {k:(v["active_bad_fact_count"],v["oracle_valid_recall"],v["success_gate_pass"]) for k,v in cr["variants"].items()})

all_equiv=all(c["baseline_equivalence_pass"] for c in case_results)

mechanism_summary={}
for mech in ["STATUS_ONLY","CASCADE_ANY","JUSTIFICATION_DAG","JUSTIFICATION_DAG_RECOMPUTE"]:
    rows=[c["variants"][mech] for c in case_results]
    mechanism_summary[mech]={
        "case_count":len(rows),
        "cases_passing_joint_gate":sum(r["success_gate_pass"] for r in rows),
        "all_cases_pass":all(r["success_gate_pass"] for r in rows),
        "active_bad_fact_count_total":sum(r["active_bad_fact_count"] for r in rows),
        "collateral_valid_retractions_total":sum(r["collateral_valid_retractions"] for r in rows),
        "min_recall":min(r["oracle_valid_recall"] for r in rows),
        "exact_graph_rate":sum(r["exact_graph_match"] for r in rows)/len(rows),
        "challenged_primary_bad_count_total":sum(r["challenged_primary_bad_count"] for r in rows),
        "recomputed_fact_count_total":sum(r.get("recomputed_fact_count",0) for r in rows),
        "new_bad_fact_count_after_recompute_total":sum(r.get("new_bad_fact_count_after_recompute",0) for r in rows),
    }

if not all_equiv:
    terminal="EXPERIMENT_INVALID"
elif any(s["all_cases_pass"] for s in mechanism_summary.values()):
    terminal="REVERSIBLE_DEPENDENCY_SUFFICIENT_FOR_DETECTED_ERRORS_WITHIN_TESTED_SCOPE"
elif any(s["cases_passing_joint_gate"]>0 for s in mechanism_summary.values()):
    terminal="PARTIAL"
else:
    terminal="DEPENDENCY_REPRESENTATION_INSUFFICIENT"

freeze=json.loads((ROOT/"PRIMITIVE-2D_FREEZE.json").read_text())
results={
    "experiment":"PRIMITIVE-2D","version":"0.1.0","terminal_verdict":terminal,
    "freeze_sha256":freeze["freeze_sha256"],"elapsed_seconds":time.time()-t0,
    "baseline_equivalence_all_cases":all_equiv,
    "case_count":len(case_results),
    "mechanism_summary":mechanism_summary,
    "cases":case_results,
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2D_RESULTS.json").write_text(json.dumps(results,indent=2))

# readable outputs
lines=[
    "# PRIMITIVE-2D Results","",
    f"**Terminal verdict:** `{terminal}`  ",
    f"**Baseline equivalence:** `{'PASS' if all_equiv else 'FAIL'}`  ",
    f"**Known failure cases:** {len(case_results)}","",
    "| Mechanism | Joint-gate cases | Active bad facts | Collateral valid retractions | Min recall | Exact graph rate |",
    "|---|---:|---:|---:|---:|---:|"
]
for mech,s in mechanism_summary.items():
    lines.append(f"| {mech} | {s['cases_passing_joint_gate']}/{s['case_count']} | {s['active_bad_fact_count_total']} | {s['collateral_valid_retractions_total']} | {s['min_recall']:.6f} | {s['exact_graph_rate']:.6f} |")
(RES/"PRIMITIVE-2D_RESULTS.md").write_text("\n".join(lines)+"\n")

csv_path=RES/"PRIMITIVE-2D_CASE_RESULTS.csv"
with csv_path.open("w",newline="") as f:
    w=csv.writer(f)
    w.writerow(["seed","fixture","mechanism","bad_after","false_negatives","recall","exact","primary_challenges","recomputed","new_bad_after_recompute","pass"])
    for c in case_results:
        for mech,m in c["variants"].items():
            w.writerow([c["seed"],c["fixture_id"],mech,m["active_bad_fact_count"],m["active_false_negative_fact_count"],
                        m["oracle_valid_recall"],m["exact_graph_match"],m["challenged_primary_bad_count"],
                        m.get("recomputed_fact_count",0),m.get("new_bad_fact_count_after_recompute",0),m["success_gate_pass"]])

print("terminal",terminal)
print(json.dumps(mechanism_summary,indent=2))