#!/usr/bin/env python3
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2D_RESULTS.json").read_text())
assert r["terminal_verdict"]=="REVERSIBLE_DEPENDENCY_SUFFICIENT_FOR_DETECTED_ERRORS_WITHIN_TESTED_SCOPE"
assert r["baseline_equivalence_all_cases"] is True
assert r["case_count"]==9
assert r["mechanism_summary"]["STATUS_ONLY"]["cases_passing_joint_gate"]==0
assert r["mechanism_summary"]["CASCADE_ANY"]["cases_passing_joint_gate"]==0
assert r["mechanism_summary"]["JUSTIFICATION_DAG"]["cases_passing_joint_gate"]==9
assert r["mechanism_summary"]["JUSTIFICATION_DAG"]["active_bad_fact_count_total"]==0
assert r["mechanism_summary"]["JUSTIFICATION_DAG"]["collateral_valid_retractions_total"]==0
assert r["mechanism_summary"]["JUSTIFICATION_DAG"]["min_recall"]==1.0
assert r["mechanism_summary"]["JUSTIFICATION_DAG_RECOMPUTE"]["cases_passing_joint_gate"]==9
print("PRIMITIVE_2D_TEST_PASS")
