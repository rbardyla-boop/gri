# PRIMITIVE-2D METHOD

1. Bind the exact three PRIMITIVE-2A model files by SHA-256.
2. Bind the frozen PRIMITIVE-2B graph fixture file by SHA-256.
3. Use all nine previously observed corrupted model/graph pairs.
4. Re-run each learned model with a frontier scheduler while recording every accepted parent-pair support.
5. Require exact reproduction of the prior PRIMITIVE-2B bad-fact count and recall before rollback scoring.
6. Label oracle-valid versus oracle-invalid semantic facts only in the experimenter audit.
7. Define PRIMARY_BAD as an oracle-invalid derived fact that has at least one learned support pair whose two parents are oracle-valid.
8. Inject an exogenous challenge against every PRIMARY_BAD semantic fact after flat inference reaches fixed point.
9. Apply each frozen epistemic-state mechanism without giving the learned model or mechanism any relation-specific truth rule.
10. Score active bad facts, valid recall, exact graph match, challenged-fact removal, collateral retractions, and recomputation effects.

The challenge oracle is intentionally external. PRIMITIVE-2D tests rollback representation, not autonomous truth detection.
