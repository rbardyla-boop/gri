# PRIMITIVE-2B Results

**Terminal verdict:** `RECURSIVE_INSTABILITY_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Frozen models:** 3  
**Local exam:** 200,000 new-reference pairs per model  
**Recursive exam:** 47 new-reference graphs per model

| Seed | Local exact | Bind FP | Bind FN | Relation errors | Corrupt graphs | Bad packets | Tainted descendants | Bad amplification | Verdict |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 13 | 0.999985 | 2 | 0 | 3 | 1/47 | 14 | 11 | 4.67× | LOCAL_ERRORS_AND_RECURSIVE_ERRORS |
| 29 | 0.999965 | 2 | 0 | 7 | 6/47 | 164 | 154 | 16.40× | LOCAL_ERRORS_AND_RECURSIVE_ERRORS |
| 61 | 0.999975 | 0 | 0 | 5 | 2/47 | 60 | 57 | 20.00× | LOCAL_ERRORS_AND_RECURSIVE_ERRORS |

## Key observations

- Every frozen model exceeded 99.99% exact accuracy on the 200,000-pair local exam.
- Every frozen model corrupted at least one recursive graph.
- All observed graph failures were false-positive additions; recall remained 1.0.
- Seed 61 had zero binding false positives/negatives in the local exam but still corrupted two recursive graphs.
- The amplification ratio is descriptive: total bad packets divided by estimated first-generation bad packets (`bad - tainted`). It was not a preregistered pass metric.
