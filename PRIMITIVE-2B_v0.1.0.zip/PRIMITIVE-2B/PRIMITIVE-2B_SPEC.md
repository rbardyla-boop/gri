# PRIMITIVE-2B — RECURSIVE ERROR STABILITY

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `8a0ff440069057023b5f3ebee2ac75e86a64c4f6593b6dad1fedf2b62ee4bd88`  
**Reference pool SHA-256:** `d82e4cdbe9db55a7f8f9149b46e7cf9e374a418357e91559c153d763811e1308`  
**Local exam SHA-256:** `aa7359ec01086fd323209d49e02eaf392a5c81f903ab66a159a4f1230898a600`  
**Recursive fixture SHA-256:** `dbe204af38f9e9244e5592ec9b4ab9f57b6361f9a44ba7e4f39db39c1b33c3db`

## Question

> Can frozen learned packet cognition remain stable when its own outputs become future inputs?

## Hard controls

The three PRIMITIVE-2A models are frozen by SHA-256.

```text
seed 13: 6a0849d63effdb2bd96017f46597f1a341ebaf3fa898bfc5a881c726f5895909
seed 29: 670bde43c833385a6d24e919048ad27279eb5934c1752c471c362b21ae6c8309
seed 61: 6f43f948703e443a46ae8df584b79ef64f04af8aeda0a4d9eb1f0ee4f5363ce0
```

PRIMITIVE-2B authorizes:

```text
NO retraining
NO fine-tuning
NO threshold tuning
NO seed selection
NO architecture changes
NO new inference rule
```

## New references

All scored references come from a newly generated 24-bit pool disjoint from both PRIMITIVE-2A training and held-out reference pools.

## Local exam

200,000 frozen packet pairs measure isolated decision errors before recursive feedback.

This separates:

```text
local false positive
local false negative
relation error
selector error
```

from graph-level amplification.

## Recursive exam

47 frozen graph traces:

```text
BEFORE chains      length 8,16,24 × 5 reference draws
PART_OF chains     length 8,16,24 × 5 reference draws
mixed hierarchies  depth 8,16,24 × 3 reference draws
distractor fields  16,64,128 × 2 reference draws
cycles             length 5,8
```

The runtime remains the exact PRIMITIVE-2A learned-binding runtime:

```text
enumerate every ordered packet pair
model decides binding
model decides output relation
model decides surviving SUBJECT/OBJECT
append derived packet
feed it into later rounds
```

No equality check is used to verify model outputs.

## Lineage audit

The experimenter records parent packet references for every emitted fact.

This audit is inaccessible to the model.

A packet is:

```text
BAD
if its semantic (SUBJECT,RELATION,OBJECT) is absent from the oracle closure.

TAINTED
if at least one derivation path used a BAD or previously TAINTED parent.
```

This permits direct measurement of recursive error amplification.

## Stability gate

A seed is `RECURSIVELY_STABLE_WITHIN_TESTED_SCOPE` only if it has:

```text
0 local false positives
0 local false negatives
0 local relation errors
0 local selector errors
100% exact recursive graphs
0 bad derived packets
0 tainted descendants
100% termination
numeric-only authoritative trajectories
```

No tolerance is introduced after scoring.
