from __future__ import annotations
import argparse, hashlib, itertools, json, math, time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)

ROOT=Path('/mnt/data/PRIMITIVE-2B')
PARENT=Path('/mnt/data/PRIMITIVE-2A')
FIX=ROOT/'PRIMITIVE-2B_FIXTURES'
RES=ROOT/'results'
RES.mkdir(exist_ok=True)

ACTS=['ASSERT','DERIVE']
RELS=['BEFORE','PART_OF','ASSIGNED_TO','LOCATED_IN']
BIND=['NONE','FORWARD','REVERSE']
REL_OUT=RELS+['NONE']
A2I={x:i for i,x in enumerate(ACTS)}
R2I={x:i for i,x in enumerate(RELS)}
B2I={x:i for i,x in enumerate(BIND)}
RO2I={x:i for i,x in enumerate(REL_OUT)}

RULES={
    'BEFORE|BEFORE':'BEFORE',
    'PART_OF|PART_OF':'PART_OF',
    'PART_OF|ASSIGNED_TO':'ASSIGNED_TO',
}

bitpos=torch.arange(24,dtype=torch.long)

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)

def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def refs_to_bits(refs):
    return ((refs.unsqueeze(-1)>>bitpos.to(refs.device))&1).float()

class BindingComposer(nn.Module):
    def __init__(self):
        super().__init__()
        self.refenc=nn.Sequential(nn.Linear(24,32),nn.ReLU(),nn.Linear(32,32),nn.ReLU())
        self.body=nn.Sequential(nn.Linear(332,128),nn.ReLU(),nn.Linear(128,128),nn.ReLU())
        self.bind=nn.Linear(128,3)
        self.rel=nn.Linear(128,5)
        self.ssel=nn.Linear(128,4)
        self.osel=nn.Linear(128,4)
    def forward(self,acts,rels,refs):
        e=self.refenc(refs_to_bits(refs))
        diffs=torch.cat([(e[:,i]-e[:,j]).abs() for i,j in itertools.combinations(range(4),2)],dim=1)
        meta=torch.cat([
            F.one_hot(acts[:,0],2).float(),F.one_hot(acts[:,1],2).float(),
            F.one_hot(rels[:,0],4).float(),F.one_hot(rels[:,1],4).float()
        ],dim=1)
        h=self.body(torch.cat([e.flatten(1),diffs,meta],dim=1))
        return self.bind(h),self.rel(h),self.ssel(h),self.osel(h)

def load_model(seed):
    p=PARENT/'models'/f'M2_seed_{seed}.pt'
    model=BindingComposer()
    model.load_state_dict(torch.load(p,map_location='cpu',weights_only=True))
    model.eval()
    return model,p

def verify_freeze(seed,model_path):
    freeze=json.loads((ROOT/'PRIMITIVE-2B_FREEZE.json').read_text())
    for rec in freeze['files']:
        p=ROOT/rec['name']
        got=sha_file(p)
        if got!=rec['sha256']:
            raise RuntimeError(f"frozen file changed: {rec['name']}")
    expected=freeze['parent_model_hashes'][str(seed)]
    got=sha_file(model_path)
    if got!=expected:
        raise RuntimeError(f'model hash changed for seed {seed}')
    return freeze

def local_exam(model,batch_size=8192):
    d=np.load(FIX/'LOCAL_ERROR_EXAM.npz')
    acts_np=d['acts']; rels_np=d['rels']; refs_np=d['refs']; labels_np=d['labels']; types_np=d['case_type']
    n=len(acts_np)
    counts={
        'cases':n,
        'binding_false_positives':0,
        'binding_false_negatives':0,
        'binding_wrong_direction':0,
        'relation_errors':0,
        'selector_errors':0,
        'exact_decision_errors':0,
    }
    by_type={str(i):{'cases':0,'exact_errors':0,'binding_fp':0,'binding_fn':0,'relation_errors':0,'selector_errors':0} for i in range(8)}
    examples=[]
    for st in range(0,n,batch_size):
        en=min(n,st+batch_size)
        acts=torch.from_numpy(acts_np[st:en].astype(np.int64))
        rels=torch.from_numpy(rels_np[st:en].astype(np.int64))
        refs=torch.from_numpy(refs_np[st:en].astype(np.int64))
        labels=torch.from_numpy(labels_np[st:en].astype(np.int64))
        with torch.no_grad():
            outs=model(acts,rels,refs)
            pb,pr,ps,po=[x.argmax(-1) for x in outs]
        lb,lr,ls,lo=[labels[:,i] for i in range(4)]
        neg=lb==0; pos=lb!=0
        fp=neg & (pb!=0)
        fn=pos & (pb==0)
        wd=pos & (pb!=0) & (pb!=lb)
        re=pr!=lr
        se=pos & ((ps!=ls)|(po!=lo))
        exact=(pb==lb)&(pr==lr)&(~pos|((ps==ls)&(po==lo)))
        counts['binding_false_positives']+=int(fp.sum())
        counts['binding_false_negatives']+=int(fn.sum())
        counts['binding_wrong_direction']+=int(wd.sum())
        counts['relation_errors']+=int(re.sum())
        counts['selector_errors']+=int(se.sum())
        counts['exact_decision_errors']+=int((~exact).sum())
        ct=types_np[st:en]
        for t in range(8):
            mask_np=(ct==t)
            if not mask_np.any(): continue
            mask=torch.from_numpy(mask_np)
            bt=by_type[str(t)]
            bt['cases']+=int(mask.sum())
            bt['exact_errors']+=int(((~exact)&mask).sum())
            bt['binding_fp']+=int((fp&mask).sum())
            bt['binding_fn']+=int((fn&mask).sum())
            bt['relation_errors']+=int((re&mask).sum())
            bt['selector_errors']+=int((se&mask).sum())
        if len(examples)<25:
            bad=torch.nonzero(~exact,as_tuple=False).flatten()
            for j in bad[:25-len(examples)].tolist():
                examples.append({
                    'index':st+j,
                    'case_type':int(ct[j]),
                    'acts':acts[j].tolist(),
                    'relations':rels[j].tolist(),
                    'references':refs[j].tolist(),
                    'label':labels[j].tolist(),
                    'prediction':[int(pb[j]),int(pr[j]),int(ps[j]),int(po[j])],
                })
    counts['binding_false_positive_rate']=counts['binding_false_positives']/n
    positive_count=int((labels_np[:,0]!=0).sum())
    negative_count=n-positive_count
    counts['positive_cases']=positive_count
    counts['negative_cases']=negative_count
    counts['binding_fp_rate_on_negatives']=counts['binding_false_positives']/negative_count
    counts['binding_fn_rate_on_positives']=counts['binding_false_negatives']/positive_count
    counts['relation_error_rate']=counts['relation_errors']/n
    counts['selector_error_rate_on_positives']=counts['selector_errors']/positive_count
    counts['exact_local_accuracy']=1-counts['exact_decision_errors']/n
    counts['by_case_type']=by_type
    counts['error_examples']=examples
    return counts

def oracle_pair(l,r):
    ls,lr,lo=l; rs,rr,ro=r
    key=f'{RELS[lr]}|{RELS[rr]}'
    if lo==rs and key in RULES:
        return (ls,R2I[RULES[key]],ro)
    key=f'{RELS[rr]}|{RELS[lr]}'
    if ro==ls and key in RULES:
        return (rs,R2I[RULES[key]],lo)
    return None

def oracle_closure(fx):
    facts={(int(p['subject']),R2I[p['relation']],int(p['object'])) for p in fx['inputs']}
    while True:
        arr=list(facts); new=set()
        for l in arr:
            for r in arr:
                x=oracle_pair(l,r)
                if x is not None and x not in facts:
                    new.add(x)
        if not new:
            return facts
        facts|=new

def count_strings(x):
    if isinstance(x,str): return 1
    if isinstance(x,(list,tuple)): return sum(count_strings(v) for v in x)
    if isinstance(x,dict): return sum(count_strings(k)+count_strings(v) for k,v in x.items())
    return 0

def infer_graph(model,fx):
    gold=oracle_closure(fx)
    # packet fields: ref, act, subject, relation, object, value
    packets=[[int(p['id']),A2I[p['act']],int(p['subject']),R2I[p['relation']],int(p['object']),1000] for p in fx['inputs']]
    audit=[]
    for p in packets:
        fact=(p[2],p[3],p[4])
        audit.append({'bad': fact not in gold, 'tainted':False, 'parents':[]})
    next_ref=max(p[0] for p in packets)+1
    existing={(p[2],p[3],p[4]) for p in packets}
    trajectory=[[0,[list(p) for p in packets]]]
    bad_by_round=[]; tainted_by_round=[]; first_corruption=None; pair_evals=0
    for rnd in range(1,int(fx['max_rounds'])+1):
        n=len(packets)
        if n<2:
            trajectory.append([rnd,[]]); break
        idx_i=torch.arange(n,dtype=torch.long).repeat_interleave(n)
        idx_j=torch.arange(n,dtype=torch.long).repeat(n)
        m=idx_i!=idx_j
        idx_i=idx_i[m]; idx_j=idx_j[m]
        candidate_info={}
        chunk=8192
        pkt=torch.tensor(packets,dtype=torch.long)
        for st in range(0,len(idx_i),chunk):
            ii=idx_i[st:st+chunk]; jj=idx_j[st:st+chunk]
            left=pkt[ii]; right=pkt[jj]
            acts=torch.stack([left[:,1],right[:,1]],dim=1)
            rels=torch.stack([left[:,3],right[:,3]],dim=1)
            refs=torch.stack([left[:,2],left[:,4],right[:,2],right[:,4]],dim=1)
            with torch.no_grad():
                outs=model(acts,rels,refs)
                pb,pr,ps,po=[x.argmax(-1) for x in outs]
            pair_evals+=len(ii)
            positive=(pb!=0)&(pr!=4)
            if not positive.any():
                continue
            sel=torch.nonzero(positive,as_tuple=False).flatten()
            slots=refs[sel]
            s=slots.gather(1,ps[sel].unsqueeze(1)).squeeze(1)
            o=slots.gather(1,po[sel].unsqueeze(1)).squeeze(1)
            rr=pr[sel]
            for k in range(len(sel)):
                posidx=int(sel[k])
                li=int(ii[posidx]); ri=int(jj[posidx])
                fact=(int(s[k]),int(rr[k]),int(o[k]))
                if fact in existing:
                    continue
                parent_taint=(audit[li]['bad'] or audit[li]['tainted'] or audit[ri]['bad'] or audit[ri]['tainted'])
                rec=candidate_info.get(fact)
                parent_pair=(packets[li][0],packets[ri][0])
                if rec is None:
                    candidate_info[fact]={'taint_any':bool(parent_taint),'parents':[parent_pair]}
                else:
                    rec['taint_any']=rec['taint_any'] or bool(parent_taint)
                    if len(rec['parents'])<8:
                        rec['parents'].append(parent_pair)
        if not candidate_info:
            trajectory.append([rnd,[]])
            terminated=True
            break
        new=[]; round_bad=0; round_tainted=0
        for fact in sorted(candidate_info):
            s,r,o=fact
            p=[next_ref,A2I['DERIVE'],s,r,o,1000]; next_ref+=1
            info=candidate_info[fact]
            is_bad=fact not in gold
            is_tainted=bool(info['taint_any'])
            packets.append(p); existing.add(fact); new.append(p)
            audit.append({'bad':is_bad,'tainted':is_tainted,'parents':info['parents']})
            round_bad+=int(is_bad)
            round_tainted+=int(is_tainted)
        bad_by_round.append(round_bad); tainted_by_round.append(round_tainted)
        if round_bad>0 and first_corruption is None:
            first_corruption=rnd
        trajectory.append([rnd,new])
    else:
        terminated=False
    if 'terminated' not in locals():
        terminated=True
    pred={(p[2],p[3],p[4]) for p in packets}
    tp=len(pred&gold); fp=len(pred-gold); fn=len(gold-pred)
    bad_count=sum(a['bad'] for a in audit)
    tainted_count=sum(a['tainted'] for a in audit)
    # tainted descendants specifically exclude bad packets themselves if they were first-generation clean-parent errors.
    tainted_gold=sum((a['tainted'] and not a['bad']) for a in audit)
    return {
        'fixture_id':fx['fixture_id'],'family':fx['family'],'scale':fx['scale'],'replicate':fx['replicate'],
        'input_packets':len(fx['inputs']),'final_packets':len(packets),'gold_fact_count':len(gold),
        'precision':1.0 if tp+fp==0 else tp/(tp+fp),'recall':1.0 if tp+fn==0 else tp/(tp+fn),
        'exact_match':pred==gold,'false_positive_facts':fp,'false_negative_facts':fn,
        'bad_packet_count':int(bad_count),'tainted_packet_count':int(tainted_count),'tainted_gold_packet_count':int(tainted_gold),
        'first_corruption_round':first_corruption,'bad_packets_by_round':bad_by_round,'tainted_packets_by_round':tainted_by_round,
        'rounds':len(trajectory)-1,'pair_evaluations':pair_evals,'terminated':bool(terminated),
        'numeric_trace_string_count':count_strings(trajectory),
        'trajectory_sha256':hashlib.sha256(json.dumps(trajectory,separators=(',',':')).encode()).hexdigest(),
    }

def recursive_exam(model):
    gd=json.loads((FIX/'RECURSIVE_STABILITY_GRAPHS.json').read_text())
    rows=[]
    for fx in gd['fixtures']:
        rows.append(infer_graph(model,fx))
    return rows

def classify_seed(local,graphs):
    local_errors=(local['binding_false_positives']+local['binding_false_negatives']+local['relation_errors']+local['selector_errors'])>0
    recursive_bad=sum(g['bad_packet_count'] for g in graphs)
    recursive_tainted=sum(g['tainted_packet_count'] for g in graphs)
    exact_rate=sum(g['exact_match'] for g in graphs)/len(graphs)
    term_rate=sum(g['terminated'] for g in graphs)/len(graphs)
    numeric=all(g['numeric_trace_string_count']==0 for g in graphs)
    if not local_errors and recursive_bad==0 and recursive_tainted==0 and exact_rate==1.0 and term_rate==1.0 and numeric:
        verdict='RECURSIVELY_STABLE_WITHIN_TESTED_SCOPE'
    elif not local_errors and (recursive_bad>0 or exact_rate<1.0):
        verdict='LOCALLY_CLEAN_BUT_RECURSIVELY_UNSTABLE'
    elif local_errors and (recursive_bad>0 or exact_rate<1.0):
        verdict='LOCAL_ERRORS_AND_RECURSIVE_ERRORS'
    else:
        verdict='LOCAL_ERRORS_WITHOUT_OBSERVED_RECURSIVE_CORRUPTION'
    return verdict,{
        'recursive_bad_packet_count':recursive_bad,
        'recursive_tainted_packet_count':recursive_tainted,
        'recursive_exact_graph_rate':exact_rate,
        'termination_rate':term_rate,
        'numeric_only':numeric,
        'graphs_with_any_bad_packet':sum(g['bad_packet_count']>0 for g in graphs),
        'graphs_with_tainted_descendants':sum(g['tainted_packet_count']>0 for g in graphs),
    }

def run(seed):
    t0=time.time()
    model,p=load_model(seed)
    freeze=verify_freeze(seed,p)
    local=local_exam(model)
    graphs=recursive_exam(model)
    verdict,summary=classify_seed(local,graphs)
    out={
        'experiment':'PRIMITIVE-2B','version':'0.1.0','seed':seed,
        'model_sha256':sha_file(p),'freeze_sha256':freeze['freeze_sha256'],
        'seed_verdict':verdict,'elapsed_seconds':time.time()-t0,
        'local_exam':local,'recursive_summary':summary,'graphs':graphs,
    }
    out['result_sha256']=hashlib.sha256(canon(out).encode()).hexdigest()
    (RES/f'SEED_{seed}_RESULT.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({
        'seed':seed,'seed_verdict':verdict,'elapsed_seconds':out['elapsed_seconds'],
        'local_exact_accuracy':local['exact_local_accuracy'],
        'local_binding_fp':local['binding_false_positives'],'local_binding_fn':local['binding_false_negatives'],
        'local_relation_errors':local['relation_errors'],'local_selector_errors':local['selector_errors'],
        **summary
    },indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--seed',type=int,required=True)
    args=ap.parse_args(); run(args.seed)
