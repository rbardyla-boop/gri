#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/'results'/'PRIMITIVE-2B_RESULTS.json').read_text())
assert r['terminal_verdict']=='RECURSIVE_INSTABILITY_DEMONSTRATED_WITHIN_TESTED_SCOPE'
assert len(r['seed_summaries'])==3
assert all(s['local_exact_accuracy']>0.9999 for s in r['seed_summaries'])
assert all(s['graphs_corrupted']>0 for s in r['seed_summaries'])
assert r['scientific_observations']['seed_61_zero_binding_fp_fn_on_200k_local_exam_but_recursive_corruption'] is True
print('PRIMITIVE_2B_TEST_PASS')
