# PRIMITIVE-2B Method

1. Freeze the three exact PRIMITIVE-2A model files by SHA-256.
2. Prohibit retraining, threshold tuning, architecture changes, or seed selection.
3. Generate and freeze a new 8,192-reference pool disjoint from all PRIMITIVE-2A references.
4. Score 200,000 frozen local packet-pair decisions per model.
5. Score 47 frozen recursive graph traces per model.
6. Feed every emitted packet back into later inference rounds exactly as PRIMITIVE-2A did.
7. Use experimenter-only oracle closure to label false-positive/false-negative final facts.
8. Use experimenter-only parent lineage to mark BAD and TAINTED packets; this audit is never model-visible.
9. Preserve every seed result separately, then issue the terminal verdict from the preregistered stability gate.
