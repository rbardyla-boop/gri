#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASE_PATH = ROOT / "implementation" / "run_primitive0.py"
OUTDIR = ROOT / "results_c1"
DECL = HERE / "C1_REPAIR_DECLARATIONS.md"
EXPECTED_MANIFEST_SHA = "844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e"

spec = importlib.util.spec_from_file_location("primitive0_base", BASE_PATH)
base = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = base
spec.loader.exec_module(base)


class CandidateC1ID(base.Candidate):
    name, version = "C1-ID", "C1-ID-0"
    representation = "(ID,ACT,SUBJECT,RELATION,OBJECT,VALUE)"
    adapters: List[str] = []
    side_channels: List[str] = []
    external_tables: List[str] = []
    future_portability = "HIGH_WITH_SYMBOL_DICTIONARY"
    symbolic_compatibility = "HIGH"

    def encode(self, p: dict):
        return (
            p.get("id"),
            p.get("act"),
            p.get("subject"),
            p.get("relation"),
            p.get("object"),
            p.get("value"),
        )

    def decode(self, x):
        d = {
            "id": x[0],
            "act": x[1],
            "subject": x[2],
            "relation": x[3],
            "object": x[4],
            "value": x[5],
        }
        return {k: v for k, v in d.items() if v is not None}


class CandidateC1Handle(base.Candidate):
    name, version = "C1-HANDLE", "C1-HANDLE-0"
    representation = "C0_PAYLOAD_PLUS_EXTERNAL_STABLE_HANDLE"
    adapters = ["stable_handle_attach", "stable_handle_lookup"]
    side_channels = ["packet_handle", "handle_to_source_id_table"]
    external_tables = ["handle_to_source_id_table"]
    future_portability = "MEDIUM_REQUIRES_SHARED_HANDLE_PROTOCOL"
    symbolic_compatibility = "HIGH_AFTER_HANDLE_LOOKUP"

    def __init__(self, vocab: Dict[str, List[str]]):
        super().__init__(vocab)
        self.next_handle = 1
        self.id_by_handle: Dict[int, str] = {}
        self.side_channel_bytes_transferred = 0
        self.side_channel_storage_bytes = 0
        self.handle_lookup_calls = 0

    def adapter_cost_encode(self):
        return 1

    def adapter_cost_decode(self):
        return 1

    @staticmethod
    def _handle_wire_bytes(handle: int) -> int:
        # Reference-only canonical decimal JSON measurement, matching the base
        # harness's explicit non-ENCODING-0 measurement policy.
        return len(json.dumps(handle, separators=(",", ":")).encode("utf-8"))

    def encode(self, p: dict):
        handle = self.next_handle
        self.next_handle += 1
        payload = (
            p.get("act"),
            p.get("subject"),
            p.get("relation"),
            p.get("object"),
            p.get("value"),
        )
        # The handle is mandatory external machinery paired with the payload.
        self.side_channel_bytes_transferred += self._handle_wire_bytes(handle)
        if p.get("id") is not None:
            self.id_by_handle[handle] = str(p["id"])
            # Count a canonical JSON table entry as reference side-channel storage.
            entry = {str(handle): str(p["id"])}
            entry_bytes = len(json.dumps(entry, sort_keys=True, separators=(",", ":")).encode("utf-8"))
            # A remote consumer cannot recover source identity from the handle
            # unless this generated table entry is synchronized too. Charge it
            # to both transport and storage rather than granting a free channel.
            self.side_channel_bytes_transferred += entry_bytes
            self.side_channel_storage_bytes += entry_bytes
        # Wrapper exists in harness state only so decoding can perform the declared
        # external handle lookup. base wire_bytes is overridden below to count only payload.
        return {"handle": handle, "payload": payload}

    def decode(self, x):
        self.handle_lookup_calls += 1
        payload = x["payload"]
        d = {
            "act": payload[0],
            "subject": payload[1],
            "relation": payload[2],
            "object": payload[3],
            "value": payload[4],
        }
        handle = int(x["handle"])
        if handle in self.id_by_handle:
            d["id"] = self.id_by_handle[handle]
        return {k: v for k, v in d.items() if v is not None}

    def encode_counted(self, packet: dict) -> Any:
        x = self.encode(packet)
        self.metrics.adapter_calls += self.adapter_cost_encode()
        # Primitive transport is C0 payload only; handle transport is counted separately.
        self.metrics.wire_bytes_transferred += base.wire_bytes(x["payload"])
        return x

    def storage_cost(self, encoded_packets):
        # Candidate payload storage only. External handle table is reported separately.
        return sum(base.wire_bytes(x["payload"]) for x in encoded_packets)

    def declaration(self):
        d = super().declaration()
        d.update({
            "mandatory_external_identity_machinery": True,
            "side_channel_cost_policy": "payload bytes in base metrics; handle/table bytes reported separately",
        })
        return d


CANDIDATES = [CandidateC1ID, CandidateC1Handle]


def validate_fixture_freeze():
    base.verify_fixtures()
    manifest_path = base.FIXTURES / "MANIFEST.json"
    got = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    if got != EXPECTED_MANIFEST_SHA:
        raise RuntimeError(f"frozen manifest changed: expected {EXPECTED_MANIFEST_SHA}, got {got}")
    return got


def extra_costs(candidate):
    return {
        "side_channel_wire_bytes_reference": int(getattr(candidate, "side_channel_bytes_transferred", 0)),
        "side_channel_storage_bytes_reference": int(getattr(candidate, "side_channel_storage_bytes", 0)),
        "handle_lookup_calls": int(getattr(candidate, "handle_lookup_calls", 0)),
    }


def run_once(ctype, vocab, task):
    c = ctype(vocab)
    try:
        r = base.run_task(c, task)
        r["repair_extra_costs"] = extra_costs(c)
        return c, r
    except Exception as e:
        return c, {
            "task_id": task["task_id"],
            "task_name": task["name"],
            "execution_verdict": "EXPERIMENT_INVALID",
            "semantic_verdict": None,
            "failure_class": "IMPLEMENTATION_ERROR",
            "notes": [f"{type(e).__name__}: {e}"],
            "trajectory_hash": None,
            "metrics": {},
            "repair_extra_costs": extra_costs(c),
        }


def summarize(declaration: dict, task_results: List[dict]):
    s = base.summarize_candidate(declaration, task_results)
    valid = [r for r in task_results if r["execution_verdict"] == "RUN_VALID"]
    side_wire = sum(r.get("repair_extra_costs", {}).get("side_channel_wire_bytes_reference", 0) for r in valid)
    side_store = sum(r.get("repair_extra_costs", {}).get("side_channel_storage_bytes_reference", 0) for r in valid)
    lookups = sum(r.get("repair_extra_costs", {}).get("handle_lookup_calls", 0) for r in valid)
    s["repair_metric_totals"] = {
        "side_channel_wire_bytes_reference": side_wire,
        "side_channel_storage_bytes_reference": side_store,
        "handle_lookup_calls": lookups,
        "total_reference_transport_including_side_channel": s["metric_totals"]["wire_bytes_transferred_reference"] + side_wire,
        "total_reference_storage_including_side_channel": s["metric_totals"]["storage_bytes_reference"] + side_store,
    }
    return s


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(OUTDIR / "PRIMITIVE-0_C1_REPAIR_RESULTS.json"))
    args = parser.parse_args()

    manifest_sha = validate_fixture_freeze()
    tasks = base.load_tasks()
    ontology = base.load_ontology()
    vocab = base.build_vocab(tasks, ontology)
    OUTDIR.mkdir(exist_ok=True)

    exp = {
        "benchmark": "PRIMITIVE-0",
        "benchmark_version": "0.1.0",
        "repair_experiment": "C1_STABLE_REFERENCE_REPAIR",
        "repair_version": "0.1.0",
        "fixture_manifest_sha256": manifest_sha,
        "declarations_sha256": hashlib.sha256(DECL.read_bytes()).hexdigest(),
        "benchmark_modified": False,
        "candidates": {},
    }

    for ctype in CANDIDATES:
        probe = ctype(vocab)
        results = []
        for task in tasks:
            c1, r1 = run_once(ctype, vocab, task)
            c2, r2 = run_once(ctype, vocab, task)
            replay_ok = (
                r1.get("execution_verdict") == r2.get("execution_verdict") == "RUN_VALID"
                and r1.get("trajectory_hash") == r2.get("trajectory_hash")
                and r1.get("semantic_verdict") == r2.get("semantic_verdict")
                and r1.get("repair_extra_costs") == r2.get("repair_extra_costs")
            )
            if r1.get("execution_verdict") == "RUN_VALID":
                r1["replay"] = {
                    "deterministic_reproducibility": "PASS" if replay_ok else "FAIL",
                    "second_trajectory_hash": r2.get("trajectory_hash"),
                }
                if not replay_ok:
                    r1["failure_class"] = r1.get("failure_class") or "REPLAY_FAILURE"
            results.append(r1)
        exp["candidates"][probe.name] = {
            "summary": summarize(probe.declaration(), results),
            "tasks": results,
        }

    invalid = any(v["summary"]["invalid_runs"] for v in exp["candidates"].values())
    sufficient = [name for name, v in exp["candidates"].items()
                  if v["summary"]["interpretation"] == "SEMANTICALLY_SUFFICIENT_WITHIN_TESTED_SCOPE"]
    exp["semantically_sufficient_candidates"] = sufficient
    if invalid:
        exp["terminal_verdict"] = "EXPERIMENT_INCOMPLETE"
    elif len(sufficient) == 2:
        # Both repairs solve semantics. The experiment's purpose is to compare
        # where identity cost lives, not to invent a scalar score.
        exp["terminal_verdict"] = "BOTH_REPAIRS_SEMANTICALLY_SUFFICIENT_COMPARE_SYSTEM_COST"
    elif len(sufficient) == 1:
        exp["terminal_verdict"] = "SINGLE_REPAIR_SUFFICIENT_WITHIN_TESTED_SCOPE"
    else:
        exp["terminal_verdict"] = "C1_REPAIR_INSUFFICIENT"

    out = Path(args.out)
    out.write_text(json.dumps(exp, indent=2), encoding="utf-8")

    lines = [
        "# PRIMITIVE-0 C1 Stable-Reference Repair Results",
        "",
        f"**Frozen benchmark:** PRIMITIVE-0 v0.1.0  ",
        f"**Fixture manifest SHA-256:** `{manifest_sha}`  ",
        "**Benchmark modified:** NO  ",
        f"**Terminal verdict:** `{exp['terminal_verdict']}`",
        "",
        "## Summary",
        "",
        "| Variant | Pass | Base ref wire bytes | Side-channel wire bytes | Total ref transport | Base storage | Side-channel storage | Adapter calls | Handle lookups |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for name, data in exp["candidates"].items():
        s = data["summary"]
        m = s["metric_totals"]
        x = s["repair_metric_totals"]
        lines.append(
            f"| {name} | {s['tasks_passed']}/8 | {m['wire_bytes_transferred_reference']} | "
            f"{x['side_channel_wire_bytes_reference']} | {x['total_reference_transport_including_side_channel']} | "
            f"{m['storage_bytes_reference']} | {x['side_channel_storage_bytes_reference']} | "
            f"{m['adapter_calls']} | {x['handle_lookup_calls']} |"
        )

    lines += ["", "## Task matrix", "", "| Task | C1-ID | C1-HANDLE |", "|---|---|---|"]
    for i in range(8):
        r_id = exp["candidates"]["C1-ID"]["tasks"][i]
        r_h = exp["candidates"]["C1-HANDLE"]["tasks"][i]
        lines.append(f"| {r_id['task_id']} {r_id['task_name']} | {r_id['semantic_verdict']} | {r_h['semantic_verdict']} |")

    lines += [
        "",
        "## Interpretation",
        "",
        "Both minimal repairs are judged semantically sufficient only if they pass the unchanged T1–T8 suite.",
        "Reference JSON byte counts are not an ENCODING-0 verdict.",
        "C1-HANDLE is not allowed to hide identity cost: mandatory handle/table bytes, adapter calls, and lookups are reported separately.",
        "No composite cost score is authorized.",
    ]
    (OUTDIR / "PRIMITIVE-0_C1_REPAIR_RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({
        "terminal_verdict": exp["terminal_verdict"],
        "summaries": {k: v["summary"] for k,v in exp["candidates"].items()},
    }, indent=2))


if __name__ == "__main__":
    main()
