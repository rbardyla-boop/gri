# PRIMITIVE-0 C1 Repair Declarations

**Benchmark:** PRIMITIVE-0 v0.1.0 (unchanged)  
**Fixture manifest SHA-256:** `844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e`  
**Purpose:** Test the minimum repair for C0's stable source-assertion reference failure on T3 without adding unrelated semantics.

## C0 baseline

`(ACT, SUBJECT, RELATION, OBJECT, VALUE)`

Known frozen result: 7/8; T3 fails because source assertion `ID` is not recoverable after encoding.

## C1-ID — in-band stable identity

Semantic representation:

`(ID, ACT, SUBJECT, RELATION, OBJECT, VALUE)`

Rules:
- `ID` is optional for packets that are never referable.
- If an input carries `ID`, C1-ID preserves it in-band.
- No external identity table is permitted.
- No confidence, provenance, timestamp, memory metadata, or other fields are added.

Cost accounting:
- ID slot/encoding cost counts as primitive transport/storage cost.
- No identity side-channel cost.

## C1-HANDLE — unchanged C0 payload + external stable-handle table

Primitive payload remains exactly:

`(ACT, SUBJECT, RELATION, OBJECT, VALUE)`

Mandatory external machinery:
- deterministic handle accompanying each encoded packet;
- handle → source `ID` table for packets that entered with an evaluator-visible ID;
- decoder lookup that restores source ID for inference/evaluation.

Rules:
- the table is not allowed to contain ACT/SUBJECT/RELATION/OBJECT/VALUE;
- it exists only to preserve packet identity;
- table/handle bytes and lookup calls are separately counted as side-channel/system cost;
- no hidden evaluator access after encoding.

This variant tests whether keeping C0's semantic payload unchanged is actually cheaper once mandatory identity machinery is accounted for.

## Shared restrictions

- Same frozen T1–T8 fixtures.
- Same ontology.
- Same deterministic structured rule engine.
- Same no-explicit-prose rule.
- No required-output fixture data used to repair candidate semantics.
- Two fresh deterministic runs per candidate/task; trajectory hashes must match.
