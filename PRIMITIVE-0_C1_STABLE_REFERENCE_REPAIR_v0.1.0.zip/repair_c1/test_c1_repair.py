#!/usr/bin/env python3
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "repair_c1" / "run_c1_repair.py"
RESULT = ROOT / "results_c1" / "PRIMITIVE-0_C1_REPAIR_RESULTS.json"
MANIFEST = ROOT / "PRIMITIVE-0_FIXTURES" / "MANIFEST.json"
EXPECTED_MANIFEST_SHA = "844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e"

assert hashlib.sha256(MANIFEST.read_bytes()).hexdigest() == EXPECTED_MANIFEST_SHA
subprocess.run([sys.executable, str(RUNNER)], check=True, stdout=subprocess.DEVNULL)
data = json.loads(RESULT.read_text())
assert data["benchmark_modified"] is False
assert data["fixture_manifest_sha256"] == EXPECTED_MANIFEST_SHA
assert set(data["candidates"]) == {"C1-ID", "C1-HANDLE"}
for name, c in data["candidates"].items():
    assert c["summary"]["tasks_passed"] == 8, name
    assert c["summary"]["invalid_runs"] == 0, name
    for r in c["tasks"]:
        assert r["execution_verdict"] == "RUN_VALID", (name, r)
        assert r["semantic_verdict"] == "PASS", (name, r)
        assert r["replay"]["deterministic_reproducibility"] == "PASS", (name, r)
print("C1_REPAIR_TEST_PASS")
