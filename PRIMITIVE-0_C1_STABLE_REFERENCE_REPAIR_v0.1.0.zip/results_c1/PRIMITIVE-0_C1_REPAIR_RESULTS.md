# PRIMITIVE-0 C1 Stable-Reference Repair Results

**Frozen benchmark:** PRIMITIVE-0 v0.1.0  
**Fixture manifest SHA-256:** `844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e`  
**Benchmark modified:** NO  
**Terminal verdict:** `BOTH_REPAIRS_SEMANTICALLY_SUFFICIENT_COMPARE_SYSTEM_COST`

## Summary

| Variant | Pass | Base ref wire bytes | Side-channel wire bytes | Total ref transport | Base storage | Side-channel storage | Adapter calls | Handle lookups |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| C1-ID | 8/8 | 1258 | 0 | 1258 | 1098 | 0 | 0 | 0 |
| C1-HANDLE | 8/8 | 1095 | 109 | 1204 | 956 | 83 | 78 | 76 |

## Task matrix

| Task | C1-ID | C1-HANDLE |
|---|---|---|
| T1 RELAY | PASS | PASS |
| T2 COMPOSE | PASS | PASS |
| T3 CONTRADICT | PASS | PASS |
| T4 UPDATE | PASS | PASS |
| T5 REQUEST_RESPONSE | PASS | PASS |
| T6 MULTISTEP_TRANSFORM | PASS | PASS |
| T7 INFORMATION_COLLISION | PASS | PASS |
| T8 NOVEL_COMBINATION | PASS | PASS |

## Interpretation

Both minimal repairs are judged semantically sufficient only if they pass the unchanged T1–T8 suite.
Reference JSON byte counts are not an ENCODING-0 verdict.
C1-HANDLE is not allowed to hide identity cost: mandatory handle/table bytes, adapter calls, and lookups are reported separately.
No composite cost score is authorized.
