# PRIMITIVE-0 C1 Repair Conclusion

**Frozen benchmark:** PRIMITIVE-0 v0.1.0  
**Fixture manifest SHA-256:** `844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e`  
**Benchmark modified:** NO

## Result

C0:

```text
(ACT, SUBJECT, RELATION, OBJECT, VALUE)
```

previously passed 7/8 and failed only T3 because source assertions were not stably referable after encoding.

Two minimal repairs were tested against the unchanged T1–T8 suite:

```text
C1-ID
(ID, ACT, SUBJECT, RELATION, OBJECT, VALUE)

C1-HANDLE
(ACT, SUBJECT, RELATION, OBJECT, VALUE)
+ mandatory external stable identity protocol
```

Both passed 8/8 with deterministic replay.

## Narrow scientific conclusion

Within PRIMITIVE-0's tested scope:

> Stable referential identity is required somewhere in the system for a machine-native primitive to preserve and reason about assertions as objects of later assertions.

The benchmark does **not** determine that identity must be a sixth semantic payload field.

It may be represented as:

- an in-band `ID` field;
- envelope metadata;
- a stable handle protocol;
- another encoding that preserves equivalent referential semantics.

However, moving identity outside the primitive does not make its cost disappear. Any mandatory handle synchronization, lookup table, adapter, or side channel remains part of total system cost.

## Reference cost observation — not ENCODING-0

Under the reference JSON measurement only:

```text
C1-ID
transport: 1258 bytes
storage:   1098 bytes
adapters:  0
lookups:   0

C1-HANDLE
payload transport:      1095 bytes
identity side channel:   109 bytes
total transport:        1204 bytes
payload storage:         956 bytes
identity table storage:   83 bytes
total storage:          1039 bytes
adapters:                 78
handle lookups:           76
```

These byte counts are not an encoding verdict. Null-slot overhead, integer packing, dictionary coding, envelope layout, batching, and variable-width encoding have not been optimized.

The meaningful current tradeoff is structural:

```text
C1-ID
slightly larger explicit semantic packet
+ no identity infrastructure

versus

C1-HANDLE
smaller base payload
+ mandatory synchronized identity infrastructure
```

## What is frozen now

The smallest tested symbolic family that clears all PRIMITIVE-0 semantics is therefore:

```text
STABLE_REFERENCE
+
ACT
+
SUBJECT
+
RELATION
+
OBJECT
+
VALUE
```

`STABLE_REFERENCE` is a required capability, not yet a frozen wire-field placement.

## Next independently judgeable question

The next narrow question is not to add more cognition fields.

It is:

> What is the cheapest interoperable encoding/protocol for stable reference + `(ACT,SUBJECT,RELATION,OBJECT,VALUE)`?

That belongs to ENCODING-0 / protocol testing, not to semantic ontology expansion.
