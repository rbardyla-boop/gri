#!/usr/bin/env python3
import argparse, hashlib, json, subprocess, sys, tempfile, zipfile
from datetime import datetime, timezone
from pathlib import Path

FIELDS = {
 'parent_freeze_sha256':'parent_freeze','operational_config_sha256':'operational_config',
 'consent_sha256':'consent','recruitment_config_sha256':'recruitment_config',
 'alpha2_parser_sha256':'alpha2_parser','export_schema_sha256':'export_schema',
 'scientific_invariant_manifest_sha256':'scientific_invariant_manifest',
 'zero_human_ingestion_receipt_sha256':'zero_human_ingestion_receipt','ethics_evidence_sha256':'ethics_evidence',
 'validator_source_sha256':'validator_source'}
def sha(p):
    h=hashlib.sha256(); h.update(Path(p).read_bytes()); return h.hexdigest()
def fail(root, blockers, checks):
    out={'status':'RECRUITMENT_NOT_AUTHORIZED','blockers':blockers,'checks':checks,
         'timestamp':datetime.now(timezone.utc).isoformat(),'validator_result':'FAIL'}
    (root/'SRI-1A-alpha.4_BLOCKERS.json').write_text(json.dumps(out,indent=2)+'\n')
    print('SRI_ALPHA4_RECRUITMENT_NOT_AUTHORIZED')
    for b in blockers: print('- '+b)
    return 2
def validate(root, fixture=False):
    checks={}; blockers=[]
    cfg=root/'operational_config.json'
    if not cfg.exists(): return fail(root,['missing operational_config.json'],checks)
    data=json.loads(cfg.read_text())
    if data.get('authority') != 'AUTHORITATIVE' or fixture or data.get('fixture_authority') == 'NON-AUTHORITY':
        blockers.append('operational configuration is not authoritative')
    for name,key in FIELDS.items():
        expected=data.get(name); path=data.get(key)
        ok=isinstance(expected,str) and len(expected)==64 and all(c in '0123456789abcdef' for c in expected) and isinstance(path,str) and (root/path).is_file() and sha(root/path)==expected
        checks[name]={'pass':ok,'expected':expected,'path':path}
        if not ok: blockers.append(name+' missing or SHA-256 mismatch')
    required=['recruitment_source','platform_configuration','inclusion_criteria','exclusion_criteria','target_n_or_fixed_stop_rule','attrition_rule','incomplete_response_rule','compensation','consent_final_sha256','data_retention_rule','withdrawal_rule','research_contact','ethics_reb_disposition']
    for k in required:
        if not data.get(k) or (isinstance(data[k],str) and data[k].startswith('UNRESOLVED')): blockers.append(k+' unresolved')
    if data.get('ethics_reb_disposition') not in ('APPROVED_WITH_IDENTIFIER','DOCUMENTED_NOT_APPLICABLE_WITH_BASIS'): blockers.append('ethics_reb_disposition invalid')
    if data.get('zero_human_replay') is not True: blockers.append('zero-human ingestion replay did not pass')
    if data.get('scientific_invariants_unchanged') is not True: blockers.append('scientific invariants changed or unverified')
    if blockers: return fail(root,blockers,checks)
    print('SRI_ALPHA4_RECRUITMENT_AUTHORIZED'); return 0
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',type=Path,default=Path(__file__).parent); ap.add_argument('--package',type=Path); ap.add_argument('--fixture',action='store_true'); a=ap.parse_args()
    if a.package:
        with tempfile.TemporaryDirectory() as d:
            with zipfile.ZipFile(a.package) as z: z.extractall(d)
            base=next(Path(d).iterdir()) if len(list(Path(d).iterdir()))==1 else Path(d)
            return validate(base,a.fixture)
    return validate(a.root,a.fixture)
if __name__=='__main__': sys.exit(main())
