import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).parents[1]; V=ROOT/'validate_authorization.py'
def run(root): return subprocess.run([sys.executable,str(V),'--root',str(root)],capture_output=True,text=True)
def test_untouched_package_is_not_authorized():
    p=subprocess.run([sys.executable,str(V),'--package',str(ROOT.parent/'SRI-1A-alpha.4_LIVE_PILOT_AUTHORIZATION_v0.1.0.zip')],capture_output=True,text=True)
    assert p.returncode==2 and 'NOT_AUTHORIZED' in p.stdout
def test_unresolved_and_missing_fail_closed():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d); (p/'operational_config.json').write_text(json.dumps({'authority':'AUTHORITATIVE'}))
        r=run(p); assert r.returncode==2 and (p/'SRI-1A-alpha.4_BLOCKERS.json').exists()
def test_fixture_cannot_authorize():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d); (p/'operational_config.json').write_text(json.dumps({'authority':'AUTHORITATIVE','fixture_authority':'NON-AUTHORITY'}))
        assert run(p).returncode==2
