The adversarial matrix is represented by the validator's independent checks:
arbitrary non-SHA text, missing/wrong parser or schema, changed scientific
parents, unresolved REB/target/compensation/consent, mutated ingestion files,
and non-authority fixtures all fail closed. The live package test verifies the
untouched current package remains locked.
