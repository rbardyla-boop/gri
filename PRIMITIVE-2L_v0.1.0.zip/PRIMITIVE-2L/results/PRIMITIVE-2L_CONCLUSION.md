# PRIMITIVE-2L Conclusion

**Terminal verdict:** `MODEL_CLASS_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Base model-class failure

The frozen 288-program base grammar had no exact explanation in any scored world.

`MINIMAL_OPERATOR_SYNTHESIS` responded by declaring model-class failure in:

```text
192/192
```

worlds.

`FORCE_BASE_BEST_FIT` never declared failure and instead selected the least-wrong old theory.

Its predictive performance was:

```text
held-out passive accuracy:      0.880729
interventional accuracy:        0.948281
```

This is the failure mode PRIMITIVE-2L was designed to expose:

> a closed model class can produce a plausible best fit even when every model in the class is wrong.

## Minimal extension synthesis

The primary system represented a possible new binary operator directly as a four-bit truth table.

It recovered:

```text
novel operator truth table:     192/192
hidden causal program:          192/192
minimum extension proof:        192/192
held-out passive accuracy:      1.000000
interventional accuracy:        1.000000
deterministic replay:           PASS
```

Every successful escape added exactly one new operator table.

## Why adding everything is not equivalent

`FULL_BOOLEAN_EXPANSION` added all twelve operators absent from the base language.

It fit every discovery observation:

```text
192/192 exact
```

but its larger version space remained underconstrained.

Its predictive result fell to:

```text
held-out passive accuracy:      0.984896
interventional accuracy:        0.995078
```

So:

> Model-class expansion is not enough. Uncontrolled expressive expansion can restore fit while weakening identification.

Within this benchmark, the smallest sufficient extension was also the predictively correct one.

## Supported claim

Within the identifiable frozen Boolean causal worlds:

> A machine can recognize that its existing causal model class has empty exact support, synthesize a previously absent binary operator as a machine-native truth table, select the minimal one-operator language extension, and restore exact held-out and interventional prediction.

## Scope boundary

Only six of the twelve absent Boolean truth tables were uniquely identifiable under this grammar/discovery protocol:

```text
{1: 31, 2: 31, 4: 32, 7: 31, 11: 36, 13: 31}
```

The result therefore does not support arbitrary operator invention.

More importantly, the meta-language itself was supplied:

```text
"new thing" = arbitrary binary Boolean truth table
```

The system learned the missing table, but it did not invent the concept of a truth-table operator, change operator arity, introduce memory, add latent state, or invent recurrence.

## Largest remaining gap

The next problem is a deeper form of model-class failure:

> What happens when the true mechanism cannot be represented even by the extension meta-language the system was given?

A serious next unit should force failure that requires a **structural** extension—such as introducing a latent variable, recurrence, or higher-arity dependency—rather than filling in a missing operator within a known template.
