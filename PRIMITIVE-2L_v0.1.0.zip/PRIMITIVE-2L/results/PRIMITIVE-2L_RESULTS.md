# PRIMITIVE-2L Results

**Terminal verdict:** `MODEL_CLASS_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Exact deterministic replay:** `PASS`  
**Worlds:** 192

| System | Base failure declared | Discovery exact | New operators | Held-out passive | Intervention prediction |
|---|---:|---:|---:|---:|---:|
| FORCE_BASE_BEST_FIT | 0/192 | 0/192 | 0.0 | 0.880729 | 0.948281 |
| FULL_BOOLEAN_EXPANSION | 192/192 | 192/192 | 12.0 | 0.984896 | 0.995078 |
| MINIMAL_OPERATOR_SYNTHESIS | 192/192 | 192/192 | 1.0 | 1.000000 | 1.000000 |

## Minimal synthesis

- Novel truth table exact: `192/192`
- Hidden causal program exact: `192/192`
- Independent minimum extension exact: `192/192`
- Unique sufficient one-table extension: `192/192`

## Frozen world coverage

- Novel truth tables represented: `{1: 31, 2: 31, 4: 32, 7: 31, 11: 36, 13: 31}`
- Novel location distribution: `{'V3': 131, 'V4': 61}`
