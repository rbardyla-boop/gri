# PRIMITIVE-2L — MODEL-CLASS ESCAPE

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `8bc53798721b527c0b17ee8c78d3a52c29b653c3b78ada6cd5100e750dd8eac2`  
**Grammar SHA-256:** `fcf1b784d4a368f63efc5111566bf543950f9d8318bd385eb2feed76e8547af8`  
**World-set SHA-256:** `27c05fd196ef1f0408854413eec2b21a90a3f663b07267cf454b9353ad1c3cfe`

## Question

> When every hypothesis available in the current machine-native grammar fails to explain the observations, can the system recognize that the model class itself is inadequate and construct a minimal extension that restores explanatory and predictive adequacy?

## Base grammar

The frozen causal language uses two binary structural equations over five variables.

Allowed base operators are canonically represented as 4-bit truth tables:

```text
AND
OR
XOR
XNOR
```

There are 288 base programs.

## Escape language

PRIMITIVE-2L does not supply a list of named rescue operators.

A possible new binary operator is represented directly as:

```text
[f(0,0), f(0,1), f(1,0), f(1,1)]
```

There are 16 possible binary Boolean truth tables.

Four already exist in the base grammar.

The primary system may add **one** previously absent table.

## Frozen world construction

Each hidden world contains exactly one operator absent from the base grammar.

For every world:

```text
base exact version space = EMPTY
```

after six discovery root states.

The world is retained only when exactly one single-table language extension admits an exact-fitting causal program.

Two root states remain held out.

## Systems

```text
FORCE_BASE_BEST_FIT
FULL_BOOLEAN_EXPANSION
MINIMAL_OPERATOR_SYNTHESIS
```

`FORCE_BASE_BEST_FIT` never admits that the grammar is wrong.

`FULL_BOOLEAN_EXPANSION` escapes by adding every absent binary operator.

`MINIMAL_OPERATOR_SYNTHESIS` must:

```text
detect zero exact base fits
→ search possible one-table language extensions
→ synthesize the unique sufficient truth table
→ freeze the extended program
→ predict unseen states/interventions
```

## Predictive gate

After extension construction, score:

```text
2 held-out passive root states
+
all 8 root states
× all 10 one-shot do(variable=value) interventions
× all 5 observed variables
```

That is 400 scalar interventional predictions per world.

## Strict pass

Across all 192 worlds:

```text
model-class failure detected
exactly one new operator table added
correct novel truth table recovered
100% held-out passive accuracy
100% interventional prediction accuracy
extension proven minimal
deterministic replay
```

## Scope limit

This is **model-class escape inside a frozen meta-language**.

The system can synthesize a previously absent binary Boolean truth table.

It does not yet invent:

```text
new arity
new state variables
latent variables
recurrence
continuous operators
entirely new computational substrates
```
