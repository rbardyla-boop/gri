# PRIMITIVE-2L METHOD

1. Freeze the PRIMITIVE-2J structural grammar with 288 programs and four binary operators: AND, OR, XOR and XNOR.
2. Canonically represent every binary Boolean operator as a four-bit truth table over inputs 00, 01, 10 and 11.
3. Permit model-class escape through a meta-language that can add one previously absent four-bit truth table.
4. Generate 192 hidden worlds containing exactly one absent operator in one structural equation.
5. Provide six of eight root states as discovery observations and hold two root states out.
6. Retain only worlds where:
   - the base grammar has zero exact fits;
   - exactly one absent truth table yields an exact one-operator extension;
   - exactly one causal program under that extension fits discovery;
   - that recovered program agrees with the hidden world on the held-out passive states and complete allowed intervention surface.
7. Compare:
   - FORCE_BASE_BEST_FIT
   - FULL_BOOLEAN_EXPANSION
   - MINIMAL_OPERATOR_SYNTHESIS
8. The primary system must explicitly detect an empty exact base version space before extension search.
9. Score the frozen extension on two held-out root states and the complete one-shot intervention surface: 8 root states × 10 interventions × 5 observed variables.
10. Independently verify that zero new operators cannot fit and exactly one new operator is sufficient.
11. Re-run the exact scorer and require byte-identical result JSON.

This experiment tests model-class escape inside a finite operator meta-language. It does not test unrestricted representation-language invention.
