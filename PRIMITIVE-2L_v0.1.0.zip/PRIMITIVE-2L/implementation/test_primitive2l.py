#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2L_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2L_REPLAY_CHECK.json").read_text())
p=r["system_summary"]["MINIMAL_OPERATOR_SYNTHESIS"]
assert r["terminal_verdict"]=="MODEL_CLASS_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["world_count"]==192
assert p["model_class_failure_declared_count"]==192
assert p["discovery_exact_fit_count"]==192
assert p["mean_new_operator_count"]==1.0
assert p["truth_table_exact_count"]==192
assert p["program_exact_count"]==192
assert p["minimum_extension_exact_count"]==192
assert p["heldout_passive_accuracy"]==1.0
assert p["interventional_prediction_accuracy"]==1.0
assert rp["exact_byte_replay"]=="PASS"
assert r["system_summary"]["FORCE_BASE_BEST_FIT"]["discovery_exact_fit_count"]==0
assert r["system_summary"]["FULL_BOOLEAN_EXPANSION"]["mean_new_operator_count"]==12.0
print("PRIMITIVE_2L_TEST_PASS")
