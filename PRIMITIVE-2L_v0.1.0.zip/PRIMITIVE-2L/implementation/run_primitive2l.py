from pathlib import Path
import json, hashlib, itertools, csv, os, zipfile, subprocess, sys

ROOT=Path("/mnt/data/PRIMITIVE-2L")
FIX=ROOT/"PRIMITIVE-2L_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2L_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"], rec["name"]

grammar=json.loads((ROOT/"PRIMITIVE-2L_GRAMMAR.json").read_text())
worlds=json.loads((FIX/"MODEL_CLASS_ESCAPE_WORLDS.json").read_text())["worlds"]

BASE_OPS={int(k):v for k,v in grammar["base_operator_truth_tables"].items()}
ALL_TT=list(range(16))
MISSING_TT=[x for x in ALL_TT if x not in BASE_OPS]
ROOT_STATES=list(itertools.product([0,1],repeat=3))
P3_PAIRS=list(itertools.combinations(range(3),2))
P4_PAIRS=list(itertools.combinations(range(4),2))
INTERVENTIONS=[(v,val) for v in range(5) for val in (0,1)]

def tt_eval(tt,a,b):
    return (tt >> (2*a+b)) & 1

def simulate(code,roots,intervention=None):
    p3a,p3b,tt3,p4a,p4b,tt4=code
    vals=[None]*5
    vals[0],vals[1],vals[2]=roots
    if intervention is not None and intervention[0] in (0,1,2):
        vals[intervention[0]]=intervention[1]
    vals[3]=intervention[1] if intervention is not None and intervention[0]==3 else tt_eval(tt3,vals[p3a],vals[p3b])
    vals[4]=intervention[1] if intervention is not None and intervention[0]==4 else tt_eval(tt4,vals[p4a],vals[p4b])
    return tuple(int(x) for x in vals)

base_programs=[p["code"] for p in grammar["base_programs"]]

# Rebuild single-extension program spaces independently.
ext_by_tt={}
for t in MISSING_TT:
    ops=list(BASE_OPS)+[t]
    arr=[]
    for a,b in P3_PAIRS:
        for t3 in ops:
            for c,d in P4_PAIRS:
                for t4 in ops:
                    if t3 in BASE_OPS and t4 in BASE_OPS:
                        continue
                    arr.append([a,b,t3,c,d,t4])
    ext_by_tt[t]=arr

# Full Boolean grammar for the over-expansion baseline.
full_programs=[]
for a,b in P3_PAIRS:
    for t3 in ALL_TT:
        for c,d in P4_PAIRS:
            for t4 in ALL_TT:
                full_programs.append([a,b,t3,c,d,t4])
assert len(full_programs)==4608

def discovery_error(code,states,obs):
    # scalar Hamming error across all five variables
    err=0
    for r,y in zip(states,obs):
        p=simulate(code,r)
        err+=sum(int(a!=b) for a,b in zip(p,y))
    return err

def exact_fits(codes,states,obs):
    return [code for code in codes if discovery_error(code,states,obs)==0]

def predictive_metrics(code,world):
    hidden=world["hidden_program"]
    # heldout passive
    h_correct=0; h_total=0
    for r,y in zip(world["heldout_root_states"],world["heldout_observations"]):
        p=simulate(code,tuple(r))
        for a,b in zip(p,y):
            h_correct+=int(a==b);h_total+=1

    # full one-shot intervention surface
    i_correct=0;i_total=0
    for roots in ROOT_STATES:
        for iv in INTERVENTIONS:
            pred=simulate(code,roots,iv)
            gold=simulate(hidden,roots,iv)
            for a,b in zip(pred,gold):
                i_correct+=int(a==b);i_total+=1
    return {
        "heldout_passive_correct":h_correct,
        "heldout_passive_total":h_total,
        "heldout_passive_accuracy":h_correct/h_total,
        "interventional_correct":i_correct,
        "interventional_total":i_total,
        "interventional_accuracy":i_correct/i_total,
    }

world_results=[]

for w in worlds:
    states=[tuple(x) for x in w["discovery_root_states"]]
    obs=[tuple(x) for x in w["discovery_observations"]]
    hidden=w["hidden_program"]
    hidden_tt=w["hidden_novel_truth_table"]

    # 1) Force base best fit.
    scored=[(discovery_error(code,states,obs),tuple(code),code) for code in base_programs]
    scored.sort(key=lambda x:(x[0],x[1]))
    base_err,_,base_choice=scored[0]
    base_exact_count=sum(err==0 for err,_,_ in scored)

    # 2) Full expansion.
    full_fits=exact_fits(full_programs,states,obs)
    full_choice=min(full_fits,key=lambda c:tuple(c)) if full_fits else None

    # 3) Minimal synthesis.
    fitting_ext={}
    for t in MISSING_TT:
        fits=exact_fits(ext_by_tt[t],states,obs)
        if fits:
            fitting_ext[t]=sorted(fits,key=lambda c:tuple(c))
    if fitting_ext:
        chosen_tt=min(fitting_ext)
        synth_choice=fitting_ext[chosen_tt][0]
    else:
        chosen_tt=None;synth_choice=None

    # Independent minimality.
    min_extension_size=0 if base_exact_count>0 else (1 if fitting_ext else None)
    unique_tt=(len(fitting_ext)==1)

    variants={}
    variants["FORCE_BASE_BEST_FIT"]={
        "base_exact_fit_count":base_exact_count,
        "discovery_error":base_err,
        "declared_model_class_failure":False,
        "new_operator_count":0,
        "recovered_truth_table":None,
        "program":base_choice,
        **predictive_metrics(base_choice,w),
    }

    variants["FULL_BOOLEAN_EXPANSION"]={
        "base_exact_fit_count":base_exact_count,
        "discovery_error":0 if full_choice is not None else None,
        "declared_model_class_failure":base_exact_count==0,
        "new_operator_count":12,
        "recovered_truth_table":None,
        "program":full_choice,
        **predictive_metrics(full_choice,w),
    }

    variants["MINIMAL_OPERATOR_SYNTHESIS"]={
        "base_exact_fit_count":base_exact_count,
        "discovery_error":0 if synth_choice is not None else None,
        "declared_model_class_failure":base_exact_count==0,
        "new_operator_count":0 if synth_choice is None else 1,
        "fitting_extension_truth_tables":sorted(fitting_ext),
        "unique_extension_truth_table":unique_tt,
        "recovered_truth_table":chosen_tt,
        "truth_table_exact":chosen_tt==hidden_tt,
        "program":synth_choice,
        "program_exact":synth_choice==hidden,
        "minimum_extension_size_independent":min_extension_size,
        "minimum_extension_exact":min_extension_size==1 and unique_tt and chosen_tt==hidden_tt,
        **predictive_metrics(synth_choice,w),
    }

    world_results.append({
        "world_id":w["world_id"],
        "hidden_novel_truth_table":hidden_tt,
        "hidden_novel_location":w["hidden_novel_location"],
        "variants":variants,
    })

systems=["FORCE_BASE_BEST_FIT","FULL_BOOLEAN_EXPANSION","MINIMAL_OPERATOR_SYNTHESIS"]
summary={}
for name in systems:
    rs=[w["variants"][name] for w in world_results]
    summary[name]={
        "world_count":len(rs),
        "model_class_failure_declared_count":sum(r["declared_model_class_failure"] for r in rs),
        "discovery_exact_fit_count":sum(r["discovery_error"]==0 for r in rs),
        "mean_new_operator_count":sum(r["new_operator_count"] for r in rs)/len(rs),
        "heldout_passive_accuracy":sum(r["heldout_passive_correct"] for r in rs)/sum(r["heldout_passive_total"] for r in rs),
        "interventional_prediction_accuracy":sum(r["interventional_correct"] for r in rs)/sum(r["interventional_total"] for r in rs),
    }

syn=[w["variants"]["MINIMAL_OPERATOR_SYNTHESIS"] for w in world_results]
summary["MINIMAL_OPERATOR_SYNTHESIS"].update({
    "truth_table_exact_count":sum(r["truth_table_exact"] for r in syn),
    "program_exact_count":sum(r["program_exact"] for r in syn),
    "minimum_extension_exact_count":sum(r["minimum_extension_exact"] for r in syn),
    "unique_extension_truth_table_count":sum(r["unique_extension_truth_table"] for r in syn),
})

primary=summary["MINIMAL_OPERATOR_SYNTHESIS"]
if (
    primary["model_class_failure_declared_count"]==192 and
    primary["discovery_exact_fit_count"]==192 and
    primary["mean_new_operator_count"]==1.0 and
    primary["truth_table_exact_count"]==192 and
    primary["minimum_extension_exact_count"]==192 and
    primary["heldout_passive_accuracy"]==1.0 and
    primary["interventional_prediction_accuracy"]==1.0
):
    terminal="MODEL_CLASS_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif primary["truth_table_exact_count"]>0:
    terminal="PARTIAL"
else:
    terminal="MODEL_CLASS_ESCAPE_INSUFFICIENT"

results={
    "experiment":"PRIMITIVE-2L",
    "version":"0.1.0",
    "freeze_sha256":freeze["freeze_sha256"],
    "terminal_verdict":terminal,
    "world_count":len(world_results),
    "system_summary":summary,
    "world_results":world_results,
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2L_RESULTS.json").write_text(json.dumps(results,indent=2))

print("PRIMITIVE-2L scored")
print("terminal:",terminal)
print(json.dumps(summary,indent=2))