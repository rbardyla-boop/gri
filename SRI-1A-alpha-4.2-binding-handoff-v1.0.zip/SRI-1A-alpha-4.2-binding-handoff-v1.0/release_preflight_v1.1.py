#!/usr/bin/env python3
import argparse, hashlib, json, re, socket, ssl, sys, urllib.error, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PARENT=ROOT/'parent_alpha4_1_v1.0.zip'
EXPECTED_PARENT_SHA='b20f28a1a5fabac324f5f490bde893c17d2e4d97a3ca16ace9d7a89e60a76e4f'
TARGET_ORIGIN='https://sri.clovelearn.io'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def placeholder(s):
    s=str(s or '')
    return not s or 'REPLACE_' in s or 'BOUND_EXTERNALLY' in s or s.startswith('SYNTHETIC')
def load_json(p): return json.loads(Path(p).read_text())
def verify_evidence_file(bindings, path_key, hash_key, required_true_keys, blockers, label):
    p=str(bindings.get(path_key,'') or '')
    h=str(bindings.get(hash_key,'') or '')
    if not p:
        blockers.append(f'{label}_EVIDENCE_MISSING'); return None
    ep=Path(p)
    if not ep.is_absolute(): ep=ROOT/ep
    if not ep.exists():
        blockers.append(f'{label}_EVIDENCE_FILE_NOT_FOUND'); return None
    actual=sha(ep)
    if not re.fullmatch(r'[0-9a-f]{64}',h) or h!=actual:
        blockers.append(f'{label}_EVIDENCE_HASH_MISMATCH')
    try: j=load_json(ep)
    except Exception:
        blockers.append(f'{label}_EVIDENCE_INVALID_JSON'); return None
    for k in required_true_keys:
        if j.get(k) is not True: blockers.append(f'{label}_{k.upper()}_NOT_VERIFIED')
    return j

def public_probe(origin):
    result={'dns':False,'https':False,'config':False,'error':''}
    try:
        host=urllib.parse.urlparse(origin).hostname
        socket.getaddrinfo(host,443); result['dns']=True
        req=urllib.request.Request(origin.rstrip('/')+'/api/config',headers={'User-Agent':'SRI-release-preflight/1.1'})
        with urllib.request.urlopen(req,timeout=10,context=ssl.create_default_context()) as r:
            result['https']=(r.status==200)
            body=json.loads(r.read().decode())
            result['config']=(body.get('participant_freeze_id')=='SRI-1A-alpha.2.1-participant-text-v1.0')
    except Exception as e: result['error']=f'{type(e).__name__}: {e}'
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--bindings',required=True); ap.add_argument('--fixture-mode',action='store_true'); ap.add_argument('--skip-network',action='store_true'); args=ap.parse_args()
    b=load_json(args.bindings); blockers=[]; evidence={}
    parent_sha=sha(PARENT)
    if parent_sha!=EXPECTED_PARENT_SHA: blockers.append('PARENT_ALPHA4_1_ARCHIVE_HASH_MISMATCH')
    fixture=bool(args.fixture_mode)
    if not b.get('researcher_affiliation_attestation'): blockers.append('AFFILIATION_SCOPE_ATTESTATION_MISSING')
    sid=str(b.get('prolific_study_id',''))
    if placeholder(sid): blockers.append('REAL_PROLIFIC_STUDY_ID_MISSING')
    elif not re.fullmatch(r'[A-Za-z0-9_-]{12,128}',sid): blockers.append('PROLIFIC_STUDY_ID_FORMAT_UNEXPECTED')
    cu=str(b.get('prolific_completion_url',''))
    if not re.match(r'^https://app\.prolific\.com/submissions/complete\?cc=[A-Za-z0-9_-]+$',cu): blockers.append('PROLIFIC_COMPLETION_URL_INVALID')
    mode=str(b.get('prolific_identity_validation_mode',''))
    if mode not in ('submission_api','secure_external_url'):
        blockers.append('PROLIFIC_IDENTITY_AUTHENTICATION_NOT_BOUND')
    origin=str(b.get('public_origin',''))
    if origin!=TARGET_ORIGIN: blockers.append('PUBLIC_ORIGIN_MISMATCH')
    pr=str(b.get('preregistration_url',''))
    if placeholder(pr) or not pr.startswith('https://'): blockers.append('TIMESTAMPED_PREREGISTRATION_URL_MISSING')
    ts=str(b.get('preregistration_timestamp_utc',''))
    if not re.match(r'^20\d\d-\d\d-\d\dT\d\d:\d\d',ts): blockers.append('PREREGISTRATION_TIMESTAMP_MISSING')

    # Smoke evidence must be a real PASS report, not merely any 64-char hash.
    sp=str(b.get('live_smoke_report','') or '')
    sh=str(b.get('live_smoke_test_sha256','') or '')
    if not sp:
        blockers.append('LIVE_SMOKE_REPORT_MISSING')
    else:
        p=Path(sp); p=p if p.is_absolute() else ROOT/p
        if not p.exists(): blockers.append('LIVE_SMOKE_REPORT_NOT_FOUND')
        else:
            actual=sha(p)
            if sh!=actual: blockers.append('LIVE_SMOKE_TEST_HASH_MISMATCH')
            try:
                sj=load_json(p); evidence['smoke']=sj
                if sj.get('pass') is not True: blockers.append('LIVE_SMOKE_TEST_NOT_PASS')
                if sj.get('origin')!=TARGET_ORIGIN: blockers.append('LIVE_SMOKE_ORIGIN_MISMATCH')
            except Exception: blockers.append('LIVE_SMOKE_REPORT_INVALID_JSON')

    evidence['cloudflare']=verify_evidence_file(b,'cloudflare_evidence','cloudflare_evidence_sha256',
        ['tls_verified','rate_limit_verified','admin_public_blocked','public_status_absent'],blockers,'CLOUDFLARE')
    evidence['storage']=verify_evidence_file(b,'storage_evidence','storage_evidence_sha256',
        ['encrypted_storage_verified','database_permissions_verified'],blockers,'STORAGE')
    evidence['affiliation']=verify_evidence_file(b,'affiliation_attestation_evidence','affiliation_attestation_sha256',
        ['attested'],blockers,'AFFILIATION')

    probe={'skipped':True}
    if not args.skip_network and not fixture:
        probe=public_probe(origin); probe['skipped']=False
        if not probe['dns']: blockers.append('PUBLIC_ORIGIN_DNS_UNRESOLVED')
        elif not probe['https']: blockers.append('PUBLIC_ORIGIN_HTTPS_FAILED')
        elif not probe['config']: blockers.append('PUBLIC_ORIGIN_FREEZE_ID_MISMATCH')

    if fixture:
        # Fixture mode can exercise the checker but can never authorize recruitment.
        verdict='FIXTURE_CHECK_PASS' if not blockers else 'FIXTURE_CHECK_FAIL'
    else:
        verdict='PASS_RELEASE_AUTHORIZED' if not blockers else 'EXTERNAL_BINDING_HOLD'
    out={
      'unit':'SRI-1A-alpha.4.2-v0.1', 'fixture_mode':fixture,
      'parent_alpha4_1_archive_sha256':parent_sha,
      'public_probe':probe, 'evidence':evidence,
      'blockers':sorted(set(blockers)), 'verdict':verdict
    }
    print(json.dumps(out,indent=2))
    return 0 if verdict=='PASS_RELEASE_AUTHORIZED' else 2
if __name__=='__main__': raise SystemExit(main())
