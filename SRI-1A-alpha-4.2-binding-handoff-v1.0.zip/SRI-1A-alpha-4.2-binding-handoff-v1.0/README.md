# SRI-1A-α.4.2 — Real External Binding Handoff

This packet does **not** modify the α.4.2 release gate or the frozen experiment. It only supplies the exact real-world inputs expected by `release_preflight_v1.1.py`.

## Required actions

1. **Independent-research scope attestation**
   - Review the actual affiliation/funding/collaboration status.
   - If accurate, set `attested=true`, add researcher name and UTC timestamp in `evidence/affiliation_attestation.json`.
   - Set `researcher_affiliation_attestation=true` in `external_bindings_REAL.json`.

2. **Prolific draft**
   - Create the real study draft.
   - Put the account-issued study ID into `prolific_study_id`.
   - Put the real completion redirect into `prolific_completion_url`.
   - Bind `prolific_identity_validation_mode` to exactly `submission_api` or `secure_external_url` after that mechanism is actually implemented.

3. **Timestamped preregistration**
   - Register the frozen protocol before recruitment.
   - Put its permanent HTTPS URL and UTC registration time into the binding file.

4. **Deploy the frozen origin**
   - Deploy at exactly `https://sri.clovelearn.io`.
   - `/api/config` must return `participant_freeze_id = SRI-1A-alpha.2.1-participant-text-v1.0`.

5. **Cloudflare evidence**
   - Verify TLS.
   - Verify the intended rate limit.
   - Verify admin endpoints are not publicly accessible.
   - Verify no public status endpoint leaks operational data.
   - Only then set the four booleans in `evidence/cloudflare_evidence.json` to true and record deployment evidence.

6. **Storage evidence**
   - Verify encrypted storage and database permissions/access controls.
   - Only then set the two booleans in `evidence/storage_evidence.json` to true.

7. **Live smoke report**
   - Run the frozen live smoke tests against the actual public origin.
   - Record results in `evidence/live_smoke_report.json` and set `pass=true` only if all required checks actually pass.

8. **Run the existing gate**

```bash
python3 fill_hashes_and_check.py
```

The helper only fills SHA-256 values and then invokes the unchanged `release_preflight_v1.1.py`.

## Victory condition

```text
fixture_mode = false
blockers = []
verdict = PASS_RELEASE_AUTHORIZED
```

Anything else means recruitment remains prohibited.
