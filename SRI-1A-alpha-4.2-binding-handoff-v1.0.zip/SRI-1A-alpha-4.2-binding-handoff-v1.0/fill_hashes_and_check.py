#!/usr/bin/env python3
import hashlib, json, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
BIND = ROOT/'external_bindings_REAL.json'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
b = json.loads(BIND.read_text())
for path_key, hash_key in [
    ('live_smoke_report','live_smoke_test_sha256'),
    ('cloudflare_evidence','cloudflare_evidence_sha256'),
    ('storage_evidence','storage_evidence_sha256'),
    ('affiliation_attestation_evidence','affiliation_attestation_sha256'),
]:
    p = ROOT / b[path_key]
    if not p.exists():
        raise SystemExit(f'Missing evidence file: {p}')
    b[hash_key] = sha(p)
BIND.write_text(json.dumps(b, indent=2) + '\n')
print('Updated evidence hashes in external_bindings_REAL.json')
proc = subprocess.run([sys.executable, str(ROOT/'release_preflight_v1.1.py'), '--bindings', str(BIND)], cwd=ROOT)
raise SystemExit(proc.returncode)
