# PRIMITIVE-2P — RESOURCE-AXIS DISCOVERY

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `f772a7b21cf1b45dfecf47a4992da0550376645bc17ac998a4977260ddee8964`

## Question

> When all existing representational axes are saturated yet contradictory outcomes remain inside the same representation equivalence class, can a machine synthesize a new computable trajectory coordinate and promote it into the resource grammar?

## Collision detection

Each world contains:

```text
Rep_old(T_A) = Rep_old(T_B)
same intervention
different outcomes
```

where `Rep_old` is the final five raw observations, matching PRIMITIVE-2O's maximum temporal offset four.

## Ω

Candidates are unlabeled streaming programs:

```text
h_(t+1) = LUT8(h_t, raw0_t, raw1_t)
```

plus numeric output readouts.

No semantic names such as parity, accumulator, memory, ordering, latch, or state are supplied.

## Gauge symmetry

Binary internal states have arbitrary labels.

Therefore:

```text
H
and
1-H
```

are the same discovered axis when their transition/readout tables are transformed consistently.

PRIMITIVE-2P scores the canonical axis equivalence class, not arbitrary internal state names.

## Elevation

After a unique zero-collision class is found:

```text
r_(k+1) := phi(T)
```

becomes a new addressable resource coordinate.

## Pareto test

```text
synthesized-axis cost: 21
full 12-step raw-history overgrowth: 112
```

## OOD transfer

Discovery length: 12

OOD length: 20, with shifted raw-event frequencies.

The frozen phi must transfer without retraining.

## Scope

Ω still supplies a generic one-bit streaming fold. This experiment tests discovery and elevation of a new coordinate within that unlabeled operator substrate, not unrestricted mathematical-axis invention.
