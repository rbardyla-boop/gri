# PRIMITIVE-2P Results

**Terminal verdict:** `RESOURCE_AXIS_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Exact deterministic replay:** `PASS`  
**Worlds:** 24

| System | Collision resolution | OOD transfer | Mean cost |
|---|---:|---:|---:|
| FORCE_EXISTING_AXES | 1128 unresolved collision buckets | n/a | existing axes saturated |
| RAW_HISTORY_OVERGROWTH | discovery keys separable | 0.000000 exact-key coverage | 112.0 |
| **SYNTHESIZE_AND_ELEVATE_AXIS** | **0 post-elevation collision errors** | **1.000000** | **21.0** |

## Primary axis discovery

- Exact unique axis equivalence class: `24/24`
- Old collision buckets: `1128`
- Post-elevation collision errors: `0`
- OOD accuracy: `1.000000`
- Mean cost advantage over raw-history overgrowth: `91.0`
- Axis cheaper in every world: `True`
