# PRIMITIVE-2P Conclusion

**Terminal verdict:** `RESOURCE_AXIS_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Collision detection

All 24 frozen worlds contained irreducible contradictions inside the inherited PRIMITIVE-2O representation equivalence classes:

```text
worlds with collisions: 24/24
collision buckets:      1128
conflicting outcomes:   1128
```

The colliding trajectories shared the complete final-five-step old representation and received the same intervention.

Thus no computation restricted to that representation can be deterministic on both outcomes.

## Axis synthesis

The system searched only numeric streaming programs.

After quotienting by internal state-label symmetry, it recovered the unique hidden axis class in:

```text
24/24
```

worlds.

After elevation:

```text
post-elevation collision errors: 0
```

## OOD transfer

The discovered axis was frozen on 12-step discovery trajectories.

It was then applied without retraining to 20-step trajectories drawn from a shifted raw-event distribution.

```text
OOD prediction accuracy: 1.000000
```

This distinguishes a reusable trajectory invariant from a lookup table over discovery histories.

The brute raw-history key had:

```text
exact-key OOD coverage: 0.000000
```

because every OOD trajectory was new.

## Pareto efficiency

Frozen cost accounting:

```text
synthesized axis:       21
raw-history overgrowth: 112
advantage:              91
```

The new coordinate was cheaper in every world.

Therefore the axis does more than patch collisions: within this experiment it strictly dominates direct old-axis history retention on representation cost and OOD usefulness.

## Supported claim

Within the frozen streaming meta-grammar Ω:

> Persistent contradictions inside saturated old representation equivalence classes can drive a machine to synthesize a new trajectory-derived coordinate, elevate it into the resource grammar, eliminate those collisions, and transfer the new coordinate to longer distribution-shifted trajectories at lower representational cost than brute-force growth along the old temporal/source axes.

## Important boundary

PRIMITIVE-2P does not demonstrate unrestricted resource-axis invention.

Ω already supplies a generic persistent fold:

```text
one binary internal state
two current raw inputs
arbitrary 8-bit transition table
```

The system discovers the particular coordinate function; it does not invent the notion of a streaming state update from nothing.

The next gap is therefore the operator substrate Ω itself.
