# PRIMITIVE-2P METHOD

1. Bind PRIMITIVE-2P to the frozen PRIMITIVE-2O experiment, resource grammar and results by SHA-256.
2. Define the inherited representation boundary as the final five raw observations, corresponding to PRIMITIVE-2O's maximum temporal offset four.
3. Generate paired trajectories that share that complete old representation and receive the same intervention, but produce contradictory outcomes under the hidden trajectory process.
4. Freeze an unlabeled axis meta-grammar Ω:
   `h_(t+1) = LUT8(h_t, raw0_t, raw1_t)`,
   with two initial-state choices and numeric LUT4 output readouts.
5. Do not supply semantic names such as parity, counter, accumulator, memory, latch, ordering or state.
6. Quotient candidate parameterizations by the exact binary-state relabeling symmetry H' = 1-H. Score canonical axis equivalence classes, not arbitrary internal state labels.
7. Retain only worlds in which one canonical axis class exactly explains all discovery examples.
8. Elevate the discovered phi(T) into one new addressable resource coordinate.
9. Score every frozen collision after elevation.
10. Freeze an OOD environment with longer trajectories (20 versus 12 steps) and shifted raw-event frequencies; no axis retraining is allowed.
11. Compare the new-axis description/runtime cost against a brute-force control that expands only the old temporal/source-reference axes until the complete raw discovery history is retained.
12. Re-run the exact scorer and require byte-identical result JSON.

Two construction attempts were discarded before any scientific freeze or score: one used inefficient random collision search; the next incorrectly treated binary internal-state relabeling as distinct representations. The final v0.1.0 freeze incorporates exact collision construction and state-label canonicalization before scoring.
