#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2P_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2P_REPLAY_CHECK.json").read_text())
p=r["system_summary"]["SYNTHESIZE_AND_ELEVATE_AXIS"]
assert r["terminal_verdict"]=="RESOURCE_AXIS_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["world_count"]==24
assert r["system_summary"]["FORCE_EXISTING_AXES"]["worlds_with_irreducible_collisions"]==24
assert p["unique_axis_class_exact_worlds"]==24
assert p["post_elevation_collision_error_total"]==0
assert p["ood_accuracy"]==1.0
assert p["mean_axis_cost"]==21.0
assert r["system_summary"]["RAW_HISTORY_OVERGROWTH"]["mean_cost"]==112.0
assert p["axis_cheaper_all_worlds"] is True
assert rp["exact_byte_replay"]=="PASS"
print("PRIMITIVE_2P_TEST_PASS")
