from pathlib import Path
import json, hashlib, itertools, os, zipfile, subprocess, sys, csv

ROOT=Path("/mnt/data/PRIMITIVE-2P")
FIX=ROOT/"PRIMITIVE-2P_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

def canon(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_file(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2P_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"],rec["name"]

omega=json.loads((ROOT/"PRIMITIVE-2P_OMEGA.json").read_text())
worlds=json.loads((FIX/"AXIS_DISCOVERY_WORLDS.json").read_text())["worlds"]

def dep3(tt,var):
    for bits in itertools.product([0,1],repeat=3):
        x=list(bits);y=x.copy();y[var]^=1
        ix=4*x[0]+2*x[1]+x[2];iy=4*y[0]+2*y[1]+y[2]
        if ((tt>>ix)&1)!=((tt>>iy)&1):return True
    return False
ESS=[tt for tt in range(256) if all(dep3(tt,v) for v in range(3))]

def step(tt,h,a,b):return (tt>>(4*h+2*a+b))&1
def fold(tt,init,traj):
    h=init
    for a,b in traj:h=step(tt,h,a,b)
    return h
def readout(op,h,u):return (op>>(2*h+u))&1
def predict(p,traj,u):
    h=fold(p[1],p[0],traj)
    return [readout(p[2],h,u),readout(p[3],h,u)]

def complement(p):
    init,tt,y,z=p
    nt=0
    for hp,a,b in itertools.product([0,1],repeat=3):
        old=1-hp
        nxt=1-step(tt,old,a,b)
        nt|=nxt<<(4*hp+2*a+b)
    def cr(op):
        nop=0
        for hp,u in itertools.product([0,1],repeat=2):
            nop|=readout(op,1-hp,u)<<(2*hp+u)
        return nop
    return (1-init,nt,cr(y),cr(z))

def caxis(p):return min(tuple(p),complement(tuple(p)))

def infer_ops(tt,init,examples,oi):
    out=[]
    for op in range(16):
        if all(readout(op,fold(tt,init,e["trajectory"]),e["intervention"])==e["outcome"][oi] for e in examples):
            out.append(op)
    return out

def discover(examples):
    params=[]
    for init in (0,1):
        for tt in ESS:
            ys=infer_ops(tt,init,examples,0)
            if not ys:continue
            zs=infer_ops(tt,init,examples,1)
            for y in ys:
                for z in zs:
                    params.append((init,tt,y,z))
    classes=sorted(set(caxis(p) for p in params))
    return params,classes

def old_collision_stats(examples):
    buckets={}
    for e in examples:
        rep=tuple(tuple(x) for x in e["trajectory"][-5:])
        key=(rep,e["intervention"])
        buckets.setdefault(key,set()).add(tuple(e["outcome"]))
    bad={k:v for k,v in buckets.items() if len(v)>1}
    return len(bad),sum(len(v)-1 for v in bad.values())

def raw_key_coverage(discovery,ood):
    # Full raw trajectory + intervention lookup; exact on discovery, no abstraction.
    keys={(tuple(tuple(x) for x in e["trajectory"]),e["intervention"]) for e in discovery}
    covered=sum((tuple(tuple(x) for x in e["trajectory"]),e["intervention"]) in keys for e in ood)
    return covered,len(ood)

rows=[]
for w in worlds:
    ex=w["discovery_examples"]
    params,classes=discover(ex)
    hidden_class=tuple(w["canonical_axis_class"])
    recovered=(len(classes)==1 and tuple(classes[0])==hidden_class)

    old_buckets,old_conflicts=old_collision_stats(ex)

    # Canonical representative predicts identically to its gauge mate.
    chosen=classes[0] if len(classes)==1 else None

    collision_errors=0
    for ce in w["collision_examples"]:
        if chosen is None:
            collision_errors+=1
            continue
        oa=predict(chosen,ce["trajectory_a"],ce["intervention"])
        ob=predict(chosen,ce["trajectory_b"],ce["intervention"])
        if oa!=ce["outcome_a"] or ob!=ce["outcome_b"]:
            collision_errors+=1

    ood_correct=0
    for e in w["ood_examples"]:
        if chosen is not None and predict(chosen,e["trajectory"],e["intervention"])==e["outcome"]:
            ood_correct+=1
    ood_total=len(w["ood_examples"])
    ood_acc=ood_correct/ood_total

    covered,total=raw_key_coverage(ex,w["ood_examples"])

    axis_cost=w["axis_description_cost"]+w["axis_runtime_cost"]
    raw_cost=w["raw_history_overgrowth_cost"]

    rows.append({
        "world_id":w["world_id"],
        "candidate_parameterization_count":len(params),
        "candidate_axis_class_count":len(classes),
        "axis_class_exact":recovered,
        "old_collision_bucket_count":old_buckets,
        "old_collision_conflict_count":old_conflicts,
        "post_elevation_collision_errors":collision_errors,
        "ood_correct":ood_correct,
        "ood_total":ood_total,
        "ood_accuracy":ood_acc,
        "raw_history_ood_key_coverage":covered/total,
        "axis_cost":axis_cost,
        "raw_history_overgrowth_cost":raw_cost,
        "pareto_cost_advantage":raw_cost-axis_cost,
    })

summary={
    "FORCE_EXISTING_AXES":{
        "world_count":len(rows),
        "worlds_with_irreducible_collisions":sum(r["old_collision_bucket_count"]>0 for r in rows),
        "total_collision_buckets":sum(r["old_collision_bucket_count"] for r in rows),
        "total_conflicting_outcomes":sum(r["old_collision_conflict_count"] for r in rows),
    },
    "RAW_HISTORY_OVERGROWTH":{
        "world_count":len(rows),
        "mean_cost":sum(r["raw_history_overgrowth_cost"] for r in rows)/len(rows),
        "mean_ood_exact_key_coverage":sum(r["raw_history_ood_key_coverage"] for r in rows)/len(rows),
    },
    "SYNTHESIZE_AND_ELEVATE_AXIS":{
        "world_count":len(rows),
        "unique_axis_class_exact_worlds":sum(r["axis_class_exact"] for r in rows),
        "post_elevation_collision_error_total":sum(r["post_elevation_collision_errors"] for r in rows),
        "ood_accuracy":sum(r["ood_correct"] for r in rows)/sum(r["ood_total"] for r in rows),
        "mean_axis_cost":sum(r["axis_cost"] for r in rows)/len(rows),
        "mean_pareto_cost_advantage":sum(r["pareto_cost_advantage"] for r in rows)/len(rows),
        "axis_cheaper_all_worlds":all(r["axis_cost"]<r["raw_history_overgrowth_cost"] for r in rows),
    }
}

p=summary["SYNTHESIZE_AND_ELEVATE_AXIS"]
if (
    summary["FORCE_EXISTING_AXES"]["worlds_with_irreducible_collisions"]==24 and
    p["unique_axis_class_exact_worlds"]==24 and
    p["post_elevation_collision_error_total"]==0 and
    p["ood_accuracy"]==1.0 and
    p["axis_cheaper_all_worlds"]
):
    terminal="RESOURCE_AXIS_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif p["unique_axis_class_exact_worlds"]>0:
    terminal="PARTIAL"
else:
    terminal="RESOURCE_AXIS_DISCOVERY_INSUFFICIENT"

results={
    "experiment":"PRIMITIVE-2P","version":"0.1.0","freeze_sha256":freeze["freeze_sha256"],
    "terminal_verdict":terminal,"world_count":len(rows),
    "system_summary":summary,"world_results":rows
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2P_RESULTS.json").write_text(json.dumps(results,indent=2))

print("PRIMITIVE-2P scored")
print("terminal:",terminal)
print(json.dumps(summary,indent=2))