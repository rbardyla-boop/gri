# PRIMITIVE-2 SPECIFICATION
## Learned Packet-Native Local Composition

**Version:** 0.1.0  
**Status:** FROZEN BEFORE TRAINING  
**Experiment SHA-256:** `a2be2f8ffb79ef49075f2d33aaed8bfdb605548ab9b37938e386ba459c67ce18`  
**Oracle SHA-256:** `321cf8728a0d7cf3798d5c8afe946b48cf69eba01d88b32c1c2931ea5355324c`  
**Held-out fixture SHA-256:** `cc5820480c12e5f8b742cbdbf55ee7fee37eba857bcfa7a67c966fe434c625f6`

## Question

> Can a learned model acquire packet→packet transformations from training examples and generalize to held-out entities, longer structures, and unseen multi-step compositions without explicit natural-language intermediate reasoning or task-specific symbolic rules?

## Narrow claim

PRIMITIVE-2 v0.1.0 tests a learned **local packet composer**.

The runtime performs only relation-agnostic structure:

```text
join when left.OBJECT == right.SUBJECT
output SUBJECT = left.SUBJECT
output OBJECT  = right.OBJECT
allocate stable reference
deduplicate
repeat to fixed point
```

The runtime does **not** contain any relation-specific inference rule.

The learner must decide:

```text
NO DERIVATION
or
output RELATION
```

from the ACT/RELATION fields of the joined packet pair.

## Why this boundary exists

Stable references already define machine-readable identity and linkage. PRIMITIVE-2 does not force a neural model to relearn equality or pointer copying before testing whether packet transformations themselves are learnable.

That harder question remains available for a later ablation.

## Training

The model sees only local packet-pair examples.

```text
training structural depth = 2 packets
```

It never receives chain, hierarchy, distractor, or cycle task labels.

## Held-out generalization

The frozen test includes:

```text
unseen entity IDs
BEFORE chains length 5,8,12,16
PART_OF chains length 5,8,12,16
mixed PART_OF→...→ASSIGNED_TO structures depth 3,5,8
16/64/128 distractor packets
cycles length 3 and 5
```

## No-prose rule

Authoritative learned inference is:

```text
numeric packets
→ numeric feature tensor
→ neural model
→ numeric class
→ numeric packet
```

No explicit natural-language intermediate may be generated or reparsed.

## Strict pass gate

All three preregistered training seeds must satisfy:

```text
exhaustive local ACT×ACT×RELATION×RELATION classification = 100%
held-out graph precision = 100%
held-out graph recall = 100%
held-out exact graph match = 100%
held-out termination = 100%
numeric-only authoritative trajectory = PASS
```

No threshold may be relaxed after training.
