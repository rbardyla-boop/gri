# PRIMITIVE-2 Conclusion

**Terminal verdict:** `LEARNED_PACKET_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Tested learned mechanism

The learner was a small feed-forward neural classifier.

It received only numeric encodings of:

```text
left.ACT
right.ACT
left.RELATION
right.RELATION
```

It did not receive:

```text
entity IDs
task IDs
fixture names
oracle rules
required outputs
natural-language reasoning
```

Training examples contained local packet pairs only.

The runtime supplied only relation-agnostic packet mechanics:

```text
OBJECT/SUBJECT reference join
outer operand copying
stable-reference allocation
deduplication
fixed-point iteration
```

## Result

All preregistered seeds passed the strict gate: `True`.

The model was tested on structures absent from training:

```text
unseen entity IDs
BEFORE chains up to length 16
PART_OF chains up to length 16
mixed multi-step hierarchy compositions
distractor fields
cycles
```

See the raw result receipt for exact per-seed and per-fixture metrics.

## Scientific claim boundary

If the terminal verdict is positive, the strongest supported statement is:

> A small learned numeric model can acquire local packet-composition behavior from examples and, when iterated by a generic packet runtime, generalize that learned behavior to the frozen held-out structures without explicit natural-language intermediate reasoning or relation-specific symbolic inference rules in the runtime.

This does not yet show that a learned model can discover reference joins, pointer copying, stable-reference allocation, VALUE transformations, UPDATE semantics, or open-ended reasoning.

Those remain separate experiments.
