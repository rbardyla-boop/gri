# PRIMITIVE-2 Results

**Terminal verdict:** `LEARNED_PACKET_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Mechanism:** `M1_NEURAL_PAIR_COMPOSER`  
**Seeds:** [11, 23, 47]  
**Held-out fixtures:** 18

| Seed | Local 64-combo accuracy | Min precision | Min recall | Exact graph rate | Termination | Verdict |
|---:|---:|---:|---:|---:|---:|---|
| 11 | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 | PASS |
| 23 | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 | PASS |
| 47 | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 | PASS |

## Held-out groups

### Seed 11
- **ENTITY_HOLDOUT:** 2/2 exact
- **LONG_CHAIN:** 8/8 exact
- **MIXED_COMPOSITION:** 3/3 exact
- **DISTRACTOR:** 3/3 exact
- **CYCLE:** 2/2 exact

### Seed 23
- **ENTITY_HOLDOUT:** 2/2 exact
- **LONG_CHAIN:** 8/8 exact
- **MIXED_COMPOSITION:** 3/3 exact
- **DISTRACTOR:** 3/3 exact
- **CYCLE:** 2/2 exact

### Seed 47
- **ENTITY_HOLDOUT:** 2/2 exact
- **LONG_CHAIN:** 8/8 exact
- **MIXED_COMPOSITION:** 3/3 exact
- **DISTRACTOR:** 3/3 exact
- **CYCLE:** 2/2 exact

