#!/usr/bin/env python3
from __future__ import annotations
import itertools, json, hashlib, time
from pathlib import Path
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIX = ROOT / "PRIMITIVE-2_FIXTURES"
RES = ROOT / "results"

ACTS = ["ASSERT","DERIVE"]
RELS = ["BEFORE","PART_OF","ASSIGNED_TO","LOCATED_IN"]
OUTS = ["BEFORE","PART_OF","ASSIGNED_TO","LOCATED_IN","NONE"]
A2I = {x:i for i,x in enumerate(ACTS)}
R2I = {x:i for i,x in enumerate(RELS)}
O2I = {x:i for i,x in enumerate(OUTS)}
I2O = {i:x for x,i in O2I.items()}

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)

def verify_freeze():
    freeze=json.loads((ROOT/"PRIMITIVE-2_FREEZE.json").read_text())
    for rec in freeze["files"]:
        p=ROOT/rec["name"]
        got=hashlib.sha256(p.read_bytes()).hexdigest()
        if got!=rec["sha256"]:
            raise RuntimeError(f"freeze file changed: {rec['name']}")
    got=hashlib.sha256(canon(freeze["files"]).encode()).hexdigest()
    if got!=freeze["freeze_sha256"]:
        raise RuntimeError("freeze manifest changed")
    return freeze

class PairComposer(nn.Module):
    def __init__(self, hidden=32):
        super().__init__()
        dim=2*len(ACTS)+2*len(RELS)
        self.net=nn.Sequential(
            nn.Linear(dim,hidden),nn.ReLU(),
            nn.Linear(hidden,hidden),nn.ReLU(),
            nn.Linear(hidden,len(OUTS)),
        )
    def forward(self,a1,a2,r1,r2):
        x=torch.cat([
            F.one_hot(a1,len(ACTS)).float(),
            F.one_hot(a2,len(ACTS)).float(),
            F.one_hot(r1,len(RELS)).float(),
            F.one_hot(r2,len(RELS)).float(),
        ],dim=1)
        return self.net(x)

def oracle_class(oracle_map,r1,r2):
    return O2I[oracle_map.get(f"{RELS[r1]}|{RELS[r2]}","NONE")]

def batch(n,gen,oracle_map):
    a1=torch.randint(0,len(ACTS),(n,),generator=gen)
    a2=torch.randint(0,len(ACTS),(n,),generator=gen)
    r1=torch.randint(0,len(RELS),(n,),generator=gen)
    r2=torch.randint(0,len(RELS),(n,),generator=gen)
    y=torch.tensor([oracle_class(oracle_map,int(x),int(y)) for x,y in zip(r1,r2)],dtype=torch.long)
    return a1,a2,r1,r2,y

def exhaustive_local(model,oracle_map):
    good=0
    with torch.no_grad():
        for a1,a2,r1,r2 in itertools.product(range(2),range(2),range(4),range(4)):
            pred=int(model(
                torch.tensor([a1]),torch.tensor([a2]),
                torch.tensor([r1]),torch.tensor([r2])
            ).argmax(-1)[0])
            good += pred==oracle_class(oracle_map,r1,r2)
    return good/64

def compile_fixture(f):
    syms=sorted({x for p in f["inputs"] for x in (p["id"],p["subject"],p["object"])})
    s2i={s:i+1 for i,s in enumerate(syms)}
    i2s={i:s for s,i in s2i.items()}
    packets=[]
    for p in f["inputs"]:
        packets.append([
            s2i[p["id"]],A2I[p["act"]],s2i[p["subject"]],
            R2I[p["relation"]],s2i[p["object"]],int(p["value"])
        ])
    return packets,i2s

def predict(model,a1,a2,r1,r2):
    with torch.no_grad():
        return int(model(
            torch.tensor([a1]),torch.tensor([a2]),
            torch.tensor([r1]),torch.tensor([r2])
        ).argmax(-1)[0])

def infer(model,f):
    packets,i2s=compile_fixture(f)
    next_ref=max(p[0] for p in packets)+1
    existing={(p[1],p[2],p[3],p[4],p[5]) for p in packets}
    trajectory=[[0,[list(p) for p in packets]]]
    for rnd in range(1,f["max_rounds"]+1):
        candidates=set()
        facts=[p for p in packets if p[1] in (A2I["ASSERT"],A2I["DERIVE"])]
        for l in facts:
            for r in facts:
                if l[4]!=r[2]:
                    continue
                c=predict(model,l[1],r[1],l[3],r[3])
                if I2O[c]=="NONE":
                    continue
                sem=(A2I["DERIVE"],l[2],c,r[4],1000)
                if sem not in existing:
                    candidates.add(sem)
        if not candidates:
            trajectory.append([rnd,[]])
            return packets,i2s,trajectory,True
        new=[]
        for act,s,rel,o,v in sorted(candidates):
            p=[next_ref,act,s,rel,o,v]
            next_ref+=1
            packets.append(p)
            existing.add((act,s,rel,o,v))
            new.append(p)
        trajectory.append([rnd,new])
    return packets,i2s,trajectory,False

def oracle_closure(f,oracle_map):
    facts={(p["subject"],p["relation"],p["object"]) for p in f["inputs"]}
    while True:
        new=set()
        for s1,r1,o1 in list(facts):
            for s2,r2,o2 in list(facts):
                if o1!=s2: continue
                out=oracle_map.get(f"{r1}|{r2}")
                if out is not None:
                    new.add((s1,out,o2))
        new-=facts
        if not new: break
        facts|=new
    return facts

def decoded(packets,i2s):
    return {(i2s[p[2]],RELS[p[3]],i2s[p[4]]) for p in packets}

def strings(x):
    if isinstance(x,str): return 1
    if isinstance(x,list): return sum(strings(v) for v in x)
    if isinstance(x,tuple): return sum(strings(v) for v in x)
    if isinstance(x,dict): return sum(strings(k)+strings(v) for k,v in x.items())
    return 0

def main():
    freeze=verify_freeze()
    exp=json.loads((ROOT/"PRIMITIVE-2_EXPERIMENT.json").read_text())
    oracle=json.loads((ROOT/"PRIMITIVE-2_ORACLE.json").read_text())["local_composition_map"]
    fixtures=json.loads((FIX/"HELDOUT_FIXTURES.json").read_text())["fixtures"]

    summaries=[]
    for seed in exp["training"]["seeds"]:
        torch.manual_seed(seed)
        gen=torch.Generator().manual_seed(seed ^ 0x5A17)
        model=PairComposer(exp["training"]["hidden_width"])
        opt=torch.optim.AdamW(
            model.parameters(),
            lr=exp["training"]["learning_rate"],
            weight_decay=exp["training"]["weight_decay"]
        )
        for _ in range(exp["training"]["steps"]):
            b=batch(exp["training"]["batch_size"],gen,oracle)
            loss=F.cross_entropy(model(*b[:4]),b[4])
            opt.zero_grad(); loss.backward(); opt.step()

        local=exhaustive_local(model,oracle)
        exact=0
        numeric=True
        term=True
        for f in fixtures:
            p,i2s,tr,t=infer(model,f)
            exact += decoded(p,i2s)==oracle_closure(f,oracle)
            numeric &= strings(tr)==0
            term &= t
        summaries.append({
            "seed":seed,
            "local_accuracy":local,
            "exact_graph_rate":exact/len(fixtures),
            "numeric_only":bool(numeric),
            "termination":bool(term)
        })

    out={
        "experiment":"PRIMITIVE-2_RERUN",
        "freeze_sha256":freeze["freeze_sha256"],
        "summaries":summaries,
        "all_pass":all(
            x["local_accuracy"]==1.0 and x["exact_graph_rate"]==1.0
            and x["numeric_only"] and x["termination"]
            for x in summaries
        )
    }
    (RES/"PRIMITIVE-2_RERUN_RESULTS.json").write_text(json.dumps(out,indent=2))
    print("PRIMITIVE_2_RERUN_PASS" if out["all_pass"] else "PRIMITIVE_2_RERUN_FAIL")
    print(json.dumps(summaries,indent=2))

if __name__=="__main__":
    main()
