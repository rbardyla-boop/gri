#!/usr/bin/env python3
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2_RESULTS.json").read_text())
assert r["terminal_verdict"]=="LEARNED_PACKET_INFERENCE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["training_seed_count"]==3
assert r["all_seeds_pass"] is True
for s in r["seed_results"]:
    assert s["seed_verdict"]=="PASS"
    assert s["exhaustive_local_accuracy"]==1.0
    assert s["heldout_min_precision"]==1.0
    assert s["heldout_min_recall"]==1.0
    assert s["heldout_exact_match_rate"]==1.0
    assert s["heldout_termination_rate"]==1.0
    assert s["numeric_only_authoritative_trajectory"]=="PASS"
print("PRIMITIVE_2_TEST_PASS")
