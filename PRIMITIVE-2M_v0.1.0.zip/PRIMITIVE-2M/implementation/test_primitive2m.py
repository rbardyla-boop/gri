#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2M_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2M_REPLAY_CHECK.json").read_text())
p=r["system_summary"]["MINIMAL_STRUCTURAL_ESCAPE"]
assert r["terminal_verdict"]=="STRUCTURAL_LANGUAGE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["world_count"]==50
assert p["base_failure_detected_count"]==50
assert p["family_exact_count"]==50
assert p["program_exact_count"]==50
assert p["mean_heldout_accuracy"]==1.0
assert p["new_capability_count"]==1
assert p["falsification_found_count"]==50
assert p["minimum_falsification_exact_count"]==50
assert p["hidden_matches_recovered_count"]==50
assert p["hidden_rejects_base_count"]==50
assert rp["exact_byte_replay"]=="PASS"
assert r["system_summary"]["FULL_STRUCTURAL_EXPANSION"]["new_capability_count"]==5
print("PRIMITIVE_2M_TEST_PASS")
