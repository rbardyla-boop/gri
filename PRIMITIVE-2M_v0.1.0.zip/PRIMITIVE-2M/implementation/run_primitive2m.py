from pathlib import Path
import json, hashlib, itertools, csv, os, zipfile, subprocess, sys
import numpy as np

ROOT=Path("/mnt/data/PRIMITIVE-2M")
FIX=ROOT/"PRIMITIVE-2M_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

def canon(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_file(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2M_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"], rec["name"]

grammar=json.loads((ROOT/"PRIMITIVE-2M_GRAMMAR.json").read_text())
worlds=json.loads((FIX/"STRUCTURAL_ESCAPE_WORLDS.json").read_text())["worlds"]

BASE_TT=[8,14,6,9]
PAIRS=list(itertools.combinations(range(3),2))
FAMILIES=("ADD_NEW_BINARY_OPERATOR","ADD_THIRD_PARENT","ADD_LATENT_VARIABLE","ADD_ONE_STEP_MEMORY","ADD_RECURRENT_EDGE")

def dep2(tt,var):
    for a,b in itertools.product([0,1],repeat=2):
        x=[a,b]; y=x.copy(); y[var]^=1
        if ((tt>>(2*x[0]+x[1]))&1)!=((tt>>(2*y[0]+y[1]))&1): return True
    return False
def dep3(tt,var):
    for bits in itertools.product([0,1],repeat=3):
        x=list(bits);y=x.copy();y[var]^=1
        if ((tt>>(4*x[0]+2*x[1]+x[2]))&1)!=((tt>>(4*y[0]+2*y[1]+y[2]))&1): return True
    return False

MISSING=[tt for tt in range(16) if tt not in BASE_TT and dep2(tt,0) and dep2(tt,1)]
ESS3=[tt for tt in range(256) if all(dep3(tt,v) for v in range(3))]

def run_spec(spec,episodes):
    allout=[]
    for roots in episodes:
        prev_y=prev_z=0;prev_roots=[0,0,0];out=[]
        for cur in roots:
            fam=spec["family"]
            if fam in ("BASE","ADD_NEW_BINARY_OPERATOR"):
                yp=spec["y"];zp=spec["z"]
                y=(yp[2]>>(2*cur[yp[0]]+cur[yp[1]]))&1
                z=(zp[2]>>(2*cur[zp[0]]+cur[zp[1]]))&1
            elif fam=="ADD_THIRD_PARENT":
                idx=4*cur[0]+2*cur[1]+cur[2]
                if spec["target"]=="Y":
                    y=(spec["tt3"]>>idx)&1
                    zp=spec["z"];z=(zp[2]>>(2*cur[zp[0]]+cur[zp[1]]))&1
                else:
                    yp=spec["y"];y=(yp[2]>>(2*cur[yp[0]]+cur[yp[1]]))&1
                    z=(spec["tt3"]>>idx)&1
            elif fam=="ADD_LATENT_VARIABLE":
                hp=spec["h"];h=(hp[2]>>(2*cur[hp[0]]+cur[hp[1]]))&1
                yr,yt=spec["y"];zr,zt=spec["z"]
                y=(yt>>(2*h+cur[yr]))&1
                z=(zt>>(2*h+cur[zr]))&1
            elif fam=="ADD_ONE_STEP_MEMORY":
                if spec["target"]=="Y":
                    cr,pr,op=spec["mem"];y=(op>>(2*cur[cr]+prev_roots[pr]))&1
                    zp=spec["z"];z=(zp[2]>>(2*cur[zp[0]]+cur[zp[1]]))&1
                else:
                    yp=spec["y"];y=(yp[2]>>(2*cur[yp[0]]+cur[yp[1]]))&1
                    cr,pr,op=spec["mem"];z=(op>>(2*cur[cr]+prev_roots[pr]))&1
            elif fam=="ADD_RECURRENT_EDGE":
                if spec["target"]=="Y":
                    cr,op=spec["rec"];y=(op>>(2*cur[cr]+prev_y))&1
                    zp=spec["z"];z=(zp[2]>>(2*cur[zp[0]]+cur[zp[1]]))&1
                else:
                    yp=spec["y"];y=(yp[2]>>(2*cur[yp[0]]+cur[yp[1]]))&1
                    cr,op=spec["rec"];z=(op>>(2*cur[cr]+prev_z))&1
            out.append([int(y),int(z)])
            prev_y,prev_z=y,z;prev_roots=list(cur)
        allout.append(out)
    return allout

# Rebuild candidate spaces independently.
base_specs=[]
for yp in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
    for zp in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
        base_specs.append({"family":"BASE","y":list(yp),"z":list(zp)})

fam_specs={f:[] for f in FAMILIES}
for target in ("Y","Z"):
    for pair in PAIRS:
        for op in MISSING:
            for other in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
                if target=="Y":
                    fam_specs["ADD_NEW_BINARY_OPERATOR"].append({"family":"ADD_NEW_BINARY_OPERATOR","target":"Y","y":[pair[0],pair[1],op],"z":list(other),"new_tt":op})
                else:
                    fam_specs["ADD_NEW_BINARY_OPERATOR"].append({"family":"ADD_NEW_BINARY_OPERATOR","target":"Z","y":list(other),"z":[pair[0],pair[1],op],"new_tt":op})

for target in ("Y","Z"):
    for op3 in ESS3:
        for other in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
            if target=="Y":
                fam_specs["ADD_THIRD_PARENT"].append({"family":"ADD_THIRD_PARENT","target":"Y","tt3":op3,"z":list(other)})
            else:
                fam_specs["ADD_THIRD_PARENT"].append({"family":"ADD_THIRD_PARENT","target":"Z","tt3":op3,"y":list(other)})

for hp in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
    remaining=({0,1,2}-{hp[0],hp[1]}).pop()
    for yt in BASE_TT:
        for zt in BASE_TT:
            fam_specs["ADD_LATENT_VARIABLE"].append({"family":"ADD_LATENT_VARIABLE","h":list(hp),"y":[remaining,yt],"z":[remaining,zt]})

for target in ("Y","Z"):
    for cr in range(3):
        for pr in range(3):
            if cr==pr: continue
            for op in BASE_TT:
                for other in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
                    if target=="Y":
                        fam_specs["ADD_ONE_STEP_MEMORY"].append({"family":"ADD_ONE_STEP_MEMORY","target":"Y","mem":[cr,pr,op],"z":list(other)})
                    else:
                        fam_specs["ADD_ONE_STEP_MEMORY"].append({"family":"ADD_ONE_STEP_MEMORY","target":"Z","mem":[cr,pr,op],"y":list(other)})

for target in ("Y","Z"):
    for cr in range(3):
        for op in BASE_TT:
            for other in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
                if target=="Y":
                    fam_specs["ADD_RECURRENT_EDGE"].append({"family":"ADD_RECURRENT_EDGE","target":"Y","rec":[cr,op],"z":list(other)})
                else:
                    fam_specs["ADD_RECURRENT_EDGE"].append({"family":"ADD_RECURRENT_EDGE","target":"Z","rec":[cr,op],"y":list(other)})

def exact_fits(specs,episodes,gold):
    return [s for s in specs if run_spec(s,episodes)==gold]

def scalar_error(spec,episodes,gold):
    p=run_spec(spec,episodes);e=0
    for pe,ge in zip(p,gold):
        for pt,gt in zip(pe,ge):
            e+=int(pt[0]!=gt[0])+int(pt[1]!=gt[1])
    return e

def flat_accuracy(pred,gold):
    c=n=0
    for pe,ge in zip(pred,gold):
        for pt,gt in zip(pe,ge):
            for a,b in zip(pt,gt):
                c+=int(a==b);n+=1
    return c,n,c/n

def intervention_candidates(world,recovered,base_best):
    e=world["validation_intervention_episode"]
    out=[]
    for t in range(len(e)):
        for r in range(3):
            for val in (0,1):
                ee=[list(x) for x in e];ee[t][r]=val
                pr=run_spec(recovered,[ee])[0]
                pb=run_spec(base_best,[ee])[0]
                if pr!=pb:
                    h=int(hashlib.sha256(f"{world['world_id']}|{t}|{r}|{val}".encode()).hexdigest()[:8],16)
                    cost=1+(h%9)
                    out.append((cost,t,r,val,pr,pb,ee))
    out.sort(key=lambda x:(x[0],x[1],x[2],x[3]))
    return out

world_results=[]
for w in worlds:
    discovery=w["discovery_episodes"];gold=w["discovery_outputs"]
    heldout=w["heldout_episodes"];heldout_gold=w["heldout_outputs"]

    basefits=exact_fits(base_specs,discovery,gold)
    base_failure=(len(basefits)==0)

    family_fits={fam:exact_fits(fam_specs[fam],discovery,gold) for fam in FAMILIES}
    live=[fam for fam in FAMILIES if family_fits[fam]]

    # Primary minimal structural escape.
    if len(live)==1 and len(family_fits[live[0]])==1:
        primary_family=live[0]
        primary_program=family_fits[primary_family][0]
    else:
        primary_family=None;primary_program=None

    # Base best fit.
    scored=sorted((scalar_error(s,discovery,gold),canon(s),s) for s in base_specs)
    base_err,_,base_best=scored[0]

    # Full structural expansion: all 5 capabilities enabled, but exact program selected across union.
    union_exact=[]
    for fam in FAMILIES:
        for s in family_fits[fam]:
            union_exact.append((fam,s))
    union_exact.sort(key=lambda x:(FAMILIES.index(x[0]),canon(x[1])))
    full_choice=union_exact[0] if union_exact else (None,None)

    # Heldout predictions.
    base_pred=run_spec(base_best,heldout)
    bc,bn,bacc=flat_accuracy(base_pred,heldout_gold)
    if primary_program is not None:
        pp=run_spec(primary_program,heldout)
        pc,pn,pacc=flat_accuracy(pp,heldout_gold)
    else:
        pc=0;pn=sum(len(ep)*2 for ep in heldout_gold);pacc=0.0

    full_prog=full_choice[1]
    if full_prog is not None:
        fp=run_spec(full_prog,heldout)
        fc,fn,facc=flat_accuracy(fp,heldout_gold)
    else:
        fc=0;fn=sum(len(ep)*2 for ep in heldout_gold);facc=0.0

    # Falsification experiment.
    fals=None
    if primary_program is not None:
        cand=intervention_candidates(w,primary_program,base_best)
        if cand:
            best=cand[0]
            # Independent minimum from generator-side frozen receipt.
            gen=w["generator_min_cost_distinguishing_intervention"]
            min_exact=(best[0]==gen["cost"] and best[1]==gen["time"] and best[2]==gen["root"] and best[3]==gen["value"])
            actual=run_spec(w["hidden_program"],[best[6]])[0]
            recovered_matches=(actual==best[4])
            base_rejected=(actual!=best[5])
            fals={
                "found":True,"cost":best[0],"time":best[1],"root":best[2],"value":best[3],
                "minimum_exact":min_exact,
                "hidden_matches_recovered":recovered_matches,
                "hidden_rejects_base":base_rejected,
            }
        else:
            fals={"found":False,"minimum_exact":False,"hidden_matches_recovered":False,"hidden_rejects_base":False}

    world_results.append({
        "world_id":w["world_id"],"hidden_family":w["hidden_family"],
        "base_failure_detected":base_failure,"base_exact_fit_count":len(basefits),
        "family_fit_counts":{k:len(v) for k,v in family_fits.items()},
        "primary_family":primary_family,
        "family_exact":primary_family==w["hidden_family"],
        "program_exact":primary_program==w["hidden_program"],
        "base_best_discovery_error":base_err,
        "base_heldout_accuracy":bacc,
        "primary_heldout_accuracy":pacc,
        "full_expansion_family":full_choice[0],
        "full_expansion_heldout_accuracy":facc,
        "full_expansion_capability_count":5,
        "primary_capability_count":1 if primary_program is not None else 0,
        "falsification":fals,
    })

def sum_bool(path):
    return sum(bool(path(w)) for w in world_results)

summary={
    "FORCE_BASE_BEST_FIT":{
        "world_count":len(world_results),
        "model_class_failure_declared_count":0,
        "mean_discovery_error":sum(w["base_best_discovery_error"] for w in world_results)/len(world_results),
        "mean_heldout_accuracy":sum(w["base_heldout_accuracy"] for w in world_results)/len(world_results),
        "new_capability_count":0,
    },
    "FULL_STRUCTURAL_EXPANSION":{
        "world_count":len(world_results),
        "exact_fit_count":sum(1 for w in world_results if w["full_expansion_family"] is not None),
        "mean_heldout_accuracy":sum(w["full_expansion_heldout_accuracy"] for w in world_results)/len(world_results),
        "new_capability_count":5,
    },
    "MINIMAL_STRUCTURAL_ESCAPE":{
        "world_count":len(world_results),
        "base_failure_detected_count":sum_bool(lambda w:w["base_failure_detected"]),
        "family_exact_count":sum_bool(lambda w:w["family_exact"]),
        "program_exact_count":sum_bool(lambda w:w["program_exact"]),
        "mean_heldout_accuracy":sum(w["primary_heldout_accuracy"] for w in world_results)/len(world_results),
        "new_capability_count":1,
        "falsification_found_count":sum_bool(lambda w:w["falsification"]["found"]),
        "minimum_falsification_exact_count":sum_bool(lambda w:w["falsification"]["minimum_exact"]),
        "hidden_matches_recovered_count":sum_bool(lambda w:w["falsification"]["hidden_matches_recovered"]),
        "hidden_rejects_base_count":sum_bool(lambda w:w["falsification"]["hidden_rejects_base"]),
    }
}

p=summary["MINIMAL_STRUCTURAL_ESCAPE"]
if (
    p["base_failure_detected_count"]==50 and p["family_exact_count"]==50 and p["program_exact_count"]==50
    and p["mean_heldout_accuracy"]==1.0 and p["falsification_found_count"]==50
    and p["minimum_falsification_exact_count"]==50 and p["hidden_matches_recovered_count"]==50
    and p["hidden_rejects_base_count"]==50
):
    terminal="STRUCTURAL_LANGUAGE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif p["family_exact_count"]>0:
    terminal="PARTIAL"
else:
    terminal="STRUCTURAL_LANGUAGE_ESCAPE_INSUFFICIENT"

results={
    "experiment":"PRIMITIVE-2M","version":"0.1.0","freeze_sha256":freeze["freeze_sha256"],
    "terminal_verdict":terminal,"world_count":len(world_results),
    "system_summary":summary,"world_results":world_results,
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2M_RESULTS.json").write_text(json.dumps(results,indent=2))

print("PRIMITIVE-2M scored")
print("terminal:",terminal)
print(json.dumps(summary,indent=2))