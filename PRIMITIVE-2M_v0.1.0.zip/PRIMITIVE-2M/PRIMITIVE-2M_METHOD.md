# PRIMITIVE-2M METHOD

1. Freeze one common temporal observation format: three binary root streams, two observed outputs, four time steps.
2. Freeze a base grammar of two same-time binary equations using AND, OR, XOR and XNOR.
3. Freeze five competing one-capability structural repairs:
   - ADD_NEW_BINARY_OPERATOR
   - ADD_THIRD_PARENT
   - ADD_LATENT_VARIABLE
   - ADD_ONE_STEP_MEMORY
   - ADD_RECURRENT_EDGE
4. Make each repair irreducible in the capability it claims to add. A three-parent rule must depend on all three parents; a new binary operator must depend on both arguments; the latent path must be essential to both outputs.
5. Generate ten frozen worlds per repair family, fifty total.
6. Retain only worlds with zero exact base fits and exactly one exact-fitting one-capability family containing exactly one exact program.
7. Primary selector receives discovery episodes only. It must declare base failure, test each one-capability family, and select the unique exact structural repair.
8. Freeze the recovered structural program before scoring two unseen episodes.
9. Independently compute the least-error base program.
10. Use a separate episode where the recovered and old base models agree passively. Enumerate every allowed one-root-bit intervention, charge deterministic costs, and select the minimum-cost action for which the models predict different output trajectories.
11. Execute that intervention under the hidden world and require the resulting trajectory to match the recovered model and reject the old base model.
12. Re-run the exact scorer and require byte-identical result JSON.

The five structural families are supplied by the meta-language. This experiment does not claim unrestricted structural invention.
