# PRIMITIVE-2M Conclusion

**Terminal verdict:** `STRUCTURAL_LANGUAGE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Structural escape

The base model class had zero exact support in all fifty frozen worlds.

The primary system then selected the correct missing structural family in:

```text
50/50
```

and reconstructed the exact hidden structural program in:

```text
50/50
```

Every successful repair added exactly one structural capability.

Held-out prediction was:

```text
1.000000
```

## Why the closed model is dangerous

`FORCE_BASE_BEST_FIT` never admitted structural failure.

It still achieved:

```text
mean discovery error:  6.060 bits/world
held-out accuracy:     0.828750
```

So the best theory inside a structurally wrong language can remain superficially competent.

## Why adding every structure is not the same result

`FULL_STRUCTURAL_EXPANSION` enabled all five repair families and also achieved exact held-out prediction.

But it paid for five new structural capabilities where one was sufficient.

PRIMITIVE-2M therefore supports a minimum-change principle:

> Structural escape should add only the expressive capability demanded by the evidence.

## Active falsification

After the structural program was frozen, each world supplied a separate episode where the recovered model and best old base model agreed passively.

The planner then found the minimum-cost intervention that forced their predictions apart in:

```text
50/50
```

worlds.

When executed against the hidden mechanism:

```text
hidden outcome matched recovered structure: 50/50
hidden outcome rejected best old model:      50/50
```

Thus the structural extension was not accepted merely because it fit old observations; it survived an actively constructed falsification test.

## Supported claim

Within the frozen bounded structural meta-language:

> A machine can recognize that its current causal language has empty exact support, identify which of five irreducible structural capabilities is required, instantiate the unique minimal repair, preserve exact unseen prediction, and design a minimum-cost intervention that empirically separates the repaired model from the best old model.

## Scope boundary

The structural alternatives were still supplied:

```text
new binary operator
third parent
latent variable
one-step memory
recurrent edge
```

The system chose among and instantiated them. It did not invent a sixth structural concept outside that meta-language.

That is now the remaining gap.
