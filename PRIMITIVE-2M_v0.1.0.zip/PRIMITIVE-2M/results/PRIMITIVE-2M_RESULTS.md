# PRIMITIVE-2M Results

**Terminal verdict:** `STRUCTURAL_LANGUAGE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Exact deterministic replay:** `PASS`  
**Worlds:** 50  

| System | Structural failure recognized | Exact structural fit | Held-out accuracy | New capabilities |
|---|---:|---:|---:|---:|
| FORCE_BASE_BEST_FIT | 0/50 | 0/50 | 0.828750 | 0 |
| FULL_STRUCTURAL_EXPANSION | 50/50 | 50/50 | 1.000000 | 5 |
| **MINIMAL_STRUCTURAL_ESCAPE** | **50/50** | **50/50** | **1.000000** | **1** |

## Primary system

- Structural family exact: `50/50`
- Hidden program exact: `50/50`
- Minimum-cost falsification found: `50/50`
- Hidden world matched recovered structure: `50/50`
- Hidden world rejected best old base model: `50/50`

Family balance: `{'ADD_NEW_BINARY_OPERATOR': 10, 'ADD_THIRD_PARENT': 10, 'ADD_LATENT_VARIABLE': 10, 'ADD_ONE_STEP_MEMORY': 10, 'ADD_RECURRENT_EDGE': 10}`
