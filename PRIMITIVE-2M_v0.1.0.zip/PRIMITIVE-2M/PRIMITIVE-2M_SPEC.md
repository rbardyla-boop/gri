# PRIMITIVE-2M — STRUCTURAL LANGUAGE ESCAPE

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `59b1809c271f4930113d5c75b7c558bc2d96b345c1c70eba5a20420a6de79677`

## Question

> Can the machine identify which structural assumption is missing when the base causal language has no exact explanation?

## Competing irreducible repairs

```text
ADD_NEW_BINARY_OPERATOR
ADD_THIRD_PARENT
ADD_LATENT_VARIABLE
ADD_ONE_STEP_MEMORY
ADD_RECURRENT_EDGE
```

All worlds use exactly:

```text
3 binary root streams
2 observed output streams
4 time steps
```

A three-parent repair must actually depend on all three parents. A new binary operator must depend on both arguments. The latent family must make the hidden path essential to both outputs. These restrictions prevent a more expressive family from winning simply by ignoring the capability it supposedly adds.

## Frozen worlds

50 worlds total, 10 per structural family.

Every world has:

```text
0 exact base fits
1 exact structural family
1 exact program in that family
```

The primary selector receives discovery episodes only.

## Predictive and falsification gate

After family/program selection is frozen:

1. predict two unseen episodes exactly;
2. compare recovered structure with the best-fitting old base model;
3. use a separate episode where both agree passively;
4. choose the minimum-cost one-root-bit intervention that makes their predictions diverge;
5. execute that intervention in the hidden world.

## Scope

The five repair families are supplied in advance. This tests structural-family escape inside a bounded structural meta-language, not unrestricted representational invention.
