from pathlib import Path
import json, hashlib, random, itertools, zipfile, shutil

BASE=Path('/mnt/data')
P2D=BASE/'PRIMITIVE-2D'
ROOT=BASE/'PRIMITIVE-2I'
FIX=ROOT/'PRIMITIVE-2I_FIXTURES'

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha_obj(v):
    return hashlib.sha256(canon(v).encode()).hexdigest()
def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

p2d_mech_hash=sha_file(P2D/'PRIMITIVE-2D_MECHANISMS.json')

OP_AND=1; OP_OR=2; OP_XOR=3; OP_XNOR=4
OPS=[OP_AND,OP_OR,OP_XOR,OP_XNOR]

def op_eval(code,a,b):
    if code==OP_AND: return a & b
    if code==OP_OR: return a | b
    if code==OP_XOR: return a ^ b
    if code==OP_XNOR: return 1-(a ^ b)
    raise ValueError(code)

def simulate(model, roots, intervention=None):
    vals=dict(roots)
    if intervention is not None and intervention[0] in vals:
        vals[intervention[0]]=intervention[1]
    for child,pa,pb,op in model['equations']:
        if intervention is not None and child==intervention[0]:
            vals[child]=intervention[1]
        else:
            vals[child]=op_eval(op,vals[pa],vals[pb])
    return vals

rng=random.Random(0x2A12026)
used_ids=set()
def fresh_ids(n):
    out=[]
    while len(out)<n:
        x=rng.randrange(1,(1<<24)-1)
        if x not in used_ids:
            used_ids.add(x); out.append(x)
    return out

worlds=[]
TARGET=192
attempts=0
while len(worlds)<TARGET and attempts<100000:
    attempts+=1
    vids=fresh_ids(6)
    v0,v1,v2,v3,v4,v5=vids
    parent_pool={v3:[v0,v1,v2], v4:[v0,v1,v2,v3], v5:[v0,v1,v2,v3,v4]}
    eqs=[]
    for child in (v3,v4,v5):
        pool=parent_pool[child]
        pa=rng.choice(pool); pb=rng.choice([x for x in pool if x!=pa])
        eqs.append([child,pa,pb,rng.choice(OPS)])
    mut_idx=rng.randrange(3)
    eqs2=[list(e) for e in eqs]
    old=eqs2[mut_idx][3]
    eqs2[mut_idx][3]=rng.choice([o for o in OPS if o!=old])
    h0={'root_ids':[v0,v1,v2],'equations':eqs}
    h1={'root_ids':[v0,v1,v2],'equations':eqs2}

    equivalent=[]
    for bits in itertools.product([0,1],repeat=3):
        roots={v0:bits[0],v1:bits[1],v2:bits[2]}
        a=simulate(h0,roots); b=simulate(h1,roots)
        if all(a[x]==b[x] for x in vids):
            equivalent.append(roots)
    if not equivalent:
        continue
    roots=rng.choice(equivalent)

    discr=[]
    for iv in vids:
        for val in (0,1):
            p0=simulate(h0,roots,[iv,val]); p1=simulate(h1,roots,[iv,val])
            for ov in vids:
                if p0[ov]!=p1[ov]:
                    discr.append([iv,val,ov,p0[ov],p1[ov]])
    if len(discr)<3:
        continue

    idx=len(worlds)
    intervention_costs={}
    observation_costs={}
    for iv in vids:
        for val in (0,1):
            h=int(hashlib.sha256(f'{idx}|I|{iv}|{val}'.encode()).hexdigest()[:8],16)
            intervention_costs[f'{iv}:{val}']=1+(h%9)
    for ov in vids:
        h=int(hashlib.sha256(f'{idx}|O|{ov}'.encode()).hexdigest()[:8],16)
        observation_costs[str(ov)]=1+(h%7)

    worlds.append({
        'world_id':idx,
        'variable_ids':vids,
        'baseline_roots':{str(k):v for k,v in roots.items()},
        'hypotheses':[h0,h1],
        'thought_hypothesis_index':idx%2,
        'hidden_true_hypothesis_index':(idx//2)%2,
        'intervention_catalog':[[iv,val] for iv in vids for val in (0,1)],
        'observable_variables':vids,
        'intervention_costs':intervention_costs,
        'observation_costs':observation_costs,
        'discriminating_pair_count_experimenter_only':len(discr),
    })

assert len(worlds)==TARGET

world_doc={
    'experiment':'PRIMITIVE-2I','version':'0.1.0',
    'description':'Anonymous deterministic binary causal worlds with two observationally equivalent competing hypotheses. True hypothesis is hidden from planner.',
    'world_count':len(worlds),'worlds':worlds,
}
world_doc['world_set_sha256']=sha_obj(worlds)
(FIX/'CAUSAL_WORLDS.json').write_text(json.dumps(world_doc,indent=2))

planners={
    'experiment':'PRIMITIVE-2I','version':'0.1.0',
    'planners':{
        'PASSIVE_CHEAPEST_OBSERVATION':{
            'policy':'perform no intervention; buy cheapest passive observation; decide only if candidate hypotheses differ on that observation, otherwise ABSTAIN'
        },
        'CHEAPEST_ACTION_PAIR':{
            'policy':'buy globally cheapest intervention+observation pair without checking whether candidate predictions diverge; decide if outcome distinguishes, otherwise ABSTAIN'
        },
        'FULL_ACQUIRE':{
            'policy':'execute every allowed intervention and observe every allowed variable; cost of all intervention+observation pairs is charged; use any discriminating result'
        },
        'MIN_COST_DISCRIMINATING_INTERVENTION':{
            'policy':'simulate both candidate hypothesis programs under every allowed one-shot intervention; choose minimum total cost intervention+observation pair whose predicted outcomes differ; tie-break by intervention variable, intervention value, observation variable'
        },
    },
    'decision_rule':'after environment observation, select the unique hypothesis whose predicted observed value matches; if both or neither match, ABSTAIN',
    'planner_truth_access':False,
    'historical_label_access':False,
    'verification_contract_supplied':False,
}
planners['planners_sha256']=sha_obj(planners)
(ROOT/'PRIMITIVE-2I_PLANNERS.json').write_text(json.dumps(planners,indent=2))

experiment={
    'experiment':'PRIMITIVE-2I','version':'0.1.0','title':'Intervention Discovery',
    'research_question':'Given a thought, two competing machine-native causal hypotheses, anonymous manipulable variables, observable outcomes, and costs—but no verification contract or labeled history—can a machine construct a minimum-cost intervention whose possible outcomes discriminate the hypotheses?',
    'semantic_primitive_changed':False,
    'justification_dag_changed':False,
    'parent_p2d_rollback_sha256':p2d_mech_hash,
    'world_set_sha256':world_doc['world_set_sha256'],
    'planners_sha256':planners['planners_sha256'],
    'causal_hypothesis_representation':{
        'root_ids':'three anonymous numeric variables',
        'equation_packet_semantics':'[child,parent_a,parent_b,operator_code]',
        'operator_codes':{'1':'AND','2':'OR','3':'XOR','4':'XNOR'},
        'human_names_visible_to_planner':False,
    },
    'hard_controls':[
        'planner receives both candidate hypothesis programs, current baseline state, intervention/observation catalogs, and costs',
        'planner does not receive hidden true hypothesis',
        'planner does not receive historical TRUE/FALSE labels',
        'planner does not receive a verification contract or relevant-variable annotation',
        'complete passive baseline observation is identical under both hypotheses',
        'all costs are generated independently of hidden truth',
        'one-shot interventions only in v0.1.0',
    ],
    'metrics':['intervention_discovery_rate','hypothesis_identification_accuracy','thought_challenge_accuracy','abstention_rate','total_evidence_cost','cost_ratio_to_experimenter_minimum','deterministic_replay'],
    'success_gate':{
        'worlds_decisively_verified':192,
        'hypothesis_identification_accuracy':1.0,
        'thought_challenge_accuracy':1.0,
        'abstentions':0,
        'planner_cost_equals_experimenter_minimum_each_world':True,
        'deterministic_replay':True,
    },
    'terminal_verdicts':['INTERVENTION_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE','PARTIAL','INTERVENTION_DISCOVERY_INSUFFICIENT','EXPERIMENT_INVALID'],
}
experiment['experiment_sha256']=sha_obj(experiment)
(ROOT/'PRIMITIVE-2I_EXPERIMENT.json').write_text(json.dumps(experiment,indent=2))

spec=f'''# PRIMITIVE-2I — INTERVENTION DISCOVERY

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `{experiment['experiment_sha256']}`  
**World-set SHA-256:** `{world_doc['world_set_sha256']}`

## Question

> Given a thought, a set of manipulable variables and observable outcomes, but no supplied verification contract and no labeled history telling the machine which observations imply truth, can it construct an intervention whose possible outcomes discriminate between competing hypotheses?

## Machine-native hypotheses

Each world contains two anonymous deterministic binary causal programs. Structural equations are numeric tuples:

```text
[child_variable, parent_A, parent_B, operator_code]
```

Operator codes are 1=AND, 2=OR, 3=XOR, 4=XNOR.

The planner receives both candidate programs but never which one is true.

## Passive equivalence

Every scored world is constructed so the complete passive baseline observation is identical under both hypotheses. Passive observation alone therefore cannot determine the answer.

## Intervention discovery

Allowed action:

```text
do(variable = 0|1)
```

Allowed observation:

```text
read one variable
```

No variable is labeled diagnostic. The planner must derive predicted consequences under both hypotheses and find a pair for which predictions diverge.

## Primary planner

`MIN_COST_DISCRIMINATING_INTERVENTION` searches all one-shot intervention/observation pairs and chooses the cheapest discriminating pair. An independent exhaustive calculation supplies the experimenter-side optimum for scoring.

## After observation

The hidden environment executes the selected intervention under the true hypothesis. The planner receives only the purchased observed bit and must identify the unique matching hypothesis, then support or challenge the current thought accordingly.

PRIMITIVE-2D rollback remains frozen and is not redesigned here.

## Strict pass

Across all 192 worlds:

```text
192/192 decisive interventions
100% hidden-hypothesis identification
100% thought support/challenge accuracy
0 abstentions
minimum evidence cost in every world
deterministic replay
```

## Scope limits

v0.1.0 uses deterministic binary worlds, known candidate hypothesis programs, one-shot interventions, perfect observations, and exactly two competing hypotheses. It does not yet test noisy outcomes, unknown model classes, sequential adaptive experiments, or learned causal-model induction.
'''
(ROOT/'PRIMITIVE-2I_SPEC.md').write_text(spec)

freeze={'experiment':'PRIMITIVE-2I','version':'0.1.0','status':'FROZEN_BEFORE_SCORING','parent_p2d_rollback_sha256':p2d_mech_hash,'files':[]}
for p in [ROOT/'PRIMITIVE-2I_EXPERIMENT.json',ROOT/'PRIMITIVE-2I_PLANNERS.json',ROOT/'PRIMITIVE-2I_SPEC.md',FIX/'CAUSAL_WORLDS.json']:
    freeze['files'].append({'name':str(p.relative_to(ROOT)),'sha256':sha_file(p)})
freeze['freeze_sha256']=sha_obj({'files':freeze['files'],'parent_p2d_rollback_sha256':p2d_mech_hash})
(ROOT/'PRIMITIVE-2I_FREEZE.json').write_text(json.dumps(freeze,indent=2))

fz=ROOT/'PRIMITIVE-2I_FIXTURES.zip'
with zipfile.ZipFile(fz,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(FIX/'CAUSAL_WORLDS.json',arcname='PRIMITIVE-2I_FIXTURES/CAUSAL_WORLDS.json')

print('PRIMITIVE-2I frozen before scoring')
print('freeze SHA:',freeze['freeze_sha256'])
print('worlds:',len(worlds))
print('avg discriminating pairs:',round(sum(w['discriminating_pair_count_experimenter_only'] for w in worlds)/len(worlds),2))
