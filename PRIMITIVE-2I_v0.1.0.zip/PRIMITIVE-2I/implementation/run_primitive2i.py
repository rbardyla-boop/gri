from pathlib import Path
import json, hashlib, itertools, csv

BASE=Path('/mnt/data')
P2D=BASE/'PRIMITIVE-2D'
ROOT=BASE/'PRIMITIVE-2I'
FIX=ROOT/'PRIMITIVE-2I_FIXTURES'
RES=ROOT/'results'
RES.mkdir(exist_ok=True)

OP_AND=1; OP_OR=2; OP_XOR=3; OP_XNOR=4

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def op_eval(code,a,b):
    if code==OP_AND: return a & b
    if code==OP_OR: return a | b
    if code==OP_XOR: return a ^ b
    if code==OP_XNOR: return 1-(a ^ b)
    raise ValueError(code)

def simulate(model, roots, intervention=None):
    vals=dict(roots)
    if intervention is not None and intervention[0] in vals:
        vals[intervention[0]]=intervention[1]
    for child,pa,pb,op in model['equations']:
        if intervention is not None and child==intervention[0]:
            vals[child]=intervention[1]
        else:
            vals[child]=op_eval(op,vals[pa],vals[pb])
    return vals

def verify_freeze():
    freeze=json.loads((ROOT/'PRIMITIVE-2I_FREEZE.json').read_text())
    for rec in freeze['files']:
        p=ROOT/rec['name']
        if sha_file(p)!=rec['sha256']:
            raise RuntimeError(f"frozen file changed: {rec['name']}")
    if sha_file(P2D/'PRIMITIVE-2D_MECHANISMS.json')!=freeze['parent_p2d_rollback_sha256']:
        raise RuntimeError('PRIMITIVE-2D rollback binding changed')
    return freeze

def roots_of(w):
    return {int(k):int(v) for k,v in w['baseline_roots'].items()}

def pair_cost(w,iv,val,ov):
    return int(w['intervention_costs'][f'{iv}:{val}'])+int(w['observation_costs'][str(ov)])

def predictions(w,iv,val,ov):
    roots=roots_of(w)
    p0=simulate(w['hypotheses'][0],roots,[iv,val])[ov]
    p1=simulate(w['hypotheses'][1],roots,[iv,val])[ov]
    return int(p0),int(p1)

def all_pairs(w):
    rows=[]
    for iv,val in w['intervention_catalog']:
        for ov in w['observable_variables']:
            p0,p1=predictions(w,iv,val,ov)
            rows.append({
                'intervention':[iv,val],'observation':ov,
                'pred0':p0,'pred1':p1,
                'cost':pair_cost(w,iv,val,ov),
                'discriminating':p0!=p1,
            })
    return rows

def decide_from_pair(w,row):
    true=int(w['hidden_true_hypothesis_index'])
    roots=roots_of(w)
    iv,val=row['intervention']; ov=row['observation']
    observed=simulate(w['hypotheses'][true],roots,[iv,val])[ov]
    matches=[]
    if row['pred0']==observed: matches.append(0)
    if row['pred1']==observed: matches.append(1)
    identified=matches[0] if len(matches)==1 else None
    thought=int(w['thought_hypothesis_index'])
    expected_challenge=(thought!=true)
    actual_challenge=None if identified is None else (thought!=identified)
    return {
        'observed':int(observed),
        'identified_hypothesis':identified,
        'true_hypothesis':true,
        'thought_hypothesis':thought,
        'expected_challenge':expected_challenge,
        'actual_challenge':actual_challenge,
        'identification_correct':identified==true,
        'challenge_correct':actual_challenge==expected_challenge if actual_challenge is not None else False,
        'abstain':identified is None,
    }

def score_world(w):
    pairs=all_pairs(w)
    discr=[r for r in pairs if r['discriminating']]
    assert discr
    optimum=min(discr,key=lambda r:(r['cost'],r['intervention'][0],r['intervention'][1],r['observation']))
    min_cost=optimum['cost']

    # Passive baseline: complete passive state is identical by construction.
    roots=roots_of(w)
    passive0=simulate(w['hypotheses'][0],roots)
    passive1=simulate(w['hypotheses'][1],roots)
    assert all(passive0[x]==passive1[x] for x in w['variable_ids'])
    cheapest_ov=min(w['observable_variables'],key=lambda x:(int(w['observation_costs'][str(x)]),x))
    passive={
        'planner':'PASSIVE_CHEAPEST_OBSERVATION',
        'cost':int(w['observation_costs'][str(cheapest_ov)]),
        'abstain':True,'identification_correct':False,'challenge_correct':False,
        'selected_observation':cheapest_ov,
        'cost_ratio_to_minimum':int(w['observation_costs'][str(cheapest_ov)])/min_cost,
        'minimum_cost_match':False,
    }

    cheapest=min(pairs,key=lambda r:(r['cost'],r['intervention'][0],r['intervention'][1],r['observation']))
    cheap_dec=decide_from_pair(w,cheapest)
    cheap={
        'planner':'CHEAPEST_ACTION_PAIR','cost':cheapest['cost'],
        'selected_pair':cheapest,'cost_ratio_to_minimum':cheapest['cost']/min_cost,
        'minimum_cost_match':cheapest['cost']==min_cost and cheapest['discriminating'],
        **cheap_dec
    }

    # Full acquire pays for every intervention/observation pair. It can use the cheapest
    # discriminating result after all evidence has been acquired.
    full_cost=sum(r['cost'] for r in pairs)
    full_dec=decide_from_pair(w,optimum)
    full={
        'planner':'FULL_ACQUIRE','cost':full_cost,
        'selected_decisive_pair_after_full_acquisition':optimum,
        'cost_ratio_to_minimum':full_cost/min_cost,
        'minimum_cost_match':False,
        **full_dec
    }

    chosen=min(discr,key=lambda r:(r['cost'],r['intervention'][0],r['intervention'][1],r['observation']))
    opt_dec=decide_from_pair(w,chosen)
    optimal={
        'planner':'MIN_COST_DISCRIMINATING_INTERVENTION','cost':chosen['cost'],
        'selected_pair':chosen,'experimenter_minimum_cost':min_cost,
        'cost_ratio_to_minimum':chosen['cost']/min_cost,
        'minimum_cost_match':chosen['cost']==min_cost,
        **opt_dec
    }
    return {
        'world_id':w['world_id'],
        'discriminating_pair_count':len(discr),
        'experimenter_minimum_cost':min_cost,
        'planners':{
            'PASSIVE_CHEAPEST_OBSERVATION':passive,
            'CHEAPEST_ACTION_PAIR':cheap,
            'FULL_ACQUIRE':full,
            'MIN_COST_DISCRIMINATING_INTERVENTION':optimal,
        }
    }

def aggregate(rows,name):
    ps=[r['planners'][name] for r in rows]
    n=len(ps)
    return {
        'world_count':n,
        'decisive_count':sum(not p['abstain'] for p in ps),
        'abstention_count':sum(p['abstain'] for p in ps),
        'hypothesis_identification_accuracy':sum(p['identification_correct'] for p in ps)/n,
        'thought_challenge_accuracy':sum(p['challenge_correct'] for p in ps)/n,
        'total_evidence_cost':sum(p['cost'] for p in ps),
        'mean_cost_ratio_to_minimum':sum(p['cost_ratio_to_minimum'] for p in ps)/n,
        'minimum_cost_match_count':sum(p['minimum_cost_match'] for p in ps),
    }

def main():
    freeze=verify_freeze()
    wd=json.loads((FIX/'CAUSAL_WORLDS.json').read_text())
    rows=[score_world(w) for w in wd['worlds']]
    names=['PASSIVE_CHEAPEST_OBSERVATION','CHEAPEST_ACTION_PAIR','FULL_ACQUIRE','MIN_COST_DISCRIMINATING_INTERVENTION']
    summary={name:aggregate(rows,name) for name in names}
    p=summary['MIN_COST_DISCRIMINATING_INTERVENTION']
    if (
        p['decisive_count']==192 and
        p['abstention_count']==0 and
        p['hypothesis_identification_accuracy']==1.0 and
        p['thought_challenge_accuracy']==1.0 and
        p['minimum_cost_match_count']==192
    ):
        verdict='INTERVENTION_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE'
    elif p['decisive_count']>0:
        verdict='PARTIAL'
    else:
        verdict='INTERVENTION_DISCOVERY_INSUFFICIENT'
    out={
        'experiment':'PRIMITIVE-2I','version':'0.1.0',
        'freeze_sha256':freeze['freeze_sha256'],
        'terminal_verdict':verdict,
        'world_count':len(rows),
        'planner_summary':summary,
        'world_results':rows,
    }
    out['results_sha256']=hashlib.sha256(canon(out).encode()).hexdigest()
    (RES/'PRIMITIVE-2I_RESULTS.json').write_text(json.dumps(out,indent=2))

    lines=['# PRIMITIVE-2I Results','',f'**Terminal verdict:** `{verdict}`  ','',
           '| Planner | Decisive | Abstain | Identification | Challenge accuracy | Total cost | Mean cost / optimum | Exact optimum worlds |',
           '|---|---:|---:|---:|---:|---:|---:|---:|']
    for name in names:
        s=summary[name]
        lines.append(f"| {name} | {s['decisive_count']}/192 | {s['abstention_count']} | {s['hypothesis_identification_accuracy']:.6f} | {s['thought_challenge_accuracy']:.6f} | {s['total_evidence_cost']} | {s['mean_cost_ratio_to_minimum']:.6f} | {s['minimum_cost_match_count']}/192 |")
    (RES/'PRIMITIVE-2I_RESULTS.md').write_text('\n'.join(lines)+'\n')

    with (RES/'PRIMITIVE-2I_WORLD_RESULTS.csv').open('w',newline='') as f:
        w=csv.writer(f)
        w.writerow(['world_id','planner','decisive','correct_hypothesis','correct_challenge','cost','min_cost','ratio','selected_intervention','selected_observation'])
        for row in rows:
            for name,pv in row['planners'].items():
                pair=pv.get('selected_pair') or pv.get('selected_decisive_pair_after_full_acquisition') or {}
                w.writerow([row['world_id'],name,not pv['abstain'],pv['identification_correct'],pv['challenge_correct'],pv['cost'],row['experimenter_minimum_cost'],pv['cost_ratio_to_minimum'],pair.get('intervention'),pair.get('observation',pv.get('selected_observation'))])

    print(json.dumps({'terminal_verdict':verdict,'planner_summary':summary},indent=2))

if __name__=='__main__':
    main()
