#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/'results'/'PRIMITIVE-2I_RESULTS.json').read_text())
rp=json.loads((ROOT/'results'/'PRIMITIVE-2I_REPLAY_CHECK.json').read_text())
assert r['terminal_verdict']=='INTERVENTION_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE'
assert r['world_count']==192
assert rp['exact_byte_replay']=='PASS'
p=r['planner_summary']['MIN_COST_DISCRIMINATING_INTERVENTION']
assert p['decisive_count']==192
assert p['abstention_count']==0
assert p['hypothesis_identification_accuracy']==1.0
assert p['thought_challenge_accuracy']==1.0
assert p['minimum_cost_match_count']==192
assert p['mean_cost_ratio_to_minimum']==1.0
assert r['planner_summary']['PASSIVE_CHEAPEST_OBSERVATION']['decisive_count']==0
print('PRIMITIVE_2I_TEST_PASS')
