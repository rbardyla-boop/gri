# PRIMITIVE-2I — INTERVENTION DISCOVERY

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `499d878c5504abba2eebd807ed062a3866b8c137676d8f2921267ea754adaed8`  
**World-set SHA-256:** `f4ae533f137885f76fea12e07094ba159d998421677b3dd9d076cb15ea3e045c`

## Question

> Given a thought, a set of manipulable variables and observable outcomes, but no supplied verification contract and no labeled history telling the machine which observations imply truth, can it construct an intervention whose possible outcomes discriminate between competing hypotheses?

## Machine-native hypotheses

Each world contains two anonymous deterministic binary causal programs. Structural equations are numeric tuples:

```text
[child_variable, parent_A, parent_B, operator_code]
```

Operator codes are 1=AND, 2=OR, 3=XOR, 4=XNOR.

The planner receives both candidate programs but never which one is true.

## Passive equivalence

Every scored world is constructed so the complete passive baseline observation is identical under both hypotheses. Passive observation alone therefore cannot determine the answer.

## Intervention discovery

Allowed action:

```text
do(variable = 0|1)
```

Allowed observation:

```text
read one variable
```

No variable is labeled diagnostic. The planner must derive predicted consequences under both hypotheses and find a pair for which predictions diverge.

## Primary planner

`MIN_COST_DISCRIMINATING_INTERVENTION` searches all one-shot intervention/observation pairs and chooses the cheapest discriminating pair. An independent exhaustive calculation supplies the experimenter-side optimum for scoring.

## After observation

The hidden environment executes the selected intervention under the true hypothesis. The planner receives only the purchased observed bit and must identify the unique matching hypothesis, then support or challenge the current thought accordingly.

PRIMITIVE-2D rollback remains frozen and is not redesigned here.

## Strict pass

Across all 192 worlds:

```text
192/192 decisive interventions
100% hidden-hypothesis identification
100% thought support/challenge accuracy
0 abstentions
minimum evidence cost in every world
deterministic replay
```

## Scope limits

v0.1.0 uses deterministic binary worlds, known candidate hypothesis programs, one-shot interventions, perfect observations, and exactly two competing hypotheses. It does not yet test noisy outcomes, unknown model classes, sequential adaptive experiments, or learned causal-model induction.
