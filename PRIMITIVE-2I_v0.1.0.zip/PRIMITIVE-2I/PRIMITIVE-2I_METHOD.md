# PRIMITIVE-2I METHOD

1. Freeze 192 anonymous six-variable deterministic binary causal worlds.
2. Give each world two competing numeric structural programs that differ in one structural operator.
3. Select a passive root state for which the complete six-variable observation is identical under both hypotheses.
4. Hide which hypothesis is the true environment and independently assign intervention and observation costs.
5. Give the planner both candidate programs, the passive state, allowed interventions, observable variables, and costs. Do not give it the hidden truth, historical TRUE/FALSE labels, a diagnostic-variable annotation, or a verification contract.
6. Enumerate one-shot `do(variable=value)` interventions and predicted observations under both candidate programs.
7. A candidate experiment is discriminating only when the two hypotheses predict different values for the purchased observation.
8. `MIN_COST_DISCRIMINATING_INTERVENTION` chooses the lowest-cost discriminating intervention/observation pair, with deterministic tie-breaking.
9. The hidden environment executes only the chosen intervention under the true hypothesis and returns only the purchased observed bit.
10. The planner identifies the unique hypothesis consistent with that observation and emits SUPPORT or CHALLENGE for the current thought.
11. Score hypothesis identification, challenge accuracy, abstention, evidence cost, and equality to the exhaustive experimenter-side minimum.
12. Re-run the frozen scorer and require byte-identical results.

The PRIMITIVE-2D justification DAG is hash-bound and unchanged. PRIMITIVE-2I isolates the upstream problem of producing a trustworthy challenge signal; it does not redesign or re-score rollback.
