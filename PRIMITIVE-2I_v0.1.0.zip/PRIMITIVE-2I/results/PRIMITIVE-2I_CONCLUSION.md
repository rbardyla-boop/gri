# PRIMITIVE-2I Conclusion

**Terminal verdict:** `INTERVENTION_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Result

`MIN_COST_DISCRIMINATING_INTERVENTION` passed the complete frozen gate:

```text
worlds decisively verified:       192/192
hidden-hypothesis accuracy:       1.000000
thought support/challenge accuracy:1.000000
abstentions:                      0
minimum-cost matches:             192/192
total evidence cost:              1247
mean cost / optimum:              1.000000
exact deterministic replay:       PASS
```

## Why intervention mattered

The full passive state was deliberately identical under both hypotheses in every world.

`PASSIVE_CHEAPEST_OBSERVATION` therefore produced:

```text
decisive worlds: 0/192
abstentions:     192
```

This establishes that the task could not be solved by merely observing more of the existing state.

## Cheap action is not the same as informative action

`CHEAPEST_ACTION_PAIR` spent only 554 total cost units, but was decisive in only 10/192 worlds.

The planner had to ask a different question:

```text
Under which intervention do the hypotheses predict different outcomes?
```

and only then optimize cost.

## Exhaustive evidence was unnecessary

`FULL_ACQUIRE` identified the true hypothesis in 192/192 worlds but cost:

```text
125076 units
```

The minimum-cost intervention planner achieved the same decision accuracy for:

```text
1247 units
```

which is a 99.00% reduction in acquisition cost.

## Supported claim

Within the frozen deterministic two-hypothesis causal worlds:

> A machine can derive a one-shot intervention from competing machine-native causal hypotheses, select the cheapest observation whose predicted outcomes differ, execute that experiment against a hidden environment, and correctly support or challenge the current thought without a supplied verification contract or labeled truth history.

## Important boundary

The machine was given the two candidate causal programs.

PRIMITIVE-2I therefore does not establish that it can discover the causal hypotheses themselves. It establishes experimental discrimination **conditional on having competing mechanistic hypotheses**.

The next largest gap is causal-model generation/induction: can the system construct useful competing hypotheses from unexplained observations, rather than merely choose an experiment between hypotheses already supplied?
