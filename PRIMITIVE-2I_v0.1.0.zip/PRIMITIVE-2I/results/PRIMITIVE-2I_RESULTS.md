# PRIMITIVE-2I Results

**Terminal verdict:** `INTERVENTION_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE`  

| Planner | Decisive | Abstain | Identification | Challenge accuracy | Total cost | Mean cost / optimum | Exact optimum worlds |
|---|---:|---:|---:|---:|---:|---:|---:|
| PASSIVE_CHEAPEST_OBSERVATION | 0/192 | 192 | 0.000000 | 0.000000 | 307 | 0.289953 | 0/192 |
| CHEAPEST_ACTION_PAIR | 10/192 | 182 | 0.052083 | 0.052083 | 554 | 0.527484 | 10/192 |
| FULL_ACQUIRE | 192/192 | 0 | 1.000000 | 1.000000 | 125076 | 122.045974 | 0/192 |
| MIN_COST_DISCRIMINATING_INTERVENTION | 192/192 | 0 | 1.000000 | 1.000000 | 1247 | 1.000000 | 192/192 |
