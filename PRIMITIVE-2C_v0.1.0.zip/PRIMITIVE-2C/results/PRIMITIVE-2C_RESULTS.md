# PRIMITIVE-2C Results

**Terminal verdict:** `NO_GENERIC_CONTROL_SUCCEEDS`  
**Frozen models:** unchanged PRIMITIVE-2A seeds 13, 29, 61  
**Known baseline:** 47 PRIMITIVE-2B graphs  
**Independent confirmation:** 40 graphs + 120,000 local pair cases

| Control | Local false accepts | Local positive recall | Baseline exact | Baseline min P/R | Baseline bad | Confirmation exact | Confirmation min P/R | Confirmation bad | Gate |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| SWAP_CONSISTENCY_SEED_13 | 0 | 1.000000 | 0.957447 | 1.000000/0.800000 | 0 | 0.875000 | 0.997361/0.833333 | 1 | FAIL |
| SWAP_CONSISTENCY_SEED_29 | 0 | 0.999967 | 0.872340 | 0.810811/0.800000 | 49 | 0.850000 | 0.980769/0.833333 | 6 | FAIL |
| SWAP_CONSISTENCY_SEED_61 | 0 | 1.000000 | 0.914894 | 0.810811/0.800000 | 38 | 0.875000 | 0.755814/0.833333 | 105 | FAIL |
| MAJORITY_2_OF_3 | 0 | 1.000000 | 0.957447 | 0.769231/1.000000 | 50 | 0.950000 | 0.855263/1.000000 | 57 | FAIL |
| UNANIMITY_3_OF_3 | 0 | 1.000000 | 0.936170 | 0.927273/0.800000 | 12 | 0.900000 | 1.000000/0.833333 | 0 | FAIL |
| MAJORITY_PLUS_SWAP | 0 | 1.000000 | 0.914894 | 0.810811/0.800000 | 38 | 0.875000 | 0.997361/0.833333 | 1 | FAIL |

## Key observations

- Every preregistered control failed the joint zero-corruption + full-recall gate.
- The ensemble controls were perfect on the independent local admission exam, yet still failed recursively.
- 2-of-3 majority preserved recall but admitted correlated wrong derivations.
- 3-of-3 unanimity was safer on the independent confirmation set, but lost valid closure recall and still admitted shared errors on the known baseline.
- Swap consistency rejected valid recursive derivations and did not reliably eliminate corruption.
- The frontier scheduling patch was semantics-preserving for all previously scored swap variants.
