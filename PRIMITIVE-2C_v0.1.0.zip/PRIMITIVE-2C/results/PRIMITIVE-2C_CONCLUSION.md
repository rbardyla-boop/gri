# PRIMITIVE-2C Conclusion

**Terminal verdict:** `NO_GENERIC_CONTROL_SUCCEEDS`

PRIMITIVE-2C kept the three learned PRIMITIVE-2A models frozen and wrapped them in four preregistered, relation-agnostic error-control strategies:

```text
SWAP_CONSISTENCY
MAJORITY_2_OF_3
UNANIMITY_3_OF_3
MAJORITY_PLUS_SWAP
```

No model was retrained, selected, thresholded, or fine-tuned. Controls were forbidden from using relation names or fixture identity.

## Result

None of the controls achieved both:

```text
zero recursive corruption
AND
full valid-inference recall
```

on both the known PRIMITIVE-2B failure suite and the independent confirmation suite.

The strongest safety/utility split was:

```text
MAJORITY_2_OF_3
  baseline recall      = 1.0
  confirmation recall  = 1.0
  baseline bad packets = 50
  confirmation bad     = 57

UNANIMITY_3_OF_3
  confirmation bad     = 0
  confirmation recall  = 0.833333...
  baseline bad packets = 12
  baseline recall      = 0.8
```

So majority preserves utility but not safety; unanimity improves safety but achieves it partly by suppressing valid inference, and shared unanimous errors still exist on the known baseline.

## The critical negative result

All three ensemble controls achieved on the new 120,000-case local admission exam:

```text
false accepted derivations = 0
positive acceptance recall = 1.0
```

Yet all failed the recursive graph gate.

Therefore:

> A generic admission control can look perfect on a large static local test and still fail when the learned system generates the distribution of packets that the control must judge next.

This is stronger than the PRIMITIVE-2B finding. The problem is not only classifier error. It is **correlated error plus endogenous distribution shift under self-consumption**.

## What the controls taught us

### Swap consistency

Symmetry checks are not sufficient. They can reject valid DERIVE-state transformations and can also ratify a wrong fact when the learned error itself is symmetric.

### 2-of-3 majority

The three models are not independent epistemic witnesses. Shared architecture and training distribution create correlated error modes. Two models can agree on the same wrong derived fact.

### 3-of-3 unanimity

Unanimity is not proof. It reduced corruption on the fresh confirmation suite to zero, but dropped valid recall to 0.8333 and still admitted 12 bad packets on the known baseline.

### Majority + swap

Combining two imperfect generic checks compounded their recall cost without eliminating corruption.

## Architectural implication

The next layer cannot be only another vote, confidence threshold, or symmetry check.

A recursive packet-native reasoner needs a mechanism that changes the epistemic status of generated packets themselves, for example by separating:

```text
PROPOSED
VERIFIED
COMMITTED
REVOKED
```

and by carrying enough derivational evidence to independently validate or roll back a conclusion after downstream use.

That is a new hypothesis, not authorized by PRIMITIVE-2C.

The next independently judgeable unit should therefore be:

```text
PRIMITIVE-2D — PROOF-CARRYING / REVERSIBLE DERIVATIONS
```

with the question:

> Can generated packets carry generic, machine-checkable derivation evidence that prevents false conclusions from becoming committed cognitive state, while preserving full recall and permitting rollback when a parent is invalidated?

PRIMITIVE-2C does not claim that this will work. It establishes that the simpler generic admission controls tested here are insufficient.
