# PRIMITIVE-2C Method

1. Bind the exact three frozen PRIMITIVE-2A models by SHA-256.
2. Bind the exact PRIMITIVE-2B baseline graphs/results by SHA-256.
3. Freeze four relation-agnostic admission controls before scoring.
4. Freeze an independent 120,000-case local pair exam and 40 recursive graphs on a new disjoint reference pool.
5. Score every control without retraining, threshold tuning, model selection, or task-specific logic.
6. Require zero bad packets and full recall on both baseline and confirmation graphs.
7. Record control cost in model-pair evaluations and candidate rejections.
8. Preserve a performance-only frontier-scheduling patch and verify semantic equivalence against all swap results scored before the patch.
