from __future__ import annotations
import argparse, hashlib, itertools, json, math, time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)
BASE=Path('/mnt/data')
ROOT=BASE/'PRIMITIVE-2C'; FIX=ROOT/'PRIMITIVE-2C_FIXTURES'; RES=ROOT/'results'; RES.mkdir(exist_ok=True)
P2A=BASE/'PRIMITIVE-2A'; P2B=BASE/'PRIMITIVE-2B'
ACTS=['ASSERT','DERIVE']; RELS=['BEFORE','PART_OF','ASSIGNED_TO','LOCATED_IN']; A2I={x:i for i,x in enumerate(ACTS)}; R2I={x:i for i,x in enumerate(RELS)}
RULES={'BEFORE|BEFORE':'BEFORE','PART_OF|PART_OF':'PART_OF','PART_OF|ASSIGNED_TO':'ASSIGNED_TO'}
bitpos=torch.arange(24,dtype=torch.long)

def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def hfile(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def refs_to_bits(refs): return ((refs.unsqueeze(-1)>>bitpos.to(refs.device))&1).float()

class BindingComposer(nn.Module):
    def __init__(self):
        super().__init__(); self.refenc=nn.Sequential(nn.Linear(24,32),nn.ReLU(),nn.Linear(32,32),nn.ReLU()); self.body=nn.Sequential(nn.Linear(332,128),nn.ReLU(),nn.Linear(128,128),nn.ReLU()); self.bind=nn.Linear(128,3); self.rel=nn.Linear(128,5); self.ssel=nn.Linear(128,4); self.osel=nn.Linear(128,4)
    def forward(self,acts,rels,refs):
        e=self.refenc(refs_to_bits(refs)); diffs=torch.cat([(e[:,i]-e[:,j]).abs() for i,j in itertools.combinations(range(4),2)],1); meta=torch.cat([F.one_hot(acts[:,0],2).float(),F.one_hot(acts[:,1],2).float(),F.one_hot(rels[:,0],4).float(),F.one_hot(rels[:,1],4).float()],1); h=self.body(torch.cat([e.flatten(1),diffs,meta],1)); return self.bind(h),self.rel(h),self.ssel(h),self.osel(h)

def verify_freeze():
    fr=json.loads((ROOT/'PRIMITIVE-2C_FREEZE.json').read_text())
    for rec in fr['files']:
        p=ROOT/rec['name']; got=hfile(p)
        if got!=rec['sha256']: raise RuntimeError(f'frozen file changed: {rec["name"]}')
    for rel,sha in fr['baseline_files'].items():
        p=P2B/rel; got=hfile(p)
        if got!=sha: raise RuntimeError(f'baseline file changed: {rel}')
    for seed,sha in fr['parent_model_hashes'].items():
        p=P2A/'models'/f'M2_seed_{seed}.pt'; got=hfile(p)
        if got!=sha: raise RuntimeError(f'model changed: {seed}')
    return fr

def load_models():
    out={}
    for seed in (13,29,61):
        m=BindingComposer(); m.load_state_dict(torch.load(P2A/'models'/f'M2_seed_{seed}.pt',map_location='cpu',weights_only=True)); m.eval(); out[seed]=m
    return out

def semantic_candidates(model,acts,rels,refs):
    with torch.no_grad(): outs=model(acts,rels,refs); pb,pr,ps,po=[x.argmax(-1) for x in outs]
    valid=(pb!=0)&(pr!=4)
    slots=refs
    s=slots.gather(1,ps.unsqueeze(1)).squeeze(1); o=slots.gather(1,po.unsqueeze(1)).squeeze(1)
    cand=torch.stack([s,pr,o],1).long(); cand[~valid]=-1
    return cand, valid

def majority(cands):
    # cands list 3 tensors [B,3], -1 invalid
    a,b,c=cands; va=(a[:,0]>=0); vb=(b[:,0]>=0); vc=(c[:,0]>=0)
    ab=va&vb&(a==b).all(1); ac=va&vc&(a==c).all(1); bc=vb&vc&(b==c).all(1)
    out=torch.full_like(a,-1); mask=ab|ac|bc
    out[ab|ac]=a[ab|ac]; onlybc=(~(ab|ac))&bc; out[onlybc]=b[onlybc]
    return out,mask

def unanimity(cands):
    a,b,c=cands; mask=(a[:,0]>=0)&(b[:,0]>=0)&(c[:,0]>=0)&(a==b).all(1)&(a==c).all(1); out=torch.full_like(a,-1); out[mask]=a[mask]; return out,mask

def control_candidates(mech,models,acts,rels,refs,seed=None):
    """Return accepted semantic candidates [B,3], accepted mask, any-positive mask, model pair eval count."""
    B=len(acts)
    if mech=='BASELINE_SINGLE':
        c,v=semantic_candidates(models[seed],acts,rels,refs); return c,v,v.clone(),B
    if mech=='SWAP_CONSISTENCY':
        c,v=semantic_candidates(models[seed],acts,rels,refs)
        acts2=acts[:,[1,0]]; rels2=rels[:,[1,0]]; refs2=refs[:,[2,3,0,1]]
        cs,vs=semantic_candidates(models[seed],acts2,rels2,refs2)
        mask=v&vs&(c==cs).all(1); out=torch.full_like(c,-1); out[mask]=c[mask]; return out,mask,v|vs,2*B
    if mech in ('MAJORITY_2_OF_3','UNANIMITY_3_OF_3','MAJORITY_PLUS_SWAP'):
        cs=[]; anypos=torch.zeros(B,dtype=torch.bool)
        for m in models.values():
            c,v=semantic_candidates(m,acts,rels,refs); cs.append(c); anypos|=v
        if mech=='MAJORITY_2_OF_3': out,mask=majority(cs); return out,mask,anypos,3*B
        if mech=='UNANIMITY_3_OF_3': out,mask=unanimity(cs); return out,mask,anypos,3*B
        # majority + swapped majority
        mf,mfmask=majority(cs)
        acts2=acts[:,[1,0]]; rels2=rels[:,[1,0]]; refs2=refs[:,[2,3,0,1]]
        css=[]; anypos2=torch.zeros(B,dtype=torch.bool)
        for m in models.values():
            c,v=semantic_candidates(m,acts2,rels2,refs2); css.append(c); anypos2|=v
        ms,msmask=majority(css); mask=mfmask&msmask&(mf==ms).all(1); out=torch.full_like(mf,-1); out[mask]=mf[mask]; return out,mask,anypos|anypos2,6*B
    raise KeyError(mech)

def expected_local(labels,refs):
    pos=labels[:,0]!=0; exp=torch.full((len(labels),3),-1,dtype=torch.long)
    s=refs.gather(1,labels[:,2:3].long()).squeeze(1); o=refs.gather(1,labels[:,3:4].long()).squeeze(1)
    exp[:,0]=s; exp[:,1]=labels[:,1].long(); exp[:,2]=o; exp[~pos]=-1
    return exp,pos

def local_exam(mech,models,npz_path,seed=None,batch=8192):
    d=np.load(npz_path); acts_np=d['acts']; rels_np=d['rels']; refs_np=d['refs']; labels_np=d['labels']; N=len(acts_np)
    pos_total=0; true_accept=0; false_accept=0; rejected_true=0; accepted_total=0; model_evals=0; any_positive_pairs=0
    examples=[]
    for st in range(0,N,batch):
        en=min(N,st+batch); acts=torch.from_numpy(acts_np[st:en].astype(np.int64)); rels=torch.from_numpy(rels_np[st:en].astype(np.int64)); refs=torch.from_numpy(refs_np[st:en].astype(np.int64)); labels=torch.from_numpy(labels_np[st:en].astype(np.int64))
        out,mask,anypos,evals=control_candidates(mech,models,acts,rels,refs,seed); model_evals+=evals; any_positive_pairs+=int(anypos.sum())
        exp,pos=expected_local(labels,refs); exact=mask&(out==exp).all(1); false=mask&(~(out==exp).all(1)); miss=pos&(~exact)
        pos_total+=int(pos.sum()); true_accept+=int(exact.sum()); false_accept+=int(false.sum()); rejected_true+=int(miss.sum()); accepted_total+=int(mask.sum())
        if len(examples)<10:
            bad=torch.nonzero(false|miss,as_tuple=False).flatten()
            for j in bad[:10-len(examples)].tolist(): examples.append({'index':st+j,'positive_label':bool(pos[j]),'accepted':bool(mask[j]),'expected':exp[j].tolist(),'output':out[j].tolist()})
    return {'cases':N,'positive_cases':pos_total,'accepted_cases':accepted_total,'true_positive_accepts':true_accept,'false_accepted_derivations':false_accept,'missed_positive_derivations':rejected_true,'positive_accept_recall':true_accept/pos_total if pos_total else 1.0,'admission_precision':true_accept/(true_accept+false_accept) if true_accept+false_accept else 1.0,'model_pair_evaluations':model_evals,'any_raw_positive_pairs':any_positive_pairs,'error_examples':examples}

def oracle_pair(l,r):
    ls,lr,lo=l; rs,rr,ro=r; k=f'{RELS[lr]}|{RELS[rr]}'
    if lo==rs and k in RULES: return (ls,R2I[RULES[k]],ro)
    k=f'{RELS[rr]}|{RELS[lr]}'
    if ro==ls and k in RULES: return (rs,R2I[RULES[k]],lo)
    return None

def oracle_closure(fx):
    facts={(int(p['subject']),R2I[p['relation']],int(p['object'])) for p in fx['inputs']}
    while True:
        arr=list(facts); new=set()
        for l in arr:
            for r in arr:
                x=oracle_pair(l,r)
                if x is not None and x not in facts:new.add(x)
        if not new:return facts
        facts|=new

def count_strings(x):
    if isinstance(x,str): return 1
    if isinstance(x,(list,tuple)): return sum(count_strings(v) for v in x)
    if isinstance(x,dict): return sum(count_strings(k)+count_strings(v) for k,v in x.items())
    return 0

def infer_graph(mech,models,fx,seed=None):
    gold=oracle_closure(fx); packets=[[int(p['id']),A2I[p['act']],int(p['subject']),R2I[p['relation']],int(p['object']),1000] for p in fx['inputs']]; audit=[]
    for p in packets: audit.append({'bad':(p[2],p[3],p[4]) not in gold,'tainted':False,'parents':[]})
    next_ref=max(p[0] for p in packets)+1; existing={(p[2],p[3],p[4]) for p in packets}; trajectory=[[0,[list(p) for p in packets]]]
    first_corruption=None; bad_by_round=[]; taint_by_round=[]; model_evals=0; pair_count=0; accepted_pair_decisions=0; raw_positive_pair_decisions=0
    frontier=list(range(len(packets)))
    for rnd in range(1,int(fx.get('max_rounds',32))+1):
        n=len(packets)
        if n<2 or not frontier: trajectory.append([rnd,[]]); terminated=True; break
        pkt=torch.tensor(packets,dtype=torch.long)
        # Semantics-preserving frontier scheduler: evaluate each ordered packet pair
        # when the later-added endpoint first enters state. Frozen deterministic
        # models/control decisions make re-evaluating old-old pairs redundant.
        fset=set(frontier); pairs=[]
        for i in range(n):
            for j in range(n):
                if i==j: continue
                if i in fset or j in fset: pairs.append((i,j))
        ii=torch.tensor([x[0] for x in pairs],dtype=torch.long); jj=torch.tensor([x[1] for x in pairs],dtype=torch.long); pair_count+=len(ii)
        candidate_info={}; chunk=4096
        for st in range(0,len(ii),chunk):
            iix=ii[st:st+chunk]; jjx=jj[st:st+chunk]; left=pkt[iix]; right=pkt[jjx]; acts=torch.stack([left[:,1],right[:,1]],1); rels=torch.stack([left[:,3],right[:,3]],1); refs=torch.stack([left[:,2],left[:,4],right[:,2],right[:,4]],1)
            cand,mask,anypos,evals=control_candidates(mech,models,acts,rels,refs,seed); model_evals+=evals; accepted_pair_decisions+=int(mask.sum()); raw_positive_pair_decisions+=int(anypos.sum())
            idx=torch.nonzero(mask,as_tuple=False).flatten()
            for k in idx.tolist():
                fact=tuple(int(x) for x in cand[k].tolist())
                if fact in existing: continue
                li=int(iix[k]); ri=int(jjx[k]); ptaint=(audit[li]['bad'] or audit[li]['tainted'] or audit[ri]['bad'] or audit[ri]['tainted']); pair=(packets[li][0],packets[ri][0]); rec=candidate_info.get(fact)
                if rec is None: candidate_info[fact]={'taint_any':bool(ptaint),'parents':[pair]}
                else:
                    rec['taint_any']=rec['taint_any'] or bool(ptaint)
                    if len(rec['parents'])<8: rec['parents'].append(pair)
        if not candidate_info: trajectory.append([rnd,[]]); terminated=True; break
        new=[]; rb=0; rt=0; new_indices=[]
        for fact in sorted(candidate_info):
            s,r,o=fact; p=[next_ref,A2I['DERIVE'],s,r,o,1000]; next_ref+=1; info=candidate_info[fact]; bad=fact not in gold; tainted=bool(info['taint_any']); packets.append(p); existing.add(fact); new.append(p); new_indices.append(len(packets)-1); audit.append({'bad':bad,'tainted':tainted,'parents':info['parents']}); rb+=int(bad); rt+=int(tainted)
        frontier=new_indices
        bad_by_round.append(rb); taint_by_round.append(rt)
        if rb and first_corruption is None:first_corruption=rnd
        trajectory.append([rnd,new])
    else: terminated=False
    pred={(p[2],p[3],p[4]) for p in packets}; tp=len(pred&gold); fp=len(pred-gold); fn=len(gold-pred); bad=sum(a['bad'] for a in audit); tainted=sum(a['tainted'] for a in audit); primary=sum(a['bad'] and not a['tainted'] for a in audit)
    return {'fixture_id':fx['fixture_id'],'family':fx.get('family',fx.get('group')),'scale':fx.get('scale',0),'replicate':fx.get('replicate',0),'input_packets':len(fx['inputs']),'final_packets':len(packets),'gold_fact_count':len(gold),'precision':1.0 if tp+fp==0 else tp/(tp+fp),'recall':1.0 if tp+fn==0 else tp/(tp+fn),'exact_match':pred==gold,'false_positive_facts':fp,'false_negative_facts':fn,'bad_packet_count':int(bad),'primary_bad_packet_count':int(primary),'tainted_packet_count':int(tainted),'first_corruption_round':first_corruption,'bad_packets_by_round':bad_by_round,'tainted_packets_by_round':taint_by_round,'rounds':len(trajectory)-1,'ordered_pair_decisions':pair_count,'model_pair_evaluations':model_evals,'accepted_pair_decisions':accepted_pair_decisions,'raw_positive_pair_decisions':raw_positive_pair_decisions,'rejected_positive_pair_decisions':raw_positive_pair_decisions-accepted_pair_decisions,'terminated':bool(terminated),'numeric_trace_string_count':count_strings(trajectory),'trajectory_sha256':hashlib.sha256(json.dumps(trajectory,separators=(',',':')).encode()).hexdigest()}

def graph_exam(mech,models,graph_path,seed=None):
    gd=json.loads(Path(graph_path).read_text()); rows=[infer_graph(mech,models,fx,seed) for fx in gd['fixtures']]
    return {'graph_count':len(rows),'exact_graph_rate':sum(r['exact_match'] for r in rows)/len(rows),'min_precision':min(r['precision'] for r in rows),'min_recall':min(r['recall'] for r in rows),'termination_rate':sum(r['terminated'] for r in rows)/len(rows),'bad_packet_count':sum(r['bad_packet_count'] for r in rows),'primary_bad_packet_count':sum(r['primary_bad_packet_count'] for r in rows),'tainted_packet_count':sum(r['tainted_packet_count'] for r in rows),'false_positive_facts':sum(r['false_positive_facts'] for r in rows),'false_negative_facts':sum(r['false_negative_facts'] for r in rows),'graphs_corrupted':sum(not r['exact_match'] for r in rows),'model_pair_evaluations':sum(r['model_pair_evaluations'] for r in rows),'accepted_pair_decisions':sum(r['accepted_pair_decisions'] for r in rows),'raw_positive_pair_decisions':sum(r['raw_positive_pair_decisions'] for r in rows),'numeric_only':all(r['numeric_trace_string_count']==0 for r in rows),'rows':rows}

def run_variant(mech,seed=None):
    fr=verify_freeze(); models=load_models(); t=time.time(); local=local_exam(mech,models,FIX/'CONFIRMATION_LOCAL_EXAM.npz',seed); base=graph_exam(mech,models,P2B/'PRIMITIVE-2B_FIXTURES'/'RECURSIVE_STABILITY_GRAPHS.json',seed); conf=graph_exam(mech,models,FIX/'CONFIRMATION_GRAPHS.json',seed)
    gate=(base['exact_graph_rate']==1 and conf['exact_graph_rate']==1 and base['min_precision']==1 and base['min_recall']==1 and conf['min_precision']==1 and conf['min_recall']==1 and base['bad_packet_count']==0 and conf['bad_packet_count']==0 and base['tainted_packet_count']==0 and conf['tainted_packet_count']==0 and base['termination_rate']==1 and conf['termination_rate']==1 and local['false_accepted_derivations']==0 and local['positive_accept_recall']==1 and base['numeric_only'] and conf['numeric_only'])
    name=mech+(f'_SEED_{seed}' if seed is not None else '')
    out={'experiment':'PRIMITIVE-2C','version':'0.1.0','variant':name,'mechanism':mech,'seed':seed,'freeze_sha256':fr['freeze_sha256'],'elapsed_seconds':time.time()-t,'success_gate_pass':bool(gate),'local_confirmation':local,'baseline_graphs':base,'confirmation_graphs':conf}; out['result_sha256']=hashlib.sha256(canon(out).encode()).hexdigest(); (RES/f'{name}_RESULT.json').write_text(json.dumps(out,indent=2)); print(json.dumps({'variant':name,'pass':gate,'local_false_accepts':local['false_accepted_derivations'],'local_positive_recall':local['positive_accept_recall'],'baseline_exact':base['exact_graph_rate'],'baseline_precision':base['min_precision'],'baseline_recall':base['min_recall'],'baseline_bad':base['bad_packet_count'],'baseline_tainted':base['tainted_packet_count'],'confirmation_exact':conf['exact_graph_rate'],'confirmation_precision':conf['min_precision'],'confirmation_recall':conf['min_recall'],'confirmation_bad':conf['bad_packet_count'],'confirmation_tainted':conf['tainted_packet_count'],'model_pair_evals':base['model_pair_evaluations']+conf['model_pair_evaluations']},indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--mechanism',required=True); ap.add_argument('--seed',type=int); a=ap.parse_args(); run_variant(a.mechanism,a.seed)
