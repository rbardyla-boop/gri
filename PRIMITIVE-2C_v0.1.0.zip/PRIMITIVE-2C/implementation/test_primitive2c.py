#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/'results'/'PRIMITIVE-2C_RESULTS.json').read_text())
assert r['terminal_verdict']=='NO_GENERIC_CONTROL_SUCCEEDS'
assert r['all_preregistered_controls_failed'] is True
assert all(v=='PASS' for v in r['frontier_semantic_equivalence'].values())
for k in ('MAJORITY_2_OF_3','UNANIMITY_3_OF_3','MAJORITY_PLUS_SWAP'):
    assert r['candidate_mechanisms'][k]['success_gate_pass'] is False
assert r['scientific_observations']['all_ensemble_controls_had_zero_false_accepts_on_confirmation_local_exam'] is True
assert r['scientific_observations']['all_ensemble_controls_had_full_positive_recall_on_confirmation_local_exam'] is True
print('PRIMITIVE_2C_TEST_PASS')
