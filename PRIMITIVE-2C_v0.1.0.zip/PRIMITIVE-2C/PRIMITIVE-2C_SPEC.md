# PRIMITIVE-2C — RECURSIVE ERROR CONTROL

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `5ccf22ff18ab3a61b935bb7cc57b220dc35457e0fc88ee833b44b6920ed753a2`  
**Confirmation pool SHA-256:** `f8461558cf49dff91dce363390d563a78fddd1f872df532781aed7a66da02eea`  
**Confirmation graph SHA-256:** `25411d9692d57708c94c4c499ff5d486afddcf830129129bc6d82731c696f1e4`

## Question

> Can generic error-control mechanisms drive recursive corruption to zero without destroying valid inference recall or quietly reintroducing symbolic task rules?

## Frozen models

The exact three PRIMITIVE-2A models are reused without retraining or tuning.

```text
seed 13  6a0849d63effdb2bd96017f46597f1a341ebaf3fa898bfc5a881c726f5895909
seed 29  670bde43c833385a6d24e919048ad27279eb5934c1752c471c362b21ae6c8309
seed 61  6f43f948703e443a46ae8df584b79ef64f04af8aeda0a4d9eb1f0ee4f5363ce0
```

## Two evaluation surfaces

1. **Baseline reproduction:** the exact 47 PRIMITIVE-2B recursive graphs.
2. **Independent confirmation:** 40 newly frozen graphs and 120,000 local pair cases on references disjoint from PRIMITIVE-2A and PRIMITIVE-2B.

A control does not pass by fixing only the known PRIMITIVE-2B failures.

## Generic controls

Controls may inspect only model outputs, model identity, ordered-pair identity, and derivation provenance. They may not inspect relation names or fixture identity when deciding admission.

### SWAP_CONSISTENCY
Accept a proposed fact only when reversing the ordered parent pair yields the exact same semantic fact.

### MAJORITY_2_OF_3
Accept a fact for an ordered parent pair only when at least two frozen models independently propose the exact same fact.

### UNANIMITY_3_OF_3
Accept only unanimous exact agreement.

### MAJORITY_PLUS_SWAP
Require both 2-of-3 model agreement and swapped-pair agreement.

## Safety/utility gate

A successful control must simultaneously achieve, on baseline and independent confirmation graphs:

```text
precision = 1.0
recall = 1.0
exact graph match = 1.0
bad packets = 0
tainted descendants = 0
termination = 1.0
```

On the independent local exam it must additionally have:

```text
false accepted derivations = 0
positive derivation acceptance recall = 1.0
```

No post-score threshold tuning is authorized.
