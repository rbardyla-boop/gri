# PRIMITIVE-2J — HYPOTHESIS GENERATION

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `861c43a4e5cfb116373ae46e2b55a8028d7a412b431bf018687ef01e61ffc2a8`  
**Grammar SHA-256:** `d965431c338ea98d24ef7f3def724e7c8d85e993867611dbb6a7d405f597e951`  
**World-set SHA-256:** `22e09714bedc13cf22f980e542a275cce895626ab011dde0b64125bafca32223`

## Question

> Given observations that are insufficiently explained by a unique causal model, can a machine generate multiple compact machine-native hypotheses that fit the observations, preserve the hidden world's possible behavior, and make meaningfully different predictions?

## Frozen hypothesis language

Five anonymous binary variables:

```text
V0 V1 V2  = exogenous roots
V3 V4     = derived
```

A causal hypothesis is the numeric program:

```text
[p3a,p3b,op3,p4a,p4b,op4]
```

Operators:

```text
1 AND
2 OR
3 XOR
4 XNOR
```

The complete grammar contains 288 two-equation programs.

## Passive ambiguity is mandatory

Every frozen world was generated so the supplied passive observations leave:

```text
2–8 distinct interventional behavior classes
```

consistent with the data.

The generator is therefore not permitted to convert underdetermination into fake certainty.

## Primary generator

`BEHAVIORAL_FRONTIER`:

1. enumerate all grammar programs exactly matching every passive observation;
2. compute each surviving program's complete allowed one-shot interventional behavior signature;
3. partition programs by identical signatures;
4. emit one deterministic representative per signature.

This represents every behaviorally distinct live explanation without emitting redundant programs that no allowed experiment could distinguish.

## Experimental distinguishability

Two generated hypotheses are considered experimentally distinguishable only if at least one allowed:

```text
do(variable=value)
+
observe(variable)
```

produces different predictions.

The experimenter separately checks the minimum discriminating intervention cost for every generated pair.

## Strict pass

Across 192 frozen worlds:

```text
all emitted hypotheses fit passive observations
true hidden behavior class represented in every world
at least two competing behavior classes retained
frontier class count exactly matches exhaustive experimenter version space
every pair of frontier hypotheses experimentally distinguishable
deterministic replay
```

## Scope

PRIMITIVE-2J v0.1.0 demonstrates search-based hypothesis generation inside a frozen finite causal grammar.

It does not yet demonstrate:

```text
learned hypothesis generation
open-ended grammar invention
continuous variables
noise
latent-variable discovery
novel operator invention
```
