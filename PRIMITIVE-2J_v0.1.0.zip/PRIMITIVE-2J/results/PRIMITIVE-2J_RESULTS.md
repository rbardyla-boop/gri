# PRIMITIVE-2J Results

**Terminal verdict:** `PARTIAL`  
**Exact deterministic replay:** `PASS`  
**Worlds:** 192  
**Behavioral-frontier class count exact:** `True`

| Generator | Passive fit | Hidden behavior covered | Pairwise reachable-distinguishable | Mean hypotheses | Max hypotheses |
|---|---:|---:|---:|---:|---:|
| SINGLE_FIRST_FIT | 192/192 | 41/192 | 192/192 | 1.000 | 1 |
| ALL_CONSISTENT | 192/192 | 192/192 | 182/192 | 4.885 | 8 |
| BEHAVIORAL_FRONTIER | 192/192 | 192/192 | 182/192 | 4.885 | 8 |

## Failure localization

`BEHAVIORAL_FRONTIER` failed the experimental-distinguishability gate in **10/192** worlds.

The surviving hypotheses differ somewhere in the full intervention space, but at least one pair cannot be separated from any currently supplied passive root state using one allowed one-shot intervention.
