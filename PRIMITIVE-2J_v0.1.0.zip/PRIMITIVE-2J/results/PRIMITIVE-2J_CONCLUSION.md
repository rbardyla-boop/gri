# PRIMITIVE-2J Conclusion

**Terminal verdict:** `PARTIAL`

## What succeeded

`BEHAVIORAL_FRONTIER` and `ALL_CONSISTENT` both achieved:

```text
passive consistency:            192/192
hidden true behavior coverage:  192/192
generated live behavior classes: 2–8 per world
frontier class-count replay:    exact 192/192
deterministic replay:           PASS
```

The single-fit baseline preserved the hidden true behavior class in only:

```text
41/192
```

worlds.

That demonstrates why choosing one convenient explanation from underdetermined evidence is not an adequate hypothesis-generation policy.

## What failed

The strict gate also required every pair of generated behavior classes to be experimentally distinguishable from the states actually available to the agent using one one-shot intervention.

`BEHAVIORAL_FRONTIER` passed this in:

```text
182/192
```

worlds and failed in:

```text
10/192
```

worlds.

Those failures are not cases where the hypotheses are behaviorally identical.

They differ in the complete intervention space.

The problem is that the distinguishing prediction requires a root configuration that is not among the currently supplied passive states, and one allowed intervention is insufficient to prepare that state.

Therefore:

> Different causal hypotheses can be genuinely distinct yet experimentally indistinguishable from the system's current reachable state.

## Supported claim

Within the frozen finite grammar:

> A machine can generate and preserve all behaviorally distinct causal hypotheses consistent with underdetermined passive observations, without collapsing uncertainty to a single explanation.

The stronger claim:

> every generated alternative is immediately experimentally distinguishable under the current action repertoire

is not supported.

## Architectural implication

Hypothesis generation and experiment design are not enough by themselves.

The machine also needs to reason about **experimental reachability**:

```text
hypothesis difference
        ≠
currently executable discriminating experiment
```

Sometimes science requires first preparing the system into a state where the hypotheses disagree.

## New largest gap

The next question is therefore:

> Can the machine synthesize a multi-step state-preparation and observation sequence that moves the world into a discriminating configuration at minimum cost?

That should be isolated as a new experiment rather than weakening PRIMITIVE-2J's one-shot gate.
