# PRIMITIVE-2J METHOD

1. Freeze a finite machine-native causal grammar of 288 two-equation binary programs.
2. Generate 192 hidden causal worlds.
3. Supply passive observations only until 2–8 distinct full interventional behavior classes remain consistent.
4. Withhold the hidden true program, hidden true behavior class, future intervention outcomes, and any TRUE/FALSE hypothesis labels.
5. Compare:
   - SINGLE_FIRST_FIT
   - ALL_CONSISTENT
   - BEHAVIORAL_FRONTIER
6. Require every emitted hypothesis to fit every passive observation exactly.
7. Score whether the hidden true interventional behavior class remains represented.
8. For BEHAVIORAL_FRONTIER, emit one deterministic representative for every distinct full one-shot interventional behavior signature.
9. Separately ask whether every generated pair can actually be discriminated from one of the passive states available in that world using one allowed intervention plus one observation.
10. Preserve a failure when hypotheses differ globally but their distinguishing state is not reachable under the current one-shot experimental setup.
11. Re-run the exact scorer and require byte-identical result JSON.

The distinction between global behavioral difference and experimentally reachable difference is intentional and is the reason PRIMITIVE-2J remains PARTIAL.
