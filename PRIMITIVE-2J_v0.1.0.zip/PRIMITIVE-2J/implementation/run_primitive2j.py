from pathlib import Path
import json, hashlib, itertools, csv, os, zipfile, subprocess, sys

ROOT=Path("/mnt/data/PRIMITIVE-2J")
FIX=ROOT/"PRIMITIVE-2J_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)

def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2J_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"], rec["name"]

grammar=json.loads((ROOT/"PRIMITIVE-2J_GRAMMAR.json").read_text())
worlds=json.loads((FIX/"HYPOTHESIS_WORLDS.json").read_text())["worlds"]
programs=grammar["programs"]

OPS={1:"AND",2:"OR",3:"XOR",4:"XNOR"}

def op_eval(code,a,b):
    if code==1:return a & b
    if code==2:return a | b
    if code==3:return a ^ b
    if code==4:return 1-(a ^ b)
    raise ValueError(code)

def simulate(code,roots,intervention=None):
    vals=[None]*5
    vals[0],vals[1],vals[2]=roots
    if intervention is not None and intervention[0] in (0,1,2):
        vals[intervention[0]]=intervention[1]
    p3a,p3b,op3,p4a,p4b,op4=code
    vals[3]=intervention[1] if intervention is not None and intervention[0]==3 else op_eval(op3,vals[p3a],vals[p3b])
    vals[4]=intervention[1] if intervention is not None and intervention[0]==4 else op_eval(op4,vals[p4a],vals[p4b])
    return tuple(int(x) for x in vals)

all_root_states=list(itertools.product([0,1],repeat=3))
all_interventions=[(v,val) for v in range(5) for val in (0,1)]

# Full signatures and classes independently recomputed.
full_signature={}
for p in programs:
    sig=[]
    for roots in all_root_states:
        for iv in all_interventions:
            sig.extend(simulate(p["code"],roots,iv))
    full_signature[p["program_id"]]=tuple(sig)
sig_to_class={}
for p in programs:
    sig=full_signature[p["program_id"]]
    if sig not in sig_to_class:
        sig_to_class[sig]=len(sig_to_class)
behavior_class={p["program_id"]:sig_to_class[full_signature[p["program_id"]]] for p in programs}

def consistent_programs(world):
    out=[]
    for p in programs:
        ok=True
        for obs in world["passive_observations"]:
            if simulate(p["code"],tuple(obs["root_assignment"])) != tuple(obs["observed_values"]):
                ok=False;break
        if ok:out.append(p["program_id"])
    return out

def generate(world,name):
    cons=consistent_programs(world)
    if name=="SINGLE_FIRST_FIT":
        return [cons[0]]
    if name=="ALL_CONSISTENT":
        return cons
    if name=="BEHAVIORAL_FRONTIER":
        reps={}
        for pid in cons:
            c=behavior_class[pid]
            reps.setdefault(c,pid)
        return [reps[c] for c in sorted(reps)]
    raise ValueError(name)

def pair_min_discriminating_cost(world,pid_a,pid_b):
    # Experiments may start from any passively observed root state in this world.
    code_a=programs[pid_a]["code"];code_b=programs[pid_b]["code"]
    best=None
    for obs in world["passive_observations"]:
        roots=tuple(obs["root_assignment"])
        for iv in all_interventions:
            pa=simulate(code_a,roots,iv);pb=simulate(code_b,roots,iv)
            ic=int(world["intervention_costs"][f"{iv[0]}:{iv[1]}"])
            for ov in range(5):
                if pa[ov]==pb[ov]:continue
                c=ic+int(world["observation_costs"][str(ov)])
                cand=(c,iv[0],iv[1],ov)
                if best is None or cand<best:
                    best=cand
    return best

generator_names=["SINGLE_FIRST_FIT","ALL_CONSISTENT","BEHAVIORAL_FRONTIER"]
world_results=[]

for w in worlds:
    true_pid=w["hidden_true_program_id"]
    true_class=behavior_class[true_pid]
    cons=consistent_programs(w)
    variants={}
    for name in generator_names:
        out=generate(w,name)
        out_classes={behavior_class[p] for p in out}
        passive_ok=all(p in cons for p in out)
        true_cov=true_class in out_classes
        pair_costs=[]
        pairwise_all=True
        for a,b in itertools.combinations(out,2):
            m=pair_min_discriminating_cost(w,a,b)
            if m is None:
                pairwise_all=False
            else:
                pair_costs.append(m[0])
        variants[name]={
            "generated_program_ids":out,
            "generated_hypothesis_count":len(out),
            "generated_behavior_class_count":len(out_classes),
            "passive_consistency":passive_ok,
            "true_behavior_class_covered":true_cov,
            "pairwise_distinguishable":pairwise_all,
            "pair_count":len(list(itertools.combinations(out,2))),
            "min_pairwise_discriminating_cost":min(pair_costs) if pair_costs else None,
            "max_pairwise_discriminating_cost":max(pair_costs) if pair_costs else None,
            "mean_pairwise_discriminating_cost":(sum(pair_costs)/len(pair_costs)) if pair_costs else None,
        }
    world_results.append({
        "world_id":w["world_id"],
        "true_program_id":true_pid,
        "true_behavior_class":true_class,
        "experimenter_consistent_program_count":len(cons),
        "experimenter_behavior_class_count":len({behavior_class[p] for p in cons}),
        "variants":variants
    })

summary={}
for name in generator_names:
    rs=[w["variants"][name] for w in world_results]
    summary[name]={
        "world_count":len(rs),
        "passive_consistency_worlds":sum(r["passive_consistency"] for r in rs),
        "true_behavior_coverage_worlds":sum(r["true_behavior_class_covered"] for r in rs),
        "pairwise_distinguishable_worlds":sum(r["pairwise_distinguishable"] for r in rs),
        "mean_generated_hypotheses":sum(r["generated_hypothesis_count"] for r in rs)/len(rs),
        "max_generated_hypotheses":max(r["generated_hypothesis_count"] for r in rs),
        "min_generated_behavior_classes":min(r["generated_behavior_class_count"] for r in rs),
        "max_generated_behavior_classes":max(r["generated_behavior_class_count"] for r in rs),
    }

frontier_exact=all(
    w["variants"]["BEHAVIORAL_FRONTIER"]["generated_behavior_class_count"]==w["experimenter_behavior_class_count"]
    for w in world_results
)

front=summary["BEHAVIORAL_FRONTIER"]
if (
    front["passive_consistency_worlds"]==192
    and front["true_behavior_coverage_worlds"]==192
    and front["min_generated_behavior_classes"]>=2
    and front["pairwise_distinguishable_worlds"]==192
    and frontier_exact
):
    terminal="HYPOTHESIS_GENERATION_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif front["true_behavior_coverage_worlds"]>0:
    terminal="PARTIAL"
else:
    terminal="HYPOTHESIS_GENERATION_INSUFFICIENT"

results={
    "experiment":"PRIMITIVE-2J",
    "version":"0.1.0",
    "freeze_sha256":freeze["freeze_sha256"],
    "terminal_verdict":terminal,
    "world_count":len(world_results),
    "frontier_exact_behavior_class_count_all_worlds":frontier_exact,
    "generator_summary":summary,
    "world_results":world_results,
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2J_RESULTS.json").write_text(json.dumps(results,indent=2))

print("PRIMITIVE-2J scored")
print("terminal:",terminal)
for name,s in summary.items():
    print(name,json.dumps(s,sort_keys=True))