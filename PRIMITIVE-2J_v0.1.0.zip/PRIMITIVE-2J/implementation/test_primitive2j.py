#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2J_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2J_REPLAY_CHECK.json").read_text())
assert r["terminal_verdict"]=="PARTIAL"
assert r["world_count"]==192
assert rp["exact_byte_replay"]=="PASS"
f=r["generator_summary"]["BEHAVIORAL_FRONTIER"]
assert f["passive_consistency_worlds"]==192
assert f["true_behavior_coverage_worlds"]==192
assert f["pairwise_distinguishable_worlds"]==182
assert f["min_generated_behavior_classes"]>=2
assert r["frontier_exact_behavior_class_count_all_worlds"] is True
assert r["generator_summary"]["SINGLE_FIRST_FIT"]["true_behavior_coverage_worlds"]==41
print("PRIMITIVE_2J_TEST_PASS")
