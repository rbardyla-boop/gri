# PRIMITIVE-0 Reference Implementation Declarations

**Declaration version:** 0.1.0  
**Declared before scored execution:** yes  
**Frozen benchmark:** PRIMITIVE-0 v0.1.0

This file declares the first deterministic reference implementations of Candidates A–G. These declarations do not modify the frozen semantic benchmark.

## Shared mechanism

All candidates are exercised by the same deterministic structured rule engine. The engine never emits or reparses natural-language reasoning. It may use only semantic fields recoverable from the candidate representation plus frozen ontology rules and shared environment constants explicitly listed below.

Shared environment constants:

- responder identity: `agent_2`
- ontology rules from `00_ONTOLOGY.json`
- T5 oracle payload from the frozen fixture (explicitly permitted by T5)

No candidate receives hidden ACT, VALUE, ID, CONFIDENCE, or evaluator output fields after encoding.

## Reference wire measurement

Transport metrics use `REFERENCE_JSON_V1_NOT_ENCODING_VERDICT`: canonical compact UTF-8 JSON of the candidate representation. This is a measurement profile only. It is **not** an ENCODING-0 result and does not determine semantic sufficiency.

## Candidate A0

Semantic representation:

`(SUBJECT, RELATION, OBJECT)`

Implementation: three-element tuple. All other evaluator fields are dropped. No semantic repair side channel.

## Candidate B0

Semantic representation:

`(SUBJECT, RELATION, OBJECT, VALUE)`

Implementation: four-element tuple. ACT, ID, and CONFIDENCE are dropped. No semantic repair side channel.

## Candidate C0

Semantic representation:

`(ACT, SUBJECT, RELATION, OBJECT, VALUE)`

Implementation: five-element tuple. ID and CONFIDENCE are dropped. No semantic repair side channel.

This is intentionally the unextended current prior. If source-reference identity proves necessary, that is recorded as a C0 failure and may motivate a later C1 variant; C0 is not silently repaired.

## Candidate D0

Semantic representation:

`(ACT, SUBJECT, RELATION, OBJECT, VALUE, CONFIDENCE)`

Implementation: six-element tuple. Fixture packets without confidence use the explicit sentinel `null`. ID is dropped. No semantic repair side channel.

## Candidate E0

Semantic representation: fixed dense state vector.

Declaration:

- categorical fields: ACT, ID, SUBJECT, RELATION, OBJECT
- encoding: field-specific one-hot blocks
- VALUE: one dedicated scalar component normalized by 1000
- vector dtype: signed integer for categorical components plus rational scalar in the reference Python representation
- vocabulary source: frozen ontology + candidate-visible initial/input fixture symbols + shared responder identity `agent_2`
- required-output fixtures are **not** used to build symbol vocabularies
- unknown symbols map to a frozen `__UNK__` slot
- dimension is computed once from those frozen vocabularies before scoring and then held constant
- external lookup structure: field dictionaries are required and counted

## Candidate F0

Semantic representation: model-specific opaque latent vector.

Declaration:

- latent family: field-factorized opaque codebook latent
- fields encoded: ACT, ID, SUBJECT, RELATION, OBJECT, VALUE
- each categorical field maps to a deterministic 4-float code generated from seed `1701`
- VALUE occupies one float component normalized by 1000
- total latent dimension: 21 float components
- decoder: nearest-code lookup independently within each field block
- producer/consumer implementation: `DeterministicCodebookLatentV1`
- normalization: categorical code vectors are unit length; VALUE is in the final scalar position
- external machinery: five categorical codebooks + decoder are mandatory and counted as an adapter/lookup structure
- cross-family use requires sharing or translating the codebooks; that cost counts against F0

This is not claimed to be a neural latent representation. It is a deterministic reference instance of the frozen `latent vector` candidate family chosen before scoring.

## Candidate G0

Semantic representation: symbolic + latent hybrid.

Declaration:

- symbolic component: C0 `(ACT,SUBJECT,RELATION,OBJECT,VALUE)`
- latent component: full F0 21-component latent over ACT, ID, SUBJECT, RELATION, OBJECT, VALUE
- inference may recover fields from either component
- if both components provide the same field and disagree, the run is invalid rather than silently selecting one
- external machinery: F0 codebooks/decoder are mandatory and counted

G0 is intentionally redundant. The benchmark may determine whether that redundancy buys semantic capability that C0 lacks.

## Shared replay policy

Every candidate/task run is executed twice from a fresh candidate instance using the same fixture seed and declaration constants. Canonical packet/state trajectories must hash identically for deterministic replay PASS.
