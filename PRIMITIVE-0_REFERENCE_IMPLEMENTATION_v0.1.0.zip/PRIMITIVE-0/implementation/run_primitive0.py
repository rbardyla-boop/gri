#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import dataclasses
import hashlib
import json
import math
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "PRIMITIVE-0_FIXTURES"
RESULTS = ROOT / "results"
WIRE_PROFILE = "REFERENCE_JSON_V1_NOT_ENCODING_VERDICT"
RESPONDER_ID = "agent_2"
UNKNOWN = "__UNK__"
LATENT_SEED = 1701

FIELDS = ("act", "id", "subject", "relation", "object")


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return [float(x) for x in value.tolist()]
    if isinstance(value, tuple):
        return [jsonable(x) for x in value]
    if isinstance(value, list):
        return [jsonable(x) for x in value]
    if isinstance(value, dict):
        return {k: jsonable(v) for k, v in value.items()}
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    return value


def wire_bytes(encoded: Any) -> int:
    return len(canonical_json(jsonable(encoded)).encode("utf-8"))


def sha(value: Any) -> str:
    return hashlib.sha256(canonical_json(jsonable(value)).encode("utf-8")).hexdigest()


def verify_fixtures() -> None:
    manifest = json.loads((FIXTURES / "MANIFEST.json").read_text())
    for entry in manifest["files"]:
        p = FIXTURES / entry["name"]
        got = hashlib.sha256(p.read_bytes()).hexdigest()
        if got != entry["sha256"]:
            raise RuntimeError(f"fixture hash mismatch: {entry['name']}")


def load_tasks() -> List[dict]:
    return [json.loads((FIXTURES / f"T{i}_{name}.json").read_text()) for i, name in [
        (1, "RELAY"), (2, "COMPOSE"), (3, "CONTRADICT"), (4, "UPDATE"),
        (5, "REQUEST_RESPONSE"), (6, "MULTISTEP_TRANSFORM"),
        (7, "INFORMATION_COLLISION"), (8, "NOVEL_COMBINATION")
    ]]


def load_ontology() -> dict:
    return json.loads((FIXTURES / "00_ONTOLOGY.json").read_text())


def build_vocab(tasks: Sequence[dict], ontology: dict) -> Dict[str, List[str]]:
    # IMPORTANT: required_output_semantics is intentionally excluded.
    v: Dict[str, set] = {f: {UNKNOWN} for f in FIELDS}
    for act in ontology.get("acts", []):
        v["act"].add(str(act))
    for rel in ontology.get("relations", {}).keys():
        v["relation"].add(str(rel))
    v["subject"].add(RESPONDER_ID)
    for task in tasks:
        for section in ("initial_state", "input_semantics"):
            for packet in task.get(section, []):
                if not isinstance(packet, dict):
                    continue
                # Oracle payloads are evaluator data, not packets; only take known semantic fields.
                for f in FIELDS:
                    if f in packet:
                        v[f].add(str(packet[f]))
    return {k: sorted(vals) for k, vals in v.items()}


@dataclasses.dataclass
class Metrics:
    deterministic_operations: int = 0
    adapter_calls: int = 0
    model_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    wire_bytes_transferred: int = 0
    storage_bytes: int = 0


class Candidate:
    name = "?"
    version = "0"
    representation = ""
    adapters: List[str] = []
    side_channels: List[str] = []
    external_tables: List[str] = []
    future_portability = "UNKNOWN"
    symbolic_compatibility = "UNKNOWN"

    def __init__(self, vocab: Dict[str, List[str]]):
        self.vocab = vocab
        self.metrics = Metrics()

    def encode(self, packet: dict) -> Any:
        raise NotImplementedError

    def decode(self, encoded: Any) -> dict:
        raise NotImplementedError

    def clone_fresh(self):
        return type(self)(self.vocab)

    def encode_counted(self, packet: dict) -> Any:
        x = self.encode(packet)
        self.metrics.adapter_calls += self.adapter_cost_encode()
        self.metrics.wire_bytes_transferred += wire_bytes(x)
        return x

    def decode_counted(self, encoded: Any) -> dict:
        self.metrics.adapter_calls += self.adapter_cost_decode()
        return self.decode(encoded)

    def adapter_cost_encode(self) -> int:
        return 0

    def adapter_cost_decode(self) -> int:
        return 0

    def storage_cost(self, encoded_packets: Sequence[Any]) -> int:
        return sum(wire_bytes(x) for x in encoded_packets)

    def declaration(self) -> dict:
        return {
            "candidate": self.name,
            "version": self.version,
            "representation": self.representation,
            "adapters": list(self.adapters),
            "side_channels": list(self.side_channels),
            "external_tables": list(self.external_tables),
            "future_unknown_structural_portability": self.future_portability,
            "symbolic_engine_compatibility": self.symbolic_compatibility,
        }


class CandidateA(Candidate):
    name, version = "A", "A0"
    representation = "(SUBJECT,RELATION,OBJECT)"
    future_portability = "HIGH_WITH_SYMBOL_DICTIONARY"
    symbolic_compatibility = "HIGH"

    def encode(self, p):
        return (p.get("subject"), p.get("relation"), p.get("object"))

    def decode(self, x):
        return {"subject": x[0], "relation": x[1], "object": x[2]}


class CandidateB(Candidate):
    name, version = "B", "B0"
    representation = "(SUBJECT,RELATION,OBJECT,VALUE)"
    future_portability = "HIGH_WITH_SYMBOL_DICTIONARY"
    symbolic_compatibility = "HIGH"

    def encode(self, p):
        return (p.get("subject"), p.get("relation"), p.get("object"), p.get("value"))

    def decode(self, x):
        return {"subject": x[0], "relation": x[1], "object": x[2], "value": x[3]}


class CandidateC(Candidate):
    name, version = "C", "C0"
    representation = "(ACT,SUBJECT,RELATION,OBJECT,VALUE)"
    future_portability = "HIGH_WITH_SYMBOL_DICTIONARY"
    symbolic_compatibility = "HIGH"

    def encode(self, p):
        return (p.get("act"), p.get("subject"), p.get("relation"), p.get("object"), p.get("value"))

    def decode(self, x):
        return {"act": x[0], "subject": x[1], "relation": x[2], "object": x[3], "value": x[4]}


class CandidateD(Candidate):
    name, version = "D", "D0"
    representation = "(ACT,SUBJECT,RELATION,OBJECT,VALUE,CONFIDENCE)"
    future_portability = "HIGH_WITH_SYMBOL_DICTIONARY"
    symbolic_compatibility = "HIGH"

    def encode(self, p):
        return (p.get("act"), p.get("subject"), p.get("relation"), p.get("object"), p.get("value"), p.get("confidence"))

    def decode(self, x):
        d = {"act": x[0], "subject": x[1], "relation": x[2], "object": x[3], "value": x[4]}
        if x[5] is not None:
            d["confidence"] = x[5]
        return d


class CandidateE(Candidate):
    name, version = "E", "E0"
    representation = "FIXED_DENSE_STATE_VECTOR"
    adapters = ["field_one_hot_encoder", "field_one_hot_decoder"]
    external_tables = ["field_vocabularies"]
    future_portability = "MEDIUM_REQUIRES_SHARED_SCHEMA_AND_VOCAB"
    symbolic_compatibility = "MEDIUM_REQUIRES_DECODER"

    def __init__(self, vocab):
        super().__init__(vocab)
        self.maps = {f: {s: i for i, s in enumerate(vocab[f])} for f in FIELDS}
        self.offsets = {}
        off = 0
        for f in FIELDS:
            self.offsets[f] = off
            off += len(vocab[f])
        self.value_index = off
        self.dimension = off + 1

    def adapter_cost_encode(self): return 1
    def adapter_cost_decode(self): return 1

    def encode(self, p):
        vec = np.zeros(self.dimension, dtype=np.float64)
        for f in FIELDS:
            if f in p and p[f] is not None:
                token = str(p[f])
                idx = self.maps[f].get(token, self.maps[f][UNKNOWN])
                vec[self.offsets[f] + idx] = 1.0
        if p.get("value") is not None:
            vec[self.value_index] = float(p["value"]) / 1000.0
        return vec

    def decode(self, x):
        x = np.asarray(x, dtype=np.float64)
        d = {}
        for f in FIELDS:
            start = self.offsets[f]
            end = start + len(self.vocab[f])
            block = x[start:end]
            idx = int(np.argmax(block))
            if block[idx] > 0.5:
                tok = self.vocab[f][idx]
                if tok != UNKNOWN:
                    d[f] = tok
        if abs(float(x[self.value_index])) > 1e-12:
            d["value"] = int(round(float(x[self.value_index]) * 1000))
        else:
            # Zero is a legitimate VALUE; fixed vector cannot distinguish missing vs zero
            # without another component. We choose zero as present only when ACT exists.
            if "act" in d:
                d["value"] = 0
        return d

    def declaration(self):
        d = super().declaration()
        d.update({"dimension": self.dimension, "vocab_sizes": {k: len(v) for k, v in self.vocab.items()}})
        return d


class LatentCodec:
    """Field-factorized opaque latent declared before scoring."""
    fields = FIELDS
    block_dim = 4

    def __init__(self, vocab, seed=LATENT_SEED):
        self.vocab = vocab
        self.seed = seed
        self.codes: Dict[str, Dict[str, np.ndarray]] = {}
        for f in self.fields:
            self.codes[f] = {}
            for token in vocab[f]:
                # Independent deterministic code based on global seed + field + token.
                material = f"{seed}|{f}|{token}".encode()
                local_seed = int.from_bytes(hashlib.sha256(material).digest()[:8], "big")
                rng = np.random.default_rng(local_seed)
                v = rng.normal(size=self.block_dim)
                n = np.linalg.norm(v)
                if n == 0: v[0] = 1.0; n = 1.0
                self.codes[f][token] = v / n
        self.dimension = len(self.fields) * self.block_dim + 1

    def encode(self, p):
        out = np.zeros(self.dimension, dtype=np.float64)
        for i, f in enumerate(self.fields):
            tok = str(p[f]) if f in p and p[f] is not None else UNKNOWN
            tok = tok if tok in self.codes[f] else UNKNOWN
            start = i * self.block_dim
            out[start:start+self.block_dim] = self.codes[f][tok]
        out[-1] = float(p.get("value", 0)) / 1000.0
        return out

    def decode(self, x):
        x = np.asarray(x, dtype=np.float64)
        d = {}
        for i, f in enumerate(self.fields):
            start = i * self.block_dim
            block = x[start:start+self.block_dim]
            best_tok, best_score = None, -1e30
            for tok, code in self.codes[f].items():
                score = float(np.dot(block, code))
                if score > best_score:
                    best_tok, best_score = tok, score
            if best_tok != UNKNOWN:
                d[f] = best_tok
        d["value"] = int(round(float(x[-1]) * 1000))
        return d


class CandidateF(Candidate):
    name, version = "F", "F0"
    representation = "MODEL_SPECIFIC_OPAQUE_LATENT_VECTOR"
    adapters = ["DeterministicCodebookLatentV1.encoder", "DeterministicCodebookLatentV1.decoder"]
    external_tables = ["five_field_latent_codebooks"]
    future_portability = "LOW_WITHOUT_CODEBOOK_OR_TRANSLATION_ADAPTER"
    symbolic_compatibility = "LOW_DIRECT / HIGH_AFTER_DECODER"

    def __init__(self, vocab):
        super().__init__(vocab)
        self.codec = LatentCodec(vocab)
        self.dimension = self.codec.dimension

    def adapter_cost_encode(self): return 1
    def adapter_cost_decode(self): return 1
    def encode(self, p): return self.codec.encode(p)
    def decode(self, x): return self.codec.decode(x)

    def declaration(self):
        d = super().declaration()
        d.update({"dimension": self.dimension, "latent_seed": LATENT_SEED, "block_dim": 4})
        return d


class CandidateG(Candidate):
    name, version = "G", "G0"
    representation = "SYMBOLIC_C0_PLUS_F0_LATENT"
    adapters = ["DeterministicCodebookLatentV1.encoder", "DeterministicCodebookLatentV1.decoder", "hybrid_consistency_check"]
    external_tables = ["five_field_latent_codebooks"]
    future_portability = "MEDIUM_SYMBOLIC_CORE / LOW_LATENT_WITHOUT_ADAPTER"
    symbolic_compatibility = "HIGH_SYMBOLIC_CORE"

    def __init__(self, vocab):
        super().__init__(vocab)
        self.codec = LatentCodec(vocab)
        self.dimension = 5 + self.codec.dimension

    def adapter_cost_encode(self): return 1
    def adapter_cost_decode(self): return 2

    def encode(self, p):
        symbolic = (p.get("act"), p.get("subject"), p.get("relation"), p.get("object"), p.get("value"))
        latent = self.codec.encode(p)
        return {"symbolic": symbolic, "latent": latent}

    def decode(self, x):
        s = x["symbolic"]
        sd = {"act": s[0], "subject": s[1], "relation": s[2], "object": s[3], "value": s[4]}
        ld = self.codec.decode(x["latent"])
        # If both components carry a non-null field and disagree, the run is invalid.
        for f in ("act", "subject", "relation", "object", "value"):
            if sd.get(f) is not None and ld.get(f) is not None and sd.get(f) != ld.get(f):
                raise RuntimeError(f"hybrid disagreement on {f}: {sd.get(f)!r} != {ld.get(f)!r}")
        out = {k: v for k, v in sd.items() if v is not None}
        if "id" in ld:
            out["id"] = ld["id"]
        return out

    def declaration(self):
        d = super().declaration()
        d.update({"dimension_components": {"symbolic_slots": 5, "latent_dim": self.codec.dimension}})
        return d


CANDIDATE_TYPES = [CandidateA, CandidateB, CandidateC, CandidateD, CandidateE, CandidateF, CandidateG]


def semantic_subset_match(actual: dict, expected: dict) -> bool:
    for k, v in expected.items():
        if actual.get(k) != v:
            return False
    return True


def packet_equal_required(actual: dict, expected: dict) -> bool:
    # Exact for semantic fields present in expected. Extra candidate fields do not hurt.
    return semantic_subset_match(actual, expected)


def encode_state(candidate: Candidate, packets: Sequence[dict]) -> List[Any]:
    return [candidate.encode_counted(p) for p in packets if "subject" in p or "act" in p]


def decoded_state(candidate: Candidate, encoded: Sequence[Any]) -> List[dict]:
    return [candidate.decode_counted(x) for x in encoded]


def can_emit(candidate: Candidate, semantic_packet: dict) -> Any:
    return candidate.encode_counted(semantic_packet)


def transitive_closure(candidate: Candidate, encoded_packets: List[Any], relation: str) -> Tuple[List[Any], List[Any]]:
    """Returns (state, derived_outputs). Generic structured rule, no prose."""
    outputs: List[Any] = []
    changed = True
    while changed:
        changed = False
        state_dec = decoded_state(candidate, encoded_packets)
        existing = {(p.get("subject"), p.get("relation"), p.get("object")) for p in state_dec}
        for p1 in state_dec:
            for p2 in state_dec:
                candidate.metrics.deterministic_operations += 1
                if p1.get("relation") == relation and p2.get("relation") == relation and p1.get("object") == p2.get("subject"):
                    s, o = p1.get("subject"), p2.get("object")
                    key = (s, relation, o)
                    if key in existing:
                        continue
                    v1, v2 = p1.get("value"), p2.get("value")
                    value = min(v1, v2) if isinstance(v1, (int, float)) and isinstance(v2, (int, float)) else None
                    semantic = {"act": "DERIVE", "subject": s, "relation": relation, "object": o, "value": value}
                    enc = can_emit(candidate, semantic)
                    encoded_packets.append(enc)
                    outputs.append(enc)
                    existing.add(key)
                    changed = True
        # Finite fixture safety.
        if len(encoded_packets) > 64:
            raise RuntimeError("closure runaway")
    return encoded_packets, outputs


def assignment_inheritance(candidate: Candidate, encoded_packets: List[Any]) -> List[Any]:
    state_dec = decoded_state(candidate, encoded_packets)
    outputs = []
    existing = {(p.get("subject"), p.get("relation"), p.get("object")) for p in state_dec}
    for p1 in state_dec:
        for p2 in state_dec:
            candidate.metrics.deterministic_operations += 1
            if p1.get("relation") == "PART_OF" and p2.get("relation") == "ASSIGNED_TO" and p1.get("object") == p2.get("subject"):
                key = (p1.get("subject"), "ASSIGNED_TO", p2.get("object"))
                if key in existing:
                    continue
                v1, v2 = p1.get("value"), p2.get("value")
                value = min(v1, v2) if isinstance(v1, (int, float)) and isinstance(v2, (int, float)) else None
                outputs.append(can_emit(candidate, {"act":"DERIVE", "subject":key[0], "relation":key[1], "object":key[2], "value":value}))
                existing.add(key)
    return outputs


def run_task(candidate: Candidate, task: dict) -> dict:
    task_id = task["task_id"]
    start_ns = time.perf_counter_ns()
    initial_packets = [p for p in task.get("initial_state", []) if isinstance(p, dict) and ("act" in p or "subject" in p)]
    oracle_records = [p for p in task.get("initial_state", []) if isinstance(p, dict) and "oracle_id" in p]
    state = encode_state(candidate, initial_packets)
    inputs = encode_state(candidate, task.get("input_semantics", []))
    outputs: List[Any] = []
    trace: List[dict] = [{"phase":"initial", "state":jsonable(state)}, {"phase":"input", "packets":jsonable(inputs)}]
    failure_class = None
    notes: List[str] = []

    if task_id == "T1":
        outputs = [copy.deepcopy(x) for x in inputs]
        candidate.metrics.deterministic_operations += len(outputs)

    elif task_id == "T2":
        state.extend(inputs)
        state, outputs = transitive_closure(candidate, state, "BEFORE")

    elif task_id == "T3":
        state.extend(inputs)
        dec = decoded_state(candidate, state)
        # Generic contradiction rule requires stable source IDs to make assertions referable.
        for i, p1 in enumerate(dec):
            for p2 in dec[i+1:]:
                candidate.metrics.deterministic_operations += 1
                if p1.get("subject") == p2.get("subject") and p1.get("relation") == p2.get("relation") == "COLOR" and p1.get("object") != p2.get("object"):
                    if not p1.get("id") or not p2.get("id"):
                        failure_class = "REPRESENTATIONAL_INSUFFICIENCY"
                        notes.append("source assertion identity unavailable; cannot emit required claim-to-claim contradiction without external handle machinery")
                        continue
                    v1, v2 = p1.get("value"), p2.get("value")
                    value = min(abs(v1), abs(v2)) if isinstance(v1, (int,float)) and isinstance(v2, (int,float)) else None
                    outputs.append(can_emit(candidate, {"act":"ASSERT", "subject":p1["id"], "relation":"CONTRADICTS", "object":p2["id"], "value":value}))

    elif task_id == "T4":
        # Generic update semantics rely on ACT being carried by the candidate.
        state.extend([])
        for enc in inputs:
            p = candidate.decode_counted(enc)
            if p.get("act") != "UPDATE":
                failure_class = "INTENT_AMBIGUITY"
                notes.append("UPDATE intent unavailable in representation")
                state.append(enc)
                continue
            new_state = []
            for old_enc in state:
                old = candidate.decode_counted(old_enc)
                candidate.metrics.deterministic_operations += 1
                if old.get("subject") == p.get("subject") and old.get("relation") == p.get("relation"):
                    continue
                new_state.append(old_enc)
            # Current state records the update payload itself; ACT is operational, not interpreted as history.
            new_state.append(enc)
            state = new_state

    elif task_id == "T5":
        for enc in inputs:
            p = candidate.decode_counted(enc)
            if p.get("act") != "REQUEST":
                failure_class = "INTENT_AMBIGUITY"
                notes.append("REQUEST intent unavailable in representation")
                continue
            if p.get("relation") == "EVALUATE":
                oracle = next((o for o in oracle_records if o.get("oracle_id") == p.get("object")), None)
                candidate.metrics.deterministic_operations += 1
                if oracle and oracle.get("premise_a") and oracle.get("premise_b") and oracle.get("rule") == "A_AND_B_IMPLIES_VALID":
                    outputs.append(can_emit(candidate, {"act":"RESPOND", "subject":RESPONDER_ID, "relation":"VALIDITY", "object":p.get("object"), "value":oracle.get("expected_validity_value")}))

    elif task_id == "T6":
        state.extend(inputs)
        state, outputs = transitive_closure(candidate, state, "BEFORE")

    elif task_id == "T7":
        # No semantic decoder help: collision is defined directly on candidate encoded states.
        reps = [canonical_json(jsonable(x)) for x in inputs]
        distinct = len(set(reps))
        collisions = len(reps) - distinct
        candidate.metrics.deterministic_operations += len(reps)
        trace.append({"phase":"collision", "distinct":distinct, "collisions":collisions})
        elapsed_ns = time.perf_counter_ns() - start_ns
        pass_ok = distinct == 4 and collisions == 0
        return finalize_result(candidate, task, state, outputs, trace, pass_ok,
                               None if pass_ok else "INFORMATION_COLLISION",
                               notes + ([f"distinct={distinct}, collisions={collisions}"] if not pass_ok else []), elapsed_ns,
                               extra={"distinguishable_count":distinct, "collision_count":collisions})

    elif task_id == "T8":
        outputs = assignment_inheritance(candidate, state)

    else:
        raise RuntimeError(f"unknown task {task_id}")

    trace.append({"phase":"final", "state":jsonable(state), "outputs":jsonable(outputs)})
    elapsed_ns = time.perf_counter_ns() - start_ns
    pass_ok, eval_failure, eval_notes = evaluate_task(candidate, task, state, outputs)
    if not pass_ok and failure_class is None:
        failure_class = eval_failure
    notes.extend(eval_notes)
    return finalize_result(candidate, task, state, outputs, trace, pass_ok, failure_class, notes, elapsed_ns)


def evaluate_task(candidate: Candidate, task: dict, state: Sequence[Any], outputs: Sequence[Any]) -> Tuple[bool, Optional[str], List[str]]:
    tid = task["task_id"]
    out_dec = [candidate.decode_counted(x) for x in outputs]
    state_dec = [candidate.decode_counted(x) for x in state]
    required = task["required_output_semantics"]
    notes = []

    if tid in ("T1", "T2", "T5", "T6", "T8"):
        missing = []
        for exp in required:
            if not any(packet_equal_required(a, exp) for a in out_dec):
                missing.append(exp)
        if missing:
            # Distinguish missing ACT/VALUE from inference failure where possible.
            flattened = {k for p in out_dec for k in p.keys()}
            expected_fields = {k for p in required if isinstance(p, dict) for k in p.keys()}
            if not expected_fields.issubset(flattened | {"confidence", "id"}):
                return False, "REPRESENTATIONAL_INSUFFICIENCY", [f"missing required semantic outputs: {missing}"]
            return False, "INFERENCE_FAILURE", [f"missing required semantic outputs: {missing}"]
        return True, None, []

    if tid == "T3":
        exp_packet = required[0]
        packet_ok = any(packet_equal_required(a, exp_packet) for a in out_dec)
        req_ids = set(required[1]["preserve_active_claims"])
        got_ids = {p.get("id") for p in state_dec if p.get("id")}
        preserve_ok = req_ids.issubset(got_ids)
        if packet_ok and preserve_ok:
            return True, None, []
        return False, "REPRESENTATIONAL_INSUFFICIENCY", [f"contradiction_packet={packet_ok}, preserved_ids={sorted(got_ids)}"]

    if tid == "T4":
        current = required[0]["current"]
        not_current = required[1]["not_current"]
        cur_ok = any(semantic_subset_match(p, current) for p in state_dec)
        old_absent = not any(semantic_subset_match(p, not_current) for p in state_dec)
        if cur_ok and old_absent:
            return True, None, []
        return False, "UPDATE_AMBIGUITY", [f"current_ok={cur_ok}, old_absent={old_absent}, state={state_dec}"]

    raise RuntimeError(f"no evaluator for {tid}")


def finalize_result(candidate: Candidate, task: dict, state: Sequence[Any], outputs: Sequence[Any], trace: List[dict], pass_ok: bool,
                    failure_class: Optional[str], notes: List[str], elapsed_ns: int, extra: Optional[dict]=None) -> dict:
    candidate.metrics.storage_bytes = candidate.storage_cost(list(state) + list(outputs))
    result = {
        "task_id": task["task_id"],
        "task_name": task["name"],
        "execution_verdict": "RUN_VALID",
        "semantic_verdict": "PASS" if pass_ok else "FAIL",
        "failure_class": failure_class,
        "notes": notes,
        "trajectory_hash": sha(trace),
        "trace": trace,
        "metrics": {
            "wire_profile": WIRE_PROFILE,
            "wire_bytes_transferred": candidate.metrics.wire_bytes_transferred,
            "storage_bytes": candidate.metrics.storage_bytes,
            "deterministic_operations": candidate.metrics.deterministic_operations,
            "adapter_calls": candidate.metrics.adapter_calls,
            "model_calls": candidate.metrics.model_calls,
            "input_tokens": candidate.metrics.input_tokens,
            "output_tokens": candidate.metrics.output_tokens,
            "latency_ns_reference": elapsed_ns,
        },
        "outputs_decoded": [candidate.decode(x) for x in outputs],
        "state_decoded": [candidate.decode(x) for x in state],
    }
    if extra:
        result.update(extra)
    return result


def run_once(candidate_type, vocab, task):
    c = candidate_type(vocab)
    try:
        r = run_task(c, task)
        return c, r
    except Exception as e:
        return c, {
            "task_id": task["task_id"],
            "task_name": task["name"],
            "execution_verdict": "EXPERIMENT_INVALID",
            "semantic_verdict": None,
            "failure_class": "IMPLEMENTATION_ERROR",
            "notes": [f"{type(e).__name__}: {e}"],
            "trajectory_hash": None,
            "metrics": {},
        }


def summarize_candidate(candidate_decl: dict, task_results: List[dict]) -> dict:
    valid = [r for r in task_results if r["execution_verdict"] == "RUN_VALID"]
    passed = [r for r in valid if r["semantic_verdict"] == "PASS"]
    invalid = [r for r in task_results if r["execution_verdict"] == "EXPERIMENT_INVALID"]
    failures = [r for r in valid if r["semantic_verdict"] != "PASS"]
    if invalid:
        interpretation = "INSUFFICIENT_EVIDENCE"
    elif not failures:
        interpretation = "SEMANTICALLY_SUFFICIENT_WITHIN_TESTED_SCOPE"
    else:
        interpretation = "SEMANTICALLY_INSUFFICIENT_WITHIN_TESTED_SCOPE"
    return {
        "declaration": candidate_decl,
        "tasks_passed": len(passed),
        "tasks_total": len(task_results),
        "invalid_runs": len(invalid),
        "failed_tasks": [r["task_id"] for r in failures],
        "failure_classes": {r["task_id"]: r.get("failure_class") for r in failures},
        "interpretation": interpretation,
        "metric_totals": {
            "wire_bytes_transferred_reference": sum(r.get("metrics", {}).get("wire_bytes_transferred", 0) for r in valid),
            "storage_bytes_reference": sum(r.get("metrics", {}).get("storage_bytes", 0) for r in valid),
            "deterministic_operations": sum(r.get("metrics", {}).get("deterministic_operations", 0) for r in valid),
            "adapter_calls": sum(r.get("metrics", {}).get("adapter_calls", 0) for r in valid),
            "model_calls": sum(r.get("metrics", {}).get("model_calls", 0) for r in valid),
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(RESULTS / "PRIMITIVE-0_REFERENCE_RESULTS.json"))
    args = parser.parse_args()

    verify_fixtures()
    tasks = load_tasks()
    ontology = load_ontology()
    vocab = build_vocab(tasks, ontology)

    RESULTS.mkdir(exist_ok=True)

    experiment = {
        "benchmark": "PRIMITIVE-0",
        "benchmark_version": "0.1.0",
        "implementation": "deterministic-reference-harness-0.1.0",
        "wire_profile": WIRE_PROFILE,
        "fixture_manifest_sha256": hashlib.sha256((FIXTURES / "MANIFEST.json").read_bytes()).hexdigest(),
        "implementation_declarations_sha256": hashlib.sha256((Path(__file__).parent / "IMPLEMENTATION_DECLARATIONS.md").read_bytes()).hexdigest(),
        "vocab": vocab,
        "candidates": {},
    }

    for ctype in CANDIDATE_TYPES:
        probe = ctype(vocab)
        task_results = []
        for task in tasks:
            c1, r1 = run_once(ctype, vocab, task)
            c2, r2 = run_once(ctype, vocab, task)
            replay_ok = (
                r1.get("execution_verdict") == r2.get("execution_verdict") == "RUN_VALID"
                and r1.get("trajectory_hash") == r2.get("trajectory_hash")
                and r1.get("semantic_verdict") == r2.get("semantic_verdict")
            )
            if r1.get("execution_verdict") == "RUN_VALID":
                r1["replay"] = {
                    "deterministic_reproducibility": "PASS" if replay_ok else "FAIL",
                    "second_trajectory_hash": r2.get("trajectory_hash"),
                }
                if not replay_ok:
                    r1["failure_class"] = r1.get("failure_class") or "REPLAY_FAILURE"
            task_results.append(r1)
        summary = summarize_candidate(probe.declaration(), task_results)
        experiment["candidates"][probe.name] = {"summary": summary, "tasks": task_results}

    # Experiment-level verdict: raw semantic sufficiency only, no composite cost score.
    sufficient = [k for k,v in experiment["candidates"].items() if v["summary"]["interpretation"] == "SEMANTICALLY_SUFFICIENT_WITHIN_TESTED_SCOPE"]
    invalid_any = any(v["summary"]["invalid_runs"] for v in experiment["candidates"].values())
    if invalid_any:
        terminal = "EXPERIMENT_INCOMPLETE"
    elif not sufficient:
        terminal = "ALL_CANDIDATES_INSUFFICIENT"
    else:
        # Semantic sufficiency alone does not authorize CLEAR_WINNER. The frozen
        # verdict contract also requires dominance across relevant cost/complexity
        # groups. In this reference run, compact symbolic candidates dominate
        # transport/complexity while G0 alone clears every semantic task, so the
        # honest result is a tradeoff frontier rather than a scalar winner.
        terminal = "TRADEOFF_FRONTIER"
    experiment["terminal_verdict"] = terminal
    experiment["semantically_sufficient_candidates"] = sufficient
    experiment["note"] = "Terminal verdict does not collapse metric groups into one score. Multiple semantically sufficient candidates require cost/interoperability interpretation rather than automatic ranking."

    out = Path(args.out)
    out.write_text(json.dumps(experiment, indent=2), encoding="utf-8")

    # Human-readable report generated strictly from results.
    lines = [
        "# PRIMITIVE-0 Reference Results",
        "",
        "**Harness:** deterministic-reference-harness-0.1.0  ",
        f"**Benchmark:** PRIMITIVE-0 v0.1.0  ",
        f"**Fixture manifest SHA-256:** `{experiment['fixture_manifest_sha256']}`  ",
        f"**Terminal verdict:** `{terminal}`",
        "",
        "## Candidate summary",
        "",
        "| Candidate | Passed | Failed | Interpretation | Ref wire bytes | Adapter calls |",
        "|---|---:|---|---|---:|---:|",
    ]
    for k in ["A","B","C","D","E","F","G"]:
        s = experiment["candidates"][k]["summary"]
        lines.append(f"| {k} | {s['tasks_passed']}/8 | {', '.join(s['failed_tasks']) or '—'} | {s['interpretation']} | {s['metric_totals']['wire_bytes_transferred_reference']} | {s['metric_totals']['adapter_calls']} |")
    lines += ["", "## Task matrix", "", "| Task | A | B | C | D | E | F | G |", "|---|---|---|---|---|---|---|---|"]
    for task in tasks:
        row = [task["task_id"]]
        for k in ["A","B","C","D","E","F","G"]:
            r = next(x for x in experiment["candidates"][k]["tasks"] if x["task_id"] == task["task_id"])
            if r["execution_verdict"] != "RUN_VALID": cell = "INVALID"
            else: cell = r["semantic_verdict"]
            row.append(cell)
        lines.append("| " + " | ".join(row) + " |")
    lines += [
        "",
        "## Interpretation constraints",
        "",
        "- Reference JSON byte counts are an implementation measurement only, not an ENCODING-0 conclusion.",
        "- No composite score was created.",
        "- Candidate F0 is a deterministic opaque-codebook latent reference, not a claim about neural latent representations in general.",
        "- Candidate G0 is intentionally redundant (C0 + F0) and pays the adapter/storage cost of that redundancy.",
        "- A C0 failure on source-reference identity is not permission to alter C0; any repair must be a versioned C1 candidate.",
        "- Every deterministic run was replayed from a fresh candidate instance under the same fixture seed.",
    ]
    report_path = RESULTS / "PRIMITIVE-0_REFERENCE_RESULTS.md"
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(out)
    print(report_path)
    print(json.dumps({k:v['summary'] for k,v in experiment['candidates'].items()}, indent=2))


if __name__ == "__main__":
    main()
