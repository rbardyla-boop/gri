#!/usr/bin/env python3
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "implementation" / "run_primitive0.py"
RESULT = ROOT / "results" / "PRIMITIVE-0_REFERENCE_RESULTS.json"

subprocess.run([sys.executable, str(RUNNER)], check=True)
data = json.loads(RESULT.read_text())
assert data["benchmark"] == "PRIMITIVE-0"
assert set(data["candidates"]) == set("ABCDEFG")
for name, c in data["candidates"].items():
    assert len(c["tasks"]) == 8
    for r in c["tasks"]:
        assert r["execution_verdict"] == "RUN_VALID", (name, r)
        assert r["replay"]["deterministic_reproducibility"] == "PASS", (name, r)
print("HARNESS_TEST_PASS")
