# PRIMITIVE-0 Reference Results

**Harness:** deterministic-reference-harness-0.1.0  
**Benchmark:** PRIMITIVE-0 v0.1.0  
**Fixture manifest SHA-256:** `844709200e2453180b6e7989c7e5fde14cf8e46a4cb1690b477b765bff88287e`  
**Terminal verdict:** `TRADEOFF_FRONTIER`

## Candidate summary

| Candidate | Passed | Failed | Interpretation | Ref wire bytes | Adapter calls |
|---|---:|---|---|---:|---:|
| A | 0/8 | T1, T2, T3, T4, T5, T6, T7, T8 | SEMANTICALLY_INSUFFICIENT_WITHIN_TESTED_SCOPE | 681 | 0 |
| B | 0/8 | T1, T2, T3, T4, T5, T6, T7, T8 | SEMANTICALLY_INSUFFICIENT_WITHIN_TESTED_SCOPE | 776 | 0 |
| C | 7/8 | T3 | SEMANTICALLY_INSUFFICIENT_WITHIN_TESTED_SCOPE | 1042 | 0 |
| D | 7/8 | T3 | SEMANTICALLY_INSUFFICIENT_WITHIN_TESTED_SCOPE | 1167 | 0 |
| E | 7/8 | T3 | SEMANTICALLY_INSUFFICIENT_WITHIN_TESTED_SCOPE | 5963 | 78 |
| F | 7/8 | T3 | SEMANTICALLY_INSUFFICIENT_WITHIN_TESTED_SCOPE | 10539 | 78 |
| G | 8/8 | — | SEMANTICALLY_SUFFICIENT_WITHIN_TESTED_SCOPE | 12232 | 130 |

## Task matrix

| Task | A | B | C | D | E | F | G |
|---|---|---|---|---|---|---|---|
| T1 | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS |
| T2 | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS |
| T3 | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS |
| T4 | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS |
| T5 | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS |
| T6 | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS |
| T7 | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS |
| T8 | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS |

## Interpretation constraints

- Reference JSON byte counts are an implementation measurement only, not an ENCODING-0 conclusion.
- No composite score was created.
- Candidate F0 is a deterministic opaque-codebook latent reference, not a claim about neural latent representations in general.
- Candidate G0 is intentionally redundant (C0 + F0) and pays the adapter/storage cost of that redundancy.
- A C0 failure on source-reference identity is not permission to alter C0; any repair must be a versioned C1 candidate.
- Every deterministic run was replayed from a fresh candidate instance under the same fixture seed.
