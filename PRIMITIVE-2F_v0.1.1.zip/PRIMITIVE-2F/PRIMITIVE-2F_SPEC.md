# PRIMITIVE-2F — INDEPENDENT CONSEQUENCE / CONSTRAINT VERIFICATION

**Version:** 0.1.1  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `da0dd18259205d572ded98518c885a84274ee89429902ab2e8e5f55471cddf14`  
**Verifier SHA-256:** `7f9dc5f20d14513b3291e6ebfb60a828081bd90d5ee8314e35ab0bc10b189fb3`  
**Witness-set SHA-256:** `1b3cf1e3706174ad6ba41bb937130adeea3f7dabbd4ff8f979730705e634ac33`

## Question

> Can a derived packet be challenged by testing an independently supplied observable/constraint, rather than asking the same computation whether it is confident or internally consistent?

## Frozen rollback

PRIMITIVE-2D `JUSTIFICATION_DAG` remains unchanged.

PRIMITIVE-2F changes only challenge generation.

## Independent witness channel

Before learned inference begins, each graph receives environment-side numeric witness state generated solely from immutable roots.

Examples:

```text
BEFORE
  hidden order component + scalar order rank

PART_OF
  hidden containment component + nested numeric interval

ASSIGNED_TO
  environment assignment label

LOCATED_IN
  environment location label
```

The verifier tests the candidate semantic packet against that independent state.

It does not inspect:

```text
model confidence
model hidden activations
model voting
reference-renaming stability
oracle closure
```

## Why this is not a complete symbolic truth engine

The verifier does not perform transitive closure or packet composition.

It checks whether a candidate conclusion is compatible with separately supplied world state.

For the frozen synthetic worlds, that world state is intentionally strong. A positive result therefore demonstrates the value of independent evidence, not that such evidence is always available in an open world.

## Scored surfaces

```text
9 known corrupted PRIMITIVE-2B model/graph cases
30 fresh acyclic PRIMITIVE-2E graphs × 3 models
= 99 model/graph cases
```

Cycles are excluded in v0.1.0 because the chosen scalar-order witness cannot encode cyclic BEFORE truth.

## Strict gate

A verifier succeeds only if all 99 cases end with:

```text
0 active bad facts
100% oracle-valid recall
100% exact final graphs
0 oracle-valid derived facts challenged
deterministic replay
```

## v0.1.1 pre-scoring witness correction

Before any verifier score existed, the mixed-hierarchy witness generator was found to assign the zone object a self-assignment label.

Removed:

```text
assignment_zone[zone] = zone
```

Reason: this would incorrectly allow `zone ASSIGNED_TO zone` to satisfy the environmental witness.

No model, graph fixture, rollback mechanism, candidate verifier, or success gate changed.
