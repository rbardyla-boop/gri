# PRIMITIVE-2F METHOD

1. Freeze the exact three PRIMITIVE-2A learned binding models by SHA-256.
2. Freeze PRIMITIVE-2D JUSTIFICATION_DAG rollback unchanged.
3. Use all nine known PRIMITIVE-2B corrupted model/graph pairs.
4. Reuse 30 acyclic fresh PRIMITIVE-2E graphs and score them with all three frozen models.
5. Before learned inference, construct environment-side numeric witness ledgers from immutable graph roots only.
6. Run the unchanged learned reasoner and record every accepted parent-pair justification.
7. Generate autonomous challenges from witness incompatibility only; the verifier receives no model confidence, hidden activations, model voting, reference-renaming score, or oracle closure.
8. Apply the unchanged PRIMITIVE-2D JUSTIFICATION_DAG rollback.
9. Use the experimenter oracle only after challenge generation to score false challenges, remaining bad facts, recall, and exact graph state.
10. Re-run the entire 99-case scorer and require byte-identical result JSON.

PRIMITIVE-2F v0.1.1 excludes cyclic BEFORE worlds because the chosen scalar-order witness cannot encode cyclic truth. This is an explicit scope limit, not a post-result exclusion.
