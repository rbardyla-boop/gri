#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2F_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2F_REPLAY_CHECK.json").read_text())
assert r["terminal_verdict"]=="INDEPENDENT_WITNESS_VERIFICATION_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["known_baseline_equivalence"]=="PASS"
assert r["case_count"]==99
assert rp["exact_byte_replay"]=="PASS"
d=r["verifier_summary"]["WITNESS_DIRECT"]
assert d["known"]["exact_after_rollback_count"]==9
assert d["confirmation"]["exact_after_rollback_count"]==90
assert d["all"]["active_bad_after_total"]==0
assert d["all"]["valid_false_challenges_total"]==0
assert d["all"]["aggregate_challenge_precision"]==1.0
assert d["all"]["min_post_rollback_recall"]==1.0
assert d["success_gate_pass"] is True
x=r["verifier_summary"]["WITNESS_DIRECT_AND_SUPPORT"]
assert x["success_gate_pass"] is False
print("PRIMITIVE_2F_TEST_PASS")
