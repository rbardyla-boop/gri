from pathlib import Path
import json, hashlib, itertools, time, os, csv
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)

BASE=Path("/mnt/data")
P2A=BASE/"PRIMITIVE-2A"
P2B=BASE/"PRIMITIVE-2B"
P2D=BASE/"PRIMITIVE-2D"
P2E=BASE/"PRIMITIVE-2E"
ROOT=BASE/"PRIMITIVE-2F"
FIX=ROOT/"PRIMITIVE-2F_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

ACTS=["ASSERT","DERIVE"]
RELS=["BEFORE","PART_OF","ASSIGNED_TO","LOCATED_IN"]
A2I={x:i for i,x in enumerate(ACTS)}
R2I={x:i for i,x in enumerate(RELS)}
I2R={i:x for x,i in R2I.items()}
RO_NONE=4
RULES={"BEFORE|BEFORE":"BEFORE","PART_OF|PART_OF":"PART_OF","PART_OF|ASSIGNED_TO":"ASSIGNED_TO"}
bitpos=torch.arange(24,dtype=torch.long)

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2F_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"],rec["name"]
for seed,h in freeze["parent_model_hashes"].items():
    assert sha_file(P2A/"models"/f"M2_seed_{seed}.pt")==h
assert sha_file(P2D/"PRIMITIVE-2D_MECHANISMS.json")==freeze["parent_p2d_mechanism_sha256"]

suite=json.loads((FIX/"CASE_SUITE.json").read_text())
wdoc=json.loads((FIX/"WITNESS_LEDGERS.json").read_text())
wmap={r["fixture_id"]:r for r in wdoc["records"]}
known_suite=json.loads((P2D/"PRIMITIVE-2D_FIXTURES"/"CHALLENGE_SUITE.json").read_text())
p2b_graphs=json.loads((P2B/"PRIMITIVE-2B_FIXTURES"/"RECURSIVE_STABILITY_GRAPHS.json").read_text())
p2b_map={f["fixture_id"]:f for f in p2b_graphs["fixtures"]}
p2e_graphs=json.loads((P2E/"PRIMITIVE-2E_FIXTURES"/"CONFIRMATION_GRAPHS.json").read_text())
p2e_map={f["fixture_id"]:f for f in p2e_graphs["fixtures"]}

class BindingComposer(nn.Module):
    def __init__(self):
        super().__init__()
        self.refenc=nn.Sequential(nn.Linear(24,32),nn.ReLU(),nn.Linear(32,32),nn.ReLU())
        self.body=nn.Sequential(nn.Linear(332,128),nn.ReLU(),nn.Linear(128,128),nn.ReLU())
        self.bind=nn.Linear(128,3); self.rel=nn.Linear(128,5)
        self.ssel=nn.Linear(128,4); self.osel=nn.Linear(128,4)
    def forward(self,acts,rels,refs):
        rb=((refs.unsqueeze(-1)>>bitpos)&1).float()
        e=self.refenc(rb)
        diffs=torch.cat([(e[:,i]-e[:,j]).abs() for i,j in itertools.combinations(range(4),2)],dim=1)
        meta=torch.cat([
            F.one_hot(acts[:,0],2).float(),F.one_hot(acts[:,1],2).float(),
            F.one_hot(rels[:,0],4).float(),F.one_hot(rels[:,1],4).float()
        ],dim=1)
        h=self.body(torch.cat([e.flatten(1),diffs,meta],dim=1))
        return self.bind(h),self.rel(h),self.ssel(h),self.osel(h)

def load_model(seed):
    m=BindingComposer()
    m.load_state_dict(torch.load(P2A/"models"/f"M2_seed_{seed}.pt",map_location="cpu",weights_only=True))
    m.eval()
    return m

def oracle_pair(l,r):
    ls,lr,lo=l; rs,rr,ro=r
    key=f"{I2R[lr]}|{I2R[rr]}"
    if lo==rs and key in RULES:
        return (ls,R2I[RULES[key]],ro)
    key=f"{I2R[rr]}|{I2R[lr]}"
    if ro==ls and key in RULES:
        return (rs,R2I[RULES[key]],lo)
    return None

def oracle_closure(fx):
    facts={(int(p["subject"]),R2I[p["relation"]],int(p["object"])) for p in fx["inputs"]}
    while True:
        arr=list(facts); new=set()
        for l in arr:
            for r in arr:
                x=oracle_pair(l,r)
                if x is not None and x not in facts:new.add(x)
        if not new:return facts
        facts|=new

def predict_candidates(model,packets,pairs,chunk=4096):
    pkt=torch.tensor(packets,dtype=torch.long)
    for st in range(0,len(pairs),chunk):
        ij=pairs[st:st+chunk]
        ii=torch.tensor([x[0] for x in ij],dtype=torch.long)
        jj=torch.tensor([x[1] for x in ij],dtype=torch.long)
        left=pkt[ii]; right=pkt[jj]
        acts=torch.stack([left[:,1],right[:,1]],dim=1)
        rels=torch.stack([left[:,3],right[:,3]],dim=1)
        refs=torch.stack([left[:,2],left[:,4],right[:,2],right[:,4]],dim=1)
        with torch.no_grad():
            outs=model(acts,rels,refs)
            pb,pr,ps,po=[x.argmax(-1) for x in outs]
        mask=(pb!=0)&(pr!=RO_NONE)
        sel=torch.nonzero(mask,as_tuple=False).flatten()
        for t in sel.tolist():
            i,j=ij[t]
            slots=refs[t]
            fact=(int(slots[int(ps[t])]),int(pr[t]),int(slots[int(po[t])]))
            yield fact,i,j

def audited_run(model,fx):
    gold=oracle_closure(fx)
    packets=[[int(p["id"]),A2I[p["act"]],int(p["subject"]),R2I[p["relation"]],int(p["object"]),1000] for p in fx["inputs"]]
    facts=[(p[2],p[3],p[4]) for p in packets]
    fact_to_idx={f:i for i,f in enumerate(facts)}
    is_input={f:True for f in facts}
    supports={f:set() for f in facts}
    next_ref=max(p[0] for p in packets)+1
    frontier=list(range(len(packets)))
    rounds=0; pair_evals=0
    while frontier and rounds<int(fx["max_rounds"]):
        rounds+=1
        n=len(packets); fset=set(frontier)
        pairs=[(i,j) for i in range(n) for j in range(n) if i!=j and (i in fset or j in fset)]
        pair_evals+=len(pairs)
        newfacts=set()
        for fact,li,ri in predict_candidates(model,packets,pairs):
            lf=facts[li]; rf=facts[ri]
            supports.setdefault(fact,set()).add((lf,rf))
            if fact not in fact_to_idx:newfacts.add(fact)
        if not newfacts:break
        frontier=[]
        for fact in sorted(newfacts):
            if fact in fact_to_idx:continue
            s,r,o=fact
            p=[next_ref,A2I["DERIVE"],s,r,o,1000]; next_ref+=1
            idx=len(packets); packets.append(p); facts.append(fact)
            fact_to_idx[fact]=idx; is_input[fact]=False; frontier.append(idx)
    final=set(facts)
    return {
        "gold":gold,"final":final,"bad":final-gold,"supports":supports,
        "is_input":is_input,"rounds":rounds,"pair_evaluations":pair_evals
    }

def witness_valid(fact,w):
    s,r,o=fact
    rel=I2R[r]
    ss=str(s); oo=str(o)
    if rel=="BEFORE":
        return (
            ss in w["order_component"] and oo in w["order_component"] and
            w["order_component"][ss]==w["order_component"][oo] and
            w["order_rank"][ss] < w["order_rank"][oo]
        )
    if rel=="PART_OF":
        return (
            ss in w["containment_component"] and oo in w["containment_component"] and
            w["containment_component"][ss]==w["containment_component"][oo] and
            w["interval_low"][ss] > w["interval_low"][oo] and
            w["interval_high"][ss] < w["interval_high"][oo]
        )
    if rel=="ASSIGNED_TO":
        return ss in w["assignment_zone"] and int(w["assignment_zone"][ss])==o
    if rel=="LOCATED_IN":
        return ss in w["location"] and int(w["location"][ss])==o
    return False

def challenge_set(run,w,variant):
    challenged=set()
    for fact in run["final"]:
        if run["is_input"].get(fact,False):continue
        if witness_valid(fact,w):continue
        if variant=="WITNESS_DIRECT":
            challenged.add(fact)
        else:
            sups=run["supports"].get(fact,set())
            rootroot=any(run["is_input"].get(l,False) and run["is_input"].get(r,False) for l,r in sups)
            if not rootroot:challenged.add(fact)
    return challenged

def justification_dag(run,challenged):
    active={f for f,v in run["is_input"].items() if v and f not in challenged}
    changed=True
    while changed:
        changed=False
        for fact in run["final"]:
            if fact in active or fact in challenged or run["is_input"].get(fact,False):continue
            for l,r in run["supports"].get(fact,set()):
                if l in active and r in active:
                    active.add(fact);changed=True;break
    return active

def score_case(seed,fx,model,w,expected=None,surface="CONFIRMATION"):
    run=audited_run(model,fx)
    baseline_equiv=True
    if expected is not None:
        recall=len(run["final"]&run["gold"])/len(run["gold"])
        baseline_equiv=(
            len(run["bad"])==expected["baseline_bad_packet_count"] and
            len(run["final"]-run["gold"])==expected["baseline_false_positive_facts"] and
            abs(recall-expected["baseline_recall"])<1e-12
        )
    variants={}
    for v in ("WITNESS_DIRECT","WITNESS_DIRECT_AND_SUPPORT"):
        ch=challenge_set(run,w,v)
        active=justification_dag(run,ch)
        bad_after=active-run["gold"]; fn=run["gold"]-active
        variants[v]={
            "challenged_fact_count":len(ch),
            "challenged_bad_fact_count":len(ch & run["bad"]),
            "challenged_valid_fact_count":len(ch & run["gold"]),
            "challenge_precision":1.0 if not ch else len(ch&run["bad"])/len(ch),
            "bad_fact_challenge_recall":1.0 if not run["bad"] else len(ch&run["bad"])/len(run["bad"]),
            "active_bad_fact_count_after_rollback":len(bad_after),
            "false_negative_fact_count_after_rollback":len(fn),
            "oracle_valid_recall_after_rollback":len(active&run["gold"])/len(run["gold"]),
            "exact_graph_match_after_rollback":active==run["gold"],
        }
    return {
        "surface":surface,"seed":seed,"fixture_id":fx["fixture_id"],"family":fx["family"],"scale":fx["scale"],
        "baseline_equivalence_pass":baseline_equiv,
        "baseline_bad_fact_count":len(run["bad"]),
        "baseline_fact_count":len(run["final"]),
        "gold_fact_count":len(run["gold"]),
        "rounds":run["rounds"],"pair_evaluations":run["pair_evaluations"],
        "variants":variants
    }

models={s:load_model(s) for s in (13,29,61)}
case_results=[]
t0=time.time()

# Known failures.
for c in known_suite["cases"]:
    fx=p2b_map[c["fixture_id"]]
    case_results.append(score_case(c["seed"],fx,models[c["seed"]],wmap[fx["fixture_id"]],expected=c,surface="KNOWN"))

# Fresh confirmation.
for seed in (13,29,61):
    for fid in suite["confirmation_fixture_ids"]:
        fx=p2e_map[fid]
        case_results.append(score_case(seed,fx,models[seed],wmap[fid],surface="CONFIRMATION"))

print("scored",len(case_results),"cases in",round(time.time()-t0,2),"s")

known=[c for c in case_results if c["surface"]=="KNOWN"]
conf=[c for c in case_results if c["surface"]=="CONFIRMATION"]
known_equiv=all(c["baseline_equivalence_pass"] for c in known)

def agg(sub,v):
    rs=[c["variants"][v] for c in sub]
    return {
        "case_count":len(rs),
        "exact_after_rollback_count":sum(r["exact_graph_match_after_rollback"] for r in rs),
        "active_bad_after_total":sum(r["active_bad_fact_count_after_rollback"] for r in rs),
        "valid_false_challenges_total":sum(r["challenged_valid_fact_count"] for r in rs),
        "challenged_bad_total":sum(r["challenged_bad_fact_count"] for r in rs),
        "challenge_count_total":sum(r["challenged_fact_count"] for r in rs),
        "aggregate_challenge_precision":1.0 if sum(r["challenged_fact_count"] for r in rs)==0 else sum(r["challenged_bad_fact_count"] for r in rs)/sum(r["challenged_fact_count"] for r in rs),
        "min_post_rollback_recall":min(r["oracle_valid_recall_after_rollback"] for r in rs),
    }

summary={}
for v in ("WITNESS_DIRECT","WITNESS_DIRECT_AND_SUPPORT"):
    summary[v]={"known":agg(known,v),"confirmation":agg(conf,v),"all":agg(case_results,v)}
    a=summary[v]["all"]
    summary[v]["success_gate_pass"]=(
        summary[v]["known"]["exact_after_rollback_count"]==9 and
        summary[v]["confirmation"]["exact_after_rollback_count"]==90 and
        a["active_bad_after_total"]==0 and
        a["valid_false_challenges_total"]==0 and
        a["min_post_rollback_recall"]==1.0
    )

if not known_equiv:
    terminal="EXPERIMENT_INVALID"
elif any(summary[v]["success_gate_pass"] for v in summary):
    terminal="INDEPENDENT_WITNESS_VERIFICATION_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif any(summary[v]["known"]["exact_after_rollback_count"]==9 for v in summary):
    terminal="PARTIAL"
else:
    terminal="INDEPENDENT_WITNESS_INSUFFICIENT"

results={
    "experiment":"PRIMITIVE-2F","version":"0.1.1","terminal_verdict":terminal,
    "freeze_sha256":freeze["freeze_sha256"],
    "known_baseline_equivalence":"PASS" if known_equiv else "FAIL",
    "case_count":len(case_results),
    "known_case_count":len(known),"confirmation_case_count":len(conf),
    "confirmation_baseline_corrupted_case_count":sum(c["baseline_bad_fact_count"]>0 for c in conf),
    "verifier_summary":summary,
    "cases":case_results
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2F_RESULTS.json").write_text(json.dumps(results,indent=2))

print("terminal:",terminal)
print(json.dumps(summary,indent=2))