# PRIMITIVE-2F Conclusion

**Terminal verdict:** `INDEPENDENT_WITNESS_VERIFICATION_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Result

`WITNESS_DIRECT` passed the complete frozen gate:

```text
known corrupted cases repaired:       9/9
fresh confirmation cases exact:       90/90
bad facts active after rollback:       0
oracle-valid facts challenged:         0
aggregate challenge precision:         1.000000
minimum oracle-valid recall:            1.000000
exact deterministic result replay:      PASS
```

It challenged exactly 375 derived semantic facts, and every one was oracle-invalid.

## What changed relative to PRIMITIVE-2E

The verifier did not ask the thought-producing model for another opinion.

It checked candidate facts against separately supplied numeric world state:

```text
BEFORE      → same order component + rank(subject) < rank(object)
PART_OF     → same containment component + strict interval containment
ASSIGNED_TO → environment assignment label matches object
LOCATED_IN  → environment location label matches object
```

The witness ledger was generated from immutable environment roots before learned inference and was not influenced by model outputs.

## Why the second candidate failed

`WITNESS_DIRECT_AND_SUPPORT` demanded extra suspicion before challenging a witness violation.

It left:

```text
bad facts active: 8
exact cases:      91/99
```

The extra rule protected some first-order model mistakes because those mistakes had been produced directly from immutable roots.

This is an important distinction:

> A clean derivation history does not make a conclusion true when independent world evidence contradicts it.

## Supported claim

Within the frozen acyclic synthetic worlds:

> Independently supplied numeric world constraints can generate perfect challenge signals for the tested learned packet errors, and the unchanged PRIMITIVE-2D justification DAG can then restore exact epistemic state with no loss of valid recall.

## What this does not prove

The external witness state is deliberately strong.

PRIMITIVE-2F does not establish that:

- every real-world thought has an independent witness;
- witness data is always correct;
- open-world truth can be reduced to rank, containment, assignment, or location labels;
- cyclic BEFORE semantics are solved;
- witness acquisition is free;
- a verifier can invent the right experiment or observation by itself.

The result establishes the architectural value of genuinely independent evidence, not universal truth detection.

## New largest gap

The remaining problem is no longer whether independent evidence can repair self-generated error.

It can, in this tested setting.

The next question is:

> Can the system decide what independent evidence to seek, and acquire it economically, when the required witness is not already present?

That is an active verification / experiment-selection problem rather than another confidence-calibration problem.
