# PRIMITIVE-2F Results

**Terminal verdict:** `INDEPENDENT_WITNESS_VERIFICATION_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Known baseline equivalence:** `PASS`  
**Exact deterministic replay:** `PASS`  
**Cases:** 99 = 9 known failures + 90 fresh confirmation cases  
**Fresh confirmation cases with baseline corruption:** 4/90

| Verifier | Known exact | Confirmation exact | Bad after | Valid challenges | Challenge precision | Min final recall | Gate |
|---|---:|---:|---:|---:|---:|---:|---|
| WITNESS_DIRECT | 9/9 | 90/90 | 0 | 0 | 1.000000 | 1.000000 | PASS |
| WITNESS_DIRECT_AND_SUPPORT | 3/9 | 88/90 | 8 | 0 | 1.000000 | 1.000000 | FAIL |
