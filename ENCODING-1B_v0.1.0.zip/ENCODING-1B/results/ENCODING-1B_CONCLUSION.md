# ENCODING-1B Conclusion

**Terminal verdict:** `REPLICATED_DIRECTION_NOT_THRESHOLD`

The held-out generator removed fixed periodic ACT/RELATION runs while preserving their expected run lengths:

```text
ACT expected run length      = 8
RELATION expected run length = 4
```

Exact reproduction of the parent 4/6 thresholds occurred in **203/243** base conditions.
Batching still crossed and became cheaper somewhere in `2..31` in **243/243** base conditions.

Threshold distribution:

```json
{
  "4": 162,
  "5": 34,
  "6": 41,
  "7": 4,
  "8": 2
}
```

By packet count:

```json
{
  "64": {
    "6": 41,
    "5": 34,
    "8": 2,
    "7": 4
  },
  "1024": {
    "4": 81
  },
  "16384": {
    "4": 81
  }
}
```

No semantic field changed. Any threshold movement is attributable to the held-out repetition structure and finite traffic effects within the frozen generator.
