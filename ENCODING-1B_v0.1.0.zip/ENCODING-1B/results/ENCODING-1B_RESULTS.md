# ENCODING-1B Results

**Terminal verdict:** `REPLICATED_DIRECTION_NOT_THRESHOLD`  
**Scored regimes:** 7290  
**Base conditions:** 243  
**Replay:** `PASS`

## Threshold histogram

- **4:** 162
- **5:** 34
- **6:** 41
- **7:** 4
- **8:** 2

## By packet count

- **64:** {"5": 34, "6": 41, "7": 4, "8": 2}
- **1024:** {"4": 81}
- **16384:** {"4": 81}

Exact parent 4/6 threshold matches: **203/243**
Batching still crosses within 2..31: **243/243**
