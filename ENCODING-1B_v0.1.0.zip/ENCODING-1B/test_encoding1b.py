#!/usr/bin/env python3
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
g=json.loads((HERE/"ENCODING-1B_GRID.json").read_text())
r=json.loads((HERE/"results"/"ENCODING-1B_RESULTS.json").read_text())
assert g["grid_sha256"]=="bd3df5835daa75f6c249a6480f35308a9c46095f05a1c13d3efefdfd4ef490b4"
assert g["heldout_generator_sha256"]=="14ad638d39551612be86fe33836b3dd5f45b83a7868d8decadb933b278925673"
assert r["grid_sha256"]==g["grid_sha256"]
assert r["heldout_generator_sha256"]==g["heldout_generator_sha256"]
assert r["scenario_count"]==7290
assert r["base_condition_count"]==243
assert r["replay"]=="PASS"
assert sum(r["threshold_histogram"].values())==243
print("ENCODING_1B_TEST_PASS")
