# ENCODING-1B METHOD

1. Freeze the ENCODING-1A traffic envelope unchanged.
2. Replace only ACT/RELATION repetition structure.
3. Keep expected ACT run length at 8 and expected RELATION run length at 4.
4. Use independent deterministic RNG streams for ACT and RELATION.
5. Keep SUBJECT/OBJECT/VALUE traffic on the parent generator stream.
6. Score VARINT_INBAND and BATCH_INBAND for every batch size 2..31.
7. Replay every base traffic condition and require exact byte accounting.
8. Compare first strict batch-win threshold to the preregistered parent 4/6 result.
