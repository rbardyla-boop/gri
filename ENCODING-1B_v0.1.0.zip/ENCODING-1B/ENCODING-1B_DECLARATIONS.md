# ENCODING-1B — HELD-OUT REPETITION REPLICATION

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Parent:** ENCODING-1A v0.1.0  
**Parent grid SHA-256:** `bd3df5835daa75f6c249a6480f35308a9c46095f05a1c13d3efefdfd4ef490b4`  
**ENCODING-1B grid SHA-256:** `bd3df5835daa75f6c249a6480f35308a9c46095f05a1c13d3efefdfd4ef490b4`  
**Held-out generator SHA-256:** `14ad638d39551612be86fe33836b3dd5f45b83a7868d8decadb933b278925673`

## Question

> Do the ENCODING-1A batch crossover thresholds survive a held-out traffic generator with different repetition structure?

This is a replication test, not a new search.

## Semantic primitive

Unchanged:

```text
STABLE_REFERENCE
ACT
SUBJECT
RELATION
OBJECT
VALUE
```

No field may be added, removed, or reinterpreted.

## Profiles

Only:

```text
VARINT_INBAND
BATCH_INBAND
```

## Frozen traffic envelope

Exactly ENCODING-1A:

```text
packet_count               = [64, 1024, 16384]
symbol_cardinality         = [32, 512, 8192]
new_symbol_rate            = [0.0, 0.05, 0.5]
batch_size                 = 2..31
session_lifetime           = [128, 2048, 16384]
dictionary_reset_frequency = [0, 256, 4096]
```

Total:

```text
243 base traffic conditions × 30 batch sizes = 7290
```

## Held-out repetition generator

Parent ENCODING-1/1A used fixed periodic repetition:

```text
ACT run length      = exactly 8
RELATION run length = exactly 4
```

ENCODING-1B replaces only that structure.

Held-out generator:

```text
ACT:
  geometric/irregular runs
  probability of changing each packet = 1/8
  expected run length = 8

RELATION:
  geometric/irregular runs
  probability of changing each packet = 1/4
  expected run length = 4
```

When a change occurs, a new code is chosen uniformly from the remaining values.

Therefore average repetition is intentionally matched to the parent while periodicity is removed.

## Isolation rule

ACT and RELATION use separate deterministic RNG streams.

SUBJECT, OBJECT, and VALUE continue to use the parent generator logic and parent seed basis without consuming the new ACT/RELATION RNG streams.

This is intended to isolate repetition structure rather than accidentally changing the symbol/value traffic.

## Scoring

For each base traffic condition and batch size:

```text
delta = BATCH_INBAND_bytes - VARINT_INBAND_bytes
```

Record:

```text
FIRST_WIN_BATCH_SIZE
FIRST_TIE_BATCH_SIZE
delta_bytes_by_batch_size
```

## Replication verdict

The specific prior result being tested is:

```text
packet_count = 64      → first strict batching win at 6
packet_count = 1,024   → first strict batching win at 4
packet_count = 16,384  → first strict batching win at 4
```

Terminal interpretation:

```text
REPLICATED_EXACTLY
REPLICATED_DIRECTION_NOT_THRESHOLD
NOT_REPLICATED
EXPERIMENT_INVALID
```

`REPLICATED_DIRECTION_NOT_THRESHOLD` means batching still crosses and remains superior at larger batch sizes, but the exact 4/6 thresholds move.

## Validity

Invalid if:

- primitive semantics change;
- parent non-batch levels change;
- batch range changes;
- dictionary accounting changes;
- ACT/RELATION generator is modified after scoring;
- SUBJECT/OBJECT/VALUE generator consumes ACT/RELATION randomness;
- deterministic replay diverges.
