# ENCODING-1A Conclusion

**Status:** COMPLETE WITHIN FROZEN BATCH RANGE `2..31`  
**Scored regimes:** 7,290  
**Base non-batch traffic conditions:** 243  
**Deterministic replay:** PASS  
**Standalone regeneration:** PASS

## Resolved crossover

The crossover is traffic-regime dependent, but the dependence is entirely explained by `packet_count` inside the frozen grid:

```text
packet_count = 64
first strict BATCH_INBAND win = batch size 6
81 / 81 conditions

packet_count = 1,024
first strict BATCH_INBAND win = batch size 4
81 / 81 conditions

packet_count = 16,384
first strict BATCH_INBAND win = batch size 4
81 / 81 conditions
```

Therefore:

```text
64-packet runs:
batch 2..5  → VARINT_INBAND
batch 6..31 → BATCH_INBAND

1,024+ packet runs within this envelope:
batch 2..3  → VARINT_INBAND
batch 4..31 → BATCH_INBAND
```

There were **no ties** in the tested range.

Once batching first won, it never lost again through batch size 31 in any of the 243 base traffic conditions.

## Variables that did not move the crossover threshold

Within their frozen ENCODING-1 levels:

```text
symbol_cardinality
new_symbol_rate
session_lifetime
dictionary_reset_frequency
```

did not change whether the first strict batching win occurred at 4 or 6.

Each of these axes contains the same threshold mixture solely because it is crossed with the packet-count levels:

```text
54 conditions at threshold 4
27 conditions at threshold 6
```

per level.

## Near-boundary evidence

At batch size 4:

```text
BATCH wins: 162
VARINT wins: 81
```

At batch size 5:

```text
BATCH wins: 162
VARINT wins: 81
```

At batch size 6:

```text
BATCH wins: 243
VARINT wins: 0
```

The 64-packet cases are very close at batch 5: the worst observed batch-minus-varint delta is only `+1 byte`. At batch 6 the worst delta becomes `-3 bytes`.

## Scientific boundary

No semantic primitive changed.

ENCODING-1A resolves only the previously unknown `2..31` batch crossover in the frozen synthetic traffic envelope. It does not establish that batch size 4 or 6 is optimal for arbitrary real workloads.

The next question, if pursued, should not add another encoding mechanism. It should test whether these crossover thresholds survive a held-out traffic generator with different repetition structure.
