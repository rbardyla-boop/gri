#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(HERE/"run_encoding1a.py")],check=True,stdout=subprocess.DEVNULL)
a=json.loads((HERE/"results"/"ENCODING-1A_RESULTS.json").read_text())
b=json.loads((HERE/"results"/"ENCODING-1A_RESULTS_RERUN.json").read_text())
a.pop("results_sha256",None); b.pop("results_sha256",None)
assert a==b
assert a["scenario_count"]==7290
assert a["base_condition_count"]==243
assert a["threshold_histogram"]=={"4":162,"6":81}
assert a["first_tie_histogram"]=={"NONE":243}
assert a["non_monotonic_after_first_win_count"]==0
print("ENCODING_1A_TEST_PASS")
