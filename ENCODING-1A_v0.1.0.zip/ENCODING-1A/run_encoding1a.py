#!/usr/bin/env python3
from __future__ import annotations
import hashlib, itertools, json, math, statistics
from pathlib import Path

HERE=Path(__file__).resolve().parent
GRID_PATH=HERE/"ENCODING-1A_GRID.json"
OUT=HERE/"results"/"ENCODING-1A_RESULTS_RERUN.json"

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def uv_len(n):
    if n<0: raise ValueError("negative")
    for i,b in enumerate((7,14,21,28,35,42,49,56,63),1):
        if n < (1<<b): return i
    return 10
def zz(n): return (n<<1) if n>=0 else ((-n<<1)-1)

class LCG:
    def __init__(self,seed): self.state=seed & 0xFFFFFFFFFFFFFFFF
    def next_u64(self):
        self.state=(6364136223846793005*self.state+1442695040888963407)&0xFFFFFFFFFFFFFFFF
        return self.state
    def frac(self): return self.next_u64()/2**64
    def randint(self,n): return self.next_u64()%n

NONBATCH=["packet_count","symbol_cardinality","new_symbol_rate","session_lifetime","dictionary_reset_frequency"]

def seed(params):
    s="|".join(str(params[k]) for k in NONBATCH)
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],"big")

def rle_interval(start,end,period):
    runs=1+(end//period)-(start//period)
    return uv_len(runs)+2*runs

def generate_base(params):
    n=params["packet_count"]; card=params["symbol_cardinality"]; rate=params["new_symbol_rate"]
    session=params["session_lifetime"]; reset=params["dictionary_reset_frequency"]
    rng=LCG(seed(params))
    known=list(range(1,min(card,8)+1)); next_new=len(known)+1
    d={}; next_code=1; session_start=1; seg_start=1
    dict_bytes=0; var_payload=0; sov=[0]*(n+1); segments=[]
    for i in range(1,n+1):
        if i==1 or ((i-1)%session==0):
            if i>seg_start: segments.append((seg_start,i-1))
            seg_start=i; d={}; next_code=1; session_start=i
        elif reset and ((i-session_start)%reset==0):
            if i>seg_start: segments.append((seg_start,i-1))
            seg_start=i; d={}; next_code=1
        codes=[]
        for _ in range(2):
            introduce=(next_new<=card) and (rng.frac()<rate)
            if introduce:
                sym=next_new; known.append(sym); next_new+=1
            else:
                sym=known[rng.randint(len(known))]
            if sym not in d:
                d[sym]=next_code
                dict_bytes += 1+uv_len(next_code)+uv_len(sym)
                next_code += 1
            codes.append(d[sym])
        act=1+((i//8)%8); rel=1+((i//4)%16)
        val=int((rng.next_u64()%2001)-1000)
        sov[i]=uv_len(codes[0])+uv_len(codes[1])+uv_len(zz(val))
        var_payload += uv_len(i)+uv_len(act)+uv_len(codes[0])+uv_len(rel)+uv_len(codes[1])+uv_len(zz(val))
    if seg_start<=n: segments.append((seg_start,n))
    pref=[0]*(n+1)
    for i in range(1,n+1): pref[i]=pref[i-1]+sov[i]
    return {"n":n,"dict":dict_bytes,"var_total":dict_bytes+var_payload,"segments":segments,"pref":pref}

def batch_total(base,b):
    payload=0; pref=base["pref"]
    for a,z in base["segments"]:
        s=a
        while s<=z:
            e=min(z,s+b-1); k=e-s+1
            cost=uv_len(k)+uv_len(s)+(k-1)
            cost+=rle_interval(s,e,8)+rle_interval(s,e,4)
            cost+=pref[e]-pref[s-1]
            payload+=cost; s=e+1
    return base["dict"]+payload

def build():
    gd=json.loads(GRID_PATH.read_text())
    grid=gd["grid"]
    got=hashlib.sha256(canon(grid).encode()).hexdigest()
    if got!=gd["grid_sha256"]: raise RuntimeError("grid hash mismatch")
    base_grid={k:grid[k] for k in NONBATCH}
    base_conditions=[]; rows=[]; th={}; tieh={}
    for vals in itertools.product(*(base_grid[k] for k in NONBATCH)):
        params=dict(zip(NONBATCH,vals))
        x=generate_base(params); y=generate_base(params)
        if x!=y: raise RuntimeError("base replay mismatch")
        v=x["var_total"]; deltas={}; fw=None; ft=None
        for b in range(2,32):
            one=batch_total(x,b); two=batch_total(y,b)
            if one!=two: raise RuntimeError("batch replay mismatch")
            delta=one-v; deltas[str(b)]=delta
            if delta==0 and ft is None: ft=b
            if delta<0 and fw is None: fw=b
            rows.append({**params,"batch_size":b,"varint_bytes":v,"batch_bytes":one,"delta_bytes":delta,
                         "winner":"BATCH_INBAND" if delta<0 else ("TIE" if delta==0 else "VARINT_INBAND")})
        th[str(fw) if fw is not None else "NONE"]=th.get(str(fw) if fw is not None else "NONE",0)+1
        tieh[str(ft) if ft is not None else "NONE"]=tieh.get(str(ft) if ft is not None else "NONE",0)+1
        base_conditions.append({"params":params,"varint_bytes":v,"first_tie_batch_size":ft,
                                "first_win_batch_size":fw,"delta_bytes_by_batch_size":deltas})
    bs={}
    for b in range(2,32):
        sub=[r for r in rows if r["batch_size"]==b]; ds=[r["delta_bytes"] for r in sub]
        bs[str(b)]={"batch_wins":sum(x<0 for x in ds),"ties":sum(x==0 for x in ds),
                    "varint_wins":sum(x>0 for x in ds),"min_delta_bytes":min(ds),
                    "median_delta_bytes":statistics.median(ds),"max_delta_bytes":max(ds)}
    nonmono=[]
    for bc in base_conditions:
        won=False
        for b in range(2,32):
            d=bc["delta_bytes_by_batch_size"][str(b)]
            if d<0: won=True
            elif won and d>0:
                nonmono.append({"params":bc["params"],"batch_size":b,"delta":d}); break
    r={"experiment":"ENCODING-1A","version":"0.1.0","parent_grid_sha256":gd["parent_grid_sha256"],
       "grid_sha256":gd["grid_sha256"],"scenario_count":len(rows),"base_condition_count":len(base_conditions),
       "replay":"PASS","threshold_histogram":dict(sorted(th.items(),key=lambda kv:999 if kv[0]=="NONE" else int(kv[0]))),
       "first_tie_histogram":dict(sorted(tieh.items(),key=lambda kv:999 if kv[0]=="NONE" else int(kv[0]))),
       "batch_size_summary":bs,"non_monotonic_after_first_win_count":len(nonmono),
       "non_monotonic_examples":nonmono[:10],"base_conditions":base_conditions}
    r["results_sha256"]=hashlib.sha256(canon(r).encode()).hexdigest()
    return r

if __name__=="__main__":
    r=build()
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text(json.dumps(r,indent=2))
    print("ENCODING_1A_RERUN_PASS")
    print("scenarios",r["scenario_count"])
    print("threshold_histogram",json.dumps(r["threshold_histogram"],sort_keys=True))
