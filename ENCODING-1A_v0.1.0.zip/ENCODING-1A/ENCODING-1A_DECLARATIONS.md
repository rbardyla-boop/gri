# ENCODING-1A — BATCH CROSSOVER RESOLUTION

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Parent:** ENCODING-1 v0.1.0  
**Parent grid SHA-256:** `3728dc811af1d514f1a371486bcb18de53f670612f87150a2af1e971e0c07995`  
**ENCODING-1A grid SHA-256:** `bd3df5835daa75f6c249a6480f35308a9c46095f05a1c13d3efefdfd4ef490b4`

## Question

> Between batch size 2 and 31, where does `BATCH_INBAND` first beat `VARINT_INBAND` while the semantic primitive and all other ENCODING-1 traffic variables remain fixed?

## Semantic primitive

Unchanged:

```text
STABLE_REFERENCE
ACT
SUBJECT
RELATION
OBJECT
VALUE
```

No field may be added, removed, or reinterpreted.

## Profiles under test

Only the unresolved pair is authorized:

```text
VARINT_INBAND
BATCH_INBAND
```

Fixed-width and external-handle profiles are not rescored because ENCODING-1 already established that they never strictly beat `VARINT_INBAND` in the parent envelope. ENCODING-1A is not authorized to reopen those questions.

## Frozen variables

The five non-batch axes are byte-for-byte inherited from ENCODING-1:

```text
packet_count               = [64, 1024, 16384]
symbol_cardinality         = [32, 512, 8192]
new_symbol_rate            = [0.0, 0.05, 0.5]
session_lifetime           = [128, 2048, 16384]
dictionary_reset_frequency = [0, 256, 4096]
```

Only batch resolution changes:

```text
batch_size = 2..31 inclusive
```

Full Cartesian product:

```text
3^5 × 30 = 7290 scored regimes
```

The 243 unique non-batch traffic conditions each receive all 30 batch sizes.

## Traffic generator and protocol

Exactly the ENCODING-1 generator/protocol:

- 8 fixed ACT symbols;
- 16 fixed RELATION symbols;
- deterministic semantic symbol introduction controlled by `new_symbol_rate`;
- session-local SUBJECT/OBJECT dictionary;
- dictionary update cost charged before first use;
- session boundaries reset dictionary state;
- periodic dictionary reset behaves exactly as ENCODING-1;
- stable references remain global monotonic packet identities;
- batches never cross session or dictionary-reset boundaries.

## Primary result

For each of the 243 non-batch traffic conditions record:

```text
FIRST_WIN_BATCH_SIZE =
smallest b in [2,31] such that
BATCH_INBAND_bytes(b) < VARINT_INBAND_bytes
```

Also record:

```text
FIRST_TIE_BATCH_SIZE
delta_bytes_by_batch_size
```

If batching never wins in [2,31]:

```text
FIRST_WIN_BATCH_SIZE = NONE_WITHIN_TESTED_RANGE
```

## Determinism

Same traffic condition + same batch size must reproduce identical packet stream accounting and byte totals.

## Validity

`EXPERIMENT_INVALID` if:

- any parent non-batch level changes;
- a batch size outside 2..31 is scored;
- dictionary update cost differs from ENCODING-1;
- batch crosses a session/reset boundary;
- semantics change;
- replay diverges.
