#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,itertools,math,copy,sys

ROOT=Path(__file__).resolve().parent.parent
PARENT=Path("/mnt/data/PRIMITIVE-2S")
NORM=ROOT/"normalization"

def canon(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_obj(v): return hashlib.sha256(canon(v).encode()).hexdigest()

CF=json.loads((PARENT/"results"/"PRIMITIVE-2S_CANDIDATE_FREEZE.json").read_text())
PUB=json.loads((PARENT/"fixtures"/"PRIMITIVE-2S_PUBLIC_WORLDS.json").read_text())
DISC=PUB["discovery_inputs"]

RAW_SINGLE=[]
RAW_SINGLE += [["CMP_TOK",k] for k in range(5)]
RAW_SINGLE += [["CMP_REG_ZERO",r] for r in (0,1)]
RAW_SINGLE += [["CMP_REG_POS",r] for r in (0,1)]
RAW_SINGLE += [["ADD_IMM",r,d] for r in (0,1) for d in (-1,1)]
RAW_SINGLE += [["SET_IMM",r,0] for r in (0,1)]
RAW_SINGLE += [["ADVANCE"]]

def signed_bits(v):
    return max(1,math.ceil(math.log2(abs(v)+2))+1)

def edges(cfg):
    e={}
    for k,b in cfg["blocks"].items():
        u=int(k);t=b["term"]
        if t[0]=="JMP":
            e[u]=[t[1]] if t[1]!="HALT" else []
        elif t[0]=="JZ":
            e[u]=[x for x in t[1:] if x!="HALT"]
        else:
            e[u]=[]
    return e

def reachable(cfg):
    E=edges(cfg);seen=set();q=[cfg.get("entry",0)]
    while q:
        u=q.pop()
        if u in seen or u not in E: continue
        seen.add(u);q.extend(E[u])
    return seen

def prune_unreachable(cfg):
    c=json.loads(json.dumps(cfg))
    R=reachable(c)
    c["blocks"]={str(k):c["blocks"][str(k)] for k in sorted(R)}
    return c

def simple_cycles(cfg):
    E=edges(cfg);R=sorted(reachable(cfg));found=set()
    def canonical(c):
        rots=[tuple(c[i:]+c[:i]) for i in range(len(c))]
        return min(rots)
    for st in R:
        def dfs(u,path):
            for v in E.get(u,[]):
                if v==st:
                    found.add(canonical(path))
                elif v not in path and len(path)<len(R):
                    dfs(v,path+[v])
        dfs(st,[st])
    return sorted(found)

def certify_cycle(cfg,cyc):
    bodies=[ins for u in cyc for ins in cfg["blocks"][str(u)]["body"]]
    if any(i[0]=="ADVANCE" for i in bodies):
        for u in cyc:
            b=cfg["blocks"][str(u)]
            if ["CMP_TOK",4] in b["body"] and "HALT" in b["term"][1:]:
                return {"type":"INPUT_REMAINING","rank":"remaining_unread_tokens"}
        return None
    for r in (0,1):
        has_zero=any(i==["CMP_REG_ZERO",r] for i in bodies)
        has_dec=any(i==["ADD_IMM",r,-1] for i in bodies)
        forbidden=any(
            (i[0]=="ADD_IMM" and i[1]==r and i[2]>0) or
            (i[0]=="SET_IMM" and i[1]==r)
            for i in bodies
        )
        outside=[ins for u in reachable(cfg) if u not in cyc for ins in cfg["blocks"][str(u)]["body"]]
        outside_dec=any(i==["ADD_IMM",r,-1] for i in outside)
        if has_zero and has_dec and not forbidden and not outside_dec:
            return {"type":"REGISTER_DESCENT","rank":f"register_{r}"}
    return None

def halting_ok(cfg):
    return all(certify_cycle(cfg,c) is not None for c in simple_cycles(cfg))

def execute(cfg,tokens,cap=20000):
    regs=[0,0];ip=0;flag=False;pc=cfg.get("entry",0);steps=0
    peak=[signed_bits(0),signed_bits(0)]
    while pc!="HALT":
        if steps>=cap or str(pc) not in cfg["blocks"]:
            return None,{"halted":False,"steps":steps}
        b=cfg["blocks"][str(pc)]
        for ins in b["body"]:
            steps+=1
            op=ins[0]
            if op=="CMP_TOK":
                flag=((tokens[ip] if ip<len(tokens) else 4)==ins[1])
            elif op=="CMP_REG_ZERO":
                flag=(regs[ins[1]]==0)
            elif op=="CMP_REG_POS":
                flag=(regs[ins[1]]>0)
            elif op=="ADD_IMM":
                regs[ins[1]]+=ins[2]
                peak[ins[1]]=max(peak[ins[1]],signed_bits(regs[ins[1]]))
            elif op=="SET_IMM":
                regs[ins[1]]=0
            elif op=="ADVANCE":
                ip=min(ip+1,len(tokens))
            else:
                raise ValueError(op)
        steps+=1
        t=b["term"]
        if t[0]=="JMP": pc=t[1]
        elif t[0]=="JZ": pc=t[1] if not flag else t[2]
        elif t[0]=="HALT": pc="HALT"
        else: raise ValueError(t[0])
    out=[]
    for typ,r in cfg["readouts"]:
        out.append(int(regs[r]==0) if typ=="EQ_ZERO" else int(regs[r]>0))
    R=len(reachable(cfg))
    pointer_bits=max(1,math.ceil(math.log2(len(tokens)+1))) if tokens else 1
    pc_bits=max(1,math.ceil(math.log2(R+1)))
    state_bits=sum(peak)+pointer_bits+pc_bits+1
    return out,{"halted":True,"steps":steps,"state_bits":state_bits}

def structural_cost_parts(cfg):
    cfg=prune_unreachable(cfg)
    R=reachable(cfg);description=0.0;edge_count=0;halt_used=False
    for u in R:
        b=cfg["blocks"][str(u)]
        description += 0.1+len(b["body"])+1.0
        t=b["term"]
        targets=t[1:] if t[0]=="JZ" else (t[1:] if t[0]=="JMP" else [])
        for v in targets:
            edge_count+=1
            if v=="HALT":halt_used=True
    vertex_count=len(R)+(1 if halt_used else 0)
    M=max(0,edge_count-vertex_count+2) if vertex_count else 0
    return description,M

def evaluate_public(cfg,gold=None):
    cfg=prune_unreachable(cfg)
    if not halting_ok(cfg):
        return {"halting":False,"cost":float("inf"),"outputs":None,"first_failure":0 if gold is not None else None}
    description,M=structural_cost_parts(cfg)
    rt=0;st=0;outs=[];first=None
    for i,seq in enumerate(DISC):
        o,m=execute(cfg,seq)
        if not m["halted"]:
            return {"halting":False,"cost":float("inf"),"outputs":None,"first_failure":i if gold is not None else None}
        outs.append(o);rt+=m["steps"];st=max(st,m["state_bits"])
        if gold is not None and first is None and o!=gold[i]:first=i
    cost=description+0.5*M+0.02*(rt/len(DISC))+st
    return {"halting":True,"cost":cost,"outputs":outs,"first_failure":first}

def cfg_cost(cfg,corpus=DISC):
    if corpus is DISC:
        return evaluate_public(cfg)["cost"]
    # retained for API completeness; normalization itself uses DISC.
    cfg=prune_unreachable(cfg)
    if not halting_ok(cfg):return float("inf")
    description,M=structural_cost_parts(cfg);rt=0;st=0
    for seq in corpus:
        _,m=execute(cfg,seq)
        if not m["halted"]:return float("inf")
        rt+=m["steps"];st=max(st,m["state_bits"])
    return description+0.5*M+0.02*(rt/len(corpus))+st

def exact_on_indices_from_outputs(outputs,gold,indices):
    return outputs is not None and all(outputs[i]==gold[i] for i in indices)

def exact_on_indices(cfg,gold,indices):
    ev=evaluate_public(cfg,gold)
    if not ev["halting"]:return False
    return exact_on_indices_from_outputs(ev["outputs"],gold,indices)

def first_failure(cfg,gold):
    return evaluate_public(cfg,gold)["first_failure"]

def canonicalize(cfg):
    return prune_unreachable(cfg)

def predecessor_count(cfg):
    pred={u:0 for u in reachable(cfg)}
    for u,vs in edges(cfg).items():
        if u not in pred:continue
        for v in vs:
            if v in pred:pred[v]+=1
    return pred

def splice_delete(cfg,u,target):
    c=json.loads(json.dumps(cfg))
    if str(u) not in c["blocks"]:return None
    c["blocks"].pop(str(u))
    for b in c["blocks"].values():
        t=b["term"]
        if t[0]=="JMP" and t[1]==u:t[1]=target
        elif t[0]=="JZ":
            if t[1]==u:t[1]=target
            if t[2]==u:t[2]=target
    return canonicalize(c)

def neighbors(cfg):
    base=canonicalize(cfg);R=sorted(reachable(base));target_domain=R+["HALT"]
    out={}
    def add(edit,c):
        if c is None:return
        c=canonicalize(c)
        if str(c.get("entry",0)) not in c["blocks"]:return
        key=canon(c)
        if key==canon(base):return
        old=out.get(key);rec={"edit":edit,"cfg":c}
        if old is None or canon(edit)<canon(old["edit"]):out[key]=rec
    add({"type":"PRUNE_UNREACHABLE_BLOCKS"},prune_unreachable(cfg))
    for u in R:
        if u==base.get("entry",0):continue
        b=base["blocks"][str(u)];repl=[]
        for x in b["term"][1:]+["HALT"]:
            if x!=u and x not in repl:repl.append(x)
        for target in repl:add({"type":"DELETE_BASIC_BLOCK","block":u,"splice_target":target},splice_delete(base,u,target))
    for u in R:
        b=base["blocks"][str(u)];positions=[1] if b["term"][0]=="JMP" else ([1,2] if b["term"][0]=="JZ" else [])
        for pos in positions:
            for target in target_domain:
                if target==b["term"][pos]:continue
                c=json.loads(json.dumps(base));c["blocks"][str(u)]["term"][pos]=target
                add({"type":"REBIND_JUMP_TARGET","block":u,"term_position":pos,"target":target},c)
    for u in R:
        b=base["blocks"][str(u)]
        if b["term"][0]=="JZ":
            for pos in (1,2):
                c=json.loads(json.dumps(base));c["blocks"][str(u)]["term"]=["JMP",b["term"][pos]]
                add({"type":"COLLAPSE_JZ_TO_JMP","block":u,"chosen_branch":pos},c)
    pred=predecessor_count(base)
    for u in R:
        b=base["blocks"][str(u)]
        if b["term"][0]!="JMP":continue
        v=b["term"][1]
        if v=="HALT" or v==base.get("entry",0) or v not in R or pred.get(v,0)!=1:continue
        vb=base["blocks"][str(v)];merged=b["body"]+vb["body"]
        if len(merged)>2:continue
        c=json.loads(json.dumps(base));c["blocks"][str(u)]={"body":merged,"term":json.loads(json.dumps(vb["term"]))};c["blocks"].pop(str(v))
        for bb in c["blocks"].values():
            t=bb["term"]
            if t[0]=="JMP" and t[1]==v:t[1]=u
            elif t[0]=="JZ":
                if t[1]==v:t[1]=u
                if t[2]==v:t[2]=u
        add({"type":"CONTRACT_LINEAR_JMP_EDGE","from":u,"removed":v},c)
    for u in R:
        body=base["blocks"][str(u)]["body"];opts=[]
        if len(body)>=1:opts.append([])
        if len(body)>=2:opts.extend([[x] for x in RAW_SINGLE])
        for nb in opts:
            if nb==body:continue
            c=json.loads(json.dumps(base));c["blocks"][str(u)]["body"]=nb
            add({"type":"SHORTEN_BLOCK_PAYLOAD","block":u,"new_body":nb},c)
    return list(out.values())

def evaluated_neighbors(cfg,gold):
    vals=[]
    for n in neighbors(cfg):
        ev=evaluate_public(n["cfg"],gold)
        vals.append({**n,"eval":ev,"sha256":sha_obj(n["cfg"])})
    return vals

def dead_block_only(cfg):
    return prune_unreachable(cfg),[]

def greedy(cfg,gold):
    cur=canonicalize(cfg);trace=[]
    while True:
        cc=evaluate_public(cur,gold)["cost"]
        viable=[]
        for n in evaluated_neighbors(cur,gold):
            ev=n["eval"]
            if ev["cost"] < cc-1e-12 and ev["first_failure"] is None:
                viable.append((ev["cost"],canon(n["cfg"]),canon(n["edit"]),n))
        if not viable:break
        viable.sort();chosen=viable[0][3];nc=chosen["eval"]["cost"]
        trace.append({"edit":chosen["edit"],"before_cost":cc,"after_cost":nc,"candidate_sha256":chosen["sha256"]})
        cur=chosen["cfg"]
    return cur,trace

def anchors():
    return list(range(min(1+4+16,len(DISC))))

def cegis(cfg,gold):
    cur=canonicalize(cfg);trace=[];active=anchors();counterexamples=[]
    while True:
        current=evaluate_public(cur,gold);cc=current["cost"]
        pool=evaluated_neighbors(cur,gold)
        rejected=set();committed=False
        while True:
            viable=[]
            for n in pool:
                if n["sha256"] in rejected:continue
                ev=n["eval"]
                if ev["cost"] < cc-1e-12 and exact_on_indices_from_outputs(ev["outputs"],gold,active):
                    viable.append((ev["cost"],canon(n["cfg"]),canon(n["edit"]),n))
            if not viable:return cur,trace,counterexamples
            viable.sort();chosen=viable[0][3];ev=chosen["eval"]
            fail=ev["first_failure"]
            if fail is None:
                trace.append({"action":"COMMIT","edit":chosen["edit"],"before_cost":cc,"after_cost":ev["cost"],"active_count":len(active),"candidate_sha256":chosen["sha256"]})
                cur=chosen["cfg"]
                active=anchors()+[i for i in counterexamples if i not in anchors()]
                committed=True;break
            rejected.add(chosen["sha256"])
            if fail not in active:active.append(fail)
            if fail not in counterexamples:counterexamples.append(fail)
            trace.append({"action":"REJECT_WITH_COUNTEREXAMPLE","edit":chosen["edit"],"before_cost":cc,"proposed_cost":ev["cost"],"counterexample_index":fail,"active_count_after":len(active),"candidate_sha256":chosen["sha256"]})
        if not committed:break

def local_fixed_point(cfg,gold):
    cc=evaluate_public(cfg,gold)["cost"];cheaper=[]
    for n in evaluated_neighbors(cfg,gold):
        ev=n["eval"]
        if ev["cost"] < cc-1e-12 and ev["first_failure"] is None:
            cheaper.append({"edit":n["edit"],"cost":ev["cost"],"cfg_sha256":n["sha256"]})
    cheaper.sort(key=lambda x:(x["cost"],canon(x["edit"])))
    return {"pass":len(cheaper)==0,"base_cost":cc,"cheaper_exact_neighbors":cheaper[:20]}

def main():
    # Hard firewall: this source intentionally opens no audit or prior counterexample file.
    mechanisms={}
    traces={}
    fixed={}
    for name in ("NO_NORMALIZATION","DEAD_BLOCK_ONLY","GREEDY_STRICT_COST_DESCENT","CEGIS_TOPOLOGY_NORMALIZE"):
        mechanisms[name]=[];traces[name]=[];fixed[name]=[]
    for c in CF["candidates"]:
        wid=c["world_id"];orig=c["candidate_cfg"];gold=PUB["worlds"][wid]["discovery_outputs"]
        # Baseline
        b=canonicalize(orig)
        mechanisms["NO_NORMALIZATION"].append({"world_id":wid,"cfg":b,"sha256":sha_obj(b)})
        traces["NO_NORMALIZATION"].append({"world_id":wid,"trace":[]})
        fixed["NO_NORMALIZATION"].append({"world_id":wid,**local_fixed_point(b,gold)})
        # Dead-only
        d,tr=dead_block_only(orig)
        mechanisms["DEAD_BLOCK_ONLY"].append({"world_id":wid,"cfg":d,"sha256":sha_obj(d)})
        traces["DEAD_BLOCK_ONLY"].append({"world_id":wid,"trace":tr})
        fixed["DEAD_BLOCK_ONLY"].append({"world_id":wid,**local_fixed_point(d,gold)})
        # Greedy
        g,tr=greedy(orig,gold)
        mechanisms["GREEDY_STRICT_COST_DESCENT"].append({"world_id":wid,"cfg":g,"sha256":sha_obj(g)})
        traces["GREEDY_STRICT_COST_DESCENT"].append({"world_id":wid,"trace":tr})
        fixed["GREEDY_STRICT_COST_DESCENT"].append({"world_id":wid,**local_fixed_point(g,gold)})
        # CEGIS
        q,tr,cex=cegis(orig,gold)
        mechanisms["CEGIS_TOPOLOGY_NORMALIZE"].append({"world_id":wid,"cfg":q,"sha256":sha_obj(q)})
        traces["CEGIS_TOPOLOGY_NORMALIZE"].append({"world_id":wid,"trace":tr,"counterexample_indices":cex})
        fixed["CEGIS_TOPOLOGY_NORMALIZE"].append({"world_id":wid,**local_fixed_point(q,gold)})

    out={
        "experiment":"PRIMITIVE-2S.1","version":"0.1.0",
        "status":"NORMALIZED_CANDIDATES_READY_FOR_FREEZE",
        "normalization_data_access":{
            "parent_candidate_freeze":True,
            "public_discovery":True,
            "audit_gold":False,
            "prior_2s_local_counterexamples":False,
            "ood_outputs":False
        },
        "mechanisms":mechanisms,
        "traces":traces,
        "public_local_fixed_point_checks":fixed
    }
    out["normalization_output_sha256"]=sha_obj(out)
    (NORM/"PRIMITIVE-2S.1_NORMALIZATION_OUTPUT.json").write_text(json.dumps(out,indent=2))
    print("NORMALIZATION_COMPLETE")
    for name in mechanisms:
        vals=fixed[name]
        print(name,
              "fixed",sum(x["pass"] for x in vals),"/12",
              "mean_cost",sum(x["base_cost"] for x in vals)/12,
              "committed_edits",sum(len(x["trace"]) for x in traces[name]))

if __name__=="__main__":
    main()
