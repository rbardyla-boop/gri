#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2S.1_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2S.1_REPLAY_CHECK.json").read_text())
d=json.loads((ROOT/"results"/"PRIMITIVE-2S.1_TOPOLOGY_IDENTIFIABILITY_DIAGNOSIS.json").read_text())
assert r["terminal_verdict"]=="PARTIAL"
for name in ("GREEDY_STRICT_COST_DESCENT","CEGIS_TOPOLOGY_NORMALIZE"):
 s=r["mechanism_results"][name]["summary"]
 assert s["discovery_exact_worlds"]==12
 assert s["ood_exact_worlds"]==12
 assert s["overall_ood_accuracy"]==1.0
 assert s["static_halting_worlds"]==12
 assert s["local_one_edit_irreducible_worlds"]==12
 assert s["cheaper_than_raw_history_worlds"]==12
 assert s["required_topology_worlds"]==8
assert all(w["inductive_all_sequence_equivalence"] for w in d["worlds"])
assert rp["exact_byte_replay"]=="PASS"
print("PRIMITIVE_2S_1_TEST_PASS")
