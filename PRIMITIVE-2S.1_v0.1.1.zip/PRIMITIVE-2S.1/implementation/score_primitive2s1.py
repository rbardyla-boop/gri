#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,itertools,math,importlib.util

ROOT=Path('/mnt/data/PRIMITIVE-2S.1')
PARENT=Path('/mnt/data/PRIMITIVE-2S')
RES=ROOT/'results'
IMP=ROOT/'implementation'

def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha_obj(v): return hashlib.sha256(canon(v).encode()).hexdigest()

def load_normalizer():
    p=IMP/'normalize_primitive2s1_v0.1.1.py'
    spec=importlib.util.spec_from_file_location('norm',p)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m

N=load_normalizer()
CF=json.loads((RES/'PRIMITIVE-2S.1_NORMALIZED_CANDIDATE_FREEZE.json').read_text())
PUB=json.loads((PARENT/'fixtures'/'PRIMITIVE-2S_PUBLIC_WORLDS.json').read_text())
AUD=json.loads((PARENT/'audit'/'PRIMITIVE-2S_AUDIT_GOLD.json').read_text())
DISC=PUB['discovery_inputs']; OOD=PUB['ood_inputs']
audit_by_id={x['world_id']:x for x in AUD['worlds']}

def execute(cfg,tokens,cap=20000):
    regs=[0,0];ip=0;flag=False;pc=cfg.get('entry',0);steps=0
    peak=[N.signed_bits(0),N.signed_bits(0)]
    visited=[]
    while pc!='HALT':
        if steps>=cap or str(pc) not in cfg['blocks']:
            return None,{'halted':False,'steps':steps}
        b=cfg['blocks'][str(pc)];visited.append(pc)
        for ins in b['body']:
            steps+=1;op=ins[0]
            if op=='CMP_TOK':flag=((tokens[ip] if ip<len(tokens) else 4)==ins[1])
            elif op=='CMP_REG_ZERO':flag=(regs[ins[1]]==0)
            elif op=='CMP_REG_POS':flag=(regs[ins[1]]>0)
            elif op=='ADD_IMM':
                regs[ins[1]]+=ins[2]
                peak[ins[1]]=max(peak[ins[1]],N.signed_bits(regs[ins[1]]))
            elif op=='SET_IMM':regs[ins[1]]=0
            elif op=='ADVANCE':ip=min(ip+1,len(tokens))
            else:raise ValueError(op)
        steps+=1;t=b['term']
        if t[0]=='JMP':pc=t[1]
        elif t[0]=='JZ':pc=t[1] if not flag else t[2]
        elif t[0]=='HALT':pc='HALT'
        else:raise ValueError(t[0])
    out=[]
    for typ,r in cfg['readouts']:
        out.append(int(regs[r]==0) if typ=='EQ_ZERO' else int(regs[r]>0))
    R=len(N.reachable(cfg))
    pointer_bits=max(1,math.ceil(math.log2(len(tokens)+1))) if tokens else 1
    pc_bits=max(1,math.ceil(math.log2(R+1)))
    state_bits=sum(peak)+pointer_bits+pc_bits+1
    return out,{'halted':True,'steps':steps,'final_ip':ip,'final_regs':regs,'state_bits':state_bits,'visited_blocks':visited}

def cfg_cost(cfg,corpus):
    cfg=N.prune_unreachable(cfg);R=N.reachable(cfg);description=0.0;edge_count=0;halt_used=False
    for u in R:
        b=cfg['blocks'][str(u)]
        description += 0.1+len(b['body'])+1.0
        t=b['term'];targets=t[1:] if t[0]=='JZ' else (t[1:] if t[0]=='JMP' else [])
        for v in targets:
            edge_count+=1
            if v=='HALT':halt_used=True
    vertex_count=len(R)+(1 if halt_used else 0)
    M=max(0,edge_count-vertex_count+2) if vertex_count else 0
    rt=0;st=0
    for seq in corpus:
        _,m=execute(cfg,seq)
        if not m['halted']:return float('inf'),{}
        rt+=m['steps'];st=max(st,m['state_bits'])
    mean=rt/len(corpus)
    total=description+0.5*M+0.02*mean+st
    return total,{'description':description,'cyclomatic':M,'mean_runtime':mean,'peak_persistent_state_bits':st}

def first_return_advances(cfg,tok):
    seq=[tok,3,3];regs=[0,0];ip=0;flag=False;pc=0;left=False;adv=0;steps=0
    while steps<300:
        if pc=='HALT':return {'kind':'HALT','advances':adv,'input_pointer':ip}
        if left and pc==0:return {'kind':'RETURN','advances':adv,'input_pointer':ip}
        if str(pc) not in cfg['blocks']:return {'kind':'INVALID','advances':adv,'input_pointer':ip}
        b=cfg['blocks'][str(pc)]
        for ins in b['body']:
            steps+=1;op=ins[0]
            if op=='CMP_TOK':flag=((seq[ip] if ip<len(seq) else 4)==ins[1])
            elif op=='CMP_REG_ZERO':flag=(regs[ins[1]]==0)
            elif op=='CMP_REG_POS':flag=(regs[ins[1]]>0)
            elif op=='ADD_IMM':regs[ins[1]]+=ins[2]
            elif op=='SET_IMM':regs[ins[1]]=0
            elif op=='ADVANCE':ip=min(ip+1,len(seq));adv+=1
        t=b['term'];old=pc
        if t[0]=='JMP':pc=t[1]
        elif t[0]=='JZ':pc=t[1] if not flag else t[2]
        else:pc='HALT'
        if old==0:left=True
    return {'kind':'NONHALTING','advances':adv,'input_pointer':ip}

def topology_property(cfg,audit_class):
    if audit_class=='DATA_DEPENDENT_STREAM_SKIP':
        traces=[first_return_advances(cfg,t) for t in range(4)]
        counts=[x['advances'] for x in traces if x['kind']=='RETURN']
        return {'pass':(1 in counts and any(x>=2 for x in counts)),'first_return_by_token':traces}
    if audit_class=='MULTI_WAY_EARLY_EXIT':
        early=False;complete=False
        for seq in DISC:
            _,m=execute(cfg,seq)
            if not m['halted']:continue
            if len(seq)>0 and m['final_ip']<len(seq):early=True
            if len(seq)>0 and m['final_ip']==len(seq):complete=True
        return {'pass':early and complete,'early_halt_exists':early,'full_consumption_exists':complete}
    if audit_class=='NESTED_ZERO_ADVANCE_SUBLOOP':
        rec=[]
        for cyc in N.simple_cycles(cfg):
            bodies=[ins for u in cyc for ins in cfg['blocks'][str(u)]['body']]
            cert=N.certify_cycle(cfg,cyc)
            if not any(i[0]=='ADVANCE' for i in bodies):rec.append({'cycle':list(cyc),'certificate':cert})
        passed=any(x['certificate'] and x['certificate']['type']=='REGISTER_DESCENT' for x in rec)
        return {'pass':passed,'zero_advance_cycles':rec}
    raise ValueError(audit_class)

raw_description=sum(2*len(s)+2 for s in DISC)/len(DISC)
raw_storage=max(2*len(s) for s in OOD)
raw_cost=raw_description+raw_storage

mechanism_results={}
for name,items in CF['mechanisms'].items():
    rows=[]
    for item in items:
        wid=item['world_id'];cfg=item['cfg'];gold=PUB['worlds'][wid]['discovery_outputs'];a=audit_by_id[wid]
        disc_ev=N.evaluate_public(cfg,gold)
        discovery_exact=(disc_ev['halting'] and disc_ev['first_failure'] is None)
        ood_correct=0
        for seq,g in zip(OOD,a['ood_outputs']):
            o,m=execute(cfg,seq)
            ood_correct += int(m['halted'] and o==g)
        ood_acc=ood_correct/len(OOD)
        topo=topology_property(cfg,a['audit_class'])
        local=N.local_fixed_point(cfg,gold)
        cost,parts=cfg_cost(cfg,OOD)
        rows.append({
            'world_id':wid,'audit_class':a['audit_class'],
            'discovery_exact':discovery_exact,'ood_accuracy':ood_acc,
            'static_halting_certified':N.halting_ok(cfg),
            'required_topology_retained':topo['pass'],'topology_receipt':topo,
            'local_one_edit_irreducible':local['pass'],'local_receipt':local,
            'ood_cost':cost,'cost_parts':parts,'raw_history_cost':raw_cost,
            'cheaper_than_raw_history':cost<raw_cost,
            'cfg_sha256':sha_obj(cfg)
        })
    mechanism_results[name]={
        'world_results':rows,
        'summary':{
            'discovery_exact_worlds':sum(x['discovery_exact'] for x in rows),
            'ood_exact_worlds':sum(x['ood_accuracy']==1.0 for x in rows),
            'overall_ood_accuracy':sum(x['ood_accuracy'] for x in rows)/12,
            'static_halting_worlds':sum(x['static_halting_certified'] for x in rows),
            'required_topology_worlds':sum(x['required_topology_retained'] for x in rows),
            'local_one_edit_irreducible_worlds':sum(x['local_one_edit_irreducible'] for x in rows),
            'cheaper_than_raw_history_worlds':sum(x['cheaper_than_raw_history'] for x in rows),
            'mean_ood_cost':sum(x['ood_cost'] for x in rows)/12,
            'raw_history_cost':raw_cost
        }
    }

primary=mechanism_results['CEGIS_TOPOLOGY_NORMALIZE']['summary']
weaker_pass=(
    primary['discovery_exact_worlds']==12 and primary['ood_exact_worlds']==12 and
    primary['static_halting_worlds']==12 and primary['required_topology_worlds']==12 and
    primary['local_one_edit_irreducible_worlds']==12 and
    primary['cheaper_than_raw_history_worlds']==12
)
# Global lower-cost CFG closure is deliberately not claimed here.
if weaker_pass:
    terminal='TOPOLOGY_NORMALIZATION_DEMONSTRATED_WITHOUT_GLOBAL_MINIMALITY'
elif primary['discovery_exact_worlds']>0:
    terminal='PARTIAL'
else:
    terminal='TOPOLOGY_NORMALIZATION_INSUFFICIENT'

results={
    'experiment':'PRIMITIVE-2S.1','version':'0.1.1',
    'normalized_candidate_freeze_sha256':CF['candidate_freeze_sha256'],
    'terminal_verdict':terminal,
    'global_minimality':'NOT_CLAIMED_LOWER_COST_CFG_CLOSURE_NOT_EXHAUSTED',
    'primary_mechanism':'CEGIS_TOPOLOGY_NORMALIZE',
    'mechanism_results':mechanism_results
}
results['results_sha256']=sha_obj(results)
(RES/'PRIMITIVE-2S.1_RESULTS.json').write_text(json.dumps(results,indent=2))
print(terminal)
for name,m in mechanism_results.items():
    print(name,json.dumps(m['summary'],sort_keys=True))
