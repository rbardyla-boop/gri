# PRIMITIVE-2S.1 Results

**Terminal verdict:** `PARTIAL`  
**Exact deterministic replay:** `PASS`

| Mechanism | Discovery exact | OOD exact | Topology retained | Locally irreducible | Mean OOD cost |
|---|---:|---:|---:|---:|---:|
| NO_NORMALIZATION | 12/12 | 12/12 | 12/12 | 0/12 | 40.203858 |
| DEAD_BLOCK_ONLY | 12/12 | 12/12 | 12/12 | 0/12 | 40.203858 |
| GREEDY_STRICT_COST_DESCENT | 12/12 | 12/12 | 8/12 | 12/12 | 32.272052 |
| CEGIS_TOPOLOGY_NORMALIZE | 12/12 | 12/12 | 8/12 | 12/12 | 32.272052 |

The active normalizers converge to the same CFG in all twelve worlds.

```text
GREEDY_STRICT_COST_DESCENT
CEGIS_TOPOLOGY_NORMALIZE

12/12 discovery exact
12/12 OOD exact
12/12 static halting
12/12 locally one-edit irreducible
12/12 cheaper than raw history
 8/12 required topology retained
```

All four topology-retention failures are `NESTED_ZERO_ADVANCE_SUBLOOP` worlds.

Post-freeze diagnosis shows that the hidden loop and the normalized graph are behaviorally equivalent under the only state distinction exposed by the frozen readouts: `(reg0>0, reg1>0)`. Thus the hidden repeated-count transfer is not identifiable from the benchmark's observable interface.
