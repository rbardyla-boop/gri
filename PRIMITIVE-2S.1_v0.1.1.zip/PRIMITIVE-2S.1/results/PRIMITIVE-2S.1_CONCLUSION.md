# PRIMITIVE-2S.1 Conclusion

**Terminal verdict:** `PARTIAL`

The normalization problem from PRIMITIVE-2S was real and was repaired at the local structural level.

Both active mechanisms reached:

```text
12/12 discovery exact
12/12 OOD exact
12/12 static halting certified
12/12 local one-edit irreducibility
12/12 cheaper than raw history
```

However, both retained the frozen required topology in only:

```text
8/12 worlds
```

The four failures are exactly the `NESTED_ZERO_ADVANCE_SUBLOOP` class.

This is not an OOD failure. The normalized graphs remain 100% exact on the unchanged OOD set.

Post-freeze audit diagnosis found the deeper reason: the hidden repeated inner loop changes integer magnitudes, but the frozen outputs observe only whether `reg0` is zero and whether `reg1` is positive. The normalized graph computes the same abstract transition system without the inner loop. The four hidden and normalized systems match all 16 combinations of four abstract states and four input tokens under `(reg0>0, reg1>0)`, yielding an inductive all-sequence behavioral equivalence under the frozen readouts.

Therefore two demands in the current benchmark conflict:

```text
minimize unjustified architecture
and
retain a hidden loop whose repeated work is observationally unidentifiable
```

The correct scientific verdict remains `PARTIAL` under the frozen gate.

Supported claim:

> Generic discovery-only topology normalization can remove the redundant inherited dispatch structure from all twelve 2S CFGs, preserve exact OOD behavior and static halting, and reach a complete one-edit cost fixed point. The frozen nested-subloop fixture does not behaviorally identify the repeated inner-loop topology, so minimal exact normalization removes it.

The largest remaining gap is not another normalization heuristic. It is **topology identifiability**.

The next unit should preserve the failed 2S/2S.1 records and create a new independently frozen fixture family in which repeated internal work changes a later observable decision using only the existing VM semantics—for example, transfer magnitude into a register and later consume it so one-shot replacement and true repeated transfer make different predictions. Only then can topology necessity and topology minimality be tested coherently.
