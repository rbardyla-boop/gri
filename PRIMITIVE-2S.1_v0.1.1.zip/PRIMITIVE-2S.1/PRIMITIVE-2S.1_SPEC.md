# PRIMITIVE-2S.1 — TOPOLOGY NORMALIZATION / MINIMIZATION

**Version:** 0.1.0  
**Status:** `FROZEN_BEFORE_NORMALIZATION`  
**Parent package:** `b94a5e730c1fd668eeb17945ea86a22dc51a43e37a0de9163a39c5bc6ab9df89`

## Question

> Given a behaviorally exact, statically terminating synthesized CFG and public discovery evidence only, can generic normalization remove unjustified inherited control-flow structure until no cheaper one-edit simplification preserves the evidence, without damaging unseen behavior or the required topology?

## Frozen parent

PRIMITIVE-2S v0.1.1 ended `PARTIAL`:

```text
discovery exact             12/12
OOD exact                   12/12
static halting              12/12
required topology           12/12
local one-edit irreducible   0/12
```

The same twelve candidates and same frozen worlds are reused.

## Firewall

Before normalized candidates are frozen, the normalizer may read only:

```text
candidate CFG
public discovery input/output
VM semantics
cost accounting
```

It may not read:

```text
audit class
hidden CFG
OOD answers
the prior local-irredundancy counterexample file
```

## Mechanisms

```text
NO_NORMALIZATION

DEAD_BLOCK_ONLY

GREEDY_STRICT_COST_DESCENT

CEGIS_TOPOLOGY_NORMALIZE
```

The two active normalizers use exactly the same generic one-edit edit language.

## Generic edit language

```text
prune unreachable blocks
delete one block and splice incoming edges
rebind one edge
collapse JZ to one branch
contract a linear JMP edge
shorten a block payload
```

There are no class-specific rewrites.

## Weaker topology victory gate

A successful normalized mechanism must achieve:

```text
12/12 discovery exact
12/12 OOD exact
12/12 required topology retained
12/12 static halting
12/12 locally one-edit irreducible
12/12 cheaper than raw history
deterministic replay
```

This is sufficient only for:

```text
TOPOLOGY_NORMALIZATION_DEMONSTRATED_WITHOUT_GLOBAL_MINIMALITY
```

unless every lower-cost CFG in the bounded graph grammar is independently exhausted.

## Global-minimum firewall

Local irreducibility is not global minimality.

No global-minimum claim will be made unless an exhaustive lower-cost closure proof is actually completed.
