# PRIMITIVE-2S.1 Method

1. Bind the experiment to the exact PRIMITIVE-2S v0.1.1 package SHA-256 `b94a5e730c1fd668eeb17945ea86a22dc51a43e37a0de9163a39c5bc6ab9df89`.
2. Reuse the same twelve frozen 2S candidate CFGs and the same public/audit fixtures. No world is regenerated.
3. Freeze four normalization mechanisms and one shared generic edit language before normalization.
4. During normalization, open only the parent candidate freeze and public discovery fixture. Do not open audit gold, OOD answers, hidden CFGs, audit class labels, or the prior 2S local-irredundancy counterexample file.
5. `NO_NORMALIZATION` copies the candidate. `DEAD_BLOCK_ONLY` prunes unreachable blocks. `GREEDY_STRICT_COST_DESCENT` takes the cheapest discovery-exact, statically halting one-edit cost reduction to a fixed point. `CEGIS_TOPOLOGY_NORMALIZE` proposes the cheapest edit consistent with an active public subset, verifies against full public discovery, and adds the deterministic first public counterexample on failure.
6. A performance-only v0.1.1 patch caches each one-edit neighbor's public-discovery execution once per current CFG. The edit language, acceptance semantics, costs, halting rules and firewall do not change.
7. The first cached-normalizer rehearsal was discarded because the implementation-patch freeze receipt failed to write before execution due to a bookkeeping `NameError`. No audit data was opened and no scientific score existed. The rehearsal output was deleted, the patch was frozen, and normalization was rerun from scratch.
8. Freeze all normalized CFGs before opening the audit side.
9. Score unchanged OOD outputs, audit topology requirement, static halting, raw-history cost and complete one-edit public local irreducibility.
10. Do not claim global CFG minimality because the full lower-cost CFG closure is not exhausted.
11. After the frozen audit score, diagnose the four nested-topology failures by comparing hidden and normalized transition systems under the observable abstraction `(reg0>0, reg1>0)`.
12. Re-run the exact scorer and require byte-identical result JSON.
