#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2S_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2S_REPLAY_CHECK.json").read_text())
s=r["summary"]
assert r["terminal_verdict"]=="PARTIAL"
assert s["discovery_exact_worlds"]==12
assert s["ood_exact_worlds"]==12
assert s["overall_ood_accuracy"]==1.0
assert s["static_halting_pass_worlds"]==12
assert s["required_topology_property_worlds"]==12
assert s["cheaper_than_raw_history_worlds"]==12
assert s["local_one_edit_irreducible_worlds"]==0
assert s["local_redundancy_counterexample_worlds"]==12
assert rp["exact_byte_replay"]=="PASS"
print("PRIMITIVE_2S_TEST_PASS")
