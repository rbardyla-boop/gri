#include <bits/stdc++.h>
using namespace std;
struct Seq{vector<int> t; int g0,g1;};
struct Block{int kind=-1; int body=0; int t0=-1,t1=-2;};
struct Cand{array<Block,8>b; int ro0=0,ro1=2;};
struct Res{int err,nh; double comp; string sig;};
vector<Seq> D;
// pred ids: 0..4 CMP_TOK;5,6 zero r0,r1;7,8 pos r0,r1
struct Atom{int op,r,arg; bool operator==(const Atom&) const = default;}; // 0 adv 1 add 2 set
vector<vector<Atom>> ACT;
vector<array<int,2>> ROS={{{0,0}},{{1,0}},{{0,1}},{{1,1}}}; // 0 eq,1 pos
string keyCand(const Cand&c){
 string s; s.reserve(128);
 for(auto &b:c.b){s+=to_string(b.kind)+","+to_string(b.body)+","+to_string(b.t0)+","+to_string(b.t1)+";";}
 s+=to_string(c.ro0)+","+to_string(c.ro1);return s;
}
vector<int> reach(const Cand&c){
 vector<int> seen(8); vector<int> st={0};
 while(!st.empty()){int u=st.back();st.pop_back(); if(u<0||u>=8||seen[u]||c.b[u].kind<0)continue; seen[u]=1; auto &b=c.b[u]; if(b.kind==0){if(b.t0>=0)st.push_back(b.t0);if(b.t1>=0)st.push_back(b.t1);}else if(b.t0>=0)st.push_back(b.t0);}
 vector<int>r;for(int i=0;i<8;i++)if(seen[i])r.push_back(i);return r;
}
struct Exec{bool halt; int o0,o1,r0,r1,ip; uint64_t vh;};
Exec run(const Cand&c,const vector<int>&t){
 long r[2]={0,0};int ip=0,pc=0,steps=0;bool flag=false;uint64_t vh=1469598103934665603ULL;
 while(pc>=0){if(++steps>250||pc>=8||c.b[pc].kind<0)return {false,0,0,0,0,ip,vh}; vh^=(uint64_t)(pc+1);vh*=1099511628211ULL; auto b=c.b[pc];
   if(b.kind==0){int p=b.body;if(p<=4)flag=((ip<(int)t.size()?t[ip]:4)==p);else if(p<=6)flag=(r[p-5]==0);else flag=(r[p-7]>0);pc=flag?b.t1:b.t0;}
   else{for(auto a:ACT[b.body]){if(++steps>250)return {false,0,0,0,0,ip,vh}; if(a.op==0)ip=min(ip+1,(int)t.size());else if(a.op==1)r[a.r]+=a.arg;else r[a.r]=0;}pc=b.t0;}
 }
 auto out=[&](int ri){auto z=ROS[ri];return z[0]==0?(r[z[1]]==0):(r[z[1]]>0);};
 return {true,(int)out(c.ro0),(int)out(c.ro1),(int)r[0],(int)r[1],ip,vh};
}
double complexity(const Cand&c){auto R=reach(c);int edges=0,ins=0;for(int u:R){auto b=c.b[u];ins+=1+(b.kind==0?1:(int)ACT[b.body].size());if(b.t0>=0)edges++;if(b.kind==0&&b.t1>=0)edges++;}int M=max(0,edges-(int)R.size()+2);return ins+.5*M+.1*R.size();}

bool cycleCert(const Cand&c,const vector<int>&cyc,const vector<int>&R){
 bool adv=false,eofexit=false; bool in[8]={0};for(int u:cyc)in[u]=true;
 for(int u:cyc){auto b=c.b[u];if(b.kind==1){for(auto a:ACT[b.body])if(a.op==0)adv=true;}else if(b.body==4 && (b.t0<0||b.t1<0))eofexit=true;}
 if(adv&&eofexit)return true;
 if(adv)return false;
 for(int r=0;r<2;r++){bool z=false,dec=false,forbid=false,outdec=false;
   for(int u:cyc){auto b=c.b[u];if(b.kind==0&&b.body==5+r)z=true;if(b.kind==1)for(auto a:ACT[b.body]){if(a.op==1&&a.r==r&&a.arg==-1)dec=true;if((a.op==1&&a.r==r&&a.arg>0)||(a.op==2&&a.r==r))forbid=true;}}
   if(!(z&&dec&&!forbid))continue;
   for(int u:R)if(!in[u]){auto b=c.b[u];if(b.kind==1)for(auto a:ACT[b.body])if(a.op==1&&a.r==r&&a.arg==-1){outdec=true;break;}if(outdec)break;}
   if(!outdec)return true;
 }
 return false;
}
bool validHalting(const Cand&c){
 auto R=reach(c); bool isR[8]={0};for(int u:R)isR[u]=true;
 function<bool(int,int,int,vector<int>&)> dfs=[&](int start,int u,int mask,vector<int>&path)->bool{
   auto b=c.b[u]; int ts[2]={b.t0,b.kind==0?b.t1:-2}; int n=b.kind==0?2:1;
   for(int k=0;k<n;k++){int v=ts[k];if(v<0||v>=8||!isR[v])continue;
     if(v==start){if(!cycleCert(c,path,R))return false;}
     else if(v>start && !(mask&(1<<v))){path.push_back(v);if(!dfs(start,v,mask|(1<<v),path))return false;path.pop_back();}
   }
   return true;
 };
 for(int start:R){vector<int>path={start};if(!dfs(start,start,1<<start,path))return false;}
 return true;
}

Res eval(const Cand&c,const vector<int>&idx){if(!validHalting(c))return {100000,1,1e9,"INVALID"};int e=0,nh=0;string sig;sig.reserve(idx.size()*32);for(int i:idx){auto x=run(c,D[i].t);if(!x.halt){e+=8;nh++;sig+="N|";}else{e+=(x.o0!=D[i].g0)+(x.o1!=D[i].g1);sig+=to_string(x.o0)+to_string(x.o1)+":"+to_string(x.r0)+","+to_string(x.r1)+","+to_string(x.ip)+","+to_string(x.vh)+"|";}}return {e,nh,complexity(c),sig};}
vector<Cand> neigh(const Cand&c){vector<Cand> out;auto R=reach(c);vector<int>free;for(int i=0;i<8;i++)if(c.b[i].kind<0)free.push_back(i);
 // payload
 for(int u:R){auto b=c.b[u];if(b.kind==0){for(int p=0;p<9;p++)if(p!=b.body){Cand n=c;n.b[u].body=p;out.push_back(n);}}else{for(int a=0;a<(int)ACT.size();a++)if(a!=b.body){Cand n=c;n.b[u].body=a;out.push_back(n);}}}
 // edge rebind reachable/HALT only
 vector<int>T=R;T.push_back(-1);
 for(int u:R){auto b=c.b[u];if(b.kind==0){for(int which=0;which<2;which++)for(int t:T){if((which==0?b.t0:b.t1)==t)continue;Cand n=c;if(which==0)n.b[u].t0=t;else n.b[u].t1=t;out.push_back(n);}}else for(int t:T)if(t!=b.t0){Cand n=c;n.b[u].t0=t;out.push_back(n);}}
 // readout
 for(int x=0;x<4;x++){if(x!=c.ro0){Cand n=c;n.ro0=x;out.push_back(n);}if(x!=c.ro1){Cand n=c;n.ro1=x;out.push_back(n);}}
 // split one edge with first free block, action or predicate
 if(!free.empty()){int nn=free[0];for(int u:R){auto b=c.b[u];int slots=b.kind==0?2:1;for(int w=0;w<slots;w++){int old=(w==0?b.t0:b.t1);
   for(int a=0;a<(int)ACT.size();a++){Cand n=c;if(w==0)n.b[u].t0=nn;else n.b[u].t1=nn;n.b[nn]={1,a,old,-2};out.push_back(n);} 
   for(int p=0;p<9;p++)for(int oth:T){Cand n=c;if(w==0)n.b[u].t0=nn;else n.b[u].t1=nn;n.b[nn]={0,p,old,oth};out.push_back(n);if(oth!=old){Cand m=c;if(w==0)m.b[u].t0=nn;else m.b[u].t1=nn;m.b[nn]={0,p,oth,old};out.push_back(m);}}
 }}}
 return out;}
Cand seed(){Cand c;for(auto&b:c.b)b={-1,0,-1,-2};c.b[0]={0,4,1,-1};c.b[1]={0,0,2,4};c.b[2]={0,1,3,5};c.b[3]={0,2,6,6}; // act ids later known
 auto find=[&](vector<Atom>v){for(int i=0;i<(int)ACT.size();i++)if(ACT[i]==v)return i;return -1;};
 c.b[4]={1,find({{1,0,1},{0,0,0}}),0,-2}; c.b[5]={1,find({{2,0,0},{0,0,0}}),0,-2}; c.b[6]={1,find({{1,1,1},{0,0,0}}),0,-2};c.ro0=0;c.ro1=2;return c;}
int main(int argc,char**argv){
 ACT.push_back({});vector<Atom>A={{0,0,0},{1,0,1},{1,0,-1},{2,0,0},{1,1,1},{1,1,-1},{2,1,0}};for(auto a:A)ACT.push_back({a});for(auto a:A)for(auto b:A)ACT.push_back({a,b});
 if(argc<2){cerr<<"usage input.txt\n";return 2;} ifstream f(argv[1]);int N;f>>N;D.resize(N);for(auto &q:D){int L;f>>L;q.t.resize(L);for(int&i:q.t)f>>i;f>>q.g0>>q.g1;}
 string tag;f>>tag;if(tag!="SEED")return 3;Cand BASE;for(int i=0;i<8;i++)f>>BASE.b[i].kind>>BASE.b[i].body>>BASE.b[i].t0>>BASE.b[i].t1;f>>BASE.ro0>>BASE.ro1;f>>tag;int ac;f>>ac;vector<int>active(ac);for(int&i:active)f>>i;
 auto start=chrono::steady_clock::now(); vector<string> receipts; Cand final; bool success=false; int totalgen=0; int rounds=0;
 for(int round=0;round<16;round++){rounds=round+1; Cand found;bool ok=false;int usedWidth=0,usedDepth=-1;
   for(int BW: {64,256,1024,4096}){ int maxD=(BW==64?1:(BW==256?2:(BW==1024?7:9)));
     vector<Cand> cur={BASE};unordered_set<string> seen;seen.insert(keyCand(BASE));
     for(int depth=0;depth<=maxD&&!ok;depth++){
       struct Item{Res r;Cand c;};vector<Item> items;items.reserve(cur.size());for(auto &c:cur)items.push_back({eval(c,active),c});
       sort(items.begin(),items.end(),[](auto&a,auto&b){if(a.r.err!=b.r.err)return a.r.err<b.r.err;if(a.r.comp!=b.r.comp)return a.r.comp<b.r.comp;return keyCand(a.c)<keyCand(b.c);});
       if(items[0].r.err==0){found=items[0].c;ok=true;usedWidth=BW;usedDepth=depth;break;}
       unordered_map<string,vector<pair<pair<int,double>,Cand>>> buck; size_t gen=0;int limit=min<int>(BW/2,items.size());
       for(int ii=0;ii<limit;ii++)for(auto &n:neigh(items[ii].c)){string kc=keyCand(n);if(!seen.insert(kc).second)continue;auto rr=eval(n,active);auto &v=buck[rr.sig];v.push_back({{rr.err,rr.comp},n});gen++;}
       totalgen+=gen;vector<pair<pair<int,double>,Cand>> next;next.reserve(buck.size()*2);
       for(auto &kv:buck){auto &v=kv.second;sort(v.begin(),v.end(),[](auto&a,auto&b){if(a.first!=b.first)return a.first<b.first;return keyCand(a.second)<keyCand(b.second);});for(int j=0;j<(int)v.size()&&j<2;j++)next.push_back(v[j]);}
       sort(next.begin(),next.end(),[](auto&a,auto&b){if(a.first!=b.first)return a.first<b.first;return keyCand(a.second)<keyCand(b.second);});cur.clear();for(int i=0;i<(int)next.size()&&i<BW;i++)cur.push_back(next[i].second);if(cur.empty())break;
     }
     if(ok)break;
   }
   if(!ok){cout<<"RESULT FAIL_SEARCH round="<<round+1<<" active="<<active.size()<<" totalgen="<<totalgen<<"\n";break;}
   int fail=-1;for(int i=0;i<N;i++){auto x=run(found,D[i].t);if(!x.halt||x.o0!=D[i].g0||x.o1!=D[i].g1){fail=i;break;}}
   cout<<"ROUND "<<round+1<<" active="<<active.size()<<" width="<<usedWidth<<" depth="<<usedDepth<<" fail="<<fail<<" comp="<<complexity(found)<<"\n";
   if(fail<0){final=found;success=true;break;}if(find(active.begin(),active.end(),fail)==active.end())active.push_back(fail);else{cout<<"RESULT FAIL_REPEAT_COUNTEREXAMPLE\n";break;}
 }
 auto sec=chrono::duration<double>(chrono::steady_clock::now()-start).count();
 if(success){cout<<"RESULT SUCCESS rounds="<<rounds<<" active="<<active.size()<<" totalgen="<<totalgen<<" seconds="<<sec<<"\n";cout<<"CANDIDATE "<<keyCand(final)<<"\n";cout<<"HALTING "<<(validHalting(final)?"PASS":"FAIL")<<"\n";}else cout<<"SECONDS "<<sec<<"\n";
}
