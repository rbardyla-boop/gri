#!/usr/bin/env python3
from pathlib import Path
import json,itertools,collections,hashlib,sys

ROOT=Path(__file__).resolve().parent.parent
PUB=json.loads((ROOT/"fixtures"/"PRIMITIVE-2S_PUBLIC_WORLDS.json").read_text())
DISC=PUB["discovery_inputs"]

ATOM=[("ADVANCE",),("ADD_IMM",0,1),("ADD_IMM",0,-1),("SET_IMM",0,0),
      ("ADD_IMM",1,1),("ADD_IMM",1,-1),("SET_IMM",1,0)]
ACT=[()]+[(a,) for a in ATOM]+[(a,b) for a in ATOM for b in ATOM]
ACT_ID={b:i for i,b in enumerate(ACT)}
ROS=[("EQ_ZERO",0),("GT_ZERO",0),("EQ_ZERO",1),("GT_ZERO",1)]
RO_ID={x:i for i,x in enumerate(ROS)}

def effects(regs):
    e=[("NOOP",None,None)]
    for r in range(regs):
        e += [("ADD_IMM",r,1),("ADD_IMM",r,-1),("SET_IMM",r,0)]
    return e

def ropts(regs):
    out=[]
    for r in range(regs):
        out += [("EQ_ZERO",r),("GT_ZERO",r)]
    return out

def best_2r(gold):
    best=None; best_states=None
    for regs in (1,2):
        E=effects(regs); RO=ropts(regs)
        for handlers in itertools.product(range(len(E)),repeat=4):
            finals=[]
            for seq in DISC:
                st=[0]*regs
                for tok in seq:
                    op,r,arg=E[handlers[tok]]
                    if op=="ADD_IMM": st[r]+=arg
                    elif op=="SET_IMM": st[r]=0
                finals.append(tuple(st))
            for rp in itertools.product(RO,repeat=2):
                err=0
                for st,g in zip(finals,gold):
                    pred=[int(st[r]==0) if typ=="EQ_ZERO" else int(st[r]>0) for typ,r in rp]
                    err += (pred[0]!=g[0])+(pred[1]!=g[1])
                    if best is not None and err>best[0]:
                        break
                key=(err,regs,handlers,rp)
                if best is None or key<best:
                    best=key; best_states=finals
    return best,best_states

def compile_seed(best):
    _,regs,handlers,rp=best
    E=effects(regs)
    blocks=[None]*8
    pred_ids={0:1,1:2,2:3}
    eff_to_id={}; nxt=4
    for tok in range(4):
        eff=E[handlers[tok]]
        if eff not in eff_to_id:
            eff_to_id[eff]=nxt; nxt+=1
    if nxt>9:
        raise RuntimeError("2R baseline cannot be reified within eight slots")
    blocks[0]=(0,4,1,-1)  # CMP_TOK EOF
    tests=[0,1,2]
    for j,tok in enumerate(tests):
        false=pred_ids[tests[j+1]] if j<2 else eff_to_id[E[handlers[3]]]
        blocks[pred_ids[tok]]=(0,tok,false,eff_to_id[E[handlers[tok]]])
    for eff,bid in eff_to_id.items():
        op,r,arg=eff
        if op=="ADD_IMM":
            body=(("ADD_IMM",r,arg),("ADVANCE",))
        elif op=="SET_IMM":
            body=(("SET_IMM",r,0),("ADVANCE",))
        else:
            body=(("ADVANCE",),)
        blocks[bid]=(1,ACT_ID[body],0,-2)
    return blocks,(RO_ID[rp[0]],RO_ID[rp[1]])

def initial_collision_examples(states,gold):
    groups=collections.defaultdict(lambda:collections.defaultdict(list))
    for i,(st,g) in enumerate(zip(states,gold)):
        pad=st+(0,)*(2-len(st))
        groups[pad][tuple(g)].append(i)
    pairs=[]
    for st,by_out in groups.items():
        for a,b in itertools.combinations(sorted(by_out),2):
            pairs.append((st,a,b,min(by_out[a]),min(by_out[b])))
    pairs.sort(key=lambda x:(x[0],x[1],x[2],x[3],x[4]))

    # Pre-score v0.1.1 search-efficiency patch:
    # stratify residual collisions across distinct values of the first
    # baseline register instead of consuming eight lexicographic pairs
    # from one state region. No gold beyond the already-public discovery
    # outputs is introduced.
    by_first=collections.defaultdict(list)
    for pair in pairs:
        by_first[pair[0][0]].append(pair)
    chosen=[]
    for quota,key in zip((4,2,2),sorted(by_first)):
        chosen.extend(by_first[key][:quota])
    for pair in pairs:
        if len(chosen)>=8: break
        if pair not in chosen:
            chosen.append(pair)

    active=[]
    for pair in chosen[:8]:
        for i in pair[3:5]:
            if i not in active:
                active.append(i)
    for i in range(len(DISC)):
        if len(active)>=8: break
        if i not in active: active.append(i)
    return active

def canonical_groups():
    closed_n=sum(4**L for L in range(5))
    closed=DISC[:closed_n]
    index={tuple(s):i for i,s in enumerate(closed)}
    groups={}
    for wid,w in enumerate(PUB["worlds"]):
        best=None
        for perm in itertools.permutations(range(4)):
            sig=[]
            for s in closed:
                mapped=tuple(perm[t] for t in s)
                sig.extend(w["discovery_outputs"][index[mapped]])
            key=tuple(sig)
            if best is None or (key,perm)<best:
                best=(key,perm)
        h=hashlib.sha256(bytes(best[0])).hexdigest()
        groups.setdefault(h,[]).append({"world_id":wid,"canonical_perm":list(best[1])})
    return groups

def main(outdir):
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    groups=canonical_groups()
    representative_ids=[]
    for h,members in sorted(groups.items()):
        rep=min(x["world_id"] for x in members)
        representative_ids.append(rep)
        gold=PUB["worlds"][rep]["discovery_outputs"]
        best,states=best_2r(gold)
        active=initial_collision_examples(states,gold)
        blocks,ros=compile_seed(best)
        with (outdir/f"world_{rep}.txt").open("w") as f:
            f.write(f"{len(DISC)}\n")
            for seq,g in zip(DISC,gold):
                f.write(f"{len(seq)} "+" ".join(map(str,seq))+f" {g[0]} {g[1]}\n")
            f.write("SEED\n")
            for b in blocks:
                f.write("-1 0 -1 -2\n" if b is None else " ".join(map(str,b))+"\n")
            f.write(f"{ros[0]} {ros[1]}\n")
            f.write(f"ACTIVE {len(active)} "+" ".join(map(str,active))+"\n")
    record={
        "public_behavior_equivalence_groups":groups,
        "representative_world_ids":sorted(representative_ids),
        "group_count":len(groups),
        "symmetry":"S4 permutation of the four raw token labels, derived only from permutation-closed public discovery examples",
        "audit_data_read":False,
    }
    (outdir/"PREP_RECORD.json").write_text(json.dumps(record,indent=2))
    print(json.dumps(record,indent=2))

if __name__=="__main__":
    main(sys.argv[1])
