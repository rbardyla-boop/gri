#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,itertools,math,copy

ROOT=Path(__file__).resolve().parent.parent
RES=ROOT/"results"

def canon(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_obj(v): return hashlib.sha256(canon(v).encode()).hexdigest()

PUB=json.loads((ROOT/"fixtures"/"PRIMITIVE-2S_PUBLIC_WORLDS.json").read_text())
AUD=json.loads((ROOT/"audit"/"PRIMITIVE-2S_AUDIT_GOLD.json").read_text())
CF=json.loads((RES/"PRIMITIVE-2S_CANDIDATE_FREEZE.json").read_text())
DISC=PUB["discovery_inputs"]
OOD=PUB["ood_inputs"]

RAW_SINGLE=[]
RAW_SINGLE += [["CMP_TOK",k] for k in range(5)]
RAW_SINGLE += [["CMP_REG_ZERO",r] for r in (0,1)]
RAW_SINGLE += [["CMP_REG_POS",r] for r in (0,1)]
RAW_SINGLE += [["ADD_IMM",r,d] for r in (0,1) for d in (-1,1)]
RAW_SINGLE += [["SET_IMM",r,0] for r in (0,1)]
RAW_SINGLE += [["ADVANCE"]]

def signed_bits(v):
    return max(1,math.ceil(math.log2(abs(v)+2))+1)

def edges(cfg):
    e={}
    for k,b in cfg["blocks"].items():
        u=int(k);t=b["term"]
        if t[0]=="JMP":
            e[u]=[t[1]] if t[1]!="HALT" else []
        elif t[0]=="JZ":
            e[u]=[x for x in t[1:] if x!="HALT"]
        else:
            e[u]=[]
    return e

def reachable(cfg):
    E=edges(cfg);seen=set();q=[0]
    while q:
        u=q.pop()
        if u in seen or u not in E: continue
        seen.add(u);q.extend(E[u])
    return seen

def simple_cycles(cfg):
    E=edges(cfg);R=sorted(reachable(cfg));found=set()
    def canonical(c):
        rots=[tuple(c[i:]+c[:i]) for i in range(len(c))]
        return min(rots)
    for st in R:
        def dfs(u,path):
            for v in E.get(u,[]):
                if v==st:
                    found.add(canonical(path))
                elif v not in path and len(path)<len(R):
                    dfs(v,path+[v])
        dfs(st,[st])
    return sorted(found)

def certify_cycle(cfg,cyc):
    bodies=[ins for u in cyc for ins in cfg["blocks"][str(u)]["body"]]
    has_adv=any(i[0]=="ADVANCE" for i in bodies)
    if has_adv:
        for u in cyc:
            b=cfg["blocks"][str(u)]
            if ["CMP_TOK",4] in b["body"] and "HALT" in b["term"][1:]:
                return {"type":"INPUT_REMAINING","rank":"remaining_unread_tokens"}
        return None
    for r in (0,1):
        has_zero=any(i==["CMP_REG_ZERO",r] for i in bodies)
        has_dec=any(i==["ADD_IMM",r,-1] for i in bodies)
        forbidden=any(
            (i[0]=="ADD_IMM" and i[1]==r and i[2]>0) or
            (i[0]=="SET_IMM" and i[1]==r)
            for i in bodies
        )
        outside=[ins for u in reachable(cfg) if u not in cyc for ins in cfg["blocks"][str(u)]["body"]]
        outside_dec=any(i==["ADD_IMM",r,-1] for i in outside)
        if has_zero and has_dec and not forbidden and not outside_dec:
            return {"type":"REGISTER_DESCENT","rank":f"register_{r}"}
    return None

def halting_receipt(cfg):
    cs=[]
    for c in simple_cycles(cfg):
        cs.append({"cycle":list(c),"certificate":certify_cycle(cfg,c)})
    return {"cycles":cs,"all_certified":all(x["certificate"] is not None for x in cs)}

def execute(cfg,tokens,cap=20000):
    regs=[0,0];ip=0;flag=False;pc=0;steps=0
    peak_reg_bits=[signed_bits(0),signed_bits(0)]
    visited=[]
    while pc!="HALT":
        if steps>=cap or str(pc) not in cfg["blocks"]:
            return None,{"halted":False,"steps":steps}
        b=cfg["blocks"][str(pc)]
        visited.append(pc)
        for ins in b["body"]:
            steps+=1
            op=ins[0]
            if op=="CMP_TOK":
                flag=((tokens[ip] if ip<len(tokens) else 4)==ins[1])
            elif op=="CMP_REG_ZERO":
                flag=(regs[ins[1]]==0)
            elif op=="CMP_REG_POS":
                flag=(regs[ins[1]]>0)
            elif op=="ADD_IMM":
                regs[ins[1]]+=ins[2]
                peak_reg_bits[ins[1]]=max(peak_reg_bits[ins[1]],signed_bits(regs[ins[1]]))
            elif op=="SET_IMM":
                regs[ins[1]]=0
            elif op=="ADVANCE":
                ip=min(ip+1,len(tokens))
            else:
                raise ValueError(op)
        steps+=1
        t=b["term"]
        if t[0]=="JMP":
            pc=t[1]
        elif t[0]=="JZ":
            pc=t[1] if not flag else t[2]
        elif t[0]=="HALT":
            pc="HALT"
        else:
            raise ValueError(t[0])
    out=[]
    for typ,r in cfg["readouts"]:
        out.append(int(regs[r]==0) if typ=="EQ_ZERO" else int(regs[r]>0))
    R=len(reachable(cfg))
    pointer_bits=max(1,math.ceil(math.log2(len(tokens)+1))) if tokens else 1
    pc_bits=max(1,math.ceil(math.log2(R+1)))
    state_bits=sum(peak_reg_bits)+pointer_bits+pc_bits+1
    return out,{
        "halted":True,"steps":steps,"final_ip":ip,"final_regs":regs,
        "peak_persistent_state_bits":state_bits,"visited_blocks":visited
    }

def cfg_cost(cfg,corpus):
    R=reachable(cfg)
    description=0.0;edge_count=0;halt_used=False
    for u in R:
        b=cfg["blocks"][str(u)]
        description += 0.1 + len(b["body"]) + 1.0
        t=b["term"]
        targets=t[1:] if t[0]=="JZ" else (t[1:] if t[0]=="JMP" else [])
        for v in targets:
            edge_count+=1
            if v=="HALT": halt_used=True
    vertex_count=len(R)+(1 if halt_used else 0)
    M=max(0,edge_count-vertex_count+2) if vertex_count else 0
    runtime=0;state=0
    for seq in corpus:
        _,m=execute(cfg,seq)
        if not m["halted"]:
            return float("inf"),{}
        runtime+=m["steps"]; state=max(state,m["peak_persistent_state_bits"])
    mean_runtime=runtime/len(corpus)
    total=description+0.5*M+0.02*mean_runtime+state
    return total,{
        "description":description,"cyclomatic":M,
        "mean_runtime":mean_runtime,"peak_persistent_state_bits":state
    }

def exact_discovery(cfg,gold):
    h=halting_receipt(cfg)
    if not h["all_certified"]:
        return False
    for seq,g in zip(DISC,gold):
        o,m=execute(cfg,seq)
        if not m["halted"] or o!=g:
            return False
    return True

def deleted_variant(cfg,u,replacement):
    c=json.loads(json.dumps(cfg))
    c["blocks"].pop(str(u),None)
    for b in c["blocks"].values():
        t=b["term"]
        if t[0]=="JMP" and t[1]==u:
            t[1]=replacement
        elif t[0]=="JZ":
            if t[1]==u: t[1]=replacement
            if t[2]==u: t[2]=replacement
    return c

def local_irreducibility(cfg,gold):
    base_cost,_=cfg_cost(cfg,DISC)
    R=sorted(reachable(cfg));targets=R+["HALT"]
    # Node deletion with incoming edges spliced to each available successor/HALT.
    for u in R:
        if u==0: continue
        b=cfg["blocks"][str(u)]
        repl=[]
        for x in b["term"][1:]+["HALT"]:
            if x!=u and x not in repl: repl.append(x)
        for target in repl:
            c=deleted_variant(cfg,u,target)
            if exact_discovery(c,gold):
                cost,_=cfg_cost(c,DISC)
                if cost < base_cost-1e-12:
                    return {
                        "pass":False,"edit":"DELETE_BASIC_BLOCK",
                        "block":u,"replacement_target":target,
                        "base_cost":base_cost,"counterexample_cost":cost,
                        "saving":base_cost-cost,
                        "counterexample_cfg_sha256":sha_obj(c)
                    }
    # Single edge rebinding.
    for u in R:
        b=cfg["blocks"][str(u)]
        positions=[1] if b["term"][0]=="JMP" else ([1,2] if b["term"][0]=="JZ" else [])
        for pos in positions:
            for target in targets:
                if target==b["term"][pos]: continue
                c=json.loads(json.dumps(cfg))
                c["blocks"][str(u)]["term"][pos]=target
                if exact_discovery(c,gold):
                    cost,_=cfg_cost(c,DISC)
                    if cost < base_cost-1e-12:
                        return {
                            "pass":False,"edit":"REBIND_JUMP_TARGET",
                            "block":u,"term_position":pos,"new_target":target,
                            "base_cost":base_cost,"counterexample_cost":cost,
                            "saving":base_cost-cost,
                            "counterexample_cfg_sha256":sha_obj(c)
                        }
    # Strictly shorter payloads.
    for u in R:
        body=cfg["blocks"][str(u)]["body"]
        options=[]
        if len(body)>=1: options.append([])
        if len(body)>=2: options.extend([[x] for x in RAW_SINGLE])
        for new_body in options:
            if new_body==body: continue
            c=json.loads(json.dumps(cfg))
            c["blocks"][str(u)]["body"]=new_body
            if exact_discovery(c,gold):
                cost,_=cfg_cost(c,DISC)
                if cost < base_cost-1e-12:
                    return {
                        "pass":False,"edit":"SHORTEN_BLOCK_PAYLOAD",
                        "block":u,"new_body":new_body,
                        "base_cost":base_cost,"counterexample_cost":cost,
                        "saving":base_cost-cost,
                        "counterexample_cfg_sha256":sha_obj(c)
                    }
    return {"pass":True,"base_cost":base_cost}

def first_return_advances(cfg,tok):
    # One complete top-level dispatch/processing cycle from entry back to entry.
    seq=[tok,3,3]
    regs=[0,0];ip=0;flag=False;pc=0;left=False;adv=0;steps=0
    while steps<200:
        if pc=="HALT": return {"kind":"HALT","advances":adv,"input_pointer":ip}
        if left and pc==0: return {"kind":"RETURN","advances":adv,"input_pointer":ip}
        b=cfg["blocks"][str(pc)]
        for ins in b["body"]:
            steps+=1
            op=ins[0]
            if op=="CMP_TOK": flag=((seq[ip] if ip<len(seq) else 4)==ins[1])
            elif op=="CMP_REG_ZERO": flag=(regs[ins[1]]==0)
            elif op=="CMP_REG_POS": flag=(regs[ins[1]]>0)
            elif op=="ADD_IMM": regs[ins[1]]+=ins[2]
            elif op=="SET_IMM": regs[ins[1]]=0
            elif op=="ADVANCE": ip=min(ip+1,len(seq));adv+=1
        t=b["term"]; old=pc
        if t[0]=="JMP": pc=t[1]
        elif t[0]=="JZ": pc=t[1] if not flag else t[2]
        else: pc="HALT"
        if old==0: left=True
    return {"kind":"NONHALTING","advances":adv,"input_pointer":ip}

def topology_property(cfg,audit_class):
    if audit_class=="DATA_DEPENDENT_STREAM_SKIP":
        traces=[first_return_advances(cfg,t) for t in range(4)]
        counts=[x["advances"] for x in traces if x["kind"]=="RETURN"]
        passed=(1 in counts and any(x>=2 for x in counts))
        return {"pass":passed,"first_return_by_token":traces}
    if audit_class=="MULTI_WAY_EARLY_EXIT":
        early=False;complete=False
        for seq in DISC:
            _,m=execute(cfg,seq)
            if not m["halted"]: continue
            if len(seq)>0 and m["final_ip"]<len(seq): early=True
            if len(seq)>0 and m["final_ip"]==len(seq): complete=True
        return {"pass":early and complete,"early_halt_exists":early,"full_consumption_exists":complete}
    if audit_class=="NESTED_ZERO_ADVANCE_SUBLOOP":
        rec=[]
        for cyc in simple_cycles(cfg):
            bodies=[ins for u in cyc for ins in cfg["blocks"][str(u)]["body"]]
            cert=certify_cycle(cfg,cyc)
            if not any(i[0]=="ADVANCE" for i in bodies):
                rec.append({"cycle":list(cyc),"certificate":cert})
        passed=any(x["certificate"] and x["certificate"]["type"]=="REGISTER_DESCENT" for x in rec)
        return {"pass":passed,"zero_advance_cycles":rec}
    raise ValueError(audit_class)

audit_by_id={x["world_id"]:x for x in AUD["worlds"]}
rows=[];counterexamples=[]
raw_description=sum(2*len(s)+2 for s in DISC)/len(DISC)
raw_storage=max(2*len(s) for s in OOD)
raw_cost=raw_description+raw_storage

for c in CF["candidates"]:
    wid=c["world_id"];cfg=c["candidate_cfg"];gold=PUB["worlds"][wid]["discovery_outputs"];a=audit_by_id[wid]
    discovery_exact=exact_discovery(cfg,gold)
    h=halting_receipt(cfg)
    ood_correct=0
    for seq,g in zip(OOD,a["ood_outputs"]):
        o,m=execute(cfg,seq)
        ood_correct+=int(m["halted"] and o==g)
    ood_acc=ood_correct/len(OOD)
    topo=topology_property(cfg,a["audit_class"])
    l=local_irreducibility(cfg,gold)
    if not l["pass"]:
        counterexamples.append({"world_id":wid,**l})
    candidate_ood_cost,cost_parts=cfg_cost(cfg,OOD)
    rows.append({
        "world_id":wid,
        "audit_class":a["audit_class"],
        "discovery_exact":discovery_exact,
        "ood_exact_count":ood_correct,
        "ood_total":len(OOD),
        "ood_accuracy":ood_acc,
        "halting_all_cycles_certified":h["all_certified"],
        "halting_receipt":h,
        "required_topology_property":topo,
        "local_one_edit_irreducible":l["pass"],
        "local_irreducibility_receipt":l,
        "candidate_ood_cost":candidate_ood_cost,
        "candidate_cost_parts":cost_parts,
        "raw_history_cost":raw_cost,
        "cheaper_than_raw_history":candidate_ood_cost<raw_cost
    })

summary={
    "world_count":len(rows),
    "discovery_exact_worlds":sum(x["discovery_exact"] for x in rows),
    "ood_exact_worlds":sum(x["ood_accuracy"]==1.0 for x in rows),
    "overall_ood_accuracy":sum(x["ood_exact_count"] for x in rows)/(len(rows)*len(OOD)),
    "static_halting_pass_worlds":sum(x["halting_all_cycles_certified"] for x in rows),
    "required_topology_property_worlds":sum(x["required_topology_property"]["pass"] for x in rows),
    "local_one_edit_irreducible_worlds":sum(x["local_one_edit_irreducible"] for x in rows),
    "local_redundancy_counterexample_worlds":sum(not x["local_one_edit_irreducible"] for x in rows),
    "cheaper_than_raw_history_worlds":sum(x["cheaper_than_raw_history"] for x in rows),
    "raw_history_cost":raw_cost,
    "mean_candidate_ood_cost":sum(x["candidate_ood_cost"] for x in rows)/len(rows),
    "global_minimality":"FALSIFIED_FOR_FROZEN_CANDIDATES_BY_CHEAPER_EXACT_ONE_EDIT_NEIGHBORS"
}

if (
    summary["discovery_exact_worlds"]==12 and summary["ood_exact_worlds"]==12 and
    summary["static_halting_pass_worlds"]==12 and summary["required_topology_property_worlds"]==12 and
    summary["local_one_edit_irreducible_worlds"]==12 and summary["cheaper_than_raw_history_worlds"]==12
):
    terminal="CONTROL_FLOW_TOPOLOGY_SYNTHESIS_DEMONSTRATED_WITHOUT_GLOBAL_MINIMALITY"
else:
    terminal="PARTIAL"

results={
    "experiment":"PRIMITIVE-2S",
    "version":"0.1.1",
    "candidate_freeze_sha256":CF["candidate_freeze_sha256"],
    "terminal_verdict":terminal,
    "summary":summary,
    "world_results":rows,
    "bounded_claim_if_any":(
        "Behaviorally exact control-flow topology synthesis and OOD transfer were demonstrated, "
        "but the frozen candidates failed the structural-necessity/minimality gate because cheaper exact one-edit CFGs exist."
    )
}
results["results_sha256"]=sha_obj(results)
(RES/"PRIMITIVE-2S_RESULTS.json").write_text(json.dumps(results,indent=2))
(RES/"PRIMITIVE-2S_LOCAL_IRREDUCIBILITY_COUNTEREXAMPLES.json").write_text(json.dumps(counterexamples,indent=2))
print(results["terminal_verdict"])
print(json.dumps(summary,indent=2))
