# PRIMITIVE-2S Method

1. Freeze the 2S design boundary before fixture generation.
2. Freeze twelve worlds: four dynamic-skip, four early-exit, four zero-advance-subloop.
3. Exhaust the complete 2R normal form on every discovery world; require zero exact support.
4. Split public discovery data from audit-only class, hidden CFG and OOD answers.
5. Reify the minimum-error 2R program into an explicit CFG seed.
6. Use graph-grammar CEGIS with static cycle certification before candidate execution.
7. Use only public behavior to quotient arbitrary S4 token-label symmetry. This produced three public behavioral equivalence classes.
8. Synthesize one representative CFG per public class; instantiate class members by the lexicographically smallest discovery-exact token renaming.
9. Freeze all twelve candidate CFGs before audit/OOD scoring.
10. Score OOD behavior, required topology properties, static halting, cost versus raw-history retention, and local one-edit structural necessity.
11. Do not run global lower-cost CFG exhaustion after local irreducibility fails: an explicit cheaper exact one-edit neighbor already disproves minimality of the frozen candidate.
12. Re-run the exact scorer and require byte-identical results.

Pre-score implementation history:
- v0.1.0 fixture generation passed.
- The first implementation preparer over-concentrated the subloop representative's initial collision set and did not complete under the execution harness; no scientific verdict was produced.
- v0.1.1 changed only public collision-pair stratification before scientific scoring. Design, fixtures, VM, graph grammar, halting rules, costs, OOD data and gates remained unchanged.

Scientific failure:
- All twelve candidates are exact on discovery and OOD and contain the required topology.
- All twelve fail the frozen local structural-necessity gate because a cheaper exact one-block deletion exists.
