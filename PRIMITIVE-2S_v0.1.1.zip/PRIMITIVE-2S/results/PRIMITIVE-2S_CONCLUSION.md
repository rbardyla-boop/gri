# PRIMITIVE-2S Conclusion

**Terminal verdict:** `PARTIAL`

PRIMITIVE-2S did demonstrate the behavioral part of control-flow topology synthesis:

```text
discovery exact             12/12
OOD exact                   12/12
static halting certified    12/12
required topology present   12/12
```

The synthesized CFGs cover all frozen execution distinctions:

```text
data-dependent one-vs-two token advancement
conditional early HALT
zero-ADVANCE register-descent subloop
```

However, the experiment does **not** pass.

The frozen structural-necessity gate found cheaper exact one-edit neighbors in:

```text
12/12 worlds
```

and therefore:

```text
local one-edit irreducible = 0/12
```

The graph search constructed the required execution architecture but carried redundant dispatch structure inherited from the reified 2R starting graph.

Accordingly, global minimality is already falsified for the frozen candidates; exhaustive global search is unnecessary to establish that fact.

Supported partial claim:

> Within the frozen 2S VM and graph grammar, graph-grammar CEGIS can construct statically terminating control-flow topologies that implement data-dependent skipping, early exit and an internal register-descent loop and transfer those topologies exactly to OOD sequences. The current search/cost procedure does not yet remove redundant inherited control flow and therefore fails the frozen structural-necessity/minimality gate.

The largest remaining gap stays inside 2S.

Do not advance to instruction-substrate escape yet.

The next repair should be a bounded **2S.1 topology normalization/minimization** unit applied without changing the worlds: post-synthesis dead/redundant-block elimination, edge contraction and payload minimization must run using discovery data only, freeze the normalized CFG, and then replay the unchanged OOD and topology gates.
