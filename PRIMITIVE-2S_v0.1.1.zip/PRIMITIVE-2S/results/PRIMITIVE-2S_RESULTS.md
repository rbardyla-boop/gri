# PRIMITIVE-2S Results

**Terminal verdict:** `PARTIAL`  
**Exact deterministic replay:** `PASS`

| Gate | Result |
|---|---:|
| Discovery exact | 12/12 |
| OOD exact | 12/12 |
| Static halting certified | 12/12 |
| Required topology property present | 12/12 |
| Cheaper than raw-history control | 12/12 |
| **Local one-edit irreducibility** | **0/12** |

The behavior-level topology synthesis succeeded, including all three frozen topology classes.

The structural-necessity gate failed. Every frozen candidate has a cheaper exact one-edit neighbor, so the candidates are not minimal even locally.

`global_minimality` is therefore not merely unproven for these frozen candidates; it is falsified by explicit cheaper exact local counterexamples.
