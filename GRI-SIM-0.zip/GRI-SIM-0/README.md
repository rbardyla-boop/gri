# GRI-SIM-0 — Bounded Primitive Laboratory

GRI-SIM-0 is infrastructure for the Small-Info / GRI research branch. It is not a successor mechanism and does not authorize a new scientific claim.

Purpose: make candidate iteration fast while keeping the experiment boundary hard. Candidate code is loaded through a narrow recurrent-cell interface; the simulator owns sequence stepping, training split selection, precision modes, q8 state storage, restart testing, fixed-decoder evaluation, and budget preflight.

Core rule: a run may be convenient, but it is not a scientific verdict unless the experiment manifest, candidate declaration, hashes, accounting audit, replay, and preregistered verdict all pass.

## Commands

```bash
python gri_sim0.py validate-experiment --experiment experiment_manifest.json
python gri_sim0.py validate-candidate --experiment experiment_manifest.json \
  --candidate candidate_manifest.example.json --source candidate_template.py
python gri_sim0.py scaffold --name MY-CANDIDATE --out ./my_candidate
```

The included candidate template intentionally does not implement a research mechanism.

## Codex workflow

Give Codex only:

1. `GRI-SIM-0-SPEC.md`
2. `candidate_protocol.py`
3. the experiment manifest
4. a new candidate manifest
5. the explicit authorization for that candidate

Codex should not edit the simulator, frozen experiment manifest, fixture bank, operation rules, or verdict logic during a candidate run.

## Current GRI boundary

The closed GRI-01 → GRI-02C.1 sequence remains unchanged. `GRI-SIM-0` is tooling only. It does not authorize a successor candidate.
