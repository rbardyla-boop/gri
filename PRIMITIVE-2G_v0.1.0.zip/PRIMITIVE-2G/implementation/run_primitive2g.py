from pathlib import Path
import json, hashlib, itertools, os, time, csv
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)
BASE=Path('/mnt/data')
P2A=BASE/'PRIMITIVE-2A'; P2B=BASE/'PRIMITIVE-2B'; P2D=BASE/'PRIMITIVE-2D'; P2E=BASE/'PRIMITIVE-2E'
ROOT=BASE/'PRIMITIVE-2G'; FIX=ROOT/'PRIMITIVE-2G_FIXTURES'; RES=ROOT/'results'
RES.mkdir(exist_ok=True)
ACTS=['ASSERT','DERIVE']; RELS=['BEFORE','PART_OF','ASSIGNED_TO','LOCATED_IN']
A2I={x:i for i,x in enumerate(ACTS)}; R2I={x:i for i,x in enumerate(RELS)}; I2R={i:x for x,i in R2I.items()}
RO_NONE=4
RULES={'BEFORE|BEFORE':'BEFORE','PART_OF|PART_OF':'PART_OF','PART_OF|ASSIGNED_TO':'ASSIGNED_TO'}
bitpos=torch.arange(24,dtype=torch.long)

def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def sha_file(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/'PRIMITIVE-2G_FREEZE.json').read_text())
for rec in freeze['files']:
    assert sha_file(ROOT/rec['name'])==rec['sha256'],rec['name']
for seed,h in freeze['parent_model_hashes'].items():
    assert sha_file(P2A/'models'/f'M2_seed_{seed}.pt')==h
assert sha_file(P2D/'PRIMITIVE-2D_MECHANISMS.json')==freeze['parent_p2d_rollback_sha256']

catalog=json.loads((ROOT/'PRIMITIVE-2G_OBSERVATION_CATALOG.json').read_text())
suite=json.loads((FIX/'CASE_SUITE.json').read_text())
wdoc=json.loads((FIX/'WITNESS_LEDGERS.json').read_text()); wmap={r['fixture_id']:r for r in wdoc['records']}
known_suite=json.loads((P2D/'PRIMITIVE-2D_FIXTURES'/'CHALLENGE_SUITE.json').read_text())
p2b_graphs=json.loads((P2B/'PRIMITIVE-2B_FIXTURES'/'RECURSIVE_STABILITY_GRAPHS.json').read_text()); p2b_map={f['fixture_id']:f for f in p2b_graphs['fixtures']}
p2e_graphs=json.loads((P2E/'PRIMITIVE-2E_FIXTURES'/'CONFIRMATION_GRAPHS.json').read_text()); p2e_map={f['fixture_id']:f for f in p2e_graphs['fixtures']}

class BindingComposer(nn.Module):
    def __init__(self):
        super().__init__()
        self.refenc=nn.Sequential(nn.Linear(24,32),nn.ReLU(),nn.Linear(32,32),nn.ReLU())
        self.body=nn.Sequential(nn.Linear(332,128),nn.ReLU(),nn.Linear(128,128),nn.ReLU())
        self.bind=nn.Linear(128,3); self.rel=nn.Linear(128,5); self.ssel=nn.Linear(128,4); self.osel=nn.Linear(128,4)
    def forward(self,acts,rels,refs):
        rb=((refs.unsqueeze(-1)>>bitpos)&1).float(); e=self.refenc(rb)
        diffs=torch.cat([(e[:,i]-e[:,j]).abs() for i,j in itertools.combinations(range(4),2)],dim=1)
        meta=torch.cat([F.one_hot(acts[:,0],2).float(),F.one_hot(acts[:,1],2).float(),F.one_hot(rels[:,0],4).float(),F.one_hot(rels[:,1],4).float()],dim=1)
        h=self.body(torch.cat([e.flatten(1),diffs,meta],dim=1))
        return self.bind(h),self.rel(h),self.ssel(h),self.osel(h)

def load_model(seed):
    m=BindingComposer(); m.load_state_dict(torch.load(P2A/'models'/f'M2_seed_{seed}.pt',map_location='cpu',weights_only=True)); m.eval(); return m

def oracle_pair(l,r):
    ls,lr,lo=l; rs,rr,ro=r
    key=f'{I2R[lr]}|{I2R[rr]}'
    if lo==rs and key in RULES: return (ls,R2I[RULES[key]],ro)
    key=f'{I2R[rr]}|{I2R[lr]}'
    if ro==ls and key in RULES: return (rs,R2I[RULES[key]],lo)
    return None

def oracle_closure(fx):
    facts={(int(p['subject']),R2I[p['relation']],int(p['object'])) for p in fx['inputs']}
    while True:
        arr=list(facts); new=set()
        for l in arr:
            for r in arr:
                x=oracle_pair(l,r)
                if x is not None and x not in facts:new.add(x)
        if not new:return facts
        facts|=new

def predict_candidates(model,packets,pairs,chunk=4096):
    pkt=torch.tensor(packets,dtype=torch.long)
    for st in range(0,len(pairs),chunk):
        ij=pairs[st:st+chunk]; ii=torch.tensor([x[0] for x in ij]); jj=torch.tensor([x[1] for x in ij])
        left=pkt[ii]; right=pkt[jj]
        acts=torch.stack([left[:,1],right[:,1]],dim=1); rels=torch.stack([left[:,3],right[:,3]],dim=1)
        refs=torch.stack([left[:,2],left[:,4],right[:,2],right[:,4]],dim=1)
        with torch.no_grad(): pb,pr,ps,po=[x.argmax(-1) for x in model(acts,rels,refs)]
        mask=(pb!=0)&(pr!=RO_NONE); sel=torch.nonzero(mask,as_tuple=False).flatten()
        for t in sel.tolist():
            i,j=ij[t]; slots=refs[t]
            yield (int(slots[int(ps[t])]),int(pr[t]),int(slots[int(po[t])])),i,j

def audited_run(model,fx):
    gold=oracle_closure(fx)
    packets=[[int(p['id']),A2I[p['act']],int(p['subject']),R2I[p['relation']],int(p['object']),1000] for p in fx['inputs']]
    facts=[(p[2],p[3],p[4]) for p in packets]; fact_to_idx={f:i for i,f in enumerate(facts)}
    is_input={f:True for f in facts}; supports={f:set() for f in facts}; next_ref=max(p[0] for p in packets)+1; frontier=list(range(len(packets)))
    rounds=0; pair_evals=0
    while frontier and rounds<int(fx['max_rounds']):
        rounds+=1; n=len(packets); fset=set(frontier)
        pairs=[(i,j) for i in range(n) for j in range(n) if i!=j and (i in fset or j in fset)]; pair_evals+=len(pairs)
        newfacts=set()
        for fact,li,ri in predict_candidates(model,packets,pairs):
            supports.setdefault(fact,set()).add((facts[li],facts[ri]))
            if fact not in fact_to_idx:newfacts.add(fact)
        if not newfacts:break
        frontier=[]
        for fact in sorted(newfacts):
            if fact in fact_to_idx:continue
            s,r,o=fact; p=[next_ref,A2I['DERIVE'],s,r,o,1000]; next_ref+=1
            idx=len(packets); packets.append(p); facts.append(fact); fact_to_idx[fact]=idx; is_input[fact]=False; frontier.append(idx)
    final=set(facts)
    return {'gold':gold,'final':final,'bad':final-gold,'supports':supports,'is_input':is_input,'rounds':rounds,'pair_evaluations':pair_evals}

def justification_dag(run,challenged):
    active={f for f,v in run['is_input'].items() if v and f not in challenged}
    changed=True
    while changed:
        changed=False
        for fact in run['final']:
            if fact in active or fact in challenged or run['is_input'].get(fact,False):continue
            for l,r in run['supports'].get(fact,set()):
                if l in active and r in active: active.add(fact); changed=True; break
    return active

def channel_cost(fixture_id,fact,channel):
    rel=I2R[fact[1]]; channels={c['name']:c for c in catalog['verification_contracts'][rel]['channels']}; lo,hi=channels[channel]['cost_range']
    key=f"{catalog['cost_generation']['seed']}|{fixture_id}|{fact[0]}|{rel}|{fact[2]}|{channel}".encode()
    n=int.from_bytes(hashlib.sha256(key).digest()[:8],'big')
    return lo+(n%(hi-lo+1))

def plan_cost(fixture_id,fact,plan): return sum(channel_cost(fixture_id,fact,ch) for ch in plan)

def plan_sufficient(rel,plan):
    contract=catalog['verification_contracts'][rel]
    # DIRECT_BOOL is independently sufficient.
    if 'DIRECT_BOOL' in plan:return True
    covered=set(); cmap={c['name']:c for c in contract['channels']}
    for ch in plan: covered.update(cmap[ch]['covers'])
    return set(contract['required_slots']).issubset(covered)

def min_cost_sufficient_plan(fixture_id,fact):
    rel=I2R[fact[1]]; channels=[c['name'] for c in catalog['verification_contracts'][rel]['channels']]
    # DP over slot coverage, plus direct bool candidate.
    required=catalog['verification_contracts'][rel]['required_slots']; idx={s:i for i,s in enumerate(required)}; full=(1<<len(required))-1
    cmap={c['name']:c for c in catalog['verification_contracts'][rel]['channels']}
    best={0:(0,())}
    for ch in channels:
        if ch=='DIRECT_BOOL':continue
        mask=0
        for s in cmap[ch]['covers']:
            if s in idx: mask|=1<<idx[s]
        cost=channel_cost(fixture_id,fact,ch)
        nxt=dict(best)
        for m,(bc,bp) in best.items():
            nm=m|mask; cand=(bc+cost,tuple(sorted(bp+(ch,))))
            if nm not in nxt or cand<nxt[nm]:nxt[nm]=cand
        best=nxt
    candidates=[]
    if full in best:candidates.append(best[full])
    dc=channel_cost(fixture_id,fact,'DIRECT_BOOL'); candidates.append((dc,('DIRECT_BOOL',)))
    return min(candidates)

def choose_plan(fixture_id,fact,planner):
    rel=I2R[fact[1]]; channels=[c['name'] for c in catalog['verification_contracts'][rel]['channels']]
    if planner=='FULL_ACQUIRE': return tuple(sorted(channels)),plan_cost(fixture_id,fact,channels),True
    if planner=='DIRECT_ONLY': return ('DIRECT_BOOL',),channel_cost(fixture_id,fact,'DIRECT_BOOL'),True
    if planner=='CHEAPEST_SINGLE_QUERY':
        choices=sorted((channel_cost(fixture_id,fact,ch),ch) for ch in channels); c,ch=choices[0]; plan=(ch,); return plan,c,plan_sufficient(rel,plan)
    if planner=='MIN_COST_SUFFICIENT_PLAN':
        c,plan=min_cost_sufficient_plan(fixture_id,fact); return plan,c,True
    raise KeyError(planner)

def witness_truth(fact,w):
    s,r,o=fact; rel=I2R[r]; ss=str(s); oo=str(o)
    if rel=='BEFORE':
        return ss in w['order_component'] and oo in w['order_component'] and w['order_component'][ss]==w['order_component'][oo] and w['order_rank'][ss] < w['order_rank'][oo]
    if rel=='PART_OF':
        return ss in w['containment_component'] and oo in w['containment_component'] and w['containment_component'][ss]==w['containment_component'][oo] and w['interval_low'][ss]>w['interval_low'][oo] and w['interval_high'][ss]<w['interval_high'][oo]
    if rel=='ASSIGNED_TO': return ss in w['assignment_zone'] and int(w['assignment_zone'][ss])==o
    if rel=='LOCATED_IN': return ss in w['location'] and int(w['location'][ss])==o
    return False

def planner_challenges(run,w,fixture_id,planner):
    challenged=set(); total_cost=0; verified=0; abstained=0; optimal_cost=0; plan_records=[]
    for fact in sorted(run['final']):
        if run['is_input'].get(fact,False):continue
        opt,_plan=min_cost_sufficient_plan(fixture_id,fact); optimal_cost+=opt
        plan,cost,sufficient=choose_plan(fixture_id,fact,planner); total_cost+=cost
        if not sufficient:
            abstained+=1; decision='ABSTAIN'
        else:
            verified+=1; valid=witness_truth(fact,w); decision='SUPPORT' if valid else 'CHALLENGE'
            if not valid:challenged.add(fact)
        plan_records.append({'fact':list(fact),'plan':list(plan),'cost':cost,'sufficient':sufficient,'decision':decision,'optimal_cost':opt})
    return challenged,{'total_observation_cost':total_cost,'verified_fact_count':verified,'abstained_fact_count':abstained,'optimal_cost_lower_bound':optimal_cost,'plan_optimality_ratio':1.0 if optimal_cost==0 else total_cost/optimal_cost,'plans':plan_records}

def score_case(seed,fx,model,w,expected=None,surface='CONFIRMATION'):
    run=audited_run(model,fx); baseline_equiv=True
    if expected is not None:
        recall=len(run['final']&run['gold'])/len(run['gold'])
        baseline_equiv=len(run['bad'])==expected['baseline_bad_packet_count'] and len(run['final']-run['gold'])==expected['baseline_false_positive_facts'] and abs(recall-expected['baseline_recall'])<1e-12
    variants={}
    for planner in catalog['planners']:
        ch,meta=planner_challenges(run,w,fx['fixture_id'],planner); active=justification_dag(run,ch); bad_after=active-run['gold']; fn=run['gold']-active
        variants[planner]={
            'challenged_fact_count':len(ch),'challenged_bad_fact_count':len(ch&run['bad']),'challenged_valid_fact_count':len(ch&run['gold']),
            'active_bad_fact_count_after_rollback':len(bad_after),'false_negative_fact_count_after_rollback':len(fn),
            'oracle_valid_recall_after_rollback':len(active&run['gold'])/len(run['gold']),'exact_graph_match_after_rollback':active==run['gold'],
            'total_observation_cost':meta['total_observation_cost'],'verified_fact_count':meta['verified_fact_count'],'abstained_fact_count':meta['abstained_fact_count'],
            'optimal_cost_lower_bound':meta['optimal_cost_lower_bound'],'plan_optimality_ratio':meta['plan_optimality_ratio']
        }
    return {'surface':surface,'seed':seed,'fixture_id':fx['fixture_id'],'family':fx['family'],'scale':fx['scale'],'baseline_equivalence_pass':baseline_equiv,'baseline_bad_fact_count':len(run['bad']),'baseline_fact_count':len(run['final']),'gold_fact_count':len(run['gold']),'variants':variants}

models={s:load_model(s) for s in (13,29,61)}
case_results=[]; t0=time.time()
for c in known_suite['cases']:
    fx=p2b_map[c['fixture_id']]; case_results.append(score_case(c['seed'],fx,models[c['seed']],wmap[fx['fixture_id']],expected=c,surface='KNOWN'))
for seed in (13,29,61):
    for fid in suite['confirmation_fixture_ids']:
        fx=p2e_map[fid]; case_results.append(score_case(seed,fx,models[seed],wmap[fid],surface='CONFIRMATION'))
known=[c for c in case_results if c['surface']=='KNOWN']; conf=[c for c in case_results if c['surface']=='CONFIRMATION']; known_equiv=all(c['baseline_equivalence_pass'] for c in known)

def agg(sub,p):
    rs=[c['variants'][p] for c in sub]; total_cost=sum(r['total_observation_cost'] for r in rs); opt=sum(r['optimal_cost_lower_bound'] for r in rs)
    return {'case_count':len(rs),'exact_after_rollback_count':sum(r['exact_graph_match_after_rollback'] for r in rs),'active_bad_after_total':sum(r['active_bad_fact_count_after_rollback'] for r in rs),'valid_false_challenges_total':sum(r['challenged_valid_fact_count'] for r in rs),'min_post_rollback_recall':min(r['oracle_valid_recall_after_rollback'] for r in rs),'total_observation_cost':total_cost,'optimal_cost_lower_bound':opt,'aggregate_optimality_ratio':1.0 if opt==0 else total_cost/opt,'verified_fact_count':sum(r['verified_fact_count'] for r in rs),'abstained_fact_count':sum(r['abstained_fact_count'] for r in rs)}
summary={}
for p in catalog['planners']:
    summary[p]={'known':agg(known,p),'confirmation':agg(conf,p),'all':agg(case_results,p)}
primary=summary['MIN_COST_SUFFICIENT_PLAN']['all']; full=summary['FULL_ACQUIRE']['all']
primary_pass=(summary['MIN_COST_SUFFICIENT_PLAN']['known']['exact_after_rollback_count']==9 and summary['MIN_COST_SUFFICIENT_PLAN']['confirmation']['exact_after_rollback_count']==90 and primary['active_bad_after_total']==0 and primary['valid_false_challenges_total']==0 and primary['min_post_rollback_recall']==1.0 and abs(primary['aggregate_optimality_ratio']-1.0)<1e-12 and primary['total_observation_cost']<full['total_observation_cost'])
if not known_equiv: terminal='EXPERIMENT_INVALID'
elif primary_pass: terminal='ACTIVE_WITNESS_ACQUISITION_DEMONSTRATED_WITHIN_TESTED_SCOPE'
elif summary['MIN_COST_SUFFICIENT_PLAN']['known']['exact_after_rollback_count']==9: terminal='PARTIAL'
else: terminal='ACTIVE_ACQUISITION_INSUFFICIENT'
results={'experiment':'PRIMITIVE-2G','version':'0.1.0','terminal_verdict':terminal,'freeze_sha256':freeze['freeze_sha256'],'known_baseline_equivalence':'PASS' if known_equiv else 'FAIL','case_count':len(case_results),'elapsed_seconds':time.time()-t0,'planner_summary':summary,'cases':case_results}
# elapsed is non-deterministic; exclude it from canonical result hash.
hash_view=dict(results); hash_view.pop('elapsed_seconds',None); results['results_sha256']=hashlib.sha256(canon(hash_view).encode()).hexdigest()
(RES/'PRIMITIVE-2G_RESULTS.json').write_text(json.dumps(results,indent=2))
print('PRIMITIVE-2G',terminal,'cases',len(case_results),'seconds',round(results['elapsed_seconds'],2))
for p,s in summary.items(): print(p,s['all'])
