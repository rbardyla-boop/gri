#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.load(open(ROOT/'results/PRIMITIVE-2G_RESULTS.json'))
rp=json.load(open(ROOT/'results/PRIMITIVE-2G_REPLAY_CHECK.json'))
assert r['terminal_verdict']=='ACTIVE_WITNESS_ACQUISITION_DEMONSTRATED_WITHIN_TESTED_SCOPE'
assert r['case_count']==99
assert r['known_baseline_equivalence']=='PASS'
assert rp['deterministic_semantic_replay']=='PASS'
x=r['planner_summary']['MIN_COST_SUFFICIENT_PLAN']['all']
assert x['exact_after_rollback_count']==99
assert x['active_bad_after_total']==0
assert x['valid_false_challenges_total']==0
assert x['min_post_rollback_recall']==1.0
assert x['aggregate_optimality_ratio']==1.0
assert x['total_observation_cost'] < r['planner_summary']['FULL_ACQUIRE']['all']['total_observation_cost']
print('PRIMITIVE_2G_TEST_PASS')
