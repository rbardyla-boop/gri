# PRIMITIVE-2G Method

1. Keep the three frozen PRIMITIVE-2A learned models unchanged.
2. Keep PRIMITIVE-2D JUSTIFICATION_DAG rollback unchanged.
3. Reuse the same 99 acyclic model/graph cases and witness semantics from PRIMITIVE-2F.
4. Hide witness values before acquisition.
5. Expose only candidate fact, verification contract, observation-channel coverage, and deterministic channel cost.
6. Compare FULL_ACQUIRE, DIRECT_ONLY, CHEAPEST_SINGLE_QUERY, and MIN_COST_SUFFICIENT_PLAN.
7. For MIN_COST_SUFFICIENT_PLAN, solve exact minimum-cost coverage by dynamic programming over required witness slots; DIRECT_BOOL is an independently sufficient alternative.
8. Acquire only the selected channels, decide SUPPORT/CHALLENGE, then invoke the unchanged justification DAG.
9. Score final graph correctness, bad facts, valid recall, false challenges, acquisition cost, and plan optimality.
10. Re-run the entire scorer and require an identical canonical results hash.

This experiment tests acquisition planning given fixed verification contracts. It does not test invention of the verification contract itself.
