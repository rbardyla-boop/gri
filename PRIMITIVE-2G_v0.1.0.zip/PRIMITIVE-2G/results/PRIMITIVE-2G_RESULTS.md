# PRIMITIVE-2G Results

**Terminal verdict:** `ACTIVE_WITNESS_ACQUISITION_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Cases:** 99  
**Known baseline equivalence:** `PASS`  
**Deterministic replay:** `PASS`

| Planner | Exact cases | Bad after | Valid challenged | Total cost | Optimality ratio | Verified | Abstained |
|---|---:|---:|---:|---:|---:|---:|---:|
| FULL_ACQUIRE | 99/99 | 0 | 0 | 524997 | 5.808260 | 11464 | 0 |
| DIRECT_ONLY | 99/99 | 0 | 0 | 141151 | 1.561612 | 11464 | 0 |
| CHEAPEST_SINGLE_QUERY | 86/99 | 375 | 0 | 14882 | 0.164646 | 363 | 11101 |
| MIN_COST_SUFFICIENT_PLAN | 99/99 | 0 | 0 | 90388 | 1.000000 | 11464 | 0 |
