# PRIMITIVE-2G Conclusion

**Terminal verdict:** `ACTIVE_WITNESS_ACQUISITION_DEMONSTRATED_WITHIN_TESTED_SCOPE`

`MIN_COST_SUFFICIENT_PLAN` passed the complete gate:

```text
exact cases:                 99/99
active bad facts:            0
valid facts challenged:      0
minimum valid recall:        1.0
verified derived facts:      11464
abstentions:                 0
plan optimality ratio:       1.0
total observation cost:      90388
deterministic replay:        PASS
```

Cost comparison:

```text
FULL_ACQUIRE:                524997
DIRECT_ONLY:                 141151
MIN_COST_SUFFICIENT_PLAN:    90388
```

The active planner used **82.78% less observation cost than acquiring everything** and **35.96% less than always using the direct check**, while preserving the exact PRIMITIVE-2F verification outcome.

The negative control `CHEAPEST_SINGLE_QUERY` spent only 14882 cost units but abstained on 11101 derived facts, leaving all 375 bad facts active. Cheap evidence is not useful merely because it is cheap; the acquired evidence must be sufficient to decide the claim.

## Supported claim

> Given a fixed verification contract and a catalog of external observations with heterogeneous costs, a generic machine planner can choose an exact minimum-cost sufficient witness plan, acquire only that evidence, and preserve perfect downstream verification/rollback on the frozen packet-reasoning suite.

## Remaining boundary

PRIMITIVE-2G does not yet show that the system can invent the right test. It was told which witness slots make a claim decidable.

The next largest gap is therefore **verification-contract discovery / experimental design**: can the machine infer what observable would discriminate between a thought being true or false, rather than merely optimize the cost of a known test?
