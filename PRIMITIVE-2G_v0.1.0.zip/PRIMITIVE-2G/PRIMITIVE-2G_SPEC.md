# PRIMITIVE-2G — ACTIVE WITNESS ACQUISITION

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `8662e6fb937d73f870caacc5b4c7bb2477820fa6be794ebeea54de9b9144e6a6`  
**Observation-catalog SHA-256:** `6c1d578ebdec37a8ca49664e27ebdb10e2b08b0bf3cd26ed89d6649068febfc7`

## Question

> Given a derived packet whose truth is uncertain and several possible external checks with different costs, can the machine choose the minimum-cost sufficient witness plan, acquire only that evidence, and use it to verify or challenge the thought?

## Frozen lower layers

Unchanged:

```text
three PRIMITIVE-2A learned models
PRIMITIVE-2D JUSTIFICATION_DAG
PRIMITIVE-2F witness semantics
99 acyclic PRIMITIVE-2F model/graph cases
```

PRIMITIVE-2G changes only **how witness evidence is acquired**.

## Hidden-information boundary

Before acquisition the planner may see:

```text
candidate semantic packet
verification contract
available observation channels
channel coverage
channel cost
```

It may not see:

```text
hidden witness values
oracle closure
model confidence
whether the packet is actually valid
```

Observation values are revealed only after a channel is purchased.

## Acquisition task

Every relation has a fixed verification contract inherited from PRIMITIVE-2F. Channels expose some or all required witness slots at deterministic heterogeneous costs.

The primary candidate `MIN_COST_SUFFICIENT_PLAN` solves a generic minimum-cost set-cover problem over declared witness slots. It must acquire a plan that is sufficient **for any possible hidden witness values**, not a clairvoyant plan chosen after seeing the answer.

## Competing planners

```text
FULL_ACQUIRE
DIRECT_ONLY
CHEAPEST_SINGLE_QUERY
MIN_COST_SUFFICIENT_PLAN
```

## Scientific boundary

A positive result establishes economical active acquisition **given a known verification contract**.

It does not establish that the system can invent the correct verification contract or decide which new kind of experiment would be scientifically relevant in an open world.

## Strict gate

The primary planner must achieve:

```text
99/99 exact final graphs
0 active bad facts
100% valid recall
0 valid facts challenged
exact minimum sufficient-plan cost on every acquired fact
strictly lower total cost than FULL_ACQUIRE
deterministic replay
```
