#!/usr/bin/env python3
import json, hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
w=json.loads((HERE/"ENCODING-2_WORKLOAD.json").read_text())
p=json.loads((HERE/"ENCODING-2_PREDICTION.json").read_text())
r=json.loads((HERE/"results"/"ENCODING-2_RESULTS.json").read_text())
assert r["workload_sha256"]==w["workload_sha256"]
assert r["prediction_sha256"]==p["prediction_sha256"]
assert r["packet_count"]==1536
assert r["replay"]=="PASS"
print("ENCODING_2_REFERENCE_PASS")
