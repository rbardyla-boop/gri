#!/usr/bin/env python3
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
r=json.loads((HERE/"results"/"ENCODING-2_RESULTS.json").read_text())
assert r["packet_count"]==1536
assert r["replay"]=="PASS"
assert len(r["scores"])==9
assert r["first_strict_batch_win"] is not None
print("ENCODING_2_TEST_PASS")
