# ENCODING-2 Conclusion

**Terminal verdict:** `PREDICTION_REPLICATED_EXACTLY`

The representative workload contained:

```text
1536 packet transformations
7 ACT symbols
4 RELATION symbols
776 dynamic SUBJECT/OBJECT symbols
```

The preregistered prediction was:

```text
batch 1..3 → VARINT_INBAND cheaper
batch >=4  → BATCH_INBAND cheaper
```

Observed first strict batching win:

```text
batch size = 4
```

Raw byte results are preserved in `ENCODING-2_RESULTS.json`.

Scope:

This is a representative hand-authored/deterministically expanded research/inference packet trace, not captured production telemetry. A successful replication therefore supports transfer from synthetic traffic to one workflow-shaped trace, but does not establish production generality.
