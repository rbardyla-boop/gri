# ENCODING-2 Results

**Terminal verdict:** `PREDICTION_REPLICATED_EXACTLY`  
**Workload packets:** 1536  
**Dynamic symbols:** 776  
**Dictionary bytes:** 3626  
**VARINT_INBAND total:** 17862 bytes  
**First strict BATCH_INBAND win:** 4

| Batch size | Varint bytes | Batch bytes | Delta (batch-varint) | Winner |
|---:|---:|---:|---:|---|
| 1 | 17862 | 25542 | 7680 | VARINT_INBAND |
| 2 | 17862 | 19999 | 2137 | VARINT_INBAND |
| 3 | 17862 | 18152 | 290 | VARINT_INBAND |
| 4 | 17862 | 17227 | -635 | BATCH_INBAND |
| 6 | 17862 | 16311 | -1551 | BATCH_INBAND |
| 8 | 17862 | 15839 | -2023 | BATCH_INBAND |
| 16 | 17862 | 15145 | -2717 | BATCH_INBAND |
| 32 | 17862 | 14803 | -3059 | BATCH_INBAND |
| 64 | 17862 | 14629 | -3233 | BATCH_INBAND |
