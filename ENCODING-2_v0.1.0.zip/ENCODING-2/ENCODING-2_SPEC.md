# ENCODING-2 — REPRESENTATIVE WORKLOAD VALIDATION

**Version:** 0.1.0  
**Status:** WORKLOAD AND PREDICTION FROZEN BEFORE SCORING  
**Workload SHA-256:** `303ff357e73a50c8212a5870c4bc49bfaf36b3f2aabc50909735116630798389`  
**Prediction SHA-256:** `27fa94fa6f1becab20632af24fde63f1b3f097b017d0349e3d63441968e81861`

## Question

> Does the current six-field primitive plus varint/batch encoding behave on one representative research/inference workload the way ENCODING-1A/1B predicted?

## Important scope statement

`REPRESENTATIVE_RESEARCH_TRACE_0` is a hand-authored/deterministically expanded representative workload.

It is **not** claimed to be captured production telemetry.

The purpose is to leave the generic random/periodic traffic generators and test a workflow-shaped packet trace with:

- evidence assertions;
- evaluation requests;
- evaluator responses;
- contradictory evidence;
- derived relations;
- updates;
- retractions;
- comparisons;
- interleaved late request/response traffic.

## Semantic primitive

Unchanged:

```text
STABLE_REFERENCE
ACT
SUBJECT
RELATION
OBJECT
VALUE
```

No field may be added or reinterpreted.

## Workload

Exactly `1536` frozen packets.

The final expanded trace is authoritative. Encoding implementations may not regenerate or reorder it.

## Protocol

Same dynamic SUBJECT/OBJECT dictionary logic as ENCODING-1:

- ACT and RELATION are fixed protocol enums;
- SUBJECT/OBJECT use a session-local dictionary;
- dictionary updates are charged before first use;
- one long-lived session for this workload;
- stable packet identity is in-band;
- VALUE uses ZigZag varint.

## Profiles

```text
VARINT_INBAND
BATCH_INBAND
```

Batch sizes tested:

```text
[1, 2, 3, 4, 6, 8, 16, 32, 64]
```

`batch_size=1` is included as an internal control.

## Preregistered prediction

From ENCODING-1A/1B long-stream results:

```text
batch 1..3 → VARINT_INBAND cheaper
batch >=4  → BATCH_INBAND strictly cheaper
```

The representative workload is ~1.5k packets, so the long-stream prediction is the relevant one.

## Verdicts

```text
PREDICTION_REPLICATED_EXACTLY
PREDICTION_REPLICATED_DIRECTION_NOT_THRESHOLD
PREDICTION_NOT_REPLICATED
EXPERIMENT_INVALID
```

No benchmark or workload edits are authorized after scoring.
