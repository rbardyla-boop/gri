# ENCODING-2 METHOD

1. Construct one workflow-shaped packet trace representing a research/inference session.
2. Expand the entire trace before scoring.
3. Hash and freeze the final 1,536-packet workload.
4. Freeze the prior prediction before scoring:
   - batch sizes 1..3: VARINT_INBAND cheaper;
   - batch size 4 and above: BATCH_INBAND cheaper.
5. Preserve the six-field semantic primitive unchanged.
6. Use one long-lived dynamic SUBJECT/OBJECT dictionary.
7. Score VARINT_INBAND and BATCH_INBAND only.
8. Charge dictionary update bytes.
9. Compare exact byte totals on batch sizes 1,2,3,4,6,8,16,32,64.
10. Replay the byte accounting and preserve the raw receipt.

This workload is representative and workflow-shaped, but is not captured production telemetry.
