from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Sequence

from . import __version__
from .adapters.inspect_ai import audit_inspect_log
from .autopsy import autopsy_claim
from .claim_draft import materialize_approved_markdown_claim, scan_markdown
from .core import audit_result, create_freeze, replay_run, run_frozen, verify_freeze, verdict_frozen


def _emit(value: Any) -> None:
    print(json.dumps(value, indent=2, sort_keys=True))


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gauntlet",
        description="Evaluation-integrity and mechanism-credit tooling for AI evaluations.",
    )
    parser.add_argument("--version", action="version", version=f"gauntlet {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    freeze = sub.add_parser("freeze", help="freeze a TOML/JSON experiment spec and declared inputs")
    freeze.add_argument("spec")
    freeze.add_argument("--output")

    verify = sub.add_parser("verify", help="verify a frozen manifest against current files and repository state")
    verify.add_argument("manifest")

    run = sub.add_parser("run", help="execute exactly the run bound by a freeze manifest")
    run.add_argument("manifest")
    run.add_argument("--run-id")

    replay = sub.add_parser("replay", help="rerun a frozen evaluation and compare its declared outputs")
    replay.add_argument("manifest")
    replay.add_argument("receipt")
    replay.add_argument("--run-id")

    audit = sub.add_parser(
        "audit-result",
        help="mechanically apply gates to an existing result; explicitly retrospective, not preregistered",
    )
    audit.add_argument("spec")
    audit.add_argument("result")

    autopsy = sub.add_parser(
        "autopsy",
        help="apply generic mechanism-credit signals to existing evidence and emit the strongest surviving claim",
    )
    autopsy.add_argument("spec")

    draft_markdown = sub.add_parser(
        "draft-markdown",
        help="catalog Markdown comparison tables without assigning candidate, baseline, direction, or credit",
    )
    draft_markdown.add_argument("source")
    draft_markdown.add_argument("--output", required=True)
    draft_markdown.add_argument("--source-uri")
    draft_markdown.add_argument("--source-revision")
    draft_markdown.add_argument("--expected-git-blob-sha1")

    approve_markdown = sub.add_parser(
        "approve-markdown",
        help="materialize a content-bound comparison only after explicit human approval",
    )
    approve_markdown.add_argument("draft")
    approve_markdown.add_argument("approval")
    approve_markdown.add_argument("--output-dir", required=True)

    inspect_audit = sub.add_parser(
        "audit-inspect",
        help="conservatively audit a JSON Inspect AI EvalLog created outside Gauntlet",
    )
    inspect_audit.add_argument("log", help="JSON log or JSON output from 'inspect log dump'")
    inspect_audit.add_argument(
        "--run-config",
        help="optional JSON from 'inspect log export-config --format json'",
    )

    verdict = sub.add_parser("verdict", help="bind freeze, run receipt, optional replay, and result gates")
    verdict.add_argument("manifest")
    verdict.add_argument("receipt")
    verdict.add_argument("--replay")

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "freeze":
            value = create_freeze(args.spec, args.output)
            _emit(value)
            return 0
        if args.command == "verify":
            value = verify_freeze(args.manifest)
            _emit(value)
            return 0 if value["pass"] else 1
        if args.command == "run":
            value = run_frozen(args.manifest, args.run_id)
            _emit(value)
            return 0 if value["run_status"] == "PASS" else 1
        if args.command == "replay":
            value = replay_run(args.manifest, args.receipt, args.run_id)
            _emit(value)
            return 0 if value["pass"] else 1
        if args.command == "audit-result":
            value = audit_result(Path(args.spec), Path(args.result))
            _emit(value)
            return 0
        if args.command == "autopsy":
            value = autopsy_claim(Path(args.spec))
            _emit(value)
            return 0
        if args.command == "draft-markdown":
            value = scan_markdown(
                Path(args.source),
                output=Path(args.output),
                source_uri=args.source_uri,
                source_revision=args.source_revision,
                expected_git_blob_sha1=args.expected_git_blob_sha1,
            )
            _emit(value)
            return 0
        if args.command == "approve-markdown":
            value = materialize_approved_markdown_claim(
                Path(args.draft),
                Path(args.approval),
                output_dir=Path(args.output_dir),
            )
            _emit(value)
            return 0
        if args.command == "audit-inspect":
            value = audit_inspect_log(Path(args.log), Path(args.run_config) if args.run_config else None)
            _emit(value)
            return 0
        if args.command == "verdict":
            value = verdict_frozen(args.manifest, args.receipt, args.replay)
            _emit(value)
            return 1 if value["state"] == "INTEGRITY_FAIL" else 0
    except Exception as exc:  # CLI fail-closed boundary
        _emit({"error": type(exc).__name__, "message": str(exc), "pass": False})
        return 2
    raise AssertionError(args.command)


if __name__ == "__main__":
    raise SystemExit(main())
