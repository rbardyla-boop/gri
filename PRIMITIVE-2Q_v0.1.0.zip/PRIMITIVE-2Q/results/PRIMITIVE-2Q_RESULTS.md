# PRIMITIVE-2Q Results

**Terminal verdict:** `OPERATOR_SUBSTRATE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Exact deterministic replay:** `PASS`  
**Worlds:** 18  

| System | Exact support / recovery | OOD result | Mean cost |
|---|---:|---:|---:|
| FORCE_OMEGA0 | 0/18 exact-support worlds | n/a | saturated |
| RAW_HISTORY_MEMORIZATION | discovery keys only | 0.176101 exact-key coverage | 80.802 |
| **MICROLANGUAGE_SYNTHESIS** | **18/18** | **1.000000** | **39.332** |

## Coverage

`{'COUNT': 6, 'DISPLACEMENT': 6, 'NESTING': 6}`

## Primary system

- Minimum behavioral operator class exact: `18/18`
- OOD accuracy: `1.000000`
- Cheaper than raw-history retention: `18/18`
- Mean cost saving: `41.470`
- Operator elevation receipts: `18/18`
