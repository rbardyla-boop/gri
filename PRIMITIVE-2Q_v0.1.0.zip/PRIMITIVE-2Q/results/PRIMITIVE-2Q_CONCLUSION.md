# PRIMITIVE-2Q Conclusion

**Terminal verdict:** `OPERATOR_SUBSTRATE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Substrate saturation

The complete PRIMITIVE-2P-style one-bit streaming substrate had:

```text
exact-support worlds: 0/18
exact parameterizations: 0
```

Thus every frozen world requires computation outside that substrate.

## Micro-language synthesis

The selector received one flat low-level bytecode library with no high-level operator labels.

It recovered the correct minimum behavioral operator class in:

```text
18/18
```

worlds.

The selected bytecode was then frozen and elevated as a new operator.

## OOD extrapolation

The elevated operators were executed unchanged on sequences reaching 32 tokens, beyond the discovery lengths and with larger state ranges / deeper nesting.

```text
OOD prediction accuracy: 1.000000
```

This result covers three audit-only behavior regimes:

```text
{'COUNT': 6, 'DISPLACEMENT': 6, 'NESTING': 6}
```

The finite benchmark does not establish mathematical unboundedness. It demonstrates extrapolation beyond the synthesis range using integer-register and random-access-memory execution resources unavailable to the one-bit substrate.

## Raw-history control

Exact raw trajectory retention had:

```text
mean OOD exact-key coverage: 0.176101
mean cost:                   80.802
```

The synthesized operators had:

```text
mean cost:                   39.332
mean saving:                 41.470
cheaper worlds:              18/18
```

So the new operator substrate was both more transferable and cheaper than memorizing complete trajectories under the frozen accounting.

## Supported claim

Within the bounded μL catalog:

> When the complete one-bit streaming substrate has empty exact support, a machine can select a minimum-cost low-level register/memory program from an unlabeled micro-language, elevate its behavioral operator class into the active synthesis substrate, and preserve exact prediction on longer and deeper OOD trajectories at lower cost than full raw-history retention.

## Scope boundary

The micro-language and the 60-program bounded library are still supplied by the experiment.

The system did not invent `ADD`, branching, registers, pointers, or memory cells themselves.

Therefore the remaining gap has moved below operator synthesis:

> Can the machine synthesize or modify the execution semantics of the micro-language itself when no program expressible in the current instruction substrate resolves the collision?
