# PRIMITIVE-2Q METHOD

1. Bind PRIMITIVE-2Q to the frozen PRIMITIVE-2P experiment, Ω definition, and results by SHA-256.
2. Define the saturated baseline substrate as the complete one-bit deterministic transducer over four token symbols with two arbitrary final-state output maps.
3. Exhaustively evaluate that complete substrate on every discovery world; any exact baseline fit invalidates that world.
4. Freeze a low-level register/memory bytecode interpreter with generic instructions only.
5. Freeze a bounded 60-program bytecode library. Experimenter-side generation uses three resource/instruction envelopes for behavioral coverage, but the selector sees one flat unlabeled program list.
6. Do not expose audit labels such as counting, displacement, stack, nesting, accumulator, or memory.
7. Canonicalize operator identity behaviorally using all token sequences of length <=5. This removes arbitrary program/symbol symmetries.
8. For each world, retain exact bytecode programs and rank them by:
   description cost + 0.02 * mean runtime cost + individually measured peak persistent-state bits.
9. Freeze the minimum behavioral operator class before OOD execution.
10. Elevate its canonical bytecode representative as `omega_new`.
11. Run the frozen operator unchanged on sequences up to length 32, with count/displacement ranges and nesting depths beyond discovery.
12. Compare against full raw-history retention using frozen storage/description accounting.
13. Re-run the exact scorer and require byte-identical result JSON.

Pre-freeze corrections:
- Parity was rejected as a 2Q target because PRIMITIVE-2P already expresses it.
- Displacement outputs were made sign-sensitive so opposite directions are not artificially symmetric.
- Operator identity was changed from raw bytecode identity to behavioral equivalence classes.
- Invalid memory reads use the smallest out-of-alphabet sentinel value 2.
- Register state cost is charged per register's actual peak signed width rather than a shared sentinel-inflated width.
No scientific result existed before the final freeze.

PRIMITIVE-2Q remains bounded synthesis over a frozen 60-program bytecode library. It does not prove unrestricted program induction or literal unbounded computation.
