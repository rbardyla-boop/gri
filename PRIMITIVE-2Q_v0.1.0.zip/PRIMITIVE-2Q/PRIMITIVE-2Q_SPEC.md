# PRIMITIVE-2Q — OPERATOR-SUBSTRATE ESCAPE

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `ab3c9b1555d4ca35bff9f63636c96c4210aa18c296d0a21ebbd04b5eb96c8d23`

## Question

> When the complete one-bit streaming operator substrate fails, can the machine synthesize and elevate a new reusable operator as low-level register/memory bytecode?

## Saturated baseline

The complete two-state transducer closure is exhaustively checked:

```text
1 persistent bit
4 token symbols
arbitrary deterministic state transition
2 arbitrary final-state readouts
```

Every frozen world has zero exact support.

## μL

Selector-visible bytecode uses only generic instructions:

```text
CMP_TOK
BR_FALSE / BR_TRUE
ADD_IMM
SET_IMM
STOREM_IMM
LOADM
CMP_REG_IMM
CMP_REG_REG
OUT_...
```

No program is named counter, displacement, stack, nesting, accumulator, memory, etc.

The v0.1.0 library contains 60 canonical bytecode programs generated under bounded instruction/resource envelopes. The selector receives one flat library.

## Audit-only coverage

18 worlds:

```text
6 signed-counting-like
6 two-register displacement
6 typed nested dependency
```

Parity is excluded because 2P already expresses it.

## Operator identity

Programs are scored by behavioral equivalence class using all token sequences of length <=5. OOD validation checks that the elevated canonical representative remains equivalent on longer sequences.

## OOD

Discovery length <=12. OOD length <=32 with larger arithmetic ranges and nesting depths.

## Cost

```text
description cost
+ 0.02 * mean runtime cost
+ individually measured peak persistent-state bits
```

The elevated operator must be cheaper than full raw-history retention.

## Scope

Bounded bytecode-library synthesis only. No arbitrary program induction or literal unbounded-computation claim.
