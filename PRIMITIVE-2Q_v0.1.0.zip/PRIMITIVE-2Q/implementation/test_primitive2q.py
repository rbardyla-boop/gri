#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2Q_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2Q_REPLAY_CHECK.json").read_text())
p=r["system_summary"]["MICROLANGUAGE_SYNTHESIS"]
assert r["terminal_verdict"]=="OPERATOR_SUBSTRATE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["world_count"]==18
assert r["system_summary"]["FORCE_OMEGA0"]["exact_support_worlds"]==0
assert r["system_summary"]["FORCE_OMEGA0"]["total_exact_parameterizations"]==0
assert p["minimum_operator_class_exact_worlds"]==18
assert p["ood_accuracy"]==1.0
assert p["cheaper_than_raw_history_worlds"]==18
assert p["operator_elevation_receipts"]==18
assert rp["exact_byte_replay"]=="PASS"
print("PRIMITIVE_2Q_TEST_PASS")
