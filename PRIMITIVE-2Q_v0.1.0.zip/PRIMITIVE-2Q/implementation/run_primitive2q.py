from pathlib import Path
import json, hashlib, itertools, math, os, subprocess, sys, zipfile, csv

ROOT=Path("/mnt/data/PRIMITIVE-2Q")
FIX=ROOT/"PRIMITIVE-2Q_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

def canon(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_file(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2Q_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"],rec["name"]

micro=json.loads((ROOT/"PRIMITIVE-2Q_MICROLANGUAGE.json").read_text())
worlds=json.loads((FIX/"OPERATOR_SUBSTRATE_WORLDS.json").read_text())["worlds"]
programs=micro["programs"]
costs={k:v["description_cost"] for k,v in micro["instruction_set"].items()}
RW=float(micro["cost"]["runtime"])

def signed_bits(v):
    if v>=0:return max(1,math.ceil(math.log2(v+1))+1)
    return max(1,math.ceil(math.log2(abs(v)+1))+1)

def execute(bc,tokens):
    regs=[0]*max(1,bc["registers"]);mem=[];runtime=0;peak_mem=0;flag=False
    peak_bits=[1]*max(1,bc["registers"])
    def touch():
        for i,v in enumerate(regs):peak_bits[i]=max(peak_bits[i],signed_bits(v))
    for tok in tokens:
        pc=0
        while pc<len(bc["loop"]):
            x=bc["loop"][pc];op=x[0];runtime+=costs[op]
            if op=="CMP_TOK":flag=(tok==x[1]);pc+=1
            elif op=="BR_FALSE":pc=pc+1+x[1] if not flag else pc+1
            elif op=="BR_TRUE":pc=pc+1+x[1] if flag else pc+1
            elif op=="ADD_IMM":regs[x[1]]+=x[2];touch();pc+=1
            elif op=="SET_IMM":regs[x[1]]=x[2];touch();pc+=1
            elif op=="STOREM_IMM":
                ptr=regs[x[1]]
                if ptr>=0:
                    while len(mem)<=ptr:mem.append(0)
                    mem[ptr]=x[2];peak_mem=max(peak_mem,len(mem))
                pc+=1
            elif op=="LOADM":
                ptr=regs[x[2]]
                regs[x[1]]=mem[ptr] if 0<=ptr<len(mem) else 2
                touch();pc+=1
            elif op=="CMP_REG_IMM":flag=(regs[x[1]]==x[2]);pc+=1
            elif op=="CMP_REG_REG":flag=(regs[x[1]]==regs[x[2]]);pc+=1
            else:raise ValueError(op)
    out=[0,0]
    for x in bc["final"]:
        op=x[0];runtime+=costs[op]
        if op=="OUT_EQ_ZERO":out[x[1]]=int(regs[x[2]]==0)
        elif op=="OUT_GT_ZERO":out[x[1]]=int(regs[x[2]]>0)
        elif op=="OUT_REG_ZERO_AND_REG_ZERO":out[x[1]]=int(regs[x[2]]==0 and regs[x[3]]==0)
        else:raise ValueError(op)
    return out,{"runtime":runtime,"state_bits":sum(peak_bits)+peak_mem}

def desc_cost(bc):
    return sum(costs[x[0]] for sec in ("loop","final") for x in bc[sec])+bc["registers"]+(2 if bc["memory"] else 0)

def program_cost(p,seqs):
    rt=0;st=0
    for s in seqs:
        _,m=execute(p["bytecode"],s);rt+=m["runtime"];st=max(st,m["state_bits"])
    return desc_cost(p["bytecode"])+RW*(rt/len(seqs))+st

# canonical behavioral classes
canon_seqs=[list(x) for L in range(0,6) for x in itertools.product(range(4),repeat=L)]
def class_hash(p):
    sig=tuple(tuple(execute(p["bytecode"],s)[0]) for s in canon_seqs)
    return hashlib.sha256(canon(sig).encode()).hexdigest()
PCLASS={p["program_id"]:class_hash(p) for p in programs}

def omega0_fit(examples):
    count=0
    for trans in range(256):
        for init in (0,1):
            finals=[]
            for ex in examples:
                h=init
                for tok in ex["tokens"]:h=(trans>>(4*h+tok))&1
                finals.append(h)
            for ym in range(4):
                if not all(((ym>>finals[i])&1)==ex["outcome"][0] for i,ex in enumerate(examples)):continue
                for zm in range(4):
                    if all(((zm>>finals[i])&1)==ex["outcome"][1] for i,ex in enumerate(examples)):
                        count+=1
    return count

rows=[]
elevation_receipts=[]
for w in worlds:
    disc=w["discovery_examples"]
    discseq=[x["tokens"] for x in disc]
    omega_count=omega0_fit(disc)

    exact=[]
    for p in programs:
        if all(execute(p["bytecode"],x["tokens"])[0]==x["outcome"] for x in disc):
            exact.append(p)

    scored=sorted([
        (program_cost(p,discseq),desc_cost(p["bytecode"]),PCLASS[p["program_id"]],canon(p["bytecode"]),p["program_id"],p)
        for p in exact
    ],key=lambda x:(x[0],x[1],x[2],x[3],x[4]))
    minc=scored[0][0]
    mins=[x for x in scored if abs(x[0]-minc)<1e-12]
    minclasses=sorted(set(x[2] for x in mins))
    chosen=min(mins,key=lambda x:(x[2],x[3],x[4]))[5]
    chosen_class=PCLASS[chosen["program_id"]]

    ood_correct=0;ood_total=0
    for ex in w["ood_examples"]:
        pred=execute(chosen["bytecode"],ex["tokens"])[0]
        ood_correct+=sum(int(a==b) for a,b in zip(pred,ex["outcome"]))
        ood_total+=2
    ood_acc=ood_correct/ood_total

    raw_keys={tuple(x["tokens"]) for x in disc}
    raw_cov=sum(tuple(x["tokens"]) in raw_keys for x in w["ood_examples"])/len(w["ood_examples"])
    synth=program_cost(chosen,[x["tokens"] for x in w["ood_examples"]])
    raw_storage=max(len(x["tokens"])*2 for x in w["ood_examples"])
    raw_desc=sum(len(x["tokens"])*2+2 for x in disc)/len(disc)
    raw_cost=raw_storage+raw_desc

    class_exact=(minclasses==[w["minimum_operator_class"]])
    rows.append({
        "world_id":w["world_id"],"audit_archetype":w["audit_archetype"],
        "omega0_exact_fit_count":omega_count,
        "exact_bytecode_program_count":len(exact),
        "minimum_operator_class_count":len(minclasses),
        "minimum_operator_class_exact":class_exact,
        "chosen_program_id":chosen["program_id"],"chosen_operator_class":chosen_class,
        "ood_accuracy":ood_acc,
        "synthesized_cost":synth,"raw_history_cost":raw_cost,
        "synthesized_cheaper":synth<raw_cost,
        "raw_history_ood_key_coverage":raw_cov,
    })
    elevation_receipts.append({
        "world_id":w["world_id"],
        "omega_new_id":f"omega_new_{w['world_id']:02d}",
        "bytecode_program_id":chosen["program_id"],
        "operator_class_sha256":chosen_class,
        "frozen_before_ood":True,
        "ood_accuracy":ood_acc,
    })

summary={
    "FORCE_OMEGA0":{
        "world_count":18,
        "exact_support_worlds":sum(r["omega0_exact_fit_count"]>0 for r in rows),
        "total_exact_parameterizations":sum(r["omega0_exact_fit_count"] for r in rows),
    },
    "RAW_HISTORY_MEMORIZATION":{
        "mean_ood_exact_key_coverage":sum(r["raw_history_ood_key_coverage"] for r in rows)/len(rows),
        "mean_cost":sum(r["raw_history_cost"] for r in rows)/len(rows),
    },
    "MICROLANGUAGE_SYNTHESIS":{
        "minimum_operator_class_exact_worlds":sum(r["minimum_operator_class_exact"] for r in rows),
        "ood_accuracy":sum(r["ood_accuracy"] for r in rows)/len(rows),
        "mean_cost":sum(r["synthesized_cost"] for r in rows)/len(rows),
        "cheaper_than_raw_history_worlds":sum(r["synthesized_cheaper"] for r in rows),
        "operator_elevation_receipts":len(elevation_receipts),
    }
}
p=summary["MICROLANGUAGE_SYNTHESIS"]
if (
    summary["FORCE_OMEGA0"]["exact_support_worlds"]==0 and
    p["minimum_operator_class_exact_worlds"]==18 and
    p["ood_accuracy"]==1.0 and
    p["cheaper_than_raw_history_worlds"]==18 and
    p["operator_elevation_receipts"]==18
):
    terminal="OPERATOR_SUBSTRATE_ESCAPE_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif p["minimum_operator_class_exact_worlds"]>0:
    terminal="PARTIAL"
else:
    terminal="OPERATOR_SUBSTRATE_ESCAPE_INSUFFICIENT"

results={
    "experiment":"PRIMITIVE-2Q","version":"0.1.0","freeze_sha256":freeze["freeze_sha256"],
    "terminal_verdict":terminal,"world_count":18,
    "system_summary":summary,"world_results":rows
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2Q_RESULTS.json").write_text(json.dumps(results,indent=2))
(RES/"PRIMITIVE-2Q_OPERATOR_ELEVATION_RECEIPTS.json").write_text(json.dumps(elevation_receipts,indent=2))

print("PRIMITIVE-2Q scored")
print("terminal:",terminal)
print(json.dumps(summary,indent=2))