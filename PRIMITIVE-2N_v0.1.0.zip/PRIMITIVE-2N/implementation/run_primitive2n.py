from pathlib import Path
import json, hashlib, itertools, os, zipfile, subprocess, sys, csv
import numpy as np

ROOT=Path("/mnt/data/PRIMITIVE-2N")
FIX=ROOT/"PRIMITIVE-2N_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

def canon(v): return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_file(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2N_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"],rec["name"]

grammar=json.loads((ROOT/"PRIMITIVE-2N_GRAMMAR.json").read_text())
worlds=json.loads((FIX/"PRIMITIVE_DISCOVERY_WORLDS.json").read_text())["worlds"]

BASE_TT=[8,14,6,9]
PAIRS=list(itertools.combinations(range(3),2))
T=6

def dep2(tt,var):
    for a,b in itertools.product([0,1],repeat=2):
        x=[a,b];y=x.copy();y[var]^=1
        if ((tt>>(2*x[0]+x[1]))&1)!=((tt>>(2*y[0]+y[1]))&1): return True
    return False
def dep3(tt,var):
    for bits in itertools.product([0,1],repeat=3):
        x=list(bits);y=x.copy();y[var]^=1
        i=4*x[0]+2*x[1]+x[2];j=4*y[0]+2*y[1]+y[2]
        if ((tt>>i)&1)!=((tt>>j)&1): return True
    return False

ESS3=np.array([tt for tt in range(256) if all(dep3(tt,v) for v in range(3))],dtype=np.uint16)
MISSING2=[tt for tt in range(16) if tt not in BASE_TT and dep2(tt,0) and dep2(tt,1)]
SOURCE_TRIPLES=np.array(list(itertools.combinations(range(9),3)),dtype=np.int16)
READOUTS=np.array([(root,op) for root in range(3) for op in BASE_TT],dtype=np.int16)

# Rebuild prior 2M spaces independently.
base_specs=[]
for yp in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
    for zp in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
        base_specs.append({"family":"BASE","y":list(yp),"z":list(zp)})

fam_specs={f:[] for f in ["ADD_NEW_BINARY_OPERATOR","ADD_THIRD_PARENT","ADD_LATENT_VARIABLE","ADD_ONE_STEP_MEMORY","ADD_RECURRENT_EDGE"]}
for target in ("Y","Z"):
    for pair in PAIRS:
        for op in MISSING2:
            for other in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
                if target=="Y": fam_specs["ADD_NEW_BINARY_OPERATOR"].append({"family":"ADD_NEW_BINARY_OPERATOR","target":"Y","y":[pair[0],pair[1],op],"z":list(other)})
                else: fam_specs["ADD_NEW_BINARY_OPERATOR"].append({"family":"ADD_NEW_BINARY_OPERATOR","target":"Z","y":list(other),"z":[pair[0],pair[1],op]})
for target in ("Y","Z"):
    for op3 in [int(x) for x in ESS3]:
        for other in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
            if target=="Y": fam_specs["ADD_THIRD_PARENT"].append({"family":"ADD_THIRD_PARENT","target":"Y","tt3":op3,"z":list(other)})
            else: fam_specs["ADD_THIRD_PARENT"].append({"family":"ADD_THIRD_PARENT","target":"Z","tt3":op3,"y":list(other)})
for hp in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
    rem=({0,1,2}-{hp[0],hp[1]}).pop()
    for yt in BASE_TT:
        for zt in BASE_TT:
            fam_specs["ADD_LATENT_VARIABLE"].append({"family":"ADD_LATENT_VARIABLE","h":list(hp),"y":[rem,yt],"z":[rem,zt]})
for target in ("Y","Z"):
    for cr in range(3):
        for pr in range(3):
            if cr==pr: continue
            for op in BASE_TT:
                for other in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
                    if target=="Y": fam_specs["ADD_ONE_STEP_MEMORY"].append({"family":"ADD_ONE_STEP_MEMORY","target":"Y","mem":[cr,pr,op],"z":list(other)})
                    else: fam_specs["ADD_ONE_STEP_MEMORY"].append({"family":"ADD_ONE_STEP_MEMORY","target":"Z","mem":[cr,pr,op],"y":list(other)})
for target in ("Y","Z"):
    for cr in range(3):
        for op in BASE_TT:
            for other in [(a,b,o) for a,b in PAIRS for o in BASE_TT]:
                if target=="Y": fam_specs["ADD_RECURRENT_EDGE"].append({"family":"ADD_RECURRENT_EDGE","target":"Y","rec":[cr,op],"z":list(other)})
                else: fam_specs["ADD_RECURRENT_EDGE"].append({"family":"ADD_RECURRENT_EDGE","target":"Z","rec":[cr,op],"y":list(other)})

all_2m=[("BASE",s) for s in base_specs]
for fam in fam_specs:
    all_2m.extend((fam,s) for s in fam_specs[fam])

def run_2m(spec,episodes):
    allout=[]
    for roots in episodes:
        prev_y=prev_z=0;prev_roots=[0,0,0];out=[]
        for cur in roots:
            fam=spec["family"]
            if fam in ("BASE","ADD_NEW_BINARY_OPERATOR"):
                yp=spec["y"];zp=spec["z"]
                y=(yp[2]>>(2*cur[yp[0]]+cur[yp[1]]))&1
                z=(zp[2]>>(2*cur[zp[0]]+cur[zp[1]]))&1
            elif fam=="ADD_THIRD_PARENT":
                idx=4*cur[0]+2*cur[1]+cur[2]
                if spec["target"]=="Y":
                    y=(spec["tt3"]>>idx)&1;zp=spec["z"];z=(zp[2]>>(2*cur[zp[0]]+cur[zp[1]]))&1
                else:
                    yp=spec["y"];y=(yp[2]>>(2*cur[yp[0]]+cur[yp[1]]))&1;z=(spec["tt3"]>>idx)&1
            elif fam=="ADD_LATENT_VARIABLE":
                hp=spec["h"];h=(hp[2]>>(2*cur[hp[0]]+cur[hp[1]]))&1
                yr,yt=spec["y"];zr,zt=spec["z"];y=(yt>>(2*h+cur[yr]))&1;z=(zt>>(2*h+cur[zr]))&1
            elif fam=="ADD_ONE_STEP_MEMORY":
                if spec["target"]=="Y":
                    cr,pr,op=spec["mem"];y=(op>>(2*cur[cr]+prev_roots[pr]))&1;zp=spec["z"];z=(zp[2]>>(2*cur[zp[0]]+cur[zp[1]]))&1
                else:
                    yp=spec["y"];y=(yp[2]>>(2*cur[yp[0]]+cur[yp[1]]))&1;cr,pr,op=spec["mem"];z=(op>>(2*cur[cr]+prev_roots[pr]))&1
            elif fam=="ADD_RECURRENT_EDGE":
                if spec["target"]=="Y":
                    cr,op=spec["rec"];y=(op>>(2*cur[cr]+prev_y))&1;zp=spec["z"];z=(zp[2]>>(2*cur[zp[0]]+cur[zp[1]]))&1
                else:
                    yp=spec["y"];y=(yp[2]>>(2*cur[yp[0]]+cur[yp[1]]))&1;cr,op=spec["rec"];z=(op>>(2*cur[cr]+prev_z))&1
            out.append([int(y),int(z)]);prev_y,prev_z=y,z;prev_roots=list(cur)
        allout.append(out)
    return allout

def flat_error(pred,gold):
    p=np.asarray(pred,dtype=np.uint8);g=np.asarray(gold,dtype=np.uint8)
    return int(np.sum(p!=g))

def flat_acc(pred,gold):
    p=np.asarray(pred,dtype=np.uint8);g=np.asarray(gold,dtype=np.uint8)
    return float(np.mean(p==g))

def signal_tensor(episodes):
    X=np.asarray(episodes,dtype=np.uint8)
    E,Tm,_=X.shape
    S=np.zeros((E,Tm,9),dtype=np.uint8)
    for lag in range(3):
        for root in range(3):
            sid=lag*3+root
            if lag==0:S[:,:,sid]=X[:,:,root]
            else:S[:,lag:,sid]=X[:,:Tm-lag,root]
    return S

def run_program(program,episodes):
    X=np.asarray(episodes,dtype=np.uint8)
    S=signal_tensor(episodes);src=program["sources"];tt=program["truth_table"]
    idx=4*S[:,:,src[0]]+2*S[:,:,src[1]]+S[:,:,src[2]]
    H=((tt>>idx)&1).astype(np.uint8)
    out=[]
    for ro in (program["y_readout"],program["z_readout"]):
        root,op=ro
        out.append(((op>>(2*H+X[:,:,root]))&1).astype(np.uint8))
    return np.stack(out,axis=-1).tolist()

def all_feature_matrix(episodes):
    X=np.asarray(episodes,dtype=np.uint8)
    S=signal_tensor(episodes).reshape(-1,9)
    N=S.shape[0]
    combo=S[:,SOURCE_TRIPLES]
    idx=(4*combo[:,:,0]+2*combo[:,:,1]+combo[:,:,2]).T
    H=((ESS3[None,:,None]>>idx[:,None,:])&1).astype(np.uint8)
    return X.reshape(-1,3),H.reshape(-1,N)

def feature_matches(episodes,target):
    Xflat,H=all_feature_matrix(episodes)
    target=np.asarray(target,dtype=np.uint8).reshape(-1)
    matches=[]
    for j,(root,op) in enumerate(READOUTS):
        pred=((int(op)>>(2*H+Xflat[:,int(root)][None,:]))&1).astype(np.uint8)
        rows=np.flatnonzero(np.all(pred==target[None,:],axis=1))
        for c in rows:
            combo_idx=int(c)//len(ESS3);tt_idx=int(c)%len(ESS3)
            matches.append({
                "sources":[int(x) for x in SOURCE_TRIPLES[combo_idx]],
                "truth_table":int(ESS3[tt_idx]),
                "readout":[int(root),int(op)],
            })
    matches.sort(key=canon)
    return matches

def shared_match(episodes,gold):
    y=feature_matches(episodes,np.asarray(gold)[:,:,0])
    z=feature_matches(episodes,np.asarray(gold)[:,:,1])
    zmap={}
    for m in z:
        key=(tuple(m["sources"]),m["truth_table"])
        zmap.setdefault(key,[]).append(m["readout"])
    shared=[]
    for ym in y:
        key=(tuple(ym["sources"]),ym["truth_table"])
        for zro in zmap.get(key,[]):
            shared.append({
                "sources":list(key[0]),"truth_table":key[1],
                "y_readout":ym["readout"],"z_readout":zro
            })
    shared.sort(key=canon)
    return shared

SHARED_MDL=int(grammar["shared_program_mdl"])
SEPARATE_MDL=int(grammar["two_independent_programs_mdl"])

world_results=[]
for w in worlds:
    disc=w["discovery_episodes"];gold=w["discovery_outputs"]
    held=w["heldout_episodes"];hgold=w["heldout_outputs"]

    # Old 2M best fit and exact-support check.
    best=None; exact_count=0
    for fam,spec in all_2m:
        pred=run_2m(spec,disc)
        err=flat_error(pred,gold)
        if err==0: exact_count+=1
        key=(err,fam,canon(spec))
        if best is None or key<best[0]:
            best=(key,fam,spec)
    _,best_fam,best_spec=best
    old_held=flat_acc(run_2m(best_spec,held),hgold)

    # Independent ad-hoc features.
    ymatches=feature_matches(disc,np.asarray(gold)[:,:,0])
    zmatches=feature_matches(disc,np.asarray(gold)[:,:,1])
    ysel=ymatches[0]; zsel=zmatches[0]
    def single_output_predict(sel,episodes):
        X=np.asarray(episodes,dtype=np.uint8);S=signal_tensor(episodes)
        src=sel["sources"];tt=sel["truth_table"];root,op=sel["readout"]
        idx=4*S[:,:,src[0]]+2*S[:,:,src[1]]+S[:,:,src[2]]
        H=((tt>>idx)&1).astype(np.uint8)
        return ((op>>(2*H+X[:,:,root]))&1).astype(np.uint8)
    ypred=single_output_predict(ysel,held)
    zpred=single_output_predict(zsel,held)
    independent_pred=np.stack([ypred,zpred],axis=-1)
    independent_acc=float(np.mean(independent_pred==np.asarray(hgold,dtype=np.uint8)))

    # Shared primitive rediscovery.
    shared=shared_match(disc,gold)
    unique=(len(shared)==1)
    chosen=shared[0] if unique else None
    primitive_exact=(chosen==w["hidden_primitive"])
    shared_held=flat_acc(run_program(chosen,held),hgold) if chosen else 0.0

    # Transfer readout: H frozen, search only 12 readouts.
    transfer_exact=False; transfer_acc=0.0
    if chosen:
        cal=w["transfer_calibration_episodes"]
        target=np.asarray(w["transfer_calibration_output"],dtype=np.uint8)
        X=np.asarray(cal,dtype=np.uint8);S=signal_tensor(cal);src=chosen["sources"];tt=chosen["truth_table"]
        idx=4*S[:,:,src[0]]+2*S[:,:,src[1]]+S[:,:,src[2]]
        H=((tt>>idx)&1).astype(np.uint8)
        rms=[]
        for ro in READOUTS:
            pred=((int(ro[1])>>(2*H+X[:,:,int(ro[0])]))&1).astype(np.uint8)
            if np.array_equal(pred,target):
                rms.append([int(ro[0]),int(ro[1])])
        transfer_exact=(rms==[w["transfer_readout"]])
        if transfer_exact:
            test=w["transfer_test_episodes"]
            X2=np.asarray(test,dtype=np.uint8);S2=signal_tensor(test)
            idx2=4*S2[:,:,src[0]]+2*S2[:,:,src[1]]+S2[:,:,src[2]]
            H2=((tt>>idx2)&1).astype(np.uint8)
            ro=rms[0]
            pred=((ro[1]>>(2*H2+X2[:,:,ro[0]]))&1).astype(np.uint8)
            transfer_acc=float(np.mean(pred==np.asarray(w["transfer_test_output"],dtype=np.uint8)))

    # Complete root-bit intervention surface on heldout episodes.
    int_correct=int_total=0
    if chosen:
        hidden=w["hidden_primitive"]
        for ep in held:
            for t in range(T):
                for root in range(3):
                    for val in (0,1):
                        ee=[list(x) for x in ep];ee[t][root]=val
                        pg=np.asarray(run_program(hidden,[ee]),dtype=np.uint8)
                        pp=np.asarray(run_program(chosen,[ee]),dtype=np.uint8)
                        int_correct+=int(np.sum(pg==pp)); int_total+=pg.size
    int_acc=(int_correct/int_total) if int_total else 0.0

    world_results.append({
        "world_id":w["world_id"],
        "old_2m_exact_fit_count":exact_count,
        "old_2m_best_family":best_fam,
        "old_2m_best_discovery_error":best[0][0],
        "old_2m_heldout_accuracy":old_held,
        "independent_y_candidate_count":len(ymatches),
        "independent_z_candidate_count":len(zmatches),
        "independent_heldout_accuracy":independent_acc,
        "independent_mdl":SEPARATE_MDL,
        "shared_candidate_count":len(shared),
        "shared_unique":unique,
        "shared_program":chosen,
        "primitive_exact":primitive_exact,
        "shared_heldout_accuracy":shared_held,
        "shared_mdl":SHARED_MDL,
        "mdl_saving":SEPARATE_MDL-SHARED_MDL,
        "transfer_readout_exact":transfer_exact,
        "transfer_accuracy":transfer_acc,
        "interventional_accuracy":int_acc,
    })

summary={
    "FORCE_2M_BEST_FIT":{
        "world_count":len(world_results),
        "exact_fit_worlds":sum(w["old_2m_exact_fit_count"]>0 for w in world_results),
        "mean_discovery_error":sum(w["old_2m_best_discovery_error"] for w in world_results)/len(world_results),
        "mean_heldout_accuracy":sum(w["old_2m_heldout_accuracy"] for w in world_results)/len(world_results),
    },
    "PER_OUTPUT_FEATURE_SYNTHESIS":{
        "world_count":len(world_results),
        "primitive_count_per_world":2,
        "mdl_per_world":SEPARATE_MDL,
        "mean_heldout_accuracy":sum(w["independent_heldout_accuracy"] for w in world_results)/len(world_results),
    },
    "SHARED_PRIMITIVE_MDL":{
        "world_count":len(world_results),
        "primitive_count_per_world":1,
        "mdl_per_world":SHARED_MDL,
        "mdl_saving_per_world":SEPARATE_MDL-SHARED_MDL,
        "unique_shared_worlds":sum(w["shared_unique"] for w in world_results),
        "primitive_exact_worlds":sum(w["primitive_exact"] for w in world_results),
        "mean_heldout_accuracy":sum(w["shared_heldout_accuracy"] for w in world_results)/len(world_results),
        "transfer_readout_exact_worlds":sum(w["transfer_readout_exact"] for w in world_results),
        "mean_transfer_accuracy":sum(w["transfer_accuracy"] for w in world_results)/len(world_results),
        "mean_interventional_accuracy":sum(w["interventional_accuracy"] for w in world_results)/len(world_results),
    }
}

p=summary["SHARED_PRIMITIVE_MDL"]
if (
    summary["FORCE_2M_BEST_FIT"]["exact_fit_worlds"]==0 and
    p["unique_shared_worlds"]==16 and p["primitive_exact_worlds"]==16 and
    p["mean_heldout_accuracy"]==1.0 and p["mdl_per_world"]<SEPARATE_MDL and
    p["transfer_readout_exact_worlds"]==16 and p["mean_transfer_accuracy"]==1.0 and
    p["mean_interventional_accuracy"]==1.0
):
    terminal="REPRESENTATIONAL_PRIMITIVE_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif p["primitive_exact_worlds"]>0:
    terminal="PARTIAL"
else:
    terminal="REPRESENTATIONAL_PRIMITIVE_DISCOVERY_INSUFFICIENT"

results={
    "experiment":"PRIMITIVE-2N","version":"0.1.0","freeze_sha256":freeze["freeze_sha256"],
    "terminal_verdict":terminal,"world_count":len(world_results),
    "system_summary":summary,"world_results":world_results
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2N_RESULTS.json").write_text(json.dumps(results,indent=2))

print("PRIMITIVE-2N scored")
print("terminal:",terminal)
print(json.dumps(summary,indent=2))