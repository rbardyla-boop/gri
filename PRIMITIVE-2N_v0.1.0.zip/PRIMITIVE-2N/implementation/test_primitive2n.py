#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2N_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2N_REPLAY_CHECK.json").read_text())
p=r["system_summary"]["SHARED_PRIMITIVE_MDL"]
assert r["terminal_verdict"]=="REPRESENTATIONAL_PRIMITIVE_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["world_count"]==16
assert r["system_summary"]["FORCE_2M_BEST_FIT"]["exact_fit_worlds"]==0
assert p["unique_shared_worlds"]==16
assert p["primitive_exact_worlds"]==16
assert p["mean_heldout_accuracy"]==1.0
assert p["mdl_per_world"]==16
assert r["system_summary"]["PER_OUTPUT_FEATURE_SYNTHESIS"]["mdl_per_world"]==28
assert p["transfer_readout_exact_worlds"]==16
assert p["mean_transfer_accuracy"]==1.0
assert p["mean_interventional_accuracy"]==1.0
assert rp["exact_byte_replay"]=="PASS"
print("PRIMITIVE_2N_TEST_PASS")
