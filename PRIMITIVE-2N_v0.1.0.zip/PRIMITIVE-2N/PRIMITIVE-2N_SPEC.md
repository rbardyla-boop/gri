# PRIMITIVE-2N — REPRESENTATIONAL PRIMITIVE DISCOVERY

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `2517af85676a1ae014b09065a037930da1bcd58ee7ee4aebdde9d4e2a028a702`

## Question

> When every model and structural extension in the previous bounded meta-language fails, can the machine construct a reusable machine-native internal primitive from observed regularities rather than selecting a human-named structural repair?

## Primitive language

The synthesizer receives no labels such as:

```text
memory
latent
state
context
recurrence
```

It receives nine numeric observable source slots:

```text
3 roots × offsets t, t-1, t-2
```

and may construct:

```text
H_t = arbitrary essential Boolean function of any 3 source IDs
```

There are 18312 possible anonymous H programs before output readouts.

## Reuse / compression

The same H must support both observed outputs.

Frozen description length:

```text
one shared H + two readouts = 16
two independent H nodes     = 28
```

Exact fit without reuse is therefore not equivalent.

## Previous-language firewall

Every frozen world has zero exact fits across the complete bounded PRIMITIVE-2M menu:

```text
BASE
ADD_NEW_BINARY_OPERATOR
ADD_THIRD_PARENT
ADD_LATENT_VARIABLE
ADD_ONE_STEP_MEMORY
ADD_RECURRENT_EDGE
```

## Transfer

After H is frozen, a new output W is introduced.

The system may fit only a simple readout on top of H. It may not change or relearn H.

## Strict pass

Across all 16 frozen worlds:

```text
old 2M meta-language exact support = empty
exact hidden H program recovered
100% unseen Y/Z prediction
shared description shorter than two independent repairs
new W readout recovered exactly
100% W transfer prediction
100% root-intervention prediction
deterministic replay
```

## Scope

This remains bounded primitive invention.

The meta-language supplies binary state, history depth <= 2, three source references, and Boolean combinators. The system invents the particular reusable internal bit, not an unrestricted new computational substrate.
