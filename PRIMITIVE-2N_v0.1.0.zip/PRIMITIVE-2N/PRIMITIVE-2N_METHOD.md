# PRIMITIVE-2N METHOD

1. Preserve the complete bounded PRIMITIVE-2M menu as a negative-control model class:
   - BASE
   - ADD_NEW_BINARY_OPERATOR
   - ADD_THIRD_PARENT
   - ADD_LATENT_VARIABLE
   - ADD_ONE_STEP_MEMORY
   - ADD_RECURRENT_EDGE
2. Freeze a generic anonymous primitive-construction language over nine numeric observable source slots: three roots at lags 0, 1 and 2.
3. A candidate internal primitive H is defined only by:
   - three source IDs;
   - one essential 8-bit Boolean truth table.
4. No semantic labels such as memory, latent state, recurrence, context or hidden variable are supplied.
5. Generate sixteen worlds in which:
   - the entire previous 2M menu has zero exact fits;
   - exactly one shared H program plus two simple readouts fits all discovery observations;
   - the unique H is the hidden generating primitive.
6. Compare:
   - FORCE_2M_BEST_FIT
   - PER_OUTPUT_FEATURE_SYNTHESIS
   - SHARED_PRIMITIVE_MDL
7. Use a frozen description code:
   - one shared H + two readouts = 16 units;
   - two separately instantiated H nodes = 28 units.
8. Freeze the discovered shared H before all validation.
9. Score:
   - two unseen Y/Z trajectories;
   - the complete single-root-bit intervention surface over those heldout trajectories;
   - a new output W introduced only after H is frozen, where only a simple readout may be learned.
10. Re-run the exact scorer and require byte-identical result JSON.

An initial unoptimized fixture-construction attempt timed out before a valid experiment freeze or score existed. It was discarded. The successful vectorized construction was then frozen before scoring.

PRIMITIVE-2N remains bounded primitive invention: the generic meta-language still supplies one binary internal bit, at most two steps of observable history, three source references and Boolean combinators.
