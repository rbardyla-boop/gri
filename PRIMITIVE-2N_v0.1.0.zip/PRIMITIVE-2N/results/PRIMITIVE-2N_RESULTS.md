# PRIMITIVE-2N Results

**Terminal verdict:** `REPRESENTATIONAL_PRIMITIVE_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Exact deterministic replay:** `PASS`  
**Worlds:** 16

| System | Old-language exact worlds | Primitive nodes | MDL / world | Held-out accuracy | Transfer accuracy | Intervention accuracy |
|---|---:|---:|---:|---:|---:|---:|
| FORCE_2M_BEST_FIT | 0/16 | 0 | n/a | 0.718750 | n/a | n/a |
| PER_OUTPUT_FEATURE_SYNTHESIS | n/a | 2 | 28 | 0.994792 | n/a | n/a |
| **SHARED_PRIMITIVE_MDL** | **0/16 prior-menu fits** | **1** | **16** | **1.000000** | **1.000000** | **1.000000** |

## Shared primitive

- Unique shared representation: `16/16`
- Exact hidden primitive recovered: `16/16`
- Transfer readout exact: `16/16`
- MDL saving per world vs two separate feature nodes: `12` units
- Hidden lag patterns: `{(0, 1, 2): 11, (0, 2, 2): 1, (1, 1, 2): 1, (1, 2, 2): 3}`
