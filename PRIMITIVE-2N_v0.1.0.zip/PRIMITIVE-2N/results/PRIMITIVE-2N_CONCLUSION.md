# PRIMITIVE-2N Conclusion

**Terminal verdict:** `REPRESENTATIONAL_PRIMITIVE_DISCOVERY_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Previous representational language failed

Across all sixteen frozen worlds, the complete bounded PRIMITIVE-2M menu had:

```text
exact-fit worlds: 0/16
```

The least-wrong old representation still achieved only:

```text
mean discovery error: 19.375 bits/world
mean held-out accuracy: 0.718750
```

So PRIMITIVE-2N begins only after the previous human-authored structural repair menu is exhausted.

## Anonymous primitive synthesis

The primary system searched 18,312 possible internal feature programs.

Each candidate was only:

```text
three numeric source IDs
+
one 8-bit Boolean truth table
```

No candidate carried a label such as memory, latent state, context or recurrence.

The system recovered exactly one shared primitive in every world:

```text
unique shared primitive: 16/16
exact hidden primitive:  16/16
```

## Reuse and compression

Two independent feature repairs use:

```text
28 MDL units
```

The shared primitive uses:

```text
16 MDL units
```

for a saving of:

```text
12 units/world
```

The independent-feature system was already strong:

```text
held-out accuracy = 0.994792
```

But sharing the discovered H produced:

```text
held-out Y/Z accuracy = 1.000000
```

with a smaller representation.

## Reuse on a new task

After H was frozen, a third output W was introduced.

The system was not allowed to relearn H.

It could fit only a twelve-way simple readout on top of H.

Result:

```text
W readout recovered exactly: 16/16
W transfer accuracy:         1.000000
```

That is the strongest evidence in PRIMITIVE-2N that the synthesized internal bit is reusable rather than merely a compressed description of Y and Z.

## Intervention test

The frozen H program was also evaluated under root-bit interventions that alter future history-dependent inputs.

```text
interventional prediction accuracy = 1.000000
```

Thus the recovered representation survived changes to the trajectories that generated it.

## Supported claim

Within the frozen generic feature meta-language:

> When the complete previous structural repair menu has empty exact support, a machine can synthesize an anonymous internal bit from observable regularities, prefer a shared instance because it compresses multiple explanations, reuse that primitive for a later output without changing it, and preserve exact held-out and interventional prediction.

## What is still supplied

PRIMITIVE-2N does not yet demonstrate unrestricted representational invention.

The system was still told that a candidate new primitive may be:

```text
one binary internal value
computed from exactly three observable source slots
drawn from history depth <= 2
through an arbitrary Boolean truth table
```

What it was not told was which sources, which function, or what human structural concept the resulting bit should correspond to.

## Largest remaining gap

The next gap is no longer choosing a human-named structural family.

It is the **shape of the primitive-construction language itself**:

> Can the system discover that its primitive needs a different arity, state cardinality, temporal depth, composition rule, or internal topology when the current generic feature meta-language itself has empty support?

That would test adaptive representational growth rather than synthesis inside one fixed feature template.
