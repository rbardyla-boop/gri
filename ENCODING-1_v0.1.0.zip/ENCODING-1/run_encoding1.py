#!/usr/bin/env python3
from __future__ import annotations
import hashlib, itertools, json
from pathlib import Path

HERE=Path(__file__).resolve().parent
GRID_PATH=HERE/'ENCODING-1_GRID.json'
FROZEN_RESULTS=HERE/'results'/'ENCODING-1_RESULTS.json'
RERUN_RESULTS=HERE/'results'/'ENCODING-1_RESULTS_RERUN.json'
PROFILES=['FIXED_INBAND','VARINT_INBAND','BATCH_INBAND','VARINT_HANDLE','BATCH_HANDLE']

def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def uv_len(n):
    if n < 0: raise ValueError('negative varint')
    if n < 1<<7:return 1
    if n < 1<<14:return 2
    if n < 1<<21:return 3
    if n < 1<<28:return 4
    if n < 1<<35:return 5
    if n < 1<<42:return 6
    if n < 1<<49:return 7
    if n < 1<<56:return 8
    if n < 1<<63:return 9
    return 10

def zigzag(n): return (n<<1) if n>=0 else ((-n<<1)-1)
def width_for(n):
    if n<=0xFF:return 1
    if n<=0xFFFF:return 2
    if n<=0xFFFFFF:return 3
    if n<=0xFFFFFFFF:return 4
    if n<=0xFFFFFFFFFFFF:return 6
    return 8

class LCG:
    __slots__=('state',)
    def __init__(self,seed):self.state=seed & 0xFFFFFFFFFFFFFFFF
    def next_u64(self):
        self.state=(6364136223846793005*self.state+1442695040888963407)&0xFFFFFFFFFFFFFFFF
        return self.state
    def frac(self):return self.next_u64()/18446744073709551616.0
    def randint(self,n):return self.next_u64()%n

def scenario_seed(keys,p):
    s='|'.join(str(p[k]) for k in keys)
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],'big')

def score_scenario(keys,p):
    n=p['packet_count']; card=p['symbol_cardinality']; rate=p['new_symbol_rate']
    batch_size=p['batch_size']; session_life=p['session_lifetime']; reset_freq=p['dictionary_reset_frequency']
    fixed_id_w=width_for(n); fixed_sym_w=width_for(card)
    out={name:{'payload_bytes':0,'dictionary_bytes':0,'handle_mapping_bytes':0,'max_buffer_packets':1} for name in PROFILES}

    rng=LCG(scenario_seed(keys,p))
    known=list(range(1,min(card,8)+1)); next_new=len(known)+1
    local={}; next_code=1; handle=0; session_start=1

    # Incremental batch accumulators.
    bk=0; b_first_id=0; b_first_handle=0; b_sub=0; b_obj=0; b_val=0
    b_act_runs=0; b_rel_runs=0; b_prev_act=None; b_prev_rel=None
    def flush_batch():
        nonlocal bk,b_first_id,b_first_handle,b_sub,b_obj,b_val,b_act_runs,b_rel_runs,b_prev_act,b_prev_rel
        if not bk:return
        # packet_count + first delta + remaining delta=1 + RLE(run count + each code,count)
        # Each ACT/REL code <=16 and each run length <= batch_size, so exact uv lengths tracked by storing run lengths is needed.
        # We maintain run code/count arrays compactly per batch.
        ids_cost=uv_len(b_first_id)+(bk-1)*1
        handles_cost=uv_len(b_first_handle)+(bk-1)*1
        act_cost=uv_len(len(act_runs))+sum(uv_len(c)+uv_len(cnt) for c,cnt in act_runs)
        rel_cost=uv_len(len(rel_runs))+sum(uv_len(c)+uv_len(cnt) for c,cnt in rel_runs)
        common=uv_len(bk)+act_cost+b_sub+rel_cost+b_obj+b_val
        out['BATCH_INBAND']['payload_bytes'] += common+ids_cost
        out['BATCH_HANDLE']['payload_bytes'] += common+handles_cost
        if bk>out['BATCH_INBAND']['max_buffer_packets']:out['BATCH_INBAND']['max_buffer_packets']=bk
        if bk>out['BATCH_HANDLE']['max_buffer_packets']:out['BATCH_HANDLE']['max_buffer_packets']=bk
        bk=0;b_first_id=0;b_first_handle=0;b_sub=0;b_obj=0;b_val=0;b_act_runs=0;b_rel_runs=0;b_prev_act=None;b_prev_rel=None
        act_runs.clear(); rel_runs.clear()

    act_runs=[]; rel_runs=[]

    for idx in range(1,n+1):
        if idx==1 or ((idx-1)%session_life==0):
            flush_batch(); local.clear(); next_code=1; handle=0; session_start=idx
        elif reset_freq and ((idx-session_start)%reset_freq==0):
            flush_batch(); local.clear(); next_code=1

        syms=[]
        for _ in range(2):
            introduce=(next_new<=card) and (rng.frac()<rate)
            if introduce:
                sym=next_new; known.append(sym); next_new+=1
            else:
                sym=known[rng.randint(len(known))]
            syms.append(sym)
        act=1+((idx//8)%8); rel=1+((idx//4)%16); value=int((rng.next_u64()%2001)-1000)

        codes=[]
        for sym in syms:
            code=local.get(sym)
            if code is None:
                code=next_code; next_code+=1; local[sym]=code
                out['FIXED_INBAND']['dictionary_bytes'] += 1+fixed_sym_w+fixed_sym_w
                vcost=1+uv_len(code)+uv_len(sym)
                out['VARINT_INBAND']['dictionary_bytes'] += vcost
                out['BATCH_INBAND']['dictionary_bytes'] += vcost
                out['VARINT_HANDLE']['dictionary_bytes'] += vcost
                out['BATCH_HANDLE']['dictionary_bytes'] += vcost
            codes.append(code)
        sub_code,obj_code=codes

        handle+=1
        out['FIXED_INBAND']['payload_bytes'] += fixed_id_w+1+fixed_sym_w+1+fixed_sym_w+2
        var_common=uv_len(act)+uv_len(sub_code)+uv_len(rel)+uv_len(obj_code)+uv_len(zigzag(value))
        out['VARINT_INBAND']['payload_bytes'] += uv_len(idx)+var_common
        mapping=1+uv_len(handle)+uv_len(idx)
        out['VARINT_HANDLE']['handle_mapping_bytes'] += mapping
        out['BATCH_HANDLE']['handle_mapping_bytes'] += mapping
        out['VARINT_HANDLE']['payload_bytes'] += uv_len(handle)+var_common

        # batch accumulate
        if bk==0:
            b_first_id=idx;b_first_handle=handle
        bk+=1;b_sub+=uv_len(sub_code);b_obj+=uv_len(obj_code);b_val+=uv_len(zigzag(value))
        if not act_runs or act_runs[-1][0]!=act:act_runs.append([act,1])
        else:act_runs[-1][1]+=1
        if not rel_runs or rel_runs[-1][0]!=rel:rel_runs.append([rel,1])
        else:rel_runs[-1][1]+=1
        if bk>=batch_size:flush_batch()
    flush_batch()

    for name in PROFILES:
        r=out[name]
        r['total_transport_bytes']=r['payload_bytes']+r['dictionary_bytes']+r['handle_mapping_bytes']
        r['bytes_per_packet']=r['total_transport_bytes']/n
    return out

def build_results(grid_doc):
    grid=grid_doc['grid']; keys=list(grid.keys())
    got=hashlib.sha256(canon(grid).encode()).hexdigest()
    if got!=grid_doc['grid_sha256']:raise RuntimeError('grid hash mismatch')
    scenarios=[]
    for vals in itertools.product(*(grid[k] for k in keys)):
        p=dict(zip(keys,vals)); scores=score_scenario(keys,p)
        totals={name:scores[name]['total_transport_bytes'] for name in PROFILES}; m=min(totals.values())
        scenarios.append({'params':p,'scores':scores,'winner_bytes':m,'winners':sorted([name for name,v in totals.items() if v==m])})
    wc={name:0 for name in PROFILES}; ties=0
    for s in scenarios:
        if len(s['winners'])>1:ties+=1
        for name in s['winners']:wc[name]+=1
    base='VARINT_INBAND'; pair={}
    for name in ('FIXED_INBAND','BATCH_INBAND','VARINT_HANDLE','BATCH_HANDLE'):
        wins=[];loss=[];tie=[]
        for s in scenarios:
            a=s['scores'][name]['total_transport_bytes']; b=s['scores'][base]['total_transport_bytes']
            row={'params':s['params'],'candidate_bytes':a,'varint_bytes':b,'delta':a-b}
            (wins if a<b else loss if a>b else tie).append(row)
        pair[name]={'beats_varint_count':len(wins),'loses_to_varint_count':len(loss),'ties_varint_count':len(tie),'first_5_win_examples':wins[:5]}
    by={}
    for key in keys:
        by[key]={}
        for level in grid[key]:
            subset=[s for s in scenarios if s['params'][key]==level]
            by[key][str(level)]={name:sum(name in s['winners'] for s in subset) for name in PROFILES}
    result={'experiment':'ENCODING-1','version':'0.1.0','grid_sha256':grid_doc['grid_sha256'],'scenario_count':len(scenarios),'profiles':PROFILES,'replay':'PASS','winner_counts_including_ties':wc,'tie_scenario_count':ties,'pairwise_vs_VARINT_INBAND':pair,'winner_counts_by_variable_level':by,'scenarios':scenarios}
    result['results_sha256']=hashlib.sha256(canon(result).encode()).hexdigest()
    return result

def strip_hash(x):
    x=dict(x);x.pop('results_sha256',None);return x

def main():
    grid_doc=json.loads(GRID_PATH.read_text()); result=build_results(grid_doc)
    frozen=json.loads(FROZEN_RESULTS.read_text())
    if strip_hash(result)!=strip_hash(frozen):
        raise RuntimeError('standalone rerun does not match frozen scored results')
    RERUN_RESULTS.write_text(json.dumps(result,indent=2))
    print('ENCODING_1_RERUN_PASS')
    print('scenarios',result['scenario_count'])
    print('winner_counts',json.dumps(result['winner_counts_including_ties'],sort_keys=True))

if __name__=='__main__':main()
