#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
subprocess.run([sys.executable,'-S',str(HERE/'run_encoding1.py')],check=True,stdout=subprocess.DEVNULL)
a=json.loads((HERE/'results'/'ENCODING-1_RESULTS.json').read_text())
b=json.loads((HERE/'results'/'ENCODING-1_RESULTS_RERUN.json').read_text())
a.pop('results_sha256',None); b.pop('results_sha256',None)
assert a==b
assert a['scenario_count']==729
assert a['replay']=='PASS'
assert a['winner_counts_by_variable_level']['batch_size']['1']['VARINT_INBAND']==243
assert a['winner_counts_by_variable_level']['batch_size']['32']['BATCH_INBAND']==243
assert a['winner_counts_by_variable_level']['batch_size']['256']['BATCH_INBAND']==243
assert a['pairwise_vs_VARINT_INBAND']['VARINT_HANDLE']['beats_varint_count']==0
assert a['pairwise_vs_VARINT_INBAND']['BATCH_HANDLE']['beats_varint_count']==0
print('ENCODING_1_TEST_PASS')
