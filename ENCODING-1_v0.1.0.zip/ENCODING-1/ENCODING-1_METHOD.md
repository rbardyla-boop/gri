# ENCODING-1 METHOD

This experiment uses deterministic synthetic packet traffic with exactly six varied inputs:

1. packet_count
2. symbol_cardinality
3. new_symbol_rate
4. batch_size
5. session_lifetime
6. dictionary_reset_frequency

Every other generator behavior is fixed by the declarations.

For each of the 729 Cartesian-product scenarios:

1. derive a deterministic seed from the six parameters;
2. generate the semantic packet stream;
3. score all five encoding profiles;
4. charge dynamic dictionary updates;
5. charge handle mapping records;
6. enforce batch/session boundaries;
7. rerun the scenario and require exact identical accounting;
8. record all raw byte components and winners.

The human-readable conclusion is derived after the complete grid is scored.
