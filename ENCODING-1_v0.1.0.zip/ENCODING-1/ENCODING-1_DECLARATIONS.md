# ENCODING-1 — TRAFFIC REGIME CROSSOVER

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Grid SHA-256:** `3728dc811af1d514f1a371486bcb18de53f670612f87150a2af1e971e0c07995`

## Question

> Holding the C1 semantic primitive fixed, at what traffic regimes do fixed-width encoding, batching, or external handles overtake the ENCODING-0 varint in-band leader?

No cognitive field may be added.

## Fixed semantic packet

```text
STABLE_REFERENCE
ACT
SUBJECT
RELATION
OBJECT
VALUE
```

The traffic generator changes only workload shape, never packet semantics.

## Frozen variables

```text
packet_count                 = [64, 1024, 16384]
symbol_cardinality           = [32, 512, 8192]
new_symbol_rate              = [0.0, 0.05, 0.5]
batch_size                   = [1, 32, 256]
session_lifetime             = [128, 2048, 16384]
dictionary_reset_frequency   = [0, 256, 4096]
```

`dictionary_reset_frequency = 0` means no periodic reset. Session boundaries still reset protocol dictionaries.

The full Cartesian product is scored:

```text
3^6 = 729 traffic regimes
```

No regime may be added or removed after results are observed.

## Traffic semantics

Each packet has:

```text
stable_reference = monotonically increasing packet identity
ACT              = one of 8 fixed operation symbols
RELATION         = one of 16 fixed relation symbols
SUBJECT/OBJECT   = semantic symbols drawn from the declared symbol universe
VALUE            = deterministic signed scalar in [-1000,1000]
```

The generator starts with a reusable hot set of up to 8 symbols. For each SUBJECT and OBJECT position, `new_symbol_rate` is the probability of introducing the next previously unseen semantic symbol until `symbol_cardinality` is exhausted. Otherwise an already-known symbol is reused.

This is a traffic generator, not a cognitive benchmark.

## Dictionary protocol

ACT and RELATION codes are fixed protocol constants and require no dynamic dictionary.

SUBJECT/OBJECT use a session-local semantic-symbol dictionary.

When a symbol is first used after a session boundary or dictionary reset, a dictionary update must be sent before the packet that references it.

Dictionary updates are charged. They are not free shared knowledge.

A dictionary update contains:

```text
DICT_UPDATE_TAG
local_symbol_code
global_semantic_symbol_id
```

Global semantic symbol IDs are part of the frozen synthetic workload generator.

## Session behavior

At each session boundary:

```text
subject/object dictionary resets
external handle namespace resets
```

`session_lifetime` is measured in packets.

Periodic dictionary resets do not reset the handle namespace unless they coincide with a session boundary.

## Profiles

### FIXED_INBAND

Stable reference is carried in-band.

```text
stable_reference   fixed width sufficient for packet_count
ACT                u8
SUBJECT            fixed width sufficient for symbol_cardinality
RELATION           u8
OBJECT             same fixed symbol width
VALUE              i16
```

Dictionary update codes use the same fixed symbol width.

### VARINT_INBAND

Current generalized ENCODING-0 leader.

```text
stable_reference   unsigned varint
ACT                unsigned varint
SUBJECT            unsigned varint local dictionary code
RELATION           unsigned varint
OBJECT             unsigned varint local dictionary code
VALUE              ZigZag signed varint
```

Dictionary updates use varints.

### BATCH_INBAND

Same semantics and dictionary as VARINT_INBAND, batched by the frozen `batch_size`.

Within each batch:

```text
packet_count
delta-coded stable references
RLE ACT
SUBJECT varints
RLE RELATION
OBJECT varints
VALUE ZigZag varints
```

Batches never cross session boundaries.

### VARINT_HANDLE

Packet payload carries a session-local handle instead of the global stable reference.

Every newly allocated handle requires an explicit mapping:

```text
HANDLE_MAP_TAG
handle
stable_reference
```

Mapping bytes are charged.

### BATCH_HANDLE

Batched payload uses delta-coded session-local handles.

The handle mapping stream is also encoded in batch order. Mapping bytes remain charged.

## Frozen cost metric

Primary crossover metric:

```text
total transport bytes
```

Also record separately:

```text
payload bytes
dictionary update bytes
handle mapping bytes
bytes per packet
maximum buffering requirement
```

No composite score is used.

## Determinism

Each regime uses a deterministic seed derived only from its six frozen variable values.

Same regime + same profile must produce byte-identical accounting on replay.

## Validity

A run is invalid if:

```text
a frozen grid value changes
a profile omits dictionary update cost
a handle profile omits mapping cost
a batch crosses a session boundary
a non-authorized traffic variable is introduced
deterministic replay diverges
```
