# ENCODING-1 Results

**Grid SHA-256:** `3728dc811af1d514f1a371486bcb18de53f670612f87150a2af1e971e0c07995`  
**Scenarios:** 729  
**Replay:** `PASS`  

## Overall winner counts

- **FIXED_INBAND:** winner or tied-winner in 1 scenarios
- **VARINT_INBAND:** winner or tied-winner in 243 scenarios
- **BATCH_INBAND:** winner or tied-winner in 486 scenarios
- **VARINT_HANDLE:** winner or tied-winner in 0 scenarios
- **BATCH_HANDLE:** winner or tied-winner in 0 scenarios
- **Tie scenarios:** 1

## Pairwise crossover against VARINT_INBAND

- FIXED_INBAND: beats VARINT_INBAND in 0/729, ties 1, loses 728
- BATCH_INBAND: beats VARINT_INBAND in 486/729, ties 0, loses 243
- VARINT_HANDLE: beats VARINT_INBAND in 0/729, ties 0, loses 729
- BATCH_HANDLE: beats VARINT_INBAND in 0/729, ties 0, loses 729

## Interpretation

The full factorial deliberately contains repeated effective regimes: for example, batch_size does not alter non-batch profiles. Winner counts are therefore descriptive of the frozen grid, not estimates of real-world prevalence.

No new semantic field was introduced. All differences are encoding/protocol effects.
