# ENCODING-1 Conclusion

**Status:** COMPLETE WITHIN FROZEN 729-REGIME ENVELOPE  
**Replay:** PASS  
**Primitive semantics:** unchanged

## Main result

The frozen full-factorial sweep produced a sharp separation by `batch_size`.

```text
batch_size = 1
VARINT_INBAND wins all 243 regimes,
with one FIXED_INBAND tie.

batch_size = 32
BATCH_INBAND wins all 243 regimes.

batch_size = 256
BATCH_INBAND wins all 243 regimes.
```

Thus, within the preregistered grid:

> Batching overtakes ordinary in-band varints somewhere above batch size 1 and no later than batch size 32.

The exact crossover is **not identified by ENCODING-1** because intermediate batch sizes were not part of the frozen grid. No post-hoc interpolation is treated as evidence.

## Pairwise result against VARINT_INBAND

```text
FIXED_INBAND
beats: 0
 ties: 1
loses: 728

BATCH_INBAND
beats: 486
 ties: 0
loses: 243

VARINT_HANDLE
beats: 0
 ties: 0
loses: 729

BATCH_HANDLE
beats: 0
 ties: 0
loses: 729
```

The single fixed-width tie occurred at:

```text
packet_count               64
symbol_cardinality         32
new_symbol_rate            0.5
batch_size                 1
session_lifetime           128
dictionary_reset_frequency 256
```

Both `FIXED_INBAND` and `VARINT_INBAND` used 544 transport bytes there. Fixed width never strictly beat varints inside the frozen envelope.

## External handles

External handle placement did not win any tested regime.

The best observed `VARINT_HANDLE` case still used about 17% more transport than `VARINT_INBAND`; the worst observed overhead was about 63%.

This does not prove external handles are always inferior. It says that when handle-to-stable-reference synchronization is fully charged, they do not pay for themselves anywhere in this six-variable envelope.

## Variable interpretation

The other five sweep dimensions changed absolute byte cost but did not change the identity of the overall winner at a given frozen batch level:

```text
packet_count
symbol_cardinality
new_symbol_rate
session_lifetime
dictionary_reset_frequency
```

That is a useful negative result. In this envelope, batching dominates the crossover story; external handles do not create a second crossover, and fixed width does not create one either.

## Current engineering rule within tested scope

For individual or effectively unbatched packets:

```text
STABLE_REFERENCE in-band
+ shared/dynamic symbol codes
+ unsigned varints
+ ZigZag VALUE
```

For batches of at least 32 packets in the tested traffic regimes:

```text
same semantics
+ in-band stable reference
+ columnar batch encoding
+ delta-coded references
+ RLE where repeated structure exists
```

is cheaper.

## Scientific boundary

ENCODING-1 changes no cognitive primitive and makes no universal protocol claim.

A follow-up may refine only the unresolved batch crossover interval:

```text
1 < crossover_batch_size <= 32
```

without reopening packet semantics, stable-reference placement, memory architecture, or inference ontology.
