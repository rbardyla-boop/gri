from pathlib import Path
import json, hashlib, itertools, heapq, csv, os, zipfile, subprocess, sys

ROOT=Path("/mnt/data/PRIMITIVE-2K")
FIX=ROOT/"PRIMITIVE-2K_FIXTURES"
RES=ROOT/"results"
IMP=ROOT/"implementation"
RES.mkdir(exist_ok=True); IMP.mkdir(exist_ok=True)

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

freeze=json.loads((ROOT/"PRIMITIVE-2K_FREEZE.json").read_text())
for rec in freeze["files"]:
    assert sha_file(ROOT/rec["name"])==rec["sha256"],rec["name"]

grammar=json.loads((FIX/"PRIMITIVE-2J_GRAMMAR.json").read_text())
worlds=json.loads((FIX/"HYPOTHESIS_WORLDS.json").read_text())["worlds"]
pairs=json.loads((FIX/"PAIR_CASE_SUITE.json").read_text())["pair_cases"]
programs={p["program_id"]:p["code"] for p in grammar["programs"]}

def op_eval(code,a,b):
    if code==1:return a & b
    if code==2:return a | b
    if code==3:return a ^ b
    if code==4:return 1-(a ^ b)
    raise ValueError(code)

def simulate(code,roots,intervention=None):
    vals=[None]*5
    vals[0],vals[1],vals[2]=roots
    if intervention is not None and intervention[0] in (0,1,2):
        vals[intervention[0]]=intervention[1]
    p3a,p3b,op3,p4a,p4b,op4=code
    vals[3]=intervention[1] if intervention is not None and intervention[0]==3 else op_eval(op3,vals[p3a],vals[p3b])
    vals[4]=intervention[1] if intervention is not None and intervention[0]==4 else op_eval(op4,vals[p4a],vals[p4b])
    return tuple(int(x) for x in vals)

all_root_states=list(itertools.product([0,1],repeat=3))
final_options=[None]+[(v,val) for v in range(5) for val in (0,1)]

# Full behavior classes independently recomputed.
all_interventions=[(v,val) for v in range(5) for val in (0,1)]
full_sig={}
for pid,code in programs.items():
    sig=[]
    for roots in all_root_states:
        for iv in all_interventions:
            sig.extend(simulate(code,roots,iv))
    full_sig[pid]=tuple(sig)
sig_to_class={}
for pid in sorted(programs):
    sig=full_sig[pid]
    sig_to_class.setdefault(sig,len(sig_to_class))
behavior_class={pid:sig_to_class[full_sig[pid]] for pid in programs}

def passive_starts(world):
    seen=[]
    for obs in world["passive_observations"]:
        r=tuple(obs["root_assignment"])
        if r not in seen:seen.append(r)
    return seen

def prep_action_cost(world,r,val):
    return int(world["intervention_costs"][f"{r}:{val}"])

def final_cost(world,iv):
    return 0 if iv is None else int(world["intervention_costs"][f"{iv[0]}:{iv[1]}"])

def obs_cost(world,ov):
    return int(world["observation_costs"][str(ov)])

def dijkstra_preparation(world):
    starts=passive_starts(world)
    INF=10**9
    best={state:(INF,None,None) for state in all_root_states} # cost,start_idx,path
    pq=[]
    for si,s in enumerate(starts):
        candidate=(0,si,tuple())
        if candidate<best[s]:
            best[s]=candidate
            heapq.heappush(pq,(0,si,tuple(),s))
    while pq:
        cost,si,path,state=heapq.heappop(pq)
        if (cost,si,path)!=best[state]:continue
        for r in range(3):
            for val in (0,1):
                if state[r]==val:continue
                ns=list(state);ns[r]=val;ns=tuple(ns)
                action=(r,val)
                nc=cost+prep_action_cost(world,r,val)
                np=path+(action,)
                cand=(nc,si,np)
                if cand<best[ns]:
                    best[ns]=cand
                    heapq.heappush(pq,(nc,si,np,ns))
    return best

def plan_key(plan):
    iv=plan["final_intervention"]
    ivkey=(-1,-1) if iv is None else tuple(iv)
    return (
        plan["total_cost"],
        len(plan["prep_actions"]),
        plan["start_state_index"],
        tuple(plan["prepared_roots"]),
        ivkey,
        plan["observation"],
        tuple(tuple(x) for x in plan["prep_actions"]),
    )

def planner_min(world,pid_a,pid_b,prep_best):
    ca=programs[pid_a];cb=programs[pid_b]
    best=None
    for prepared,(pcost,si,path) in prep_best.items():
        for iv in final_options:
            va=simulate(ca,prepared,iv)
            vb=simulate(cb,prepared,iv)
            fc=final_cost(world,iv)
            for ov in range(5):
                if va[ov]==vb[ov]:continue
                plan={
                    "start_state_index":si,
                    "prepared_roots":list(prepared),
                    "prep_actions":[list(x) for x in path],
                    "final_intervention":None if iv is None else list(iv),
                    "observation":ov,
                    "predicted_a":va[ov],
                    "predicted_b":vb[ov],
                    "total_cost":pcost+fc+obs_cost(world,ov),
                }
                if best is None or plan_key(plan)<plan_key(best):
                    best=plan
    return best

def evaluator_bruteforce_min(world,pid_a,pid_b):
    starts=passive_starts(world)
    ca=programs[pid_a];cb=programs[pid_b]
    best=None
    for si,start in enumerate(starts):
        for prepared in all_root_states:
            # Direct root preparation is independently evaluated from the starting state.
            actions=[]
            pcost=0
            for r in range(3):
                if start[r]!=prepared[r]:
                    actions.append((r,prepared[r]))
                    pcost+=prep_action_cost(world,r,prepared[r])
            for iv in final_options:
                va=simulate(ca,prepared,iv)
                vb=simulate(cb,prepared,iv)
                fc=final_cost(world,iv)
                for ov in range(5):
                    if va[ov]==vb[ov]:continue
                    plan={
                        "start_state_index":si,
                        "prepared_roots":list(prepared),
                        "prep_actions":[list(x) for x in actions],
                        "final_intervention":None if iv is None else list(iv),
                        "observation":ov,
                        "predicted_a":va[ov],
                        "predicted_b":vb[ov],
                        "total_cost":pcost+fc+obs_cost(world,ov),
                    }
                    if best is None or plan_key(plan)<plan_key(best):
                        best=plan
    return best

def one_shot(world,pid_a,pid_b):
    starts=passive_starts(world)
    ca=programs[pid_a];cb=programs[pid_b]
    best=None
    for si,start in enumerate(starts):
        for iv in final_options:
            va=simulate(ca,start,iv);vb=simulate(cb,start,iv)
            for ov in range(5):
                if va[ov]==vb[ov]:continue
                p={
                    "start_state_index":si,"prepared_roots":list(start),"prep_actions":[],
                    "final_intervention":None if iv is None else list(iv),"observation":ov,
                    "predicted_a":va[ov],"predicted_b":vb[ov],
                    "total_cost":final_cost(world,iv)+obs_cost(world,ov),
                }
                if best is None or plan_key(p)<plan_key(best):best=p
    return best

def greedy_nearest(world,pid_a,pid_b,prep_best):
    # Pick lowest-cost prepared state before considering informativeness.
    state,(pcost,si,path)=min(prep_best.items(),key=lambda kv:(kv[1][0],kv[1][1],kv[0],kv[1][2]))
    ca=programs[pid_a];cb=programs[pid_b]
    best=None
    for iv in final_options:
        va=simulate(ca,state,iv);vb=simulate(cb,state,iv)
        for ov in range(5):
            if va[ov]==vb[ov]:continue
            p={
                "start_state_index":si,"prepared_roots":list(state),"prep_actions":[list(x) for x in path],
                "final_intervention":None if iv is None else list(iv),"observation":ov,
                "predicted_a":va[ov],"predicted_b":vb[ov],
                "total_cost":pcost+final_cost(world,iv)+obs_cost(world,ov),
            }
            if best is None or plan_key(p)<plan_key(best):best=p
    return best

def full_sweep_cost(world,pid_a,pid_b,prep_best):
    ca=programs[pid_a];cb=programs[pid_b]
    candidates=[]
    for state,(pcost,si,path) in prep_best.items():
        for iv in final_options:
            va=simulate(ca,state,iv);vb=simulate(cb,state,iv)
            for ov in range(5):
                p={
                    "start_state_index":si,"prepared_roots":list(state),"prep_actions":[list(x) for x in path],
                    "final_intervention":None if iv is None else list(iv),"observation":ov,
                    "predicted_a":va[ov],"predicted_b":vb[ov],
                    "total_cost":pcost+final_cost(world,iv)+obs_cost(world,ov),
                    "discriminating":va[ov]!=vb[ov],
                }
                candidates.append(p)
    candidates.sort(key=lambda p:plan_key(p))
    spent=0;executed=0
    for p in candidates:
        spent+=p["total_cost"];executed+=1
        if p["discriminating"]:
            q=dict(p);q["cumulative_cost"]=spent;q["executed_experiments"]=executed
            return q
    return None

world_by_id={w["world_id"]:w for w in worlds}
prep_cache={wid:dijkstra_preparation(w) for wid,w in world_by_id.items()}

pair_results=[]
all_min_match=True
one_shot_found=0
greedy_found=0
full_found=0
primary_found=0
primary_total_cost=0
full_total_cost=0
max_prep=0
j_failure_ids=set(json.loads((ROOT/"PRIMITIVE-2K_EXPERIMENT.json").read_text())["hard_controls"] and json.loads((FIX/"PAIR_CASE_SUITE.json").read_text())["j_failure_world_ids"])
j_failure_pair_total=0
j_failure_pair_found=0

# True-vs-alt execution accounting.
true_exec_total=0
true_exec_correct=0

for pc in pairs:
    w=world_by_id[pc["world_id"]]
    a=pc["program_a"];b=pc["program_b"]
    primary=planner_min(w,a,b,prep_cache[w["world_id"]])
    oracle=evaluator_bruteforce_min(w,a,b)
    one=one_shot(w,a,b)
    greedy=greedy_nearest(w,a,b,prep_cache[w["world_id"]])
    full=full_sweep_cost(w,a,b,prep_cache[w["world_id"]])

    if one is not None:one_shot_found+=1
    if greedy is not None:greedy_found+=1
    if full is not None:
        full_found+=1;full_total_cost+=full["cumulative_cost"]
    if primary is not None:
        primary_found+=1
        primary_total_cost+=primary["total_cost"]
        max_prep=max(max_prep,len(primary["prep_actions"]))

    min_match=(primary is not None and oracle is not None and plan_key(primary)==plan_key(oracle))
    all_min_match &= min_match

    if w["world_id"] in j_failure_ids:
        j_failure_pair_total+=1
        if primary is not None:j_failure_pair_found+=1

    # Execute against hidden true world only when the pair includes the true behavior class.
    true_pid=w["hidden_true_program_id"]
    true_class=behavior_class[true_pid]
    ca=behavior_class[a];cb=behavior_class[b]
    execution=None
    if true_class in (ca,cb):
        true_exec_total+=1
        if primary is None:
            execution={"executed":False,"correct":False}
        else:
            prepared=tuple(primary["prepared_roots"])
            iv=None if primary["final_intervention"] is None else tuple(primary["final_intervention"])
            obs=primary["observation"]
            actual=simulate(programs[true_pid],prepared,iv)[obs]
            matches=[]
            if primary["predicted_a"]==actual:matches.append("A")
            if primary["predicted_b"]==actual:matches.append("B")
            predicted_true="A" if ca==true_class else "B"
            correct=(matches==[predicted_true])
            true_exec_correct+=int(correct)
            execution={
                "executed":True,"actual_observation":actual,"matching_hypotheses":matches,
                "expected_true_side":predicted_true,"correct":correct
            }

    pair_results.append({
        "pair_case_id":pc["pair_case_id"],"world_id":w["world_id"],"program_a":a,"program_b":b,
        "one_shot_found":one is not None,
        "greedy_found":greedy is not None,
        "primary_plan":primary,
        "oracle_plan":oracle,
        "minimum_plan_exact_match":min_match,
        "full_sweep_cumulative_cost":None if full is None else full["cumulative_cost"],
        "true_environment_execution":execution,
    })

assert true_exec_total==746

# World-level pairwise reachability under primary.
world_reach={}
for wid in world_by_id:
    rows=[x for x in pair_results if x["world_id"]==wid]
    world_reach[wid]=all(x["primary_plan"] is not None for x in rows)

j_failure_worlds_all_repaired=all(world_reach[wid] for wid in j_failure_ids)

if (
    primary_found==2125 and
    j_failure_worlds_all_repaired and
    true_exec_correct==746 and
    all_min_match
):
    terminal="MULTISTEP_REACHABILITY_DEMONSTRATED_WITHIN_TESTED_SCOPE"
elif primary_found>one_shot_found:
    terminal="PARTIAL"
else:
    terminal="MULTISTEP_REACHABILITY_INSUFFICIENT"

summary={
    "ONE_SHOT_J_BASELINE":{
        "pair_plan_found_count":one_shot_found,
        "pair_plan_found_rate":one_shot_found/2125,
    },
    "GREEDY_NEAREST_PREP":{
        "pair_plan_found_count":greedy_found,
        "pair_plan_found_rate":greedy_found/2125,
    },
    "FULL_REACHABILITY_SWEEP":{
        "pair_plan_found_count":full_found,
        "pair_plan_found_rate":full_found/2125,
        "total_cumulative_cost":full_total_cost,
    },
    "MIN_COST_REACHABLE_DISCRIMINATION":{
        "pair_plan_found_count":primary_found,
        "pair_plan_found_rate":primary_found/2125,
        "total_cost":primary_total_cost,
        "max_prep_actions":max_prep,
        "min_cost_exact_all_pairs":all_min_match,
        "j_failure_pair_repair":f"{j_failure_pair_found}/{j_failure_pair_total}",
        "j_failure_worlds_fully_repaired":j_failure_worlds_all_repaired,
        "true_vs_alternative_executions":true_exec_total,
        "true_vs_alternative_correct":true_exec_correct,
        "true_vs_alternative_accuracy":true_exec_correct/true_exec_total,
    }
}

results={
    "experiment":"PRIMITIVE-2K","version":"0.1.0","freeze_sha256":freeze["freeze_sha256"],
    "terminal_verdict":terminal,
    "pair_case_count":len(pair_results),
    "world_count":len(world_by_id),
    "planner_summary":summary,
    "world_pairwise_reachability":{str(k):v for k,v in world_reach.items()},
    "pair_results":pair_results,
}
results["results_sha256"]=hashlib.sha256(canon(results).encode()).hexdigest()
(RES/"PRIMITIVE-2K_RESULTS.json").write_text(json.dumps(results,indent=2))

print("PRIMITIVE-2K scored")
print("terminal:",terminal)
print(json.dumps(summary,indent=2))