#!/usr/bin/env python3
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/"results"/"PRIMITIVE-2K_RESULTS.json").read_text())
rp=json.loads((ROOT/"results"/"PRIMITIVE-2K_REPLAY_CHECK.json").read_text())
s=r["planner_summary"]["MIN_COST_REACHABLE_DISCRIMINATION"]
assert r["terminal_verdict"]=="MULTISTEP_REACHABILITY_DEMONSTRATED_WITHIN_TESTED_SCOPE"
assert r["pair_case_count"]==2125
assert s["pair_plan_found_count"]==2125
assert s["j_failure_pair_repair"]=="158/158"
assert s["j_failure_worlds_fully_repaired"] is True
assert s["true_vs_alternative_executions"]==746
assert s["true_vs_alternative_correct"]==746
assert s["min_cost_exact_all_pairs"] is True
assert s["max_prep_actions"]==1
assert rp["exact_byte_replay"]=="PASS"
print("PRIMITIVE_2K_TEST_PASS")
