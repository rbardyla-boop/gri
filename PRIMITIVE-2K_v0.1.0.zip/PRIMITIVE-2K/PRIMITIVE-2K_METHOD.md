# PRIMITIVE-2K METHOD

1. Preserve the 192 frozen PRIMITIVE-2J worlds and every BEHAVIORAL_FRONTIER hypothesis.
2. Form all 2,125 unordered hypothesis pairs, rather than testing only the ten J failure worlds.
3. Let a plan begin from any already observed passive root state at zero cost.
4. Permit persistent preparation only on root variables 0, 1 and 2.
5. After preparation, permit one optional final intervention on any variable and one observation.
6. Charge every preparation action, final intervention and observation using the frozen J costs.
7. Primary planner: multi-source Dijkstra over the eight reachable root states, followed by exhaustive final intervention/observation comparison.
8. Independent evaluator: brute-force every start state, prepared root assignment, optional final intervention and observation.
9. Require the planner's canonical minimum-cost plan to match the evaluator for all 2,125 pairs.
10. For every frontier pair containing the hidden true behavior class, execute the chosen plan against the hidden causal program and require the purchased observation to identify the true side uniquely.
11. Re-run the exact scorer and require byte-identical result JSON.

PRIMITIVE-2K does not change hypothesis generation. It isolates experimental reachability.
