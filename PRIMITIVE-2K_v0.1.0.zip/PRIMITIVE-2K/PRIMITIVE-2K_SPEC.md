# PRIMITIVE-2K — MULTI-STEP EXPERIMENTAL REACHABILITY

**Version:** 0.1.0  
**Status:** FROZEN BEFORE SCORING  
**Experiment SHA-256:** `c9289cec5c045f6867db4eea88a4a54edcd5a20a4f257a373e121bcde873a2bd`  
**Pair-suite SHA-256:** `609302254260ef037d7a7431adea5b2cd630e6309de3c86d72a29b46b1cc9c1e`

## Question

> Given surviving hypotheses that cannot always be distinguished from the currently available state with a single intervention, can the machine construct the minimum-cost state-preparation sequence needed to make a discriminating experiment reachable?

## Parent result

PRIMITIVE-2J retained the hidden true behavior class in all 192 worlds, but only 182/192 worlds had immediate pairwise distinguishability under its one-shot reachability gate.

The ten failure worlds remain frozen.

## State preparation

A plan is:

```text
choose an already observed passive root state
→ zero or more persistent SET_ROOT actions
→ optional final do(variable=value)
→ observe one variable
```

Only roots `0,1,2` may be used for persistent state preparation.

Derived variables are recomputed after preparation under each candidate hypothesis.

## Why this is not a benchmark patch

PRIMITIVE-2K scores:

```text
all 192 worlds
all 2,125 frontier-hypothesis pairs
```

not only the ten J failure worlds.

For every pair, the experiment independently computes the global minimum-cost reachable discriminating plan.

## Reality execution

For every true-vs-alternative frontier pair, the minimum-cost plan is executed against the hidden true world.

The purchased observation must uniquely identify the hidden true behavior.

## Strict pass

```text
2,125/2,125 pairs have a reachable discriminating plan
all ten J failure worlds become fully pairwise reachable
746/746 true-vs-alternative executions identify truth correctly
0 abstentions
exact minimum cost for every pair
deterministic replay
```
