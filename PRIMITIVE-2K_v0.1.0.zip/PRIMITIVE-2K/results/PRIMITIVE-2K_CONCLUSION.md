# PRIMITIVE-2K Conclusion

**Terminal verdict:** `MULTISTEP_REACHABILITY_DEMONSTRATED_WITHIN_TESTED_SCOPE`

## Result

The minimum-cost reachability planner achieved:

```text
pairwise plans found:                 2125/2125
J failure pairs repaired:             158/158
J failure worlds fully repaired:      True
true-vs-alternative executions:       746/746
minimum-cost match:                   True
deterministic replay:                 PASS
```

The one-shot J baseline could distinguish only:

```text
2110/2125
```

pairs.

Exactly 15 pairwise failures therefore required additional reachability.

## How much planning was actually required?

The optimal plans used:

```text
0 preparation actions: 2088
1 preparation action:  37
2+ preparation actions:0
```

Only 15 pairs strictly required state preparation to become experimentally reachable.

A further 22 pairs were already one-shot reachable, but one preparation action produced a cheaper total experiment.

So the strongest bounded interpretation is:

> The PRIMITIVE-2J reachability failures were repaired by two-stage experimentation: one persistent state-preparation action followed by a final discriminating test.

PRIMITIVE-2K does not demonstrate arbitrary long-horizon experimental planning.

## Cost

```text
MIN_COST total cost:      14150
FULL_SWEEP cumulative:    856621
```

The exhaustive sweep was therefore about 60.5× as expensive.

## Scientific implication

PRIMITIVE-2J exposed:

```text
hypotheses differ
≠
the difference is testable from here
```

PRIMITIVE-2K adds:

```text
not testable from here
        ↓
reason about reachable states
        ↓
prepare a discriminating state
        ↓
run the experiment
```

Within this tested grammar, reachability is therefore an explicit part of experimental intelligence.

## Largest remaining gap

The hidden causal programs were still drawn from a fixed grammar, and the world was deterministic and fully controllable.

The next scientifically different question is whether the machine can **learn or extend its causal hypothesis language when the true mechanism is not representable in the current grammar**, rather than merely searching and experimenting inside a closed model class.
