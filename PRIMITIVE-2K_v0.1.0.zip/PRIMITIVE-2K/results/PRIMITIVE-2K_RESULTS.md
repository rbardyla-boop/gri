# PRIMITIVE-2K Results

**Terminal verdict:** `MULTISTEP_REACHABILITY_DEMONSTRATED_WITHIN_TESTED_SCOPE`  
**Exact deterministic replay:** `PASS`  

| Planner | Pair plans found | Pair reachability | Total cost |
|---|---:|---:|---:|
| ONE_SHOT_J_BASELINE | 2110/2125 | 0.992941 | n/a |
| GREEDY_NEAREST_PREP | 1794/2125 | 0.844235 | n/a |
| FULL_REACHABILITY_SWEEP | 2125/2125 | 1.000000 | 856621 |
| **MIN_COST_REACHABLE_DISCRIMINATION** | **2125/2125** | **1.000000** | **14150** |

## Primary planner

- J failure pairs repaired: `158/158`
- J failure worlds fully pairwise reachable: `True`
- True-vs-alternative executions: `746/746`
- Exact minimum-cost match on every pair: `True`
- Optimal plans with 0 prep actions: `2088`
- Optimal plans with 1 prep action: `37`
- Optimal plans with ≥2 prep actions: `0`
- Pairs where prep was strictly required for reachability: `15`
- Primary plan cost min/median/max: `2/7/21`
